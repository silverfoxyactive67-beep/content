import {
    EntityInitializationCause,
    EntityInventoryComponent,
    ItemStack,
    system,
    world,
} from "@minecraft/server";
import { OnDie } from "./src/events/OnDie";
import { OnHit } from "./src/events/OnHit";
import { OnInteract } from "./src/events/OnInteract";
import { OnScriptEvent } from "./src/events/ScriptEvent";
import { OnPlayerSpawn } from "./src/events/OnPlayerSpawn";
import {
    GRAVESTONE_LEVELS,
    GRAVESTONE_SKINS,
    GRAVESTONE_XP,
    LAST_DEATH_DIMENSION,
    LAST_DEATH_SCORE_NAMES,
} from "./src/utils/utils";
import { OnUseItem } from "./src/events/OnUseItem";

if (world.scoreboard.getObjective(GRAVESTONE_LEVELS) == undefined) {
    world.scoreboard.addObjective(GRAVESTONE_LEVELS, `gravestone_levels`);
}
if (world.scoreboard.getObjective(GRAVESTONE_SKINS) == undefined) {
    world.scoreboard.addObjective(GRAVESTONE_SKINS, `gravestone_skins`);
}
if (world.scoreboard.getObjective(GRAVESTONE_XP) == undefined) {
    world.scoreboard.addObjective(GRAVESTONE_XP, `gravestone_xp`);
}

if (world.scoreboard.getObjective(LAST_DEATH_SCORE_NAMES.x) == undefined) {
    world.scoreboard.addObjective(LAST_DEATH_SCORE_NAMES.x, `last_death_vec_x`);
    world.scoreboard.addObjective(LAST_DEATH_SCORE_NAMES.y, `last_death_vec_y`);
    world.scoreboard.addObjective(LAST_DEATH_SCORE_NAMES.z, `last_death_vec_z`);
}
if (world.scoreboard.getObjective(LAST_DEATH_DIMENSION) == undefined) {
    world.scoreboard.addObjective(LAST_DEATH_DIMENSION, `last_death_dimension`);
}

if (!world.scoreboard.getObjective("boxbuild_gravestones:first_join")) {
    world.scoreboard.addObjective(
        "boxbuild_gravestones:first_join",
        "boxbuild_gravestones:first_join"
    );
}

world.afterEvents.entityDie.subscribe(OnDie);
world.afterEvents.entityHitEntity.subscribe(OnHit);
world.afterEvents.dataDrivenEntityTrigger.subscribe(OnInteract);
system.afterEvents.scriptEventReceive.subscribe(OnScriptEvent);
world.afterEvents.playerSpawn.subscribe(OnPlayerSpawn);
world.afterEvents.itemUse.subscribe(OnUseItem);

world.afterEvents.entitySpawn.subscribe((ev) => {
    if (ev.entity.typeId === "boxbuild_gravestones:gravestone") {
        const items = ev.entity.dimension.getEntities({
            type: "minecraft:item",
            location: ev.entity.location,
            maxDistance: 3,
        });

        for (const item of items) {
            if (!ev.entity.isValid()) continue;

            const grave_inv = ev.entity.getComponent("inventory");
            const item_stack = item.getComponent("minecraft:item").itemStack;
            grave_inv.container.addItem(item_stack);
            item.remove();
        }
    }
});
