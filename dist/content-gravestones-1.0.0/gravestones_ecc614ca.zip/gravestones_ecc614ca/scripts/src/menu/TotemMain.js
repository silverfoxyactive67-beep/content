import {
    EntityInventoryComponent,
    ItemStack,
    ItemType,
    Player,
    world,
} from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";
import { GRAVESTONE_LEVELS } from "../utils/utils";
import { GraveData } from "../classes/GraveData";
import { Skins_Menu } from "./SkinsMenu";
import { config } from "../../config.boxbuild";

const next_upgrade_text = [""];

/**
 *
 * @param {Player} player
 */
export const TotemMain_Menu = (player) => {
    const score = world.scoreboard.getObjective(GRAVESTONE_LEVELS);
    const level = score.getScore(player);

    const menu = new ActionFormData()
        .title("Gravestone Totem")
        .body(
            `Your gravestone level: ${level}${
                level == config.max_gravestone_level ? " §d(MAX)§r" : ""
            } \nUse this to upgrade your gravestone`
        )
        .button("Upgrade", "textures/boxbuild/gravestones/icons/upgrade")
        .button("Skins", "textures/boxbuild/gravestones/icons/skins")
        .button("Teleport", "textures/boxbuild/gravestones/icons/teleport")
        .show(player)
        .then((result) => {
            if (result.canceled) return;
            switch (result.selection) {
                case 0:
                    Upgrades_Menu(player);
                    break;
                case 1:
                    Skins_Menu(player);
                    break;
                case 2:
                    Teleport_Menu(player);
                    break;

                default:
                    break;
            }
            player.runCommandAsync(
                `playsound boxbuild_gravestones.ui_button_press @s ~ ~ ~ 1 ${
                    Math.random() * (1 - 0.5) + 0.5
                }`
            );
        });
};

const Upgrades_Menu = (player) => {
    const score = world.scoreboard.getObjective(GRAVESTONE_LEVELS);
    const level = score.getScore(player);

    const menu = new ActionFormData()
        .title("Gravestone Totem | Upgrades")
        .body(
            `Gravestone level: ${level}${
                level == config.max_gravestone_level ? " §d(MAX)§r" : ""
            }`
        )
        .button("Return", "textures/boxbuild/gravestones/icons/return")
        .button(
            `Upgrade!\n${
                level < config.max_gravestone_level
                    ? "§a10 xp levels"
                    : "§d(MAX)"
            }`,
            "textures/boxbuild/gravestones/icons/real_upgrade"
        )
        .show(player)
        .then((result) => {
            if (result.canceled) return;
            switch (result.selection) {
                case 0:
                    TotemMain_Menu(player);
                    player.runCommandAsync(
                        `playsound boxbuild_gravestones.ui_button_press @s ~ ~ ~ 1 ${
                            Math.random() * (1 - 0.5) + 0.5
                        }`
                    );
                    break;
                case 1:
                    const gravedata = new GraveData(player);
                    gravedata.upgrade(1);
                    break;

                default:
                    break;
            }
        });
};

/**
 *
 * @param {Player} player
 */
const Teleport_Menu = (player) => {
    const score = world.scoreboard.getObjective(GRAVESTONE_LEVELS);
    const level = score.getScore(player);

    const menu = new ActionFormData()
        .title("Gravestone Totem | Teleport")
        .body(`This teleports you to your last death position.`)
        .button("Return", "textures/boxbuild/gravestones/icons/return")
        .button(
            "Teleport key\n§l§a10 xp levels",
            "textures/boxbuild/gravestones/icons/teleport_key"
        )
        .show(player)
        .then((result) => {
            if (result.canceled) return;
            switch (result.selection) {
                case 0:
                    TotemMain_Menu(player);
                    player.runCommandAsync(
                        `playsound boxbuild_gravestones.ui_button_press @s ~ ~ ~ 1 ${
                            Math.random() * (1 - 0.5) + 0.5
                        }`
                    );
                    break;
                case 1:
                    player.runCommandAsync(`xp -10L @s[lm=10]`).then((cm) => {
                        if (cm.successCount != 1) {
                            player.sendMessage({
                                translate:
                                    "boxbuild_gravestones.messages.not_enough_xp",
                            });
                            return;
                        }

                        const graveto = new GraveData(player);

                        graveto.effects.UpgradeSound();
                        player.runCommandAsync(
                            `playanimation @e[type=boxbuild_gravestones:gravestone_totem,c=1,r=16] animation.boxbuild_gravestones.gravestone_totem.upgrade a 1`
                        );

                        player.sendMessage({
                            translate:
                                "boxbuild_gravestones.message.key_obtained",
                        });

                        player.runCommandAsync(
                            `structure load boxbuild_gravestones:lastkey ~ ~1 ~`
                        );
                        player.runCommandAsync(
                            `playsound boxbuild_gravestones.ui_button_press @s ~ ~ ~`
                        );
                    });
                    break;

                default:
                    break;
            }
        });
};
