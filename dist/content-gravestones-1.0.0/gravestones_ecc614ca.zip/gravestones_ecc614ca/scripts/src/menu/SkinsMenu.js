import { world } from "@minecraft/server";
import { GraveData } from "../classes/GraveData";
import { TotemMain_Menu } from "./TotemMain";
import { GRAVESTONE_LEVELS, GRAVESTONE_SKINS } from "../utils/utils";
import { ActionFormData } from "@minecraft/server-ui";

const skins_icons = [
    "textures/boxbuild/gravestones/icons/skins/default",
    "textures/boxbuild/gravestones/icons/skins/skin_1",
    "textures/boxbuild/gravestones/icons/skins",
    "textures/boxbuild/gravestones/icons/skins/skin_3",
    "textures/boxbuild/gravestones/icons/skins/skin_4",
    "textures/boxbuild/gravestones/icons/skins/skin_5",
    "textures/boxbuild/gravestones/icons/skins/skin_6",
    "textures/boxbuild/gravestones/icons/skins/skin_7",
];

const skin_names = [
    "Default",
    "Skin 1",
    "Skin 2",
    "Skin 3",
    "Skin 4",
    "Skin 5",
    "Skin 6",
    "Skin 7",
];

export const Skins_Menu = (player) => {
    const score = world.scoreboard.getObjective(GRAVESTONE_LEVELS);
    const level = score.getScore(player);
    const skinscore = world.scoreboard.getObjective(GRAVESTONE_SKINS);
    const skinid = skinscore.getScore(player);

    const menu = new ActionFormData()
        .title("Gravestone Totem | Skins")
        .body(
            `Gravestone level: ${level} \nUpgrade your gravestone to get more skins`
        )
        .button("Return", "textures/boxbuild/gravestones/icons/return");

    for (let i = 0; i < 8; i++) {
        if (i < level * 2) {
            menu.button(
                `§l${skin_names[i]}§r\n${
                    i == skinid ? "§5§l<< selected >>§r" : ""
                }`,
                skins_icons[i]
            );
            continue;
        }

        menu.button(
            `§l---\n[LOCKED]`,
            "textures/boxbuild/gravestones/icons/locked"
        );
    }

    menu.show(player).then((result) => {
        if (result.canceled) return;

        if (result.selection == 0) {
            TotemMain_Menu(player);
            player.runCommandAsync(
                `playsound boxbuild_gravestones.ui_button_press @s ~ ~ ~ 1 ${
                    Math.random() * (1 - 0.5) + 0.5
                }`
            );
            return;
        }

        if (result.selection > level * 2) return;

        skinscore.setScore(player, result.selection - 1);
        player.runCommandAsync(
            `playsound boxbuild_gravestones.ui_button_press @s ~ ~ ~ 1 ${
                Math.random() * (1 - 0.5) + 0.5
            }`
        );
        player.runCommandAsync(
            `playanimation @e[type=boxbuild_gravestones:gravestone_totem,c=1,r=16] animation.boxbuild_gravestones.gravestone_totem.upgrade a 1`
        );
        Skins_Menu(player);
    });
};
