import {
    EntityDieAfterEvent,
    EntityInventoryComponent,
    EntityScaleComponent,
    EntitySkinIdComponent,
    Player,
    system,
    world,
} from "@minecraft/server";
import { EffectManager } from "../classes/EffectManager";
import { GraveData } from "../classes/GraveData";
import { GRAVESTONE_XP } from "../utils/utils";

const GRAVE_TYPEID = "boxbuild_gravestones:gravestone";

/**
 *
 * @param {EntityDieAfterEvent} event
 */
export const OnDie = (event) => {
    /** @type {Player} */
    const player = event.deadEntity;

    if (player.typeId != "minecraft:player") return;

    const grave_data = new GraveData(player);

    /** @type {EntityInventoryComponent} */
    const player_inv = player.getComponent("inventory");

    player.runCommandAsync(`fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 stone replace lava`);
    player.runCommandAsync(
        `fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 stone replace flowing_lava`
    );
    player.runCommandAsync(`fill ~-1 ~-1 ~-1 ~1 ~2 ~1 air replace lava`);
    player.runCommandAsync(
        `fill ~-1 ~-1 ~-1 ~1 ~2 ~1 air replace flowing_lava`
    );

    const grave = player.dimension.spawnEntity(GRAVE_TYPEID, {
        x: player.location.x,
        y: player.location.y,
        z: player.location.z,
    });
    grave.teleport(
        {
            x: player.location.x,
            y: player.location.y,
            z: player.location.z,
        },
        {
            rotation: player.getRotation(),
        }
    );
    grave.nameTag = `${player.nameTag}'s gravestone`;
    grave.setRotation(player.getRotation());
    grave.addTag(`owner:${player.nameTag.toLowerCase()}`);
    grave.triggerEvent(`upgrades:level_${grave_data.getLevel()}`);
    const xpstorage = world.scoreboard.getObjective(GRAVESTONE_XP);
    xpstorage.setScore(grave, 0);

    player.runCommandAsync(`xp 0L @s[lm=10,l=20]`).then((sd) => {
        if (sd.successCount != 1) return;
        xpstorage.setScore(grave, 10);
    });
    player.runCommandAsync(`xp 0L @s[lm=20,l=30]`).then((sd) => {
        if (sd.successCount != 1) return;
        xpstorage.setScore(grave, 20);
    });
    player.runCommandAsync(`xp 0L @s[lm=30]`).then((sd) => {
        if (sd.successCount != 1) return;
        xpstorage.setScore(grave, 30);
    });

    /** @type {EntitySkinIdComponent} */
    const skinid = grave.getComponent("skin_id");
    skinid.value = grave_data.getGravestoneSkinID();

    grave_data.effects.GravestonSpawnedVisualEffect(grave);
    player.addTag("recently_death");
    grave_data.lastDeath.setLastDeath(player.location);
};
