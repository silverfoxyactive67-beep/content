import { ScriptEventCommandMessageAfterEvent } from "@minecraft/server";
import { TotemMain_Menu } from "../menu/TotemMain";

/**
 *
 * @param {ScriptEventCommandMessageAfterEvent} event
 */
const ShowTotemMenu = (event) => {
    TotemMain_Menu(event.sourceEntity);
};

const events = {
    "boxbuild_gravestones:show_totem_menu": ShowTotemMenu,
};

/**
 *
 * @param {ScriptEventCommandMessageAfterEvent} event
 */
export const OnScriptEvent = (event) => {
    if (!events.hasOwnProperty(event.id)) return;
    events[event.id](event);
};
