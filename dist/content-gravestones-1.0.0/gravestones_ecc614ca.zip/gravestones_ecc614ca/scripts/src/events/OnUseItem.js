import { EntityInventoryComponent, ItemUseAfterEvent } from "@minecraft/server";
import { GraveData } from "../classes/GraveData";

function calculateDistance(pos1, pos2) {
    // Descomponemos los vectores en sus componentes x, y, z
    const dx = pos2.x - pos1.x;
    const dy = pos2.y - pos1.y;
    const dz = pos2.z - pos1.z;

    // Aplicamos la fórmula de la distancia euclidiana
    const distancia = Math.sqrt(dx * dx + dy * dy + dz * dz);

    return distancia;
}

/**
 *
 * @param {ItemUseAfterEvent} event
 */
export const OnUseItem = (event) => {
    if (event.source.typeId != "minecraft:player") return;
    if (!Actions.hasOwnProperty(event.itemStack.typeId)) return;
    Actions[event.itemStack.typeId](event);
};

/**
 * @description when the player uses the gravestone key item.
 * @param {ItemUseAfterEvent} event
 */
const OnUseKey = (event) => {
    const player = event.source;
    const key = event.itemStack;

    const gdata = new GraveData(player);

    if (gdata.lastDeath.getDimension() != player.dimension.id) {
        player.sendMessage({
            translate: "boxbuild_gravestones.message.invalid_dimension",
        });
        player.runCommandAsync(
            `playsound boxbuild_gravestones.key_use @a ~ ~ ~ 1 0.3`
        );
        return;
    }

    player.teleport({
        x: gdata.lastDeath.getPosition().x,
        y: gdata.lastDeath.getPosition().y,
        z: gdata.lastDeath.getPosition().z,
    });

    player.runCommandAsync(`playsound boxbuild_gravestones.key_use @a ~ ~ ~`);
    player.runCommandAsync(`clear @s boxbuild_gravestones:gravestone_key 0 1`);
};

const OnUseTracker = (event) => {
    const player = event.source;
    const tracker = event.itemStack;
    const gdata = new GraveData(player);

    player.runCommandAsync(
        `particle boxbuild_gravestones:white_line ${
            gdata.lastDeath.getPosition().x
        } ${gdata.lastDeath.getPosition().y} ${gdata.lastDeath.getPosition().z}`
    );
    //player.runCommandAsync(`summon lightning_bolt ${gdata.lastDeath.getPosition().x} ${gdata.lastDeath.getPosition().y} ${gdata.lastDeath.getPosition().z}`);
    player.sendMessage(
        `§d[Distance] §a○ §6${Math.round(
            calculateDistance(player.location, gdata.lastDeath.getPosition())
        )}`
    );
};

const Actions = {
    "boxbuild_gravestones:gravestone_key": OnUseKey,
    "boxbuild_gravestones:gravestone_tracker": OnUseTracker,
};
