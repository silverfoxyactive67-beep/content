import {
    DataDrivenEntityTriggerAfterEvent,
    EntitySkinIdComponent,
    world,
} from "@minecraft/server";

const allowedPages = ["page:next", "page:prev"];

/**
 *
 * @param {DataDrivenEntityTriggerAfterEvent} event
 */
export const OnInteract = (event) => {
    if (
        event.eventId == "interaction:click" &&
        event.entity.typeId == "boxbuild_gravestones:gravestone_totem"
    ) {
        event.entity.runCommandAsync(
            `execute as @p[r=16,c=1] at @p[r=16,c=1] run scriptevent boxbuild_gravestones:show_totem_menu`
        );
    }

    if (event.entity.typeId == "boxbuild_gravestones:guide_book") {
        if (!allowedPages.includes(event.eventId)) return;
        event.entity.runCommandAsync(
            `playsound boxbuild_gravestones.book_page @a ~ ~ ~ 1 ${
                Math.random() * (1 - 0.5) + 0.5
            }`
        );
        /** @type {EntitySkinIdComponent} */
        const skinid = event.entity.getComponent("skin_id");
        if (event.eventId == "page:next") {
            if (skinid.value < 5) {
                skinid.value = skinid.value + 1;
            } else {
                skinid.value = 0;
            }
        } else if (event.eventId == "page:prev") {
            if (skinid.value > 0) {
                skinid.value = skinid.value - 1;
            } else {
                skinid.value = 5;
            }
        }
    }
};
