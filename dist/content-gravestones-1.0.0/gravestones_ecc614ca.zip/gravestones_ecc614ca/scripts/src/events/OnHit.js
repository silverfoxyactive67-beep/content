import {
    Entity,
    EntityHealthComponent,
    EntityHitEntityAfterEvent,
    EntityInventoryComponent,
    EntityVariantComponent,
    world,
} from "@minecraft/server";
import { TotemMain_Menu } from "../menu/TotemMain";
import { GRAVESTONE_XP } from "../utils/utils";
import { GraveData } from "../classes/GraveData";

/**
 *
 * @param {EntityHitEntityAfterEvent} event
 */
export const OnHit = (event) => {
    //OnHitTotem(event);
    OnHitGravestone(event);
};

const OnHitGravestone = (event) => {
    if (event.hitEntity.typeId != "boxbuild_gravestones:gravestone") return;

    const owner = event.damagingEntity;
    if (owner.typeId != "minecraft:player") return;

    /** @type {Entity} */
    const me = event.hitEntity;
    /** @type {EntityVariantComponent} */
    const variant = me.getComponent("variant");
    /** @type {EntityInventoryComponent} */
    const grave_inv = event.hitEntity.getComponent("inventory");

    if (
        !me.hasTag(`owner:${owner.nameTag.toLowerCase()}`) &&
        variant.value < 1
    ) {
        /** @type {EntityHealthComponent} */
        const health = me.getComponent("health");
        health.resetToDefaultValue();
        //me.runCommandAsync(`say ${health.currentValue}`);
        return;
    }

    const xpget = world.scoreboard.getObjective(GRAVESTONE_XP);
    const saved = xpget.hasParticipant(me) ? xpget.getScore(me) : 0;
    owner.runCommandAsync(`xp ${saved}L @s`);
    owner.runCommandAsync(`clear @s boxbuild_gravestones:gravestone_tracker`);
    owner.runCommandAsync(`clear @s boxbuild_gravestones:phantom_sword`);
    me.runCommandAsync(`kill @s`);
    xpget.setScore(me, 0);
};

const OnHitTotem = (event) => {
    if (event.hitEntity.typeId != "boxbuild_gravestones:gravestone_totem")
        return;

    const owner = event.damagingEntity;
    if (owner.typeId != "minecraft:player") return;
    TotemMain_Menu(owner);
};
