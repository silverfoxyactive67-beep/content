import {
    PlayerJoinAfterEvent,
    PlayerSpawnAfterEvent,
    world,
} from "@minecraft/server";
import { GRAVESTONE_LEVELS } from "../utils/utils";
import { GraveData } from "../classes/GraveData";

/**
 *
 * @param {PlayerSpawnAfterEvent} event
 */
export const OnPlayerSpawn = (event) => {
    if (event.initialSpawn) {
        event.player
            .runCommandAsync(
                `testfor @s[scores={boxbuild_gravestones:first_join=1..}]`
            )
            .then((cmd) => {
                if (cmd.successCount > 0) return;

                event.player.sendMessage({
                    rawtext: [
                        { text: `§8§lGravestones§r §d»§r ` },
                        {
                            translate:
                                "boxbuild_gravestones.message.addon_welcome",
                        },
                    ],
                });
                event.player.runCommandAsync(
                    `structure load boxbuild_gravestones:guide ~ ~1 ~`
                );
                event.player.runCommandAsync(
                    `scoreboard players set @s "boxbuild_gravestones:first_join" 1`
                );
            });
    }
    //const player = event.player;
    const gdata = new GraveData(event.player);
    gdata.levelsNotCreatedYet();
    gdata.skinIDNotCreatedYet();
    gdata.lastDeathNotCreatedYet();

    if (!event.player.hasTag("recently_death")) return;
    gdata.effects.byLevelSpawn(gdata.getLevel());
    event.player.removeTag("recently_death");
};
