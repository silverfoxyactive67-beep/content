import { Player } from "@minecraft/server";

export const messages = {
    have_max_level: `boxbuild_gravestones.messages.already_have_max_level`,
};
