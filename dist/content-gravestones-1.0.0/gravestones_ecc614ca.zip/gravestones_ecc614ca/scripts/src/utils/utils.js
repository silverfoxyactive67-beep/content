export const GRAVESTONE_LEVELS = "boxbuild_gravestones:gravestone_level";
export const GRAVESTONE_SKINS = "boxbuild_gravestones:gravestone_skin";
export const GRAVESTONE_XP = "boxbuild_gravestones:gravestone_xp";

// VECTOR3
export const LAST_DEATH_SCORE_NAMES = {
    x: "boxbuild_gravestones:last_death_vec_x",
    y: "boxbuild_gravestones:last_death_vec_y",
    z: "boxbuild_gravestones:last_death_vec_z",
};

export const LAST_DEATH_DIMENSION =
    "boxbuild_gravestones:last_death_dimension";
