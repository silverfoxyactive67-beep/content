import { Entity, Player, system, world } from "@minecraft/server";
import { GRAVESTONE_LEVELS, GRAVESTONE_SKINS } from "../utils/utils";
import { config } from "../../config.boxbuild";
import { messages } from "../utils/Message";
import { EffectManager } from "./EffectManager";
import { LastDeath } from "./LastDeath";

export class GraveData {
    constructor(player) {
        /** @type {Player} */
        this.player = player;
        this.max_level = config.max_gravestone_level;
        this.level_score = world.scoreboard.getObjective(GRAVESTONE_LEVELS);
        this.skin_score = world.scoreboard.getObjective(GRAVESTONE_SKINS);
        this.effects = new EffectManager(this.player);
        this.lastDeath = new LastDeath(this.player);
    }

    /**
     * @description returns the player gravestone level
     * @returns {number | undefined}
     */
    getLevel() {
        return this.level_score.getScore(this.player);
    }

    getGravestoneSkinID() {
        return this.skin_score.getScore(this.player);
    }

    /**
     * @description upgrade the player gravestone level
     * @param {number} levels
     * @param {Entity} grave
     */
    upgrade(levels) {
        if (this.getLevel() >= this.max_level) {
            this.msgTranslate(messages.have_max_level);
            return;
        }

        this.player.runCommandAsync(`xp -10L @s[lm=10]`).then((cmd) => {
            if (cmd.successCount != 1) {
                this.player.sendMessage({
                    translate: "boxbuild_gravestones.messages.not_enough_xp",
                });
                return;
            }

            this.level_score.addScore(this.player, levels);
            this.effects.UpgradeSound();
            this.player.runCommandAsync(
                `playanimation @e[type=boxbuild_gravestones:gravestone_totem,c=1,r=16] animation.boxbuild_gravestones.gravestone_totem.upgrade a 1`
            );
            this.player.runCommandAsync(
                `execute as @e[type=boxbuild_gravestones:gravestone_totem,c=1,r=16] at @e[type=boxbuild_gravestones:gravestone_totem,c=1,r=16] run particle boxbuild_gravestones:white_line ~ ~ ~`
            );
        });
    }

    /**
     * @description returns the player gravestone skin id.
     * @returns {number | undefined}
     */
    getSkinID() {
        return this.skin_score.getScore(this.player);
    }

    /**
     * @description add the player to the score.
     */
    skinIDNotCreatedYet() {
        if (this.skin_score.hasParticipant(this.player)) return;
        this.skin_score.setScore(this.player, 0);
    }

    /**
     * @description add the player to the score.
     */
    levelsNotCreatedYet() {
        if (this.level_score.hasParticipant(this.player)) return;
        this.level_score.setScore(this.player, 0);
    }

    lastDeathNotCreatedYet() {
        if (this.lastDeath.vectorscore.x.hasParticipant(this.player)) return;
        if (this.lastDeath.vectorscore.y.hasParticipant(this.player)) return;
        if (this.lastDeath.vectorscore.z.hasParticipant(this.player)) return;

        this.lastDeath.vectorscore.x.setScore(this.player, 0);
        this.lastDeath.vectorscore.y.setScore(this.player, 0);
        this.lastDeath.vectorscore.z.setScore(this.player, 0);
    }

    // M E S S A G E S . . .

    /**
     *
     * @param {string} message
     */
    msgTranslate(message) {
        this.player.sendMessage({ translate: message });
    }

    /**
     *
     * @param {string} message
     */
    msg(message) {
        this.player.sendMessage(message);
    }
}
