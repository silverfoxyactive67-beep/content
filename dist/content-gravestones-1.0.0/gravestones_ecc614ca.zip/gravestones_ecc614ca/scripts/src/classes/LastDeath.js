import { Player, world } from "@minecraft/server";
import { LAST_DEATH_DIMENSION, LAST_DEATH_SCORE_NAMES } from "../utils/utils";

export class LastDeath {
    #position;

    constructor(player) {
        /**
         * @type {Player}
         */
        this.player = player;

        this.vectorscore = {
            x: world.scoreboard.getObjective(LAST_DEATH_SCORE_NAMES.x),
            y: world.scoreboard.getObjective(LAST_DEATH_SCORE_NAMES.y),
            z: world.scoreboard.getObjective(LAST_DEATH_SCORE_NAMES.z),
        };

        this.dim_strings = [
            "minecraft:overworld",
            "minecraft:nether",
            "minecraft:the_end",
        ];

        this.dimension = world.scoreboard
            .getObjective(LAST_DEATH_DIMENSION)
            .getScore(this.player);

        this.#position = {
            x: 0,
            y: 0,
            z: 0,
        };

        this.notCreated();
    }

    getPosition() {
        return this.#position;
    }

    getDimension() {
        return this.dimension != undefined
            ? this.dim_strings[this.dimension]
            : this.dim_strings[0];
    }

    notCreated() {
        if (this.vectorscore.x.hasParticipant(this.player)) {
            this.#position = {
                x: this.vectorscore.x.getScore(this.player),
                y: this.vectorscore.y.getScore(this.player),
                z: this.vectorscore.z.getScore(this.player),
            };
            return;
        }
        if (this.vectorscore.y.hasParticipant(this.player)) return;
        if (this.vectorscore.z.hasParticipant(this.player)) return;

        this.vectorscore.x.setScore(this.player, 0);
        this.vectorscore.y.setScore(this.player, 0);
        this.vectorscore.z.setScore(this.player, 0);
        world.scoreboard
            .getObjective(LAST_DEATH_DIMENSION)
            .setScore(this.player, 0);
    }

    /**
     *
     * @param {{x: number, y: number, z: number}} vector
     */
    setLastDeath(vector) {
        this.vectorscore.x.setScore(this.player, this.player.location.x);
        this.vectorscore.y.setScore(this.player, this.player.location.y);
        this.vectorscore.z.setScore(this.player, this.player.location.z);

        this.#position = {
            x: this.vectorscore.x.getScore(this.player),
            y: this.vectorscore.y.getScore(this.player),
            z: this.vectorscore.z.getScore(this.player),
        };

        const new_dimension = this.dim_strings.indexOf(
            this.player.dimension.id
        );
        world.scoreboard
            .getObjective(LAST_DEATH_DIMENSION)
            .setScore(this.player, new_dimension);
    }
}
