import {
    Entity,
    EntityInventoryComponent,
    Player,
    system,
    world,
} from "@minecraft/server";

export class EffectManager {
    constructor(player) {
        /**
         * @type {Player}
         */
        this.player = player;

        this.levelActions = {
            level_1: () => {},
            level_4: () => {
                this.player.runCommandAsync(
                    `give @s boxbuild_gravestones:gravestone_tracker`
                );
            },
            level_2: () => {},
            level_3: () => {
                this.player.addEffect("speed", 20 * 30, { amplifier: 3 });
                this.player.addEffect("resistance", 20 * 30, { amplifier: 5 });
                this.player.addEffect("fire_resistance", 20 * 30, {
                    amplifier: 5,
                });
                this.player.runCommandAsync(
                    `give @s boxbuild_gravestones:phantom_sword`
                );
            },
        };
    }

    /**
     * @description upgrade sound effect
     */
    UpgradeSound() {
        this.player.runCommandAsync(
            `playsound boxbuild_gravestones.ui_upgrade @s ~ ~ ~ 1 ${
                Math.random() * (1 - 0.5) + 0.5
            }`
        );
        this.player.runCommandAsync(`camerashake add @s 0.05 1 positional`);
    }

    GravestonSpawnedVisualEffect(grave) {
        grave.runCommandAsync(
            `playsound boxbuild_gravestones.gravestone_spawn @a ~ ~ ~`
        );
        grave.runCommandAsync(
            `particle boxbuild_gravestones:white_line ~ ~ ~`
        );
        grave.runCommandAsync(
            `particle boxbuild_gravestones:mini_ghost ~ ~ ~`
        );

        // grave.runCommandAsync(`setblock ~ ~ ~ structure_void`).then((e) => {
        //     if (e.successCount == 0) return;
        //     system.runTimeout(() => {
        //         grave.runCommandAsync(`setblock ~ ~ ~ air`);
        //     }, 20);
        // });
        grave.runCommandAsync(`tp @e[type=item,r=2] ~ ~ ~`);
        this.player.runCommandAsync(
            `playanimation @s animation.boxbuild_gravestones.cancel_death a 1 q.is_alive`
        );
    }

    byLevelSpawn(level) {
        for (let i = level; i > 0; i--) {
            if (!this.levelActions.hasOwnProperty(`level_${i}`)) continue;
            this.levelActions[`level_${i}`]();
        }
    }
}
