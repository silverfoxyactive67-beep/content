export const config = {
    max_gravestone_level: 4,
};
