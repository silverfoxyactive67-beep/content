# calculate if this is on a 1s interval to give regeneration to nearby players
scoreboard players operation .calc spark_pets_pro.var = @s spark_pets_pro.t0
scoreboard players operation .calc spark_pets_pro.var %= _20 spark_pets_pro.var
execute if score .calc spark_pets_pro.var matches 0 run effect @a[r=3] regeneration 2 1 true

# every x ticks play a sound and reset the counter
# you can change this to any number of ticks you want, its 20* the number of seconds
execute if score @s spark_pets_pro.t1 matches 40.. run scoreboard players set @s spark_pets_pro.t1 0

# TODO: change this to your sound effect
# play the repeating sound
execute if score @s spark_pets_pro.t1 matches 0 run playsound sound.spark_pets_pro.trick_regeneration @a ~ ~ ~

scoreboard players remove @s spark_pets_pro.t0 1
scoreboard players add @s spark_pets_pro.t1 1