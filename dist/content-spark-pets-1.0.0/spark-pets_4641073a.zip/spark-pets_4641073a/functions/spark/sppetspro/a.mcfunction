# © Spark Universe, 2023
# authors: FetchBot
# description: trigger the achievements when taming a pet
# called by: pets via controller.animation.achievement_spark_pets_pro

execute unless score achievement.basset_hound spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:basset_hound] run function spark/sppetspro/a/basset_hound
execute unless score achievement.bichon_frise spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:bichon_frise] run function spark/sppetspro/a/bichon_frise
execute unless score achievement.border_collie spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:border_collie] run function spark/sppetspro/a/border_collie
execute unless score achievement.bulldog spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:bulldog] run function spark/sppetspro/a/bulldog
execute unless score achievement.capybara spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:capybara] run function spark/sppetspro/a/capybara
execute unless score achievement.chameleon spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:chameleon] run function spark/sppetspro/a/chameleon
execute unless score achievement.chinchilla spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:chinchilla] run function spark/sppetspro/a/chinchilla
execute unless score achievement.chow_chow spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:chow_chow] run function spark/sppetspro/a/chow_chow
execute unless score achievement.corgi spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:corgi] run function spark/sppetspro/a/corgi
execute unless score achievement.dachshund spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:dachshund] run function spark/sppetspro/a/dachshund
execute unless score achievement.ferret spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:ferret] run function spark/sppetspro/a/ferret
execute unless score achievement.frog spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:frog] run function spark/sppetspro/a/frog
execute unless score achievement.german_shepherd spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:german_shepherd] run function spark/sppetspro/a/german_shepherd
execute unless score achievement.golden_retriever spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:golden_retriever] run function spark/sppetspro/a/golden_retriever
execute unless score achievement.hedgehog spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:hedgehog] run function spark/sppetspro/a/hedgehog
execute unless score achievement.iguana spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:iguana] run function spark/sppetspro/a/iguana
execute unless score achievement.mainecoon spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:mainecoon] run function spark/sppetspro/a/mainecoon
execute unless score achievement.malamute spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:malamute] run function spark/sppetspro/a/malamute
execute unless score achievement.monkey spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:monkey] run function spark/sppetspro/a/monkey
execute unless score achievement.mouse spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:mouse] run function spark/sppetspro/a/mouse
execute unless score achievement.old_english_sheepdog spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:old_english_sheepdog] run function spark/sppetspro/a/sheepdog
execute unless score achievement.persian spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:persian] run function spark/sppetspro/a/persian
execute unless score achievement.platypus spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:platypus] run function spark/sppetspro/a/platypus
execute unless score achievement.pomeranian spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:pomeranian] run function spark/sppetspro/a/pomeranian
execute unless score achievement.poodle spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:poodle] run function spark/sppetspro/a/poodle
execute unless score achievement.saint_bernard spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:saint_bernard] run function spark/sppetspro/a/saint_bernard
execute unless score achievement.scottish_fold spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:scottish_fold] run function spark/sppetspro/a/scottish_fold
execute unless score achievement.shiba_inu spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:shiba_inu] run function spark/sppetspro/a/shiba_inu
execute unless score achievement.siamese spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:siamese] run function spark/sppetspro/a/siamese
execute unless score achievement.snail spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:snail] run function spark/sppetspro/a/snail
execute unless score achievement.snake spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:snake] run function spark/sppetspro/a/snake
execute unless score achievement.tarantula spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:tarantula] run function spark/sppetspro/a/tarantula
execute unless score achievement.tortoise spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:tortoise] run function spark/sppetspro/a/tortoise
execute unless score achievement.t_rex spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:t_rex] run function spark/sppetspro/a/t_rex
execute unless score achievement.guinea_pig spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:guinea_pig] run function spark/sppetspro/a/guinea_pig
execute unless score achievement.crab spark_pets_pro.var matches 1 if entity @s[type=spark_pets_pro:crab] run function spark/sppetspro/a/crab

scoreboard players add "spark_pets_pro:pets_tamed" "spark_pets_pro.jig_computer.addon_stats" 1
