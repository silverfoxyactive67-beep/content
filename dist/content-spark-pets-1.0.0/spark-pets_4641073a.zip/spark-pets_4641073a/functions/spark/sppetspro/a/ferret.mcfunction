tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.ferret","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:ferret.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.ferret spark_pets_pro.var 1
function spark/sppetspro/a_particles