tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.mainecoon","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:mainecoon.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.mainecoon spark_pets_pro.var 1
function spark/sppetspro/a_particles