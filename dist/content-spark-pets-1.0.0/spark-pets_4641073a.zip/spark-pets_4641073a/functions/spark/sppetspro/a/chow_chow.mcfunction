tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.chow_chow","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:chow_chow.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.chow_chow spark_pets_pro.var 1
function spark/sppetspro/a_particles