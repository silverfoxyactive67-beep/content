tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.german_shepherd","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:german_shepherd.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.german_shepherd spark_pets_pro.var 1
function spark/sppetspro/a_particles