tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.dachshund","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:dachshund.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.dachshund spark_pets_pro.var 1
function spark/sppetspro/a_particles