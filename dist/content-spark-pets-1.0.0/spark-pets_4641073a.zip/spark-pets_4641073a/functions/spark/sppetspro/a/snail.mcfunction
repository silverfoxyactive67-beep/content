tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.snail","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:snail.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.snail spark_pets_pro.var 1
function spark/sppetspro/a_particles