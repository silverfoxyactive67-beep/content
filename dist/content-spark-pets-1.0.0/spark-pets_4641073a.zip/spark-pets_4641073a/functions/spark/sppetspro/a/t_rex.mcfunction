tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.t_rex","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:t_rex.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.t_rex spark_pets_pro.var 1
function spark/sppetspro/a_particles