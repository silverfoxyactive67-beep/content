tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.tortoise","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:tortoise.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.tortoise spark_pets_pro.var 1
function spark/sppetspro/a_particles