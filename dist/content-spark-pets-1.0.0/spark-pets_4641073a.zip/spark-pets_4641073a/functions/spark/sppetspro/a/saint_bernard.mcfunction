tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.saint_bernard","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:saint_bernard.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.saint_bernard spark_pets_pro.var 1
function spark/sppetspro/a_particles