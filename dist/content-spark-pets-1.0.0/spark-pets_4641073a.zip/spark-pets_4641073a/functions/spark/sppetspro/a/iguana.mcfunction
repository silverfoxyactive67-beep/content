tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.iguana","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:iguana.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.iguana spark_pets_pro.var 1
function spark/sppetspro/a_particles