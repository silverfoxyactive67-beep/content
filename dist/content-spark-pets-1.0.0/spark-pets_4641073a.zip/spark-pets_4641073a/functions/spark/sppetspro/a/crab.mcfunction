tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.crab","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:crab.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.crab spark_pets_pro.var 1
function spark/sppetspro/a_particles