tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.poodle","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:poodle.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.poodle spark_pets_pro.var 1
function spark/sppetspro/a_particles