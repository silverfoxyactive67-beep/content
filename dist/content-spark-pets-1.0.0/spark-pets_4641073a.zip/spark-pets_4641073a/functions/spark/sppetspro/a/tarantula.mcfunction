tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.tarantula","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:tarantula.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.tarantula spark_pets_pro.var 1
function spark/sppetspro/a_particles