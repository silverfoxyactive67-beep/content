tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.guinea_pig","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:guinea_pig.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.guinea_pig spark_pets_pro.var 1
function spark/sppetspro/a_particles