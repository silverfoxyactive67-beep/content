tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.old_english_sheepdog","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:old_english_sheepdog.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.old_english_sheepdog spark_pets_pro.var 1
function spark/sppetspro/a_particles