tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.bulldog","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:bulldog.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.bulldog spark_pets_pro.var 1
function spark/sppetspro/a_particles