tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.bichon_frise","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:bichon_frise.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.bichon_frise spark_pets_pro.var 1
function spark/sppetspro/a_particles