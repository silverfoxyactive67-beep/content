tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.chameleon","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:chameleon.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.chameleon spark_pets_pro.var 1
function spark/sppetspro/a_particles