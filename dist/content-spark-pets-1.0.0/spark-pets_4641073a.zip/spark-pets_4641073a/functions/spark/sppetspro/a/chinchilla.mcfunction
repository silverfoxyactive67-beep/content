tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.chinchilla","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:chinchilla.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.chinchilla spark_pets_pro.var 1
function spark/sppetspro/a_particles