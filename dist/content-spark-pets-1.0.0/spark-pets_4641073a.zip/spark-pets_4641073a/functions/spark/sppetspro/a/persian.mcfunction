tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.persian","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:persian.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.persian spark_pets_pro.var 1
function spark/sppetspro/a_particles