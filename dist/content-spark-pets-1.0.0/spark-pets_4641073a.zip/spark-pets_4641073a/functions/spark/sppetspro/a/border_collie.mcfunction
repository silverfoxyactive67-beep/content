tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.border_collie","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:border_collie.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.border_collie spark_pets_pro.var 1
function spark/sppetspro/a_particles