tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.basset_hound","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:basset_hound.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.basset_hound spark_pets_pro.var 1
function spark/sppetspro/a_particles