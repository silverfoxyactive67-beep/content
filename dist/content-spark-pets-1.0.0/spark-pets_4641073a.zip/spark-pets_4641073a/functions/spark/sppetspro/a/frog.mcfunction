tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.frog","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:frog.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.frog spark_pets_pro.var 1
function spark/sppetspro/a_particles