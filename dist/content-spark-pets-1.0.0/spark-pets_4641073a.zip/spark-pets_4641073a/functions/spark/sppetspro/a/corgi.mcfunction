tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.corgi","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:corgi.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.corgi spark_pets_pro.var 1
function spark/sppetspro/a_particles