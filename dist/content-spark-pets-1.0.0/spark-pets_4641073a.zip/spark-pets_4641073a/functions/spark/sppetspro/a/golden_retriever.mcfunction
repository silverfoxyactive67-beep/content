tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.golden_retriever","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:golden_retriever.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.golden_retriever spark_pets_pro.var 1
function spark/sppetspro/a_particles