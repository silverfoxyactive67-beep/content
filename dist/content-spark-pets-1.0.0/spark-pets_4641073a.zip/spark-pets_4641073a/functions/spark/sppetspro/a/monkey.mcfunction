tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.monkey","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:monkey.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.monkey spark_pets_pro.var 1
function spark/sppetspro/a_particles