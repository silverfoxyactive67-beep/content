tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.guide_book","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:guide_book.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.guide_book spark_pets_pro.var 1
function spark/sppetspro/a_particles