tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.malamute","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:malamute.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.malamute spark_pets_pro.var 1
function spark/sppetspro/a_particles