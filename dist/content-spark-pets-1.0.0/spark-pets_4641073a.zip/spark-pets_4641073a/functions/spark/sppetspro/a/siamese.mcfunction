tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.siamese","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:siamese.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.siamese spark_pets_pro.var 1
function spark/sppetspro/a_particles