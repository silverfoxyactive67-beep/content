tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.mouse","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:mouse.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.mouse spark_pets_pro.var 1
function spark/sppetspro/a_particles