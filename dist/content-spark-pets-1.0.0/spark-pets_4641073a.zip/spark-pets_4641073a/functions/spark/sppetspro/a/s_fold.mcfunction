tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.scottish_fold","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:scottish_fold.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.scottish_fold spark_pets_pro.var 1
function spark/sppetspro/a_particles