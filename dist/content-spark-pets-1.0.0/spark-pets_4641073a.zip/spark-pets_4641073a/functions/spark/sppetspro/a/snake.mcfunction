tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.snake","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:snake.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.snake spark_pets_pro.var 1
function spark/sppetspro/a_particles