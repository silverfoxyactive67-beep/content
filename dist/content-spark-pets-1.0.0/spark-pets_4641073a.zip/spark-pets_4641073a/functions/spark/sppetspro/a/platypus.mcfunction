tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.platypus","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:platypus.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.platypus spark_pets_pro.var 1
function spark/sppetspro/a_particles