tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.shiba_inu","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:shiba_inu.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.shiba_inu spark_pets_pro.var 1
function spark/sppetspro/a_particles