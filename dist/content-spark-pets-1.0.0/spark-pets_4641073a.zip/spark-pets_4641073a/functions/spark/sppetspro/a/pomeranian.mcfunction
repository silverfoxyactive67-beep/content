tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.pomeranian","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:pomeranian.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.pomeranian spark_pets_pro.var 1
function spark/sppetspro/a_particles