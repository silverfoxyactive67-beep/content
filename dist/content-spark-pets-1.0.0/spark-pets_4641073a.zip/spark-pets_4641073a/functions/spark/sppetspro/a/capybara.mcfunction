tellraw @a {"rawtext":[{"translate":"spark_pets_pro.achievement.capybara","with":{"rawtext":[{"text":"\n"},{"translate":"entity.spark_pets_pro:capybara.name"},{"selector":"@p"}]}}]}
scoreboard players set achievement.capybara spark_pets_pro.var 1
function spark/sppetspro/a_particles