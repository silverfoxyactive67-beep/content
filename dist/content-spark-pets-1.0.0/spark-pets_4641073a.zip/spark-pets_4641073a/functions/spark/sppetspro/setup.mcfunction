# © Spark Universe, 2023
# authors: FetchBot
# description: initialize the pack, this has to be dynamic due to it being an addon
# called by: spark/pets/tick

# create the var scoreboard and set the setup flag to <Version>
# this is used to check if the setup has been run

# version 1. initial version
# version 2. adding the jig computer stats
scoreboard objectives add spark_pets_pro.var dummy
scoreboard players set spark_pets_pro.setup spark_pets_pro.var 2

# timer for players joining the game to show the intro message
scoreboard objectives add spark_pets_pro.t0 dummy
# this is incremented in the tick for all players
scoreboard players set _20 spark_pets_pro.var 20
scoreboard objectives add spark_pets_pro.t1 dummy



# jig computer stats stuff

scoreboard objectives add spark_pets_pro.jig_computer.addon_stats dummy

# I don't know if these are technically required but I think they serve a good perpose
# for the sake of documentation
# scoreboard players add "spark_pets_pro:pets_tamed" "spark_pets_pro.jig_computer.addon_stats" 0
# scoreboard players add "spark_pets_pro:pets_discovered" "spark_pets_pro.jig_computer.addon_stats" 0
# scoreboard players add "spark_pets_pro:cosmetics_applied" "spark_pets_pro.jig_computer.addon_stats" 0
# scoreboard players add "spark_pets_pro:treats_given" "spark_pets_pro.jig_computer.addon_stats" 0