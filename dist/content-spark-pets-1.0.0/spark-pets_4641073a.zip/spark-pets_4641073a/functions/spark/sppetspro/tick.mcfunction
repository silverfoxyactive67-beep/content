# © Spark Universe, 2023
# authors: FetchBot
# description: ticking things
# called by: tick.json

execute unless score spark_pets_pro.setup spark_pets_pro.var matches 2 run function spark/sppetspro/setup
execute as @a[tag=!spark_pets_pro:has_recipe] run function spark/sppetspro/give_recipe
execute as @e[family=pet,scores={spark_pets_pro.t0=1..}] at @s run function spark/sppetspro/tick_trick_regen