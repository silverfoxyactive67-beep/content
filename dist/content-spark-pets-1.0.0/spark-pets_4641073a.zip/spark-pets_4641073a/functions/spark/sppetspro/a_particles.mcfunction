playsound sound.spark_pets_pro.tame_achievement @p
playanimation @s animation.spark_pets_pro.pet.tame


scoreboard players add "spark_pets_pro:pets_discovered" "spark_pets_pro.jig_computer.addon_stats" 1