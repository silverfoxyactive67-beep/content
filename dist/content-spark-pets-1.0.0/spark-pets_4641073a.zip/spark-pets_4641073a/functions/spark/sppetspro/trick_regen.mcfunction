# © Spark Universe, 2023
# authors: FetchBot
# description: impliment the regen on trick end effect for pets
# called by: pets via controller.animation.trick_regen_spark_pets_pro
scoreboard players add @s spark_pets_pro.t0 0
execute if score @s spark_pets_pro.t0 matches 0 run scoreboard players set @s spark_pets_pro.t1 0
scoreboard players set @s spark_pets_pro.t0 200
playanimation @s animation.spark_pets_pro.pet.regenerate
playsound random.eat @a ~ ~ ~


scoreboard players add "spark_pets_pro:treats_given" "spark_pets_pro.jig_computer.addon_stats" 1

effect @s instant_health 1 10 true