import { Guidebook } from "./guidebook";
// guidebook on join
Guidebook.init({
    'entityId': 'spark_pets_pro:guide_book',
    itemId: 'spark_pets_pro:guide_book_spawn_egg',
    'joinString': 'spark_pets_pro.chat.is_active',
    'tag': 'spark_pets_pro:has_joined_before'
});
