import { system, world } from "@minecraft/server";
import * as debug from "../debug_functions";
import * as util from "../util";
import * as challenges from "../data/challenges";

system.afterEvents.scriptEventReceive.subscribe(e => {
    const entity = e.sourceEntity;
	if (e.id == "ljw_ch:distracted_piglin") {
		const challengeId = "gold_collector";
		if (challenges.validate(entity, challengeId)) {
			return;
		}
		challenges.increment(entity, challengeId);
    }
});

world.beforeEvents.playerInteractWithEntity.subscribe((e) => {
	const player = e.player;
	const itemStack = e.itemStack;
	const target = e.target;
	
	if (!player || !player.isValid || !target || !target.isValid || !itemStack) {
		return;
	}
	
	const isBaby = target.getComponent("minecraft:is_baby") != null;
	if (!isBaby) {
		return;
	}
	
	if ((itemStack.typeId == "minecraft:bone") && target.matches({families: ["wolf"]})) {
		const challengeId = "puppy_tamer";
		const isTamed = target.getComponent("minecraft:is_tamed") != null;
		if (isTamed) {
			return;
		}
		
		if (challenges.validate(player, challengeId)) {
			return;
		}
		
		system.runTimeout(() => {
			if (!player || !player.isValid || !target || !target.isValid) {
				return;
			}
			
			const isTamedNow = target.getComponent("minecraft:is_tamed") != null;
			if (isTamedNow) {
				challenges.increment(player, challengeId)
			}
		}, 1);
	}
	if ((itemStack.typeId == "minecraft:golden_dandelion") && challenges.discoverableBabyMobDandelionChallenges.includes(target.typeId)) {
		const challengeId = `dandelion_${target.typeId.split(":")[1]}`;
		challenges.increment(player, challengeId);
	}
	if (Object.keys(challenges.discoverableBabyMobFoodItems).includes(target.typeId) && challenges.discoverableBabyMobFoodItems[target.typeId].includes(itemStack.typeId)) {
		const challengeId = `feed_a_${target.typeId.split(":")[1]}`;
		challenges.increment(player, challengeId);
	}
	//if (target.matches({families: ["cat"]})) {
	//	const challengeId = "kitten_tamer";
	//	const isTamed = target.getComponent("minecraft:is_tamed") != null;
	//	if (isTamed || !isBaby) {
	//		return;
	//	}
	//	
	//	if (challenges.validate(player, challengeId)) {
	//		return;
	//	}
	//	
	//	system.runTimeout(() => {
	//		if (!player || !player.isValid || !target || !target.isValid) {
	//			return;
	//		}
	//		
	//		const isTamedNow = target.getComponent("minecraft:is_tamed") != null;
	//		if (isTamedNow) {
	//			challenges.increment(player, challengeId);
	//		}
	//	}, 1);
	//}
	if (target.matches({families: ["drowned"]}) && (itemStack.typeId == "minecraft:name_tag")) {
		const challengeId = "drowned_name";
		if (!isBaby) {
			return;
		}
		
		if (challenges.validate(player, challengeId)) {
			return;
		}
		
		const currentName = target.nameTag;
		system.runTimeout(() => {
			if (!player || !player.isValid || !target || !target.isValid) {
				return;
			}
			
			const newName = target.nameTag;
			if (currentName != newName) {
				challenges.increment(player, challengeId);
			}
		}, 1);
	}
});

world.afterEvents.playerInventoryItemChange.subscribe((e) => {
	const itemStack = e.itemStack;
	const player = e.player;
	//if (itemStack && (itemStack.typeId == "minecraft:golden_dandelion")) {
	//	const challengeId = "golden_flower";
	//	if (challenges.validate(player, challengeId)) {
	//		return;
	//	}
	//	
	//	challenges.increment(player, challengeId);
	//}
	if (itemStack && (itemStack.typeId == "minecraft:axolotl_bucket")) {
		const challengeId = "bucket_an_axolotl";
		if (challenges.validate(player, challengeId)) {
			return;
		}
		
		challenges.increment(player, challengeId);
	}
});

world.beforeEvents.entityItemPickup.subscribe((e) => {
	const entity = e.entity;
	if (!entity || !entity.isValid) {
		return;
	}
	
	const isBaby = entity.getComponent("minecraft:is_baby") != null;
	if (!isBaby) {
		return;
	}
	
	if (entity.typeId == "minecraft:piglin") {
		const challengeId = "gold_collector";
		for (const player of entity.dimension.getPlayers({location: entity.location, maxDistance: 10})) {
			if (challenges.validate(player, challengeId)) {
				return;
			}
			
			challenges.increment(player, challengeId);
		}
	}
});

world.afterEvents.entityHurt.subscribe((e) => {
	const sourceMob = e.damageSource.damagingEntity;
	const hurtEntity = e.hurtEntity;
	
	if (!sourceMob || !sourceMob.isValid || (sourceMob.getComponent("is_baby") == null)) {
		return;
	}
	
	if (sourceMob.typeId == "minecraft:goat") {
		const challengeId = "goat_ram";
		
		for (const player of hurtEntity.dimension.getPlayers({location: hurtEntity.location, maxDistance: 10})) {
			if (challenges.validate(player, challengeId)) {
				return;
			}
			
			challenges.increment(player, challengeId);
		}
	}
});

world.afterEvents.dataDrivenEntityTrigger.subscribe((e) => {
	const entity = e.entity;
	const eventId = e.eventId;
	if (!entity || !entity.isValid) {
		return;
	}
	const isBaby = entity.getComponent("minecraft:is_baby") != null;
	if (!isBaby) {
		return;
	}
	try {
		const entry = challenges.discoverableBabyMobChallengeEvents[entity.typeId];
		if (entry) {
			const challenge = entry[eventId];
			if (challenge) {
				for (const player of entity.dimension.getPlayers({location: entity.location, maxDistance: 10})) {
					if (challenges.validate(player, challenge)) {
						return;
					}
					
					challenges.increment(player, challenge);
				}
			}
		}
	}
	catch(err) {
		debug.warn(`Entity event error: ${err}`);
	}
});

world.afterEvents.playerInteractWithBlock.subscribe((e) => {
	const itemStack = e.itemStack;
	const player = e.player;
	const block = e.block;
	
	if (!block || !player || !itemStack) {
		return;
	}
	
	if ((block.typeId == "minecraft:flower_pot") && (itemStack.typeId == "minecraft:golden_dandelion")) {
		const challengeId = "golden_decor";
		if (challenges.validate(player, challengeId)) {
			return;
		}
		
		if (challenges.increment(player, challengeId)) {
			increment_points(player, 250);
		}
	}
});

world.beforeEvents.playerInteractWithEntity.subscribe((e) => {
	const itemStack = e.itemStack;
	const player = e.player;
	const entity = e.target;
	
	if (!entity || !player || !itemStack || !entity.isValid || !player.isValid) {
		return;
	}
	
	//if ((entity.typeId == "minecraft:mooshroom") && (itemStack.typeId == "minecraft:bowl")) {
	//	const markVariantComponent = entity.getComponent("mark_variant");
	//	if (!markVariantComponent) {
	//		return;
	//	}
	//	
	//	const markVariant = markVariantComponent.value;
	//	if (markVariant != 5) {
	//		debug.warn(`${markVariant}`)
	//		return;
	//	}
	//	
	//	const challengeId = "golden_stew";
	//	if (challenges.validate(player, challengeId)) {
	//		return;
	//	}
	//	
	//	challenges.increment(player, challengeId);
	//}
	//
	//if (itemStack.typeId == "minecraft:golden_dandelion") {
	//	const isBabyComponent = entity.getComponent("is_baby");
	//	if (isBabyComponent) {
	//		const challengeId = "eternal_youth";
	//		if (challenges.validate(player, challengeId)) {
	//			return;
	//		}
	//		
	//		challenges.increment(player, challengeId);
	//	}
	//}
});

function baby_mob_discovery_check() {
	for (const player of world.getPlayers()) {
		for (const entity of player.dimension.getEntities({location: player.location, maxDistance: 10})) {
			const isBaby = entity.getComponent("minecraft:is_baby") != null;
			if (isBaby) {
				const quests = challenges.discoverableBabyMobChallenges[entity.typeId];
				if (quests && (quests.length > 0)) {
					for (const quest of quests) {
						if (challenges.validate(player, quest)) {
							continue;
						}
						if (quest.includes("find_a")) {
							let variant = "0";
							const dataComponent = entity.getComponent(entity.typeId == "minecraft:villager_v2" ? "mark_variant" : "variant");
							if (entity.getProperty("minecraft:climate_variant") != null) {
								variant = entity.getProperty("minecraft:climate_variant");
							}
							else if (dataComponent != null) {
								variant = `${dataComponent.value}`;
							}
							
							//debug.info(`Test | ${entity.typeId} | ${quests} | ${quest}`);
							challenges.increment(player, quest, `${variant}`);
						}
						else if ((quest == "floating_chicken") && !entity.isOnGround) {
							challenges.increment(player, "floating_chicken");
						}
						else if ((quest == "dolphin_swim") && player.isSwimming) {
							challenges.increment(player, "dolphin_swim");
						}
						else if ((quest == "husk_daylight") && util.is_day()) {
							challenges.increment(player, "husk_daylight");
						}
						else if ((quest == "find_brown_panda") && entity.getComponent("variant").value == 4) {
							challenges.increment(player, "find_brown_panda");
						}
						else if ((quest == "zoglin_daylight") && util.is_day() && (entity.dimension.id == "minecraft:overworld")) {
							challenges.increment(player, "zoglin_daylight");
						}
						else if ((quest == "zoglin_swimmer") && entity.isInWater) {
							challenges.increment(player, "zoglin_swimmer");
						}
						else if ((quest == "zombie_villager_swimmer") && entity.isInWater) {
							challenges.increment(player, "zombie_villager_swimmer");
						}
					}
				}
			}
		}
	}
}
system.runInterval(baby_mob_discovery_check, 50);