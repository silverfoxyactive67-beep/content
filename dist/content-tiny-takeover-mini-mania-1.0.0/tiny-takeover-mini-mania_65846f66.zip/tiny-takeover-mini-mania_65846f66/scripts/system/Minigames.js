import { system, world, ItemStack } from "@minecraft/server";
import * as debug from "../debug_functions";
import * as util from "../util";

world.afterEvents.playerSpawn.subscribe(e => {
	const player = e.player;
		
	player.setDynamicProperty("ljw_ch:minigame_id");
});

world.afterEvents.entityHurt.subscribe(e => {
	const entity = e.hurtEntity;
	const damage = e.damage;
	const cause = e.damageSource.cause;
	const source = e.damageSource.damagingEntity;
	
	try {
		if (!entity || !entity.isValid) {
			return;
		}
		
		if (!source || !source.isValid || !source.matches({families: [ "player" ]})) {
			return;
		}
		
		if (entity.matches({families: [ "siege_minigame", "mob" ]})) {
			const minigameId = entity.getDynamicProperty("ljw_ch:minigame_id");
			if (minigameId) {
				source.runCommand(`/scriptevent ljw_ch:join_minigame ${minigameId}`);
			}
		}
	}
	catch(err) {
		debug.warn(`Minigame entity hit error: ${err}`);
	}
});

system.afterEvents.scriptEventReceive.subscribe(e => {
    const entity = e.sourceEntity;
	try {
		if (e.id == "ljw_ch:start_minigame") {
			if (entity == null) {
				debug.error("'ljw_ch:start_minigame' must be run from an entity.");
				return;
			}
			
			if (e.message == "critter_corral") {
				new CorralMinigame(entity);
			}
			else if (e.message == "sweet_siege_survival") {
				new SurvivalMinigame(entity);
			}
			else if (e.message == "beehive_blitz") {
				new BlitzMinigame(entity);
			}
			else if (e.message == "test") {
				new Minigame(entity);
			}
		}
		else if (e.id == "ljw_ch:minigame_persistence_check") {
			if (entity == null) {
				debug.error("'ljw_ch:minigame_persistence_check' must be run from an entity.");
				return;
			}
			
			const minigameId = entity.getDynamicProperty("ljw_ch:minigame_id");
			if (!minigameId) {
				entity.triggerEvent("ljw_ch:despawn");
			}
			else {
				entity.setDynamicProperty("ljw_ch:minigame_check_result");
				entity.runCommand(`/scriptevent ljw_ch:check_minigame ${minigameId}`);
				system.runTimeout(() => {
					try {
						if (!(entity.getDynamicProperty("ljw_ch:minigame_check_result") ?? false)) {
							const leashableComponent = entity.getComponent("leashable");
							if (leashableComponent) {
								if (leashableComponent.isLeashed) {
									const holder = leashableComponent.leashHolder;
									if (holder) {
										holder.dimension.spawnItem(new ItemStack("minecraft:lead"), holder.location);
									}
								}
							}
							
							entity.triggerEvent("ljw_ch:despawn");
							entity.dimension.spawnParticle(`ljw_ch:minigame_poof`, entity.location);
						}
					}
					catch(err) {}
				}, 2);
			}
		}
	}
	catch(err) {
		debug.warn(`Minigame scriptevent error: ${err} | ${e.id}`);
	}
});

class Minigame {
	minigameType = "default";
	initializingPlayerName = null;
	playerRoster = [];
	hasKeyEntity = false;
	keyEntity = null;
	origin = null;
	dimension = null;
	score = 0;
	timeLimit = 45;
	tickInstance = null;
	actionBarList = [];
	startTime = 0;
	minigameId = null;
	outOfTime = false;
	tickCount = 0;
	scriptEventListener = null;
	playerDistanceWarnings = [];
	minigameDistanceLimit = 300;
	minSpawnRadius = 5;
	spawnRadiusVariance = 10;
	
	constructor(player) {
		debug.info(`New minigame! Initiated by ${player.nameTag}`);
		this.origin = player.location;
		this.dimension = player.dimension;
		this.initializingPlayerName = player.nameTag;
		this.minigameId = `${Date.now()}.${player.id}`;
		
		let validCount = 0;
		for (let i = 0; i < 10; i += 1) {
			try {
				this.find_random_valid_spawn_location();
				validCount += 1;
			}
			catch(err) {}
		}
			
		debug.info(`Area test score: ${validCount}`);
		if (validCount >= 6) {
			for (const detectedPlayer of this.dimension.getPlayers({location: this.origin, maxDistance: 10})) {
				const minigameId = detectedPlayer.getDynamicProperty("ljw_ch:minigame_id");
				if (minigameId == null) {
					this.init_player(detectedPlayer, true);
				}
				else {
					detectedPlayer.setDynamicProperty("ljw_ch:minigame_check_result");
					detectedPlayer.runCommand(`/scriptevent ljw_ch:check_minigame ${minigameId}`);
					system.runTimeout(() => {
						if (!(detectedPlayer.getDynamicProperty("ljw_ch:minigame_check_result") ?? false)) {
							this.init_player(detectedPlayer, true);
						}
					}, 2);
				}
			}
			this.init();
			this.startTime = Date.now();
			this.tickInstance = system.runInterval(() => {this.tick();}, 1);
			this.scriptEventListener = system.afterEvents.scriptEventReceive.subscribe(e => {
				const entity = e.sourceEntity;
				if (e.id == "ljw_ch:check_minigame") {
					if (entity == null) {
						return;
					}
					
					if (e.message == this.minigameId) {
						entity.setDynamicProperty("ljw_ch:minigame_check_result", true);
					}
				}
				else if (e.id == "ljw_ch:stop_minigame") {
					if (e.message == this.minigameId) {
						this.stop();
					}
				}
				else if (e.id == "ljw_ch:join_minigame") {
					if (e.message == this.minigameId) {
						this.init_player(entity);
					}
				}
			});
		}
		else {
			player.sendMessage({ translate: "ljw_ch.message.minigame_blocked_by_area", with: { rawtext: [ { text: "\n" }]} });
		}
	}
	
	init_player(player, startingMinigame = false) {
		if (player.getDynamicProperty("ljw_ch:minigame_id") != this.minigameId) {
			this.playerRoster.push(player);
			player.setDynamicProperty("ljw_ch:minigame_id", this.minigameId);
			if (startingMinigame) {
				if (this.initializingPlayerName == player.nameTag) {
					player.sendMessage({ translate: "ljw_ch.message.starting_minigame", with: { rawtext: [ { text: "\n" }, { text: this.initializingPlayerName }]} });
				}
				else {
					player.sendMessage({ translate: "ljw_ch.message.starting_minigame_with", with: { rawtext: [ { text: "\n" }, { text: this.initializingPlayerName }]} });
				}
			}
			else {
				if (this.initializingPlayerName == player.nameTag) {
					player.sendMessage({ translate: "ljw_ch.message.rejoined_minigame", with: { rawtext: [ { text: "\n" }, { text: this.initializingPlayerName }]} });
				}
				else {
					player.sendMessage({ translate: "ljw_ch.message.joined_minigame", with: { rawtext: [ { text: "\n" }, { text: this.initializingPlayerName }]} });
				}
			}
			if (player.getDynamicProperty("ljw_ch:setting_minigame_music_enabled") ?? true) {
				system.runTimeout(() => {
					try {
						player.playMusic(`ljw_ch.minigame_music.${this.minigameType}`, {fade: 2.0});
					}
					catch(err) {}
				}, 3);
			}
		}
	}
	
	player_scan(location) {
		for (const player of this.dimension.getPlayers({location, maxDistance: 7})) {
			try {
				if (player.getDynamicProperty("ljw_ch:minigame_id") != this.minigameId) {
					this.init_player(player);
				}
			}
			catch(err) {
				
			}
		}
	}
	
	init() {
		
	}
	
	tick() {
		try {
			this.check_players();
			if (this.playerRoster.length == 0) {
				throw new Error("No players remaining!");
			}
			if (this.keyEntity && !this.keyEntity.isValid) {
				throw new Error("Key Entity removed!");
			}
			this.reset_actionbar();
			this.update_timer();
			this.minigame_actions();
			this.update_score();
			this.send_actionbar();
			if (this.outOfTime) {
				this.timer_complete_actions();
				this.time_completed();
			}
			this.tickCount += 1;
		}
		catch(err) {
			debug.error(`Minigame runtime error: ${err}`);
			this.stop();
		}
	}
	
	minigame_actions() {
		
	}
	
	check_players() {
		for (let i = 0; i < this.playerRoster.length; i += 1) {
			const player = this.playerRoster[i];
			if (!player || !player.isValid) {
				if (player) {
					debug.info(`A player disconnected from the minigame.`);
				}
				this.playerRoster.splice(i, 1);
				continue;
			}
			
			if ((this.tickCount % 40) == 0) {
				this.player_scan(player.location);
			}
			
			if (player.getDynamicProperty("ljw_ch:minigame_id") != this.minigameId) {
				this.playerRoster.splice(i, 1);
				continue;
			}
			
			const distance = util.distance3D(this.origin, player.location);
			
			if (distance >= this.minigameDistanceLimit) {
				player.sendMessage({ translate: "ljw_ch.message.left_minigame", with: { rawtext: [ { text: "\n" }]} });
				player.setDynamicProperty("ljw_ch:minigame_id");
				if (player.getDynamicProperty("ljw_ch:setting_minigame_music_enabled") ?? true) {
					player.runCommand("/music stop 2");
				}
				this.playerRoster.splice(i, 1);
			}
			else if ((distance >= (this.minigameDistanceLimit * 0.65)) && (this.playerDistanceWarnings.indexOf(player.id) == -1)) {
				player.sendMessage({ translate: "ljw_ch.message.minigame_distance_warning", with: { rawtext: [ { text: "\n" }]} });
				this.playerDistanceWarnings.push(player.id);
			}
			else if ((distance < (this.minigameDistanceLimit * 0.65)) && this.playerDistanceWarnings.includes(player.id)) {
				this.playerDistanceWarnings.splice(this.playerDistanceWarnings.indexOf(player.id), 1);
			}
		}
	}
	
	update_score() {
		this.add_to_actionbar({ translate: "ljw_ch.actionbar_part.score", with: { rawtext: [ { text: "\n" }, {text: `${this.score}`}]} });
	}
	
	update_timer() {
		const timer = Math.max(0, this.startTime + (this.timeLimit * 1000) - (Date.now()));
		if (timer == 0) {
			this.outOfTime = true;
		}
		const timerCount = Math.ceil(timer / 1000);
		this.add_to_actionbar({ translate: "ljw_ch.actionbar_part.time", with: { rawtext: [ { text: "\n" }, {text: `${timerCount}`}]} });
	}
	
	time_completed() {
		for (const player of this.playerRoster) {
			try {
				const earnedPoints = (this.score * 2);
				player.sendMessage({ translate: "ljw_ch.message.minigame_timer_up", with: { rawtext: [ { text: "\n" }, { text: `${earnedPoints}` }, { text: `${this.score}` }]} });
				const currentPoints = player.getDynamicProperty("ljw_ch:points") ?? 0;
				player.setDynamicProperty("ljw_ch:points", Math.max(0, currentPoints + earnedPoints));
				debug.info(`Minigame successfully completed by ${player.nameTag}. Score: ${this.score}`);
			}
			catch(err) {
				debug.error(`Couldn't award points to ${player.nameTag}: ${err}`);
			}
		}
		this.stop();
	}
	
	timer_complete_actions() {
		
	}
	
	stop() {
		system.clearRun(this.tickInstance);
		system.afterEvents.scriptEventReceive.unsubscribe(this.scriptEventListener);
		for (const player of this.playerRoster) {
			try {
				player.setDynamicProperty("ljw_ch:minigame_id");
				if (player.getDynamicProperty("ljw_ch:setting_minigame_music_enabled") ?? true) {
					player.runCommand("/music stop 2");
				}
			}
			catch(err) {
				
			}
		}
		this.cleanup_actions();
	}
	
	cleanup_actions() {
		
	}
	
	reset_actionbar() {
		this.actionBarList = [];
	}
	
	add_to_actionbar(entry) {
		this.actionBarList.push(entry);
	}
	
	send_actionbar() {
		let actionbar = this.actionBarList[0];
		
		if (this.actionBarList.length > 1) {
			for (let i = 1; i < this.actionBarList.length; i += 1) {
				actionbar = { translate: "ljw_ch.actionbar_stack", with: { rawtext: [ actionbar, this.actionBarList[i]]} };
			}
		}
		
		for (const player of this.playerRoster) {
			player.onScreenDisplay.setActionBar(actionbar);
		}
	}
	
	find_random_valid_spawn_location() {
		for (let attempt = 0; attempt < 3; attempt++) {
			// Random horizontal offset
			const angle = Math.random() * 2 * Math.PI;
			const horizontalDist = this.minSpawnRadius + Math.random() * this.spawnRadiusVariance;
			const dx = Math.cos(angle) * horizontalDist;
			const dz = Math.sin(angle) * horizontalDist;

			// Start 5–10 blocks ABOVE the original position (random for variety)
			const heightAbove = 5;
			const startPos = {
				x: this.origin.x + dx,
				y: this.origin.y + heightAbove,
				z: this.origin.z + dz
			};

			// Raycast straight down
			const direction = { x: 0, y: -1, z: 0 };
			const raycastOptions = {
				maxDistance: 40,           // More than enough (covers deep caves or drops)
				includeLiquidBlocks: false, // Pass through water/lava — we don't want underwater spawns
				includePassableBlocks: false // Ignore flowers, vines, etc.
			};

			const hit = this.dimension.getBlockFromRay(startPos, direction, raycastOptions);

			if (!hit) continue; // Nothing hit (void, max distance reached, etc.)

			const spawnPos = {
				x: startPos.x,
				y: hit.block.location.y + 1, // Feet exactly on top of the solid block
				z: startPos.z
			};

			// Reuse the same validity check (handles water, floating, etc.)
			if (is_valid_spawn_location(this.dimension, spawnPos)) {
				return spawnPos;
			}
		}

		// No valid ground found after 3 attempts
		throw new Error("Unable to find spawn location");
	}
}

function is_valid_spawn_location(dimension, location) {
    const feetX = Math.floor(location.x);
    const feetY = Math.floor(location.y);
    const feetZ = Math.floor(location.z);

    // Block where the entity's feet would be
    const feetBlock = dimension.getBlock({ x: feetX, y: feetY, z: feetZ });
    if (!feetBlock || !feetBlock.isAir) {
        return false; // Inside solid block or underwater/liquid
    }

    // Block directly below (must be solid)
    const belowBlock = dimension.getBlock({ x: feetX, y: feetY - 1, z: feetZ });
    if (!belowBlock || belowBlock.isAir || belowBlock.isLiquid) {
        return false;
    }

    return true;
}

class BlitzMinigame extends Minigame {
	minigameType = "beehive_blitz";
	timeLimit = 60;
	minigameDistanceLimit = 650;
	minSpawnRadius = 1;
	beeCount = 0;
	
	minigame_actions() {
		// Spawn Mobs
		if (((this.tickCount % 10) == 0) && (Math.random() <= 0.5) && (this.beeCount < 25)) {
			try {
				debug.info(`Spawning blitz mob!`);
				const spawnLocation = this.find_random_valid_spawn_location();
				const mob = this.dimension.spawnEntity(`ljw_ch:minigame_blitz_bee`, spawnLocation);
				mob.setDynamicProperty("ljw_ch:minigame_id", this.minigameId);
				this.player_scan(spawnLocation);
				this.beeCount += 1;
			}
			catch(err) {
				debug.warn(`Unable to spawn blitz mob: ${err}`);
			}
		}
		
		if (((this.tickCount % 5) == 0)) {
			for (const player of this.playerRoster) {
				for (const bee of this.dimension.getEntities({location: player.location, families: [ "blitz_minigame", "mob" ], maxDistance: 3})) {
					const variant = bee.getProperty("ljw_ch:variant");
					this.score += (variant + 1);
					bee.dimension.spawnParticle(`ljw_ch:minigame_score_${(variant + 1)}`, bee.location);
					bee.dimension.spawnParticle(`ljw_ch:minigame_poof`, bee.location);
					bee.dimension.playSound(`place.small_amethyst_bud`, bee.location, {pitch: 1.2});
					bee.triggerEvent("ljw_ch:despawn");
					this.player_scan(bee.location);
					this.beeCount -= 1;
				}
			}
		}
	}
}

class CorralMinigame extends Minigame {
	minigameType = "critter_corral";
	timeLimit = 120;
	farmAnimals = [ "sheep", "cow", "chicken", "pig" ];
	
	init() {
		this.keyEntity = this.dimension.spawnEntity("ljw_ch:minigame_corral_barn", this.origin);
		this.keyEntity.setDynamicProperty("ljw_ch:minigame_id", this.minigameId);
	}
	
	minigame_actions() {
		// Count points
		if ((this.tickCount % 20) == 0) {
			for (const entity of this.keyEntity.dimension.getEntities({location: this.keyEntity.location, families: [ "corral_minigame", "mob" ], maxDistance: 3})) {
				const variant = entity.getProperty("ljw_ch:variant");
				const leashableComponent = entity.getComponent("leashable");
				entity.dimension.spawnParticle(`ljw_ch:minigame_score_${(variant + 1)}`, entity.location);
				entity.dimension.spawnParticle(`ljw_ch:minigame_poof`, entity.location);
				entity.dimension.playSound(`place.small_amethyst_bud`, entity.location, {pitch: 1.2});
				this.score += (variant + 1);
				this.player_scan(entity.location);
				if (leashableComponent) {
					if (leashableComponent.isLeashed) {
						const holder = leashableComponent.leashHolder;
						if (holder) {
							holder.dimension.spawnItem(new ItemStack("minecraft:lead"), holder.location);
						}
					}
				}
				entity.triggerEvent("ljw_ch:despawn");
			}
		}
		
		if ((this.tickCount % 40) == 0) {
			try {
				debug.info(`Spawning farm mob!`);
				const mob = this.dimension.spawnEntity(`ljw_ch:minigame_corral_${this.farmAnimals[Math.floor(Math.random() * 4)]}`, this.find_random_valid_spawn_location());
				mob.setDynamicProperty("ljw_ch:minigame_id", this.minigameId);
				this.player_scan(this.keyEntity.location);
			}
			catch(err) {
				debug.warn(`Unable to spawn farm mob: ${err}`);
			}
		}
	}
}

class SurvivalMinigame extends Minigame {
	minigameType = "sweet_siege_survival";
	timeLimit = 180;
	siegeMobs = [ "zombie", "husk", "drowned" ];
	cakeHealth = 0;
	phaseCount = 4;
	phaseLength = 0;
	normalUnits = [];
	bruteUnits = [];
	rangedUnits = [];
	normalUnitsLimit = 3;
	bruteUnitsLimit = 3;
	rangedUnitsLimit = 2;
	koListener = null;
	cakeDefeated = false;
	entityScore = 0;
	spawnTime = 0;
	
	init() {
		this.keyEntity = this.dimension.spawnEntity("ljw_ch:minigame_siege_cake", this.origin);
		this.keyEntity.setDynamicProperty("ljw_ch:minigame_id", this.minigameId);
		this.spawnTime = Date.now() - 2000;
		
		system.runTimeout(() => {
			this.koListener = system.afterEvents.scriptEventReceive.subscribe(e => {
				const entity = e.sourceEntity;
				if (e.id == "ljw_ch:siege_enemy_defeated") {
					if (entity == null) {
						return;
					}
					
					if (entity.getDynamicProperty("ljw_ch:minigame_id") != this.minigameId) {
						return;
					}
					
					const variant = entity.getProperty("ljw_ch:variant");
					this.entityScore += variant + 1;
					
					entity.dimension.spawnParticle(`ljw_ch:minigame_score_${(variant + 1)}`, {x: entity.location.x, y: entity.location.y, z: entity.location.z});
					entity.dimension.spawnParticle(`ljw_ch:minigame_poof`, entity.location);
					entity.dimension.playSound(`place.small_amethyst_bud`, entity.location, {pitch: 1.2});
					entity.triggerEvent("ljw_ch:despawn");
					let index = this.normalUnits.indexOf(entity.id);
					if (index != -1) {
						this.normalUnits.splice(index, 1);
						return;
					}
					index = this.bruteUnits.indexOf(entity.id);
					if (index != -1) {
						this.bruteUnits.splice(index, 1);
						return;
					}
					index = this.rangedUnits.indexOf(entity.id);
					if (index != -1) {
						this.rangedUnits.splice(index, 1);
						return;
					}
				}
				else if (e.id == "ljw_ch:siege_cake_defeated") {
					const entity = e.sourceEntity;
					if (entity.getDynamicProperty("ljw_ch:minigame_id") == this.minigameId) {
						if (entity == this.keyEntity) {
							this.cakeDefeated = true;
							this.time_completed();
							return;
						}
					}
				}
			});
		}, 1);
	}
	
	minigame_actions() {
		// Count time elapsed
		const timeElapsed = this.timeLimit - Math.ceil(Math.max(0, this.startTime + (this.timeLimit * 1000) - (Date.now())) / 1000);
		
		// Count points
		this.score = this.entityScore + Math.floor(timeElapsed / 2);
		
		// Spawn Mobs
		const phaseNum = Math.floor(timeElapsed / (this.timeLimit / this.phaseCount)) + 1;
		if (((this.tickCount % 20) == 0) && ((Math.random() <= (0.2 * (phaseNum))) || (Date.now() > this.spawnTime + 4000))) {
			try {
				debug.info(`Spawning siege mob!`);
				const choice = Math.floor(Math.random() * util.clamp(phaseNum, 1, 3));
				if ((choice == 0) && (this.normalUnits.length >= this.normalUnitsLimit)) {
					throw new Error("Normal unit limit reached.");
				}
				else if ((choice == 1) && (this.bruteUnits.length >= this.bruteUnitsLimit)) {
					throw new Error("Brute unit limit reached.");
				}
				else if ((choice == 2) && (this.rangedUnits.length >= this.rangedUnitsLimit)) {
					throw new Error("Ranged unit limit reached.");
				}
				const mob = this.dimension.spawnEntity(`ljw_ch:minigame_siege_${this.siegeMobs[choice]}`, this.find_random_valid_spawn_location());
				mob.setDynamicProperty("ljw_ch:minigame_id", this.minigameId);
				this.spawnTime = Date.now();
				if (choice == 0) {
					this.normalUnits.push(mob.id);
				}
				else if (choice == 1) {
					this.bruteUnits.push(mob.id);
				}
				else if (choice == 2) {
					this.rangedUnits.push(mob.id);
					mob.runCommand(`/replaceitem entity @s slot.weapon.mainhand 0 trident`);
				}
				this.player_scan(this.keyEntity.location);
			}
			catch(err) {
				debug.warn(`Unable to spawn siege mob: ${err}`);
			}
		}
		
		// Update cake HP
		if (!this.cakeDefeated) {
			const healthComponent = this.keyEntity.getComponent("health");
			if (healthComponent) {
				const currentHP = healthComponent.currentValue;
				this.add_to_actionbar({ translate: "ljw_ch.actionbar_part.siege_hp", with: { rawtext: [ { text: "\n" }, {text: `${Math.floor(currentHP)}`}, {text: `${currentHP < this.cakeHealth ? "§c" : ""}`}]} });
				this.cakeHealth = currentHP;
			}
		}
		else {
			this.add_to_actionbar({ translate: "ljw_ch.actionbar_part.siege_hp", with: { rawtext: [ { text: "\n" }, {text: `§c0§r`}, {text: ""}]} });
		}
		this.add_to_actionbar({ translate: "ljw_ch.actionbar_part.siege_phase", with: { rawtext: [ { text: "\n" }, {text: `${phaseNum}`}, {text: `${this.phaseCount}`}]} });
	}
	
	timer_complete_actions() {
		this.score += 500;
	}
	
	cleanup_actions() {
		world.afterEvents.entityDie.unsubscribe(this.koListener);
	}
}