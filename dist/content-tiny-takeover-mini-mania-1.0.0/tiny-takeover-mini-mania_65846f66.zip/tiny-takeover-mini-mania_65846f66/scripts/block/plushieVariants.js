import { BlockPermutation, system, world } from "@minecraft/server";

const NAMESPACE = "ljw_ch:";
const ROTATION_STATE = `${NAMESPACE}rotation`;
const BLOCK_FACE_STATE = "minecraft:block_face";
const DEFAULT_PARTICLE = "minecraft:villager_happy";
const DEFAULT_SOUND = "random.pop";

const VARIANT_GROUPS = [
  {
    family: "horse_black",
    ids: [
      "plushie_baby_horse_black",
      "plushie_baby_horse_black_markings_whitestockings",
      "plushie_baby_horse_black_markings_whitefield",
      "plushie_baby_horse_black_markings_whitedots",
      "plushie_baby_horse_black_markings_blackdots",
    ],
  },
  {
    family: "horse_brown",
    ids: [
      "plushie_baby_horse_brown",
      "plushie_baby_horse_brown_markings_whitestockings",
      "plushie_baby_horse_brown_markings_whitefield",
      "plushie_baby_horse_brown_markings_whitedots",
      "plushie_baby_horse_brown_markings_blackdots",
    ],
  },
  {
    family: "horse_chestnut",
    ids: [
      "plushie_baby_horse_chestnut",
      "plushie_baby_horse_chestnut_markings_whitestockings",
      "plushie_baby_horse_chestnut_markings_whitefield",
      "plushie_baby_horse_chestnut_markings_whitedots",
      "plushie_baby_horse_chestnut_markings_blackdots",
    ],
  },
  {
    family: "horse_darkbrown",
    ids: [
      "plushie_baby_horse_darkbrown",
      "plushie_baby_horse_darkbrown_markings_whitestockings",
      "plushie_baby_horse_darkbrown_markings_whitefield",
      "plushie_baby_horse_darkbrown_markings_whitedots",
      "plushie_baby_horse_darkbrown_markings_blackdots",
    ],
  },
  {
    family: "horse_gray",
    ids: [
      "plushie_baby_horse_gray",
      "plushie_baby_horse_gray_markings_whitestockings",
      "plushie_baby_horse_gray_markings_whitefield",
      "plushie_baby_horse_gray_markings_whitedots",
      "plushie_baby_horse_gray_markings_blackdots",
    ],
  },
  {
    family: "horse_creamy",
    ids: [
      "plushie_baby_horse_creamy",
      "plushie_baby_horse_creamy_markings_whitestockings",
      "plushie_baby_horse_creamy_markings_whitefield",
      "plushie_baby_horse_creamy_markings_whitedots",
      "plushie_baby_horse_creamy_markings_blackdots",
    ],
  },
  {
    family: "horse_white",
    ids: [
      "plushie_baby_horse_white",
      "plushie_baby_horse_white_markings_whitestockings",
      "plushie_baby_horse_white_markings_whitefield",
      "plushie_baby_horse_white_markings_whitedots",
      "plushie_baby_horse_white_markings_blackdots",
    ],
  }
];

const FAMILY_STYLE_OVERRIDES = {
  axolotl: { pitch: 1.35 },
  cat: { pitch: 1.3 },
  chicken: { pitch: 1.4 },
  cow: { pitch: 0.8 },
  donkey: { pitch: 0.9 },
  fox: { pitch: 1.25 },
  horse: { pitch: 0.95 },
  llama: { pitch: 1.05 },
  panda: { pitch: 0.85 },
  pig: { pitch: 1.1 },
  sheep: { pitch: 1.2 },
  squid: { pitch: 0.75 },
  villager: { particle: "minecraft:villager_happy", pitch: 1.15 },
  wolf: { pitch: 1.05 },
  zombie: { pitch: 0.7 },
};

const BLOCK_TO_GROUP = new Map();
const BLOCK_TO_INDEX = new Map();
const BLOCK_TO_FAMILY = new Map();
const RECENT_INTERACTIONS = new Set();

for (const group of VARIANT_GROUPS) {
  const fullIds = group.ids.map((id) => `${NAMESPACE}${id}`);
  for (const [index, fullId] of fullIds.entries()) {
    BLOCK_TO_GROUP.set(fullId, fullIds);
    BLOCK_TO_INDEX.set(fullId, index);
    BLOCK_TO_FAMILY.set(fullId, group.family);
  }
}

function getState(permutation, stateName, fallbackValue) {
  try {
    const value = permutation.getState(stateName);
    return value ?? fallbackValue;
  } catch {
    return fallbackValue;
  }
}

function buildNextPermutation(block, nextTypeId) {
  let nextPermutation = BlockPermutation.resolve(nextTypeId);
  const blockFace = getState(block.permutation, BLOCK_FACE_STATE, "up");
  const rotation = getState(block.permutation, ROTATION_STATE, 0);

  try {
    nextPermutation = nextPermutation.withState(BLOCK_FACE_STATE, blockFace);
  } catch {
    // Ignore plushies that do not use a placement face state.
  }

  try {
    nextPermutation = nextPermutation.withState(ROTATION_STATE, rotation);
  } catch {
    // Ignore plushies that do not use the custom rotation state.
  }

  return nextPermutation;
}

function getRandomParticleLocation(block) {
  const { x, y, z } = block.location;
  return {
    x: x + Math.random(),
    y: y + Math.random(),
    z: z + Math.random(),
  };
}

function getSoundLocation(block) {
  const { x, y, z } = block.location;
  return { x: x + 0.5, y: y + 0.5, z: z + 0.5 };
}

function emitVariantFeedback(block, currentTypeId) {
  const family = BLOCK_TO_FAMILY.get(currentTypeId) ?? "default";
  const style = FAMILY_STYLE_OVERRIDES[family] ?? {};
  const particle = style.particle ?? DEFAULT_PARTICLE;
  const sound = style.sound ?? DEFAULT_SOUND;
  const particleLocation = getRandomParticleLocation(block);
  const soundLocation = getSoundLocation(block);

  try {
    block.dimension.spawnParticle(particle, particleLocation);
  } catch {
    // Ignore unsupported particles rather than blocking the variant cycle.
  }

  try {
    block.dimension.playSound(sound, soundLocation, {
      volume: 0.8,
      pitch: style.pitch ?? 1,
    });
  } catch {
    // Ignore unsupported sounds rather than blocking the variant cycle.
  }
}

function getNextVariantTypeId(currentTypeId) {
  const group = BLOCK_TO_GROUP.get(currentTypeId);
  if (!group || group.length < 2) {
    return undefined;
  }

  const index = BLOCK_TO_INDEX.get(currentTypeId);
  if (index === undefined) {
    return undefined;
  }

  return group[(index + 1) % group.length];
}

function createInteractionKey(playerId, block) {
  const { x, y, z } = block.location;
  return `${system.currentTick}:${playerId}:${block.dimension.id}:${x},${y},${z}`;
}

function cycleVariantOnInteract(block, player) {
  if (!block || !player) {
    return;
  }

  const currentTypeId = block.typeId;
  const nextTypeId = getNextVariantTypeId(currentTypeId);
  if (!nextTypeId) {
    return;
  }

  const interactionKey = createInteractionKey(player.id, block);
  if (RECENT_INTERACTIONS.has(interactionKey)) {
    return;
  }

  RECENT_INTERACTIONS.add(interactionKey);
  system.runTimeout(() => RECENT_INTERACTIONS.delete(interactionKey), 1);

  const dimension = block.dimension;
  const location = { ...block.location };

  system.run(() => {
    const liveBlock = dimension.getBlock(location);
    if (!liveBlock) {
      return;
    }

    const liveTypeId = liveBlock.typeId;
    const liveNextTypeId = getNextVariantTypeId(liveTypeId);
    if (!liveNextTypeId) {
      return;
    }

    try {
      liveBlock.setPermutation(buildNextPermutation(liveBlock, liveNextTypeId));
      emitVariantFeedback(liveBlock, liveTypeId);
    } catch (error) {
      // Ignore failed swaps so a bad block does not break the world event subscription.
    }
  });
}

export function register() {
  world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    if (!event.isFirstEvent) {
      return;
    }

    cycleVariantOnInteract(event.block, event.player);
  });
}
