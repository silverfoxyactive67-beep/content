import { Direction, system } from "@minecraft/server";

const NAMESPACE = "ljw_ch:";
const CUSTOM_COMPONENT = `${NAMESPACE}precise_rotation`;
const ROTATION_STATE = `${NAMESPACE}rotation`;

function faceToBlockFace(face) {
  switch (face) {
    case Direction.Up:
      return "up";
    case Direction.Down:
      return "down";
    case Direction.North:
      return "north";
    case Direction.South:
      return "south";
    case Direction.East:
      return "east";
    case Direction.West:
      return "west";
    default:
      return "up";
  }
}

// Converts player Y rotation to a 0..15 intercardinal direction.
function toRotationStep(yaw) {
  let normalized = yaw % 360;
  if (normalized < 0) normalized += 360;
  return Math.round(normalized / 22.5) % 16;
}

function beforeOnPlayerPlace(ev, customComponent) {
  const { player, face, permutationToPlace } = ev;
  if (!player) return;

  let nextPermutation = permutationToPlace;

  try {
    if (face === Direction.Up) {
      const yRotationOffset = customComponent?.params?.y_rotation_offset ?? 180;
      const yaw = player.getRotation().y + yRotationOffset;
      nextPermutation = nextPermutation.withState(
        ROTATION_STATE,
        toRotationStep(yaw),
      );
    }

    nextPermutation = nextPermutation.withState(
      "minecraft:block_face",
      faceToBlockFace(face),
    );
    ev.permutationToPlace = nextPermutation;
  } catch {
    // Ignore blocks that do not define these states.
  }
}

export function register() {
  system.beforeEvents.startup.subscribe((ev) => {
    ev.blockComponentRegistry.registerCustomComponent(CUSTOM_COMPONENT, {
      beforeOnPlayerPlace,
    });
  });
}
