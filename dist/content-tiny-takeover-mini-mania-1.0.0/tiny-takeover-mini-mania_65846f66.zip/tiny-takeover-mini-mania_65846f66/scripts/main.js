import "item/InfoBook";
import "system/Challenges";
import "system/Minigames";
import * as PreciseRotation from "./block/preciseRotation.js";
import * as PlushieVariants from "./block/plushieVariants.js";
import * as HatDynamics from "./item/hatDynamics.js";
import * as MobSpawnHats from "./item/mobSpawnHats.js";

PreciseRotation.register();
PlushieVariants.register();
HatDynamics.register();
MobSpawnHats.register();
