import {system, world, BlockPermutation} from "@minecraft/server";
import {questList} from "./data/challenges";
import {plushieList} from "./data/plushies";
const debugBuffer = 2000;
const delimiter = "–";

export function info(line) {
	log_message(`§bINFO§r: ${line}`);
	if (!(world.getDynamicProperty("ljw_ch:enable_debug_logging") ?? false)) return;
	sendMessage(`[DEBUG] §bINFO§r: ${line}`);
	console.warn(`[DEBUG] INFO: ${line}`);
}
export function warn(line) {
	log_message(`§eWARN§r: ${line}`);
	if (!(world.getDynamicProperty("ljw_ch:enable_debug_logging") ?? false)) return;
	sendMessage(`[DEBUG] §eWARN§r: ${line}`);
	console.warn(`[DEBUG] WARN: ${line}`);
}
export function error(line) {
	log_message(`§cERROR§r: ${line}`);
	if (!(world.getDynamicProperty("ljw_ch:enable_debug_logging") ?? false)) return;
	sendMessage(`[DEBUG] §cERROR§r: ${line}`);
	console.warn(`[DEBUG] ERROR: ${line}`);
}
function sendMessage(line) {
	const debugPlayers = world.getPlayers({tags: ["ljw_ch_debug_chat"]});
	for (const debugPlayer of debugPlayers) {
		debugPlayer.sendMessage(line);
	}
}

function log_message(line) {
	const current = (world.getDynamicProperty("ljw_ch:debug_log") ?? "");
	world.setDynamicProperty("ljw_ch:debug_log", (current + line + delimiter).substr(Math.max(0, current.length + line.length - debugBuffer), current.length + line.length + 1));
}

system.afterEvents.scriptEventReceive.subscribe(e => {
	if (e.id == "ljw_ch:toggle_debug")
	{
		world.setDynamicProperty("ljw_ch:enable_debug_logging", !(world.getDynamicProperty("ljw_ch:enable_debug_logging") ?? false));
		world.sendMessage(`Debug logging: ${(world.getDynamicProperty("ljw_ch:enable_debug_logging") ?? false)}`);
	}
	else if (e.id == "ljw_ch:debug_log")
	{
		const lines = (world.getDynamicProperty("ljw_ch:debug_log") ?? "").split(delimiter);
		for (const line of lines)
			world.sendMessage(`${line}`);
	}
	else if (e.id == "ljw_ch:password") {
		const entity = e.sourceEntity;
		const code = e.message.replaceAll(" ", "").toUpperCase();
		switch (code) {
			case "RESETALLQUESTSTOPERFORMSOMETESTS":
				entity.sendMessage("Code accepted.");
				entity.setDynamicProperty(`ljw_ch:points`);
				for (const questId of Object.keys(questList)) {
					entity.setDynamicProperty(`ljw_ch:quest_${questId}`);
				}
				return;
			case "RESETREWARDLISTTOCHECKWHATWASMISSED":
				entity.sendMessage("Code accepted.");
				for (const plushie of Object.keys(plushieList)) {
					entity.setDynamicProperty(`${plushie}_unlocked`);
				}
				return;
			case "REPOENTHEBOOKTOTAKEASECONDLOOK":
				entity.sendMessage("Code accepted.");
				entity.setDynamicProperty(`ljw_ch:seen_intro`);
				return;
			case "LOTSOFPOINTSFORMEFORMYNEXTSHOPPINGSPREE":
				entity.sendMessage("Code accepted.");
				const currentPoints = entity.getDynamicProperty("ljw_ch:points") ?? 0;
				entity.setDynamicProperty("ljw_ch:points", Math.max(0, currentPoints + 5000));
				return;
			case "USETHISCODETOSEEALLQUESTSCOMPLETEDFORFREE":
				entity.sendMessage("Code accepted.");
				const questsCompleteOverride = entity.getDynamicProperty("ljw_ch:cheat_quests_complete") ?? false;
				entity.setDynamicProperty("ljw_ch:cheat_quests_complete", !questsCompleteOverride);
				return;
			default:
				entity.sendMessage("Invalid code.");
		}
	}
});