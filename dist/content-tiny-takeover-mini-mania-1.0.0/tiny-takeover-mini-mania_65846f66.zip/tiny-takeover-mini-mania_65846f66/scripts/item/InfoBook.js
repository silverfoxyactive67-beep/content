import {system, world, ItemStack} from "@minecraft/server";
import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import * as debug from "../debug_functions";
import * as challenges from "../data/challenges";
import * as plushies from "../data/plushies";

const divider = "_".repeat(32);
const plushieArray = Object.keys(plushies.plushieList);
const plushieArrayNoSubVariants = [];
const discoverableMobArray = Object.keys(challenges.discoverableBabyMobChallenges);

world.afterEvents.playerSpawn.subscribe(e => {
	const player = e.player;
		
	if (!(player.getDynamicProperty("ljw_ch:info_book_init") ?? false)) {
		give_info(player);
		player.setDynamicProperty("ljw_ch:info_book_init", true);
	}
});

function give_info(player) {
	player.dimension.spawnItem(new ItemStack("ljw_ch:info_book"), player.location);
}

system.afterEvents.scriptEventReceive.subscribe(e => {
    const entity = e.sourceEntity;
    if (e.id == "ljw_ch:info_book") {
		if (e.message == "get") {
			if (entity == null) {
				debug.error("'ljw_ch:info_book get' must be run from an entity.");
				return;
			}
			
			give_info(entity);
		}
		else if (e.message == "reset") {
			for (const player of world.getPlayers())
				player.setDynamicProperty("ljw_ch:info_book_init", false);
		}
    }
});

system.beforeEvents.startup.subscribe(e => {
    e.itemComponentRegistry.registerCustomComponent("ljw_ch:info_book", {onUse: open_guide});
});

function open_guide(e) {
	const player = e.source != null ? e.source : e;
	if (player == null)
		return;
	
	try {
		const minigameId = player.getDynamicProperty("ljw_ch:minigame_id");
		if (minigameId == null) {
			const hasOpenedBook = player.getDynamicProperty("ljw_ch:seen_intro") ?? false;
			if (hasOpenedBook) {
				open_main(player);
			}
			else {
				open_intro(player);
			}
		}
		else {
			player.setDynamicProperty("ljw_ch:minigame_check_result");
			player.runCommand(`/scriptevent ljw_ch:check_minigame ${minigameId}`);
			system.runTimeout(() => {
				if ((player.getDynamicProperty("ljw_ch:minigame_check_result") ?? false)) {
					open_minigame_menu(player);
				}
				else {
					player.setDynamicProperty("ljw_ch:minigame_id");
					open_guide(player);
				}
			}, 3);
		}
	}
	catch (err) {
		debug.error(`Info Book error: ${err}`)
	}
}

function open_main(player) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.main.title", with: { rawtext: [ { translate: "item.ljw_ch:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.main.body", with: { rawtext: [ { text: "\n" }, { text: divider }]} });
		guideDialog.divider();
		
		guideDialog.button({ translate: "ljw_ch.info_book.main.button.getting_started", with: { rawtext: [ { text: "\n" }]} }, "textures/blocks/sapling_oak");
		guideDialog.button({ translate: "ljw_ch.info_book.main.button.rewards", with: { rawtext: [ { text: "\n" }]} }, `textures/ljw/ch/ui/${plushieArrayNoSubVariants[Math.floor(Math.random() * plushieArrayNoSubVariants.length)].split(":")[1]}`);
		guideDialog.button({ translate: "ljw_ch.info_book.main.button.minigames", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_barn");
		guideDialog.button({ translate: "ljw_ch.info_book.main.button.discovery_journal", with: { rawtext: [ { text: "\n" }]} }, "textures/items/book_normal");
		guideDialog.button({ translate: "ljw_ch.info_book.main.button.settings", with: { rawtext: [ { text: "\n" }]} }, "textures/ui/automation_glyph_color");
		guideDialog.button({ translate: "ljw_ch.info_book.main.button.about", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/items/info_book");
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_docs(player);
			else if (response.selection == 1)
				open_rewards(player);
			else if (response.selection == 2)
				open_minigames(player);
			else if (response.selection == 3)
				open_discovery_journal(player);
			else if (response.selection == 4)
				open_settings(player);
			else if (response.selection == 5)
				open_credits(player);
		});
	}
	catch(err) {
		debug.warn(`Info Book main error: ${err}`);
	}
}

function open_intro(player) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.main.title", with: { rawtext: [ { translate: "item.ljw_ch:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.docs.intro.body", with: { rawtext: [ { text: "\n" }, { text: divider }]} });
		
		guideDialog.button({ translate: "ljw_ch.general.button.get_started", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_start");
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0) {
				player.setDynamicProperty("ljw_ch:seen_intro", true);
				open_guide(player);
			}
		});
	}
	catch(err) {
		debug.warn(`Info Book main error: ${err}`);
	}
}

function open_docs(player) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.docs.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.docs.body", with: { rawtext: [ { text: "\n" }, { text: divider }]} });
		guideDialog.divider();
		
		guideDialog.button({ translate: "ljw_ch.info_book.docs.button.intro", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/items/info_book");
		guideDialog.button({ translate: "ljw_ch.info_book.docs.button.points", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/plushie_baby_fox");
		guideDialog.button({ translate: "ljw_ch.info_book.docs.button.minigames", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_barn");
		guideDialog.button({ translate: "ljw_ch.info_book.docs.button.challenges", with: { rawtext: [ { text: "\n" }]} }, "textures/items/book_normal");
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_cancel");
		
		guideDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					explain_topic(player, "intro");
				else if (response.selection == 1)
					explain_topic(player, "points");
				else if (response.selection == 2)
					explain_minigames(player);
				else if (response.selection == 3)
					explain_topic(player, "challenges");
				else if (response.selection == 4)
					open_guide(player);
			}
		});
	}
	catch (err) {
		debug.error(`Docs error: ${err}`)
	}
}

function explain_topic(player, topic, translateA = "", translateB = "", translateC = "", translateD = "", translateE = "") {
	try {
		const guideDialog = new ActionFormData();
		guideDialog.title({ translate: `ljw_ch.info_book.docs.button.${topic}` });
		guideDialog.body({ translate: `ljw_ch.info_book.docs.${topic}.body`, with: { rawtext: [ { text: "\n" }, { translate: translateA }, { translate: translateB }, { translate: translateC }, { translate: translateD }, { translate: translateE }]} });
		
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					open_docs(player);
			}
			else
				open_docs(player);
		});
	}
	catch (err) {
		debug.error(`Explanation Error: ${err}`)
	}
}

function explain_minigames(player) {
	try {
		const guideDialog = new ActionFormData();
		guideDialog.title({ translate: `ljw_ch.info_book.docs.button.minigames` });
		guideDialog.body({ translate: `ljw_ch.info_book.docs.minigames.body`, with: { rawtext: [ { text: "\n" }]} });
		guideDialog.divider();
		
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.beehive_blitz", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_bee");
		guideDialog.label({ translate: "ljw_ch.info_book.minigames.beehive_blitz.short_description", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.critter_corral", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_barn");
		guideDialog.label({ translate: "ljw_ch.info_book.minigames.critter_corral.short_description", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.sweet_siege_survival", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_cake");
		guideDialog.label({ translate: "ljw_ch.info_book.minigames.sweet_siege_survival.short_description", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.divider();
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					preview_minigame(player, "beehive_blitz");
				else if (response.selection == 1)
					preview_minigame(player, "critter_corral");
				else if (response.selection == 2)
					preview_minigame(player, "sweet_siege_survival");
				else if (response.selection == 3)
					open_docs(player);
			}
			else
				open_docs(player);
		});
	}
	catch (err) {
		debug.error(`Explanation Error: ${err}`)
	}
}

function open_rewards(player) {
	try {
		const currentPoints = player.getDynamicProperty("ljw_ch:points") ?? 0;
		const guideDialog = new ActionFormData();
		const plushieOptionList = [];
		
		guideDialog.title({ translate: "ljw_ch.info_book.rewards.title", with: { rawtext: [ { translate: "item.ljw_ch:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.rewards.body", with: { rawtext: [ { text: "\n" }, { text: `${currentPoints}` }]} });
		
		guideDialog.label({ translate: "ljw_ch.info_book.rewards.header.plushies", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.divider();
		for (let i = 0; i < plushieArrayNoSubVariants.length; i += 1) {
			const name = plushieArrayNoSubVariants[i];
			const acquired = (player.getDynamicProperty(`${name}_unlocked`) ?? false);
			
			const entry = plushies.plushieList[name];
			if (!entry.subVariant) {
				plushieOptionList.push({name, cost: entry.cost});
				if (acquired) {
					guideDialog.button({ translate: "ljw_ch.info_book.rewards.button.acquired", with: { rawtext: [ { text: "\n" }, { translate: `reward.${name}` }, { text: `${entry.cost}` } ]} }, `textures/ljw/ch/ui/${name.split(":")[1]}`);
				}
				else {
					guideDialog.button({ translate: "ljw_ch.info_book.rewards.button", with: { rawtext: [ { text: "\n" }, { translate: `reward.${name}` }, { text: `${entry.cost}` } ]} }, `textures/ljw/ch/ui/${name.split(":")[1]}`);
				}
			}
		}
		
		guideDialog.label({ translate: "ljw_ch.info_book.rewards.header.general", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.divider();
		guideDialog.button({ translate: "ljw_ch.info_book.rewards.button", with: { rawtext: [ { text: "\n" }, { translate: "item.name_tag.name" }, { text: "200" } ]} }, "textures/items/name_tag");
		guideDialog.button({ translate: "ljw_ch.info_book.rewards.button", with: { rawtext: [ { text: "\n" }, { translate: "tile.golden_dandelion.name" }, { text: "500" } ]} }, "textures/blocks/golden_dandelion");
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection < plushieOptionList.length)
				try_buy_reward(player, plushieOptionList[response.selection].name, plushieOptionList[response.selection].cost);
			else if (response.selection == plushieOptionList.length)
				try_buy_reward(player, "minecraft:name_tag", 200);
			else if (response.selection == (plushieOptionList.length + 1))
				try_buy_reward(player, "minecraft:golden_dandelion", 500);
				
			
			system.runTimeout(() => {
				open_rewards(player);
			}, 2);
		});
	}
	catch(err) {
		debug.warn(`Info Book rewards error: ${err}`);
	}
}

function try_buy_reward(player, id, cost) {
	try {
		const currentPoints = player.getDynamicProperty("ljw_ch:points") ?? 0;
		debug.info(`${player.nameTag} (${currentPoints}) buying ${id} for ${cost}..`);
		
		if (currentPoints >= cost) {
			player.setDynamicProperty("ljw_ch:points", Math.max(0, currentPoints - cost));
			player.dimension.spawnItem(new ItemStack(`${id}`), player.location);
		}
	}
	catch(err) {
		debug.error(`Reward buy error: ${err}`);
	}
}

world.afterEvents.playerInventoryItemChange.subscribe((e) => {
	const itemStack = e.itemStack;
	const player = e.player;
	
	if (!itemStack || !player || !player.isValid) {
		return;
	}
	
	if (itemStack.hasTag('ljw_ch:plushie_reward')) {
		player.setDynamicProperty(`${itemStack.typeId}_unlocked`, true);
	}
	else if (plushies.plushieList[itemStack.typeId] != null) {
		const unlock = plushies.plushieList[itemStack.typeId].unlock;
		if (unlock != null) {
			player.setDynamicProperty(`${unlock}_unlocked`, true);
		}
	}
});

function open_minigames(player) {
	try {
		const currentPoints = player.getDynamicProperty("ljw_ch:points") ?? 0;
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.minigames.title", with: { rawtext: [ { translate: "item.ljw_ch:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.minigames.body", with: { rawtext: [ { text: "\n" }, { text: `${currentPoints}` }]} });
		guideDialog.divider();
		
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.beehive_blitz", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_bee");
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.critter_corral", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_barn");
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.sweet_siege_survival", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_cake");
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_cancel");
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				preview_minigame(player, "beehive_blitz");
			else if (response.selection == 1)
				preview_minigame(player, "critter_corral");
			else if (response.selection == 2)
				preview_minigame(player, "sweet_siege_survival");
			else if (response.selection == 3)
				open_guide(player);
		});
	}
	catch(err) {
		debug.warn(`Info Book main error: ${err}`);
	}
}

function preview_minigame(player, minigameId) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: `ljw_ch.info_book.minigames.button.${minigameId}`, with: { rawtext: [ { translate: "item.ljw_ch:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: `ljw_ch.info_book.minigames.${minigameId}.description`, with: { rawtext: [ { text: "\n" }, { text: divider }]} });
		
		guideDialog.button({ translate: "ljw_ch.info_book.minigames.button.start_minigame", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_start");
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} }, "textures/ljw/ch/ui/icon_cancel");
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				player.runCommand(`scriptevent ljw_ch:start_minigame ${minigameId}`);
			else if (response.selection == 1)
				open_minigames(player);
		});
	}
	catch(err) {
		debug.warn(`Info Book main error: ${err}`);
	}
}

function open_discovery_journal(player) {
	try {
		const currentPoints = player.getDynamicProperty("ljw_ch:points") ?? 0;
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.discovery_journal.title", with: { rawtext: [ { translate: "item.ljw_ch:info_book", with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.discovery_journal.body", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.divider();
		
		for (const id of discoverableMobArray) {
			const discoveries = challenges.discoverableBabyMobChallenges[id];
			const discoveryBar = (challenges.validate(player, discoveries[0]) ? "§e-" : "§8-") + 
				(challenges.validate(player, discoveries[1]) ? "§e-" : "§8-") +
				(challenges.validate(player, discoveries[2]) ? "§e-" : "§8-") +
				(discoveries[3] ? (challenges.validate(player, discoveries[3]) ? "§e-" : "§8-") : "");
			guideDialog.button({ translate: "ljw_ch.info_book.discovery_journal.button", with: { rawtext: [ { text: "\n" }, { translate: `entity.${id.split(":")[1]}.name` }, { text: `§8[${discoveryBar}§8]§r` }]} });
		}
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else
				review_journal_entry(player, discoverableMobArray[response.selection]);
		});
	}
	catch(err) {
		debug.warn(`Info Book journal error: ${err}`);
	}
}

function review_journal_entry(player, id) {
	try {
		const name = id.split(":")[1];
		
		const discoverChallenges = challenges.discoverableBabyMobChallenges[id];
		
		const entryA = ((discoverChallenges[0] != null) && challenges.validate(player, discoverChallenges[0])) ? `ljw_ch.info_book.discoveries.record.${name}.a` : `ljw_ch.info_book.discoveries.record.locked`;
		const entryB = ((discoverChallenges[1] != null) && challenges.validate(player, discoverChallenges[1])) ? `ljw_ch.info_book.discoveries.record.${name}.b` : `ljw_ch.info_book.discoveries.locked_record.${name}.b`;
		const entryC = ((discoverChallenges[2] != null) && challenges.validate(player, discoverChallenges[2])) ? `ljw_ch.info_book.discoveries.record.${name}.c` : `ljw_ch.info_book.discoveries.locked_record.${name}.c`;
		const entryD = ((discoverChallenges[3] != null) && challenges.validate(player, discoverChallenges[3])) ? `ljw_ch.info_book.discoveries.record.${name}.d` : `ljw_ch.info_book.discoveries.record.locked.count`;
		
		const findGoal = (discoverChallenges[3] != null) ? (challenges.questList[discoverChallenges[3]].goal ?? 0) : 0;
		const findTotal = (discoverChallenges[3] != null) ? Math.max(0, (player.getDynamicProperty(`ljw_ch:quest_${discoverChallenges[3]}`) ?? "").split(";").length - 1) : 0;
		
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.discovery_journal_entry.title", with: { rawtext: [ { text: "\n" }, { translate: `entity.${name}.name`, with: { rawtext: [ { text: "\n" }]} }]} });
		guideDialog.body({ translate: `ljw_ch.info_book.discovery_journal_entry.body${(discoverChallenges[3] != null) ? ".extended" : ""}`, with: { rawtext: [ { text: "\n" }, { translate: entryA }, { translate: entryB }, { translate: entryC }, { translate: entryD, with: { rawtext: [ { text: "\n" }, { text: `${findTotal}` }, { text: `${findGoal}` }]} }]} });
		
		guideDialog.button({ translate: `ljw_ch.general.button.back`, with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else
				open_discovery_journal(player);
		});
	}
	catch(err) {
		debug.warn(`Info Book journal error: ${err}`);
	}
}

function open_settings(player) {
	try {
		const guideDialog = new ModalFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.settings.title", with: { rawtext: [ { text: "\n" }]} });
		const minigameMusicEnabled = player.getDynamicProperty("ljw_ch:setting_minigame_music_enabled") ?? true;
		
		guideDialog.toggle({ translate: `ljw_ch.info_book.settings.minigame_music.toggle`, with: { rawtext: [ { text: "\n" }]} }, {defaultValue: minigameMusicEnabled, tooltip: { translate: "", with: { rawtext: [{ text: "\n" }] }}});
		
		guideDialog.show(player).then((formData) => {
			if (formData.canceled || formData == undefined)
				open_guide(player);
			else {
				player.setDynamicProperty("ljw_ch:setting_minigame_music_enabled", formData.formValues[0]);
			}
		}).catch((err) => {
			debug.error(`Info Book error: ${err}`);
		});
	}
	catch (err) {
		debug.error(`Info Book error: ${err}`)
	}
}

function open_credits(player) {
	try {
		const guideDialog = new ActionFormData();
		const version = "1.0.0";
		
		guideDialog.title({ translate: "ljw_ch.info_book.about.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body({ translate: `ljw_ch.info_book.about.body`, with: { rawtext: [ { text: "\n" }, { text: version }]} });
		
		guideDialog.button({ translate: "ljw_ch.info_book.about.button.changelog", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.info_book.about.button.special_thanks", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_changelog(player);
			else if (response.selection == 1)
				open_thanks(player);
			else if (response.selection == 2)
				open_guide(player);
			else if (response.selection == 3)
				return;
		});
	}
	catch (err) {
		debug.error(`Credits error: ${err}`)
	}
}

function open_changelog(player) {
	try {
		const guideDialog = new ActionFormData();
		let content = "";
		
		content += `§lTiny Takeover: Mini Mania v1.0.0§r\n- Initial Release!`
		content += `\n\n`
		
		guideDialog.title({ translate: "ljw_ch.info_book.changelog.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body(content.replaceAll("- ", "§e§l>§r "));
		
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == 0)
				open_guide(player);
			else if (response.selection == 1)
				return;
		});
	}
	catch (err) {
		debug.error(`Changelog error: ${err}`)
	}
}

const thanksList = [
	{ name: "FleischVogel", role: "Art"},
	{ name: "Jassen Scharifie", role: "Marketing"},
	{ name: "Kaioga", role: "Dev"},
	{ name: "Pixerkk", role: "Art"}
]

const roleIconMappings = {
	"Art": "textures/ui/color_picker",
	"Audio": "textures/items/record_cat",
	"Dev": "textures/ui/dev_glyph_color",
	"Marketing": "textures/ui/camera-yo",
	"Testing": "textures/ui/controller_glyph_color"
}

function open_thanks(player) {
	try {
		const guideDialog = new ActionFormData();
		
		guideDialog.title({ translate: "ljw_ch.info_book.special_thanks.title", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.body({ translate: "ljw_ch.info_book.special_thanks.body", with: { rawtext: [ { text: "\n" }]} });
		
		for (const entry of thanksList) {
			guideDialog.button(`${entry.name}`, roleIconMappings[entry.role]);
		}
		
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.exit", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then(response => {
			if (response.canceled || response.selection == undefined)
				return;
			else if (response.selection == thanksList.length)
				open_credits(player);
			else if (response.selection == thanksList.length + 1)
				return;
			else
				open_thanks(player);
		});
	}
	catch (err) {
		debug.error(`Thanks List error: ${err}`)
	}
}

function open_minigame_menu(player) {
	try {
		const minigameId = player.getDynamicProperty("ljw_ch:minigame_id");
		const guideDialog = new ActionFormData();
		guideDialog.title({ translate: `ljw_ch.info_book.minigame_menu.title` });
		guideDialog.body({ translate: `ljw_ch.info_book.minigame_menu.body`, with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.button({ translate: "ljw_ch.general.button.confirm", with: { rawtext: [ { text: "\n" }]} });
		guideDialog.button({ translate: "ljw_ch.general.button.back", with: { rawtext: [ { text: "\n" }]} });
		
		guideDialog.show(player).then((response) => {
			if (response?.selection != null) {
				if (response.selection == 0)
					player.runCommand(`scriptevent ljw_ch:stop_minigame ${minigameId}`);
			}
		});
	}
	catch (err) {
		debug.error(`Minigame Menu Error: ${err}`)
	}
}

function build_filtered_plushie_list() {
	for (let i = 0; i < plushieArray.length; i += 1) {
		const name = plushieArray[i];
		const entry = plushies.plushieList[name];
		if (!entry.subVariant) {
			plushieArrayNoSubVariants.push(name);
		}
	}
}
system.run(build_filtered_plushie_list);