import { world, system } from "@minecraft/server";
import * as plushies from "../data/plushies";

const SPAWN_CHANCE = 0.01;

const TARGET_TYPES = new Set([
  "minecraft:zombie",
  "minecraft:zombie_villager",
  "minecraft:husk",
  "minecraft:drowned",
  "minecraft:skeleton",
  "minecraft:stray",
  "minecraft:wither_skeleton",
  "minecraft:bogged",
]);

const PLUSHIE_HATS = Object.keys(plushies.plushieList);

function entityIsValid(entity) {
  try {
    if (!entity) return false;
    if (typeof entity.isValid === "function") return entity.isValid();
    if (typeof entity.isValid === "boolean") return entity.isValid;
    return typeof entity.typeId === "string";
  } catch {
    return false;
  }
}

export function register() {
  world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (!TARGET_TYPES.has(entity.typeId)) return;
    if (Math.random() >= SPAWN_CHANCE) return;

    const hatId = PLUSHIE_HATS[Math.floor(Math.random() * PLUSHIE_HATS.length)];

    system.runTimeout(() => {
      try {
        if (!entityIsValid(entity)) return;
        entity.runCommand(`replaceitem entity @s slot.armor.head 0 ${hatId} 1`);
      } catch {}
    }, 5);
  });
}
