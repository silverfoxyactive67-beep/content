import { EntityComponentTypes, EquipmentSlot, system, world } from "@minecraft/server";
import * as debug from "../debug_functions";

const DINNERBONE_NAME = "Dinnerbone";
const JEB_NAME = "jeb_";
const CYCLE_INTERVAL_TICKS = 4;

let isRegistered = false;

function tickNamedHatEffects() {
	for (const player of world.getAllPlayers()) {
		const equippable = player.getComponent(EntityComponentTypes.Equippable);
		if (!equippable) {
			continue;
		}

		const headItem = equippable.getEquipment(EquipmentSlot.Head);

		if (!headItem || !headItem.hasTag("ljw_ch:plushie_reward")) {
			continue;
		}

		try {
			const durabilityComponent = headItem.getComponent('durability');
			if (durabilityComponent != null) {
				const damage = durabilityComponent.damage;
				const damageMax = durabilityComponent.maxDurability;
				
				// Dinnerbone
				const hasDinnerboneEffect = (damage > 8) && (damage <= 18);
				const shouldHaveDinnerboneEffect = (headItem.nameTag == DINNERBONE_NAME);
				const needsDinnerboneUpdate = (hasDinnerboneEffect != shouldHaveDinnerboneEffect);
				if (needsDinnerboneUpdate) {
					durabilityComponent.damage = Math.min((shouldHaveDinnerboneEffect ? 10 : 0), damageMax);
					equippable.setEquipment(EquipmentSlot.Head, headItem);
					return;
				}
				
				// Jeb
				const hasJebEffect = (damage > 18) && (damage <= 28);
				const shouldHaveJebEffect = (headItem.typeId.includes("plushie_baby_sheep")) && (headItem.nameTag == JEB_NAME);
				const needsJebUpdate = (hasJebEffect != shouldHaveJebEffect);
				if (needsJebUpdate) {
					durabilityComponent.damage = Math.min((shouldHaveJebEffect ? 20 : 0), damageMax);
					equippable.setEquipment(EquipmentSlot.Head, headItem);
					return;
				}
			}
		} 
		catch(err){
			debug.warn(`Hat Dynamics error: ${err}`);
		}
	}
}

export function register() {
	if (isRegistered) {
		return;
	}

	isRegistered = true;
	system.runInterval(tickNamedHatEffects, CYCLE_INTERVAL_TICKS);
}
