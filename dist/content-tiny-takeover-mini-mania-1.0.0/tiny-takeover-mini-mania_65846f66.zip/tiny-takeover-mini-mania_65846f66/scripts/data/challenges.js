import * as debug from "../debug_functions";
import * as util from "../util";

export const questList = {
	//"kitten_tamer": { // Tame a Kitten
	//	type: "one_shot",
	//	group: "adventure"
	//},
	//"golden_flower": { // Obtain a Golden Dandelion
	//	type: "one_shot",
	//	group: "adventure"
	//},
	//"golden_decor": { // Place a Golden Dandelion in a Flower Pot
	//	type: "one_shot",
	//	group: "adventure"
	//},
	//"dangerously_cute": { // Use a name tag on a baby zombie mob
	//	type: "one_shot",
	//	group: "adventure"
	//},
	//"eternal_youth": { // Use a golden dandelion on a mob to pause growth
	//	type: "one_shot",
	//	group: "adventure"
	//},
	//"golden_distraction": { // Distract a piglin with a golden dandelion
	//	type: "one_shot",
	//	group: "adventure"
	//},
	//"eternal_life": { // Use a golden dandelion on a mob to resume growth. Can't detect pause/unpause separately
	//	type: "one_shot",
	//	group: "adventure",
	//	rewardPoints: 150
	//},
	//"rainbow_road": { // Gather all 16 colors of baby sheep. Does not work because we can't read sheep color values!
	//	type: "one_shot"
	//},
	//"golden_stew": { // Feed a brown mooshroom a golden dandelion, then milk it with a bowl. Sometimes does not successfully read mark_variant.
	//	type: "one_shot",
	//	group: "adventure",
	//	rewardPoints: 250
	//},
	// Find all baby mob variants
	"find_an_armadillo": {
		type: "total",
		goal: 1
	},
	"startle_an_armadillo": {
		type: "one_shot"
	},
	"feed_a_armadillo": {
		type: "one_shot"
	},
	"find_an_axolotl": {
		type: "total",
		goal: 1
	},
	"bucket_an_axolotl": {
		type: "one_shot"
	},
	"feed_a_axolotl": {
		type: "one_shot"
	},
	"find_all_axolotls": {
		type: "total",
		goal: 5,
		prerequisites: [ "find_an_axolotl" ]
	},
	"find_a_bee": {
		type: "total",
		goal: 1
	},
	"bee_pollinator": {
		type: "one_shot"
	},
	"feed_a_bee": {
		type: "one_shot"
	},
	"find_a_camel": {
		type: "total",
		goal: 1
	},
	"camel_relaxation": {
		type: "one_shot"
	},
	"feed_a_camel": {
		type: "one_shot"
	},
	"find_a_cat": {
		type: "total",
		goal: 1
	},
	"receive_cat_gift": {
		type: "one_shot"
	},
	"feed_a_cat": {
		type: "one_shot"
	},
	"find_all_cats": {
		type: "total",
		goal: 11,
		prerequisites: [ "find_a_cat" ]
	},
	"find_a_chicken": {
		type: "total",
		goal: 1
	},
	"floating_chicken": {
		type: "one_shot"
	},
	"feed_a_chicken": {
		type: "one_shot"
	},
	"find_all_chickens": {
		type: "total",
		goal: 3,
		prerequisites: [ "find_a_chicken" ]
	},
	"find_a_cow": {
		type: "total",
		goal: 1
	},
	"dandelion_cow": {
		type: "one_shot"
	},
	"feed_a_cow": {
		type: "one_shot"
	},
	"find_all_cows": {
		type: "total",
		goal: 3,
		prerequisites: [ "find_a_cow" ]
	},
	"find_a_dolphin": {
		type: "total",
		goal: 1
	},
	"dolphin_swim": {
		type: "one_shot"
	},
	"feed_a_dolphin": {
		type: "one_shot"
	},
	"find_a_donkey": {
		type: "total",
		goal: 1
	},
	"dandelion_donkey": {
		type: "one_shot"
	},
	"feed_a_donkey": {
		type: "one_shot"
	},
	"find_a_drowned": {
		type: "total",
		goal: 1
	},
	"zombie_to_drowned": {
		type: "one_shot"
	},
	"drowned_name": {
		type: "one_shot"
	},
	"find_a_fox": {
		type: "total",
		goal: 1
	},
	"trust_fox": {
		type: "one_shot"
	},
	"feed_a_fox": {
		type: "one_shot"
	},
	"find_all_foxes": {
		type: "total",
		goal: 2,
		prerequisites: [ "find_a_fox" ]
	},
	"find_a_glow_squid": {
		type: "total",
		goal: 1
	},
	"dandelion_glow_squid": {
		type: "one_shot"
	},
	"find_a_goat": {
		type: "total",
		goal: 1
	},
	"goat_ram": {
		type: "one_shot"
	},
	"feed_a_goat": {
		type: "one_shot"
	},
	"find_a_hoglin": {
		type: "total",
		goal: 1
	},
	"hoglin_scare_fungus": {
		type: "one_shot"
	},
	"feed_a_hoglin": {
		type: "one_shot"
	},
	"find_a_horse": {
		type: "total",
		goal: 1
	},
	"dandelion_horse": {
		type: "one_shot"
	},
	"feed_a_horse": {
		type: "one_shot"
	},
	"find_all_horses": {
		type: "total",
		goal: 7,
		prerequisites: [ "find_a_horse" ]
	},
	"find_a_husk": {
		type: "total",
		goal: 1
	},
	"husk_to_zombie": {
		type: "one_shot"
	},
	"husk_daylight": {
		type: "one_shot"
	},
	"find_a_llama": {
		type: "total",
		goal: 1
	},
	"lama_wolf_anger": {
		type: "one_shot"
	},
	"feed_a_llama": {
		type: "one_shot"
	},
	"find_all_llamas": {
		type: "total",
		goal: 4,
		prerequisites: [ "find_a_llama" ]
	},
	"find_a_mooshroom": {
		type: "total",
		goal: 1
	},
	"lightning_mooshroom": {
		type: "one_shot"
	},
	"feed_a_mooshroom": {
		type: "one_shot"
	},
	"find_all_mooshrooms": {
		type: "total",
		goal: 2,
		prerequisites: [ "find_a_mooshroom" ]
	},
	"find_a_mule": {
		type: "total",
		goal: 1
	},
	"mule_discovery": {
		type: "one_shot"
	},
	"feed_a_mule": {
		type: "one_shot"
	},
	"find_an_ocelot": {
		type: "total",
		goal: 1
	},
	"dandelion_ocelot": {
		type: "one_shot"
	},
	"feed_a_ocelot": {
		type: "one_shot"
	},
	"find_a_panda": {
		type: "total",
		goal: 1
	},
	"find_brown_panda": {
		type: "one_shot"
	},
	"feed_a_panda": {
		type: "one_shot"
	},
	"find_all_pandas": {
		type: "total",
		goal: 7,
		prerequisites: [ "find_a_panda" ]
	},
	"find_a_pig": {
		type: "total",
		goal: 1
	},
	"dandelion_pig": {
		type: "one_shot"
	},
	"feed_a_pig": {
		type: "one_shot"
	},
	"find_all_pigs": {
		type: "total",
		goal: 3,
		prerequisites: [ "find_a_pig" ]
	},
	"find_a_piglin": {
		type: "total",
		goal: 1
	},
	"hoglin_rider": {
		type: "one_shot"
	},
	"gold_collector": {
		type: "one_shot"
	},
	"find_a_polar_bear": {
		type: "total",
		goal: 1
	},
	"startle_polar_bear": {
		type: "one_shot"
	},
	"dandelion_polar_bear": {
		type: "one_shot"
	},
	"find_a_rabbit": {
		type: "total",
		goal: 1
	},
	"dandelion_rabbit": {
		type: "one_shot"
	},
	"feed_a_rabbit": {
		type: "one_shot"
	},
	"find_all_rabbits": {
		type: "total",
		goal: 6,
		prerequisites: [ "find_a_rabbit" ]
	},
	"find_a_sheep": {
		type: "total",
		goal: 1
	},
	"sheep_grazing": {
		type: "one_shot"
	},
	"feed_a_sheep": {
		type: "one_shot"
	},
	//"find_all_sheep": { // Does not work because we can't read sheep color values!
	//	type: "total",
	//	goal: 16,
	//	prerequisites: [ "find_a_sheep" ]
	//},
	"find_a_sniffer": {
		type: "total",
		goal: 1
	},
	"dandelion_sniffer": {
		type: "one_shot"
	},
	"feed_a_sniffer": {
		type: "one_shot"
	},
	"find_a_squid": {
		type: "total",
		goal: 1
	},
	"dandelion_squid": {
		type: "one_shot"
	},
	"find_a_strider": {
		type: "total",
		goal: 1
	},
	"cold_strider": {
		type: "one_shot"
	},
	"feed_a_strider": {
		type: "one_shot"
	},
	"find_a_trader_llama": {
		type: "total",
		goal: 1
	},
	"trader_llama_defender": {
		type: "one_shot"
	},
	"feed_a_trader_llama": {
		type: "one_shot"
	},
	"find_all_trader_llamas": {
		type: "total",
		goal: 4,
		prerequisites: [ "find_a_trader_llama" ]
	},
	"find_a_turtle": {
		type: "total",
		goal: 1
	},
	"turtle_scute": {
		type: "one_shot"
	},
	"feed_a_turtle": {
		type: "one_shot"
	},
	"find_a_villager": {
		type: "total",
		goal: 1
	},
	"zombie_villager_cure": {
		type: "one_shot"
	},
	"find_all_villagers": {
		type: "total",
		goal: 7,
		prerequisites: [ "find_a_villager" ]
	},
	"find_a_wolf": {
		type: "total",
		goal: 1
	},
	"puppy_tamer": { // Tame a Puppy
		type: "one_shot"
	},
	"feed_a_wolf": {
		type: "one_shot"
	},
	"find_all_wolves": {
		type: "total",
		goal: 1, // Unable to read variant component for some reason, so set to 1 instead of 9
		prerequisites: [ "find_a_wolf" ]
	},
	"find_a_zoglin": {
		type: "total",
		goal: 1
	},
	"find_a_zoglin": {
		type: "total",
		goal: 1
	},
	"zoglin_swimmer": {
		type: "one_shot"
	},
	"zoglin_daylight": {
		type: "one_shot"
	},
	"find_a_zombie": {
		type: "total",
		goal: 1
	},
	"find_a_zombie_piglin": {
		type: "total",
		goal: 1
	},
	"piglin_scared_by_zombie": {
		type: "one_shot"
	},
	"overworld_zombie_piglin": {
		type: "one_shot"
	},
	"find_a_zombie_villager": {
		type: "total",
		goal: 1
	},
	"zombie_villager_swimmer": {
		type: "one_shot"
	}
};

export function validate(player, questId) {
	const quest = questList[questId];
	if (!quest) {
		debug.warn(`Attempted to validate unknown quest: ${questId}`)
		return false;
	}
	
	const questsCompleteOverride = player.getDynamicProperty("ljw_ch:cheat_quests_complete") ?? false;
	
	if (questsCompleteOverride) {
		return true;
	}
	
	if (quest.type == "one_shot") {
		const completed = player.getDynamicProperty(`ljw_ch:quest_${questId}`) ?? false;
		//if (completed) {
		//	debug.info(`${player.nameTag} has completed quest: [${questId}]`);
		//}
		return (completed);
	}
	else if (quest.type == "count") {
		const completed = (player.getDynamicProperty(`ljw_ch:quest_${questId}`) ?? 0) >= quest.goal;
		//if (completed) {
		//	debug.info(`${player.nameTag} has completed quest: [${questId}]`);
		//}
		return (completed);
	}
	else if (quest.type == "total") {
		const goal = quest.goal;
		const currentDataString = (player.getDynamicProperty(`ljw_ch:quest_${questId}`) ?? "");
		const currentData = currentDataString.split(";");
		const completed = (currentData.length - 1) >= goal;
		//if (completed) {
		//	debug.info(`${player.nameTag} has completed quest: [${questId}]`);
		//}
		return (completed);
	}
	else {
		debug.error(`Unknown quest type: ${quest.type}`);
		return false;
	}
}

export function increment(player, questId, newData = "") {
	const quest = questList[questId];
	if (!quest) {
		debug.warn(`Attempted to increment unknown quest: ${questId}`)
		return false;
	}
	try {
		if (quest.type == "one_shot") {
			const currentScore = (player.getDynamicProperty(`ljw_ch:quest_${questId}`) ?? false);
			if (!currentScore) {
				player.setDynamicProperty(`ljw_ch:quest_${questId}`, true);
				completed_quest(player, questId);
			}
			return true;
		}
		else if (quest.type == "count") {
			const goal = quest.goal;
			const currentScore = (player.getDynamicProperty(`ljw_ch:quest_${questId}`) ?? 0);
			if (currentScore >= goal) {
				return true;
			}
			else {
				const newCount = currentScore + 1;
				player.setDynamicProperty(`ljw_ch:quest_${questId}`, newCount);
				if (newCount >= goal) {
					completed_quest(player, questId);
				}
				else {
					debug.info(`${player.nameTag} just progressed quest: [${questId}] | ${newCount} / ${goal}`);
				}
				return (newCount >= goal);
			}
		}
		else if (quest.type == "total") {
			const goal = quest.goal;
			const currentDataString = (player.getDynamicProperty(`ljw_ch:quest_${questId}`) ?? "");
			const currentData = currentDataString.split(";");
			if ((currentData.length - 1) >= goal) {
				return true;
			}
			else {
				if (currentData.includes(newData)) {
					debug.info(`${player.nameTag} already has data ${newData}: [${questId}] | ${currentData} | ${currentData.length - 1} / ${goal}`);
					return false;
				}
				else {
					if (newData != "") {
						currentData.push(newData);
						player.setDynamicProperty(`ljw_ch:quest_${questId}`, currentData.join(";"));
						if (currentData.length - 1 >= goal) {
							completed_quest(player, questId);
						}
						else {
							debug.info(`${player.nameTag} just progressed quest: [${questId}] | ${currentData} | ${currentData.length - 1} / ${goal}`);
						}
						return (currentData.length - 1 >= goal);
					}
					else {
						return false;
					}
				}
			}
		}
	}
	catch(err) {
		debug.error(`Error processing quest [${questId}]: ${err}`);
	}
}

function completed_quest(player, questId) {
	debug.info(`${player.nameTag} just completed quest: [${questId}]`);
	increment_points(player, 100);
	if (util.countItem(player, "ljw_ch:info_book") > 0) {
		player.sendMessage({translate: "ljw_ch.message.discovery_journal_entry_unlocked"});
	}
}

function increment_points(player, amount = 0) {
	const currentPoints = player.getDynamicProperty("ljw_ch:points") ?? 0;
	player.setDynamicProperty("ljw_ch:points", Math.max(0, currentPoints + amount));
}

export function reset_all(player) {
	for (const questId of Object.keys(questList)) {
		player.setDynamicProperty(`ljw_ch:quest_${questId}`);
	}
}

export const defaultRewardPoints = 100;

export const discoverableBabyMobChallenges = {
	"minecraft:armadillo": [ "find_an_armadillo", "startle_an_armadillo", "feed_a_armadillo" ],
	"minecraft:axolotl": [ "find_an_axolotl", "bucket_an_axolotl", "feed_a_axolotl", "find_all_axolotls" ],
	"minecraft:bee": [ "find_a_bee", "bee_pollinator", "feed_a_bee" ],
	"minecraft:camel": [ "find_a_camel", "camel_relaxation", "feed_a_camel" ],
	"minecraft:cat": [ "find_a_cat", "receive_cat_gift", "feed_a_cat", "find_all_cats" ],
	"minecraft:chicken": [ "find_a_chicken", "floating_chicken", "feed_a_chicken", "find_all_chickens" ],
	"minecraft:cow": [ "find_a_cow", "dandelion_cow", "feed_a_cow", "find_all_cows" ],
	"minecraft:dolphin": [ "find_a_dolphin", "dolphin_swim", "feed_a_dolphin" ],
	"minecraft:donkey": [ "find_a_donkey", "dandelion_donkey", "feed_a_donkey" ],
	"minecraft:drowned": [ "find_a_drowned", "zombie_to_drowned", "drowned_name" ],
	"minecraft:fox": [ "find_a_fox", "trust_fox", "feed_a_fox", "find_all_foxes" ],
	"minecraft:glow_squid": [ "find_a_glow_squid", "find_a_glow_squid", "dandelion_glow_squid" ],
	"minecraft:goat": [ "find_a_goat", "goat_ram", "feed_a_goat" ],
	"minecraft:hoglin": [ "find_a_hoglin", "hoglin_scare_fungus", "feed_a_hoglin" ],
	"minecraft:horse": [ "find_a_horse", "dandelion_horse", "feed_a_horse", "find_all_horses" ],
	"minecraft:husk": [ "find_a_husk", "husk_to_zombie", "husk_daylight" ],
	"minecraft:llama": [ "find_a_llama", "lama_wolf_anger", "feed_a_llama", "find_all_llamas" ],
	"minecraft:mooshroom": [ "find_a_mooshroom", "lightning_mooshroom", "feed_a_mooshroom", "find_all_mooshrooms" ],
	"minecraft:mule": [ "find_a_mule", "mule_discovery", "feed_a_mule" ],
	"minecraft:ocelot": [ "find_an_ocelot", "dandelion_ocelot", "feed_a_ocelot" ],
	"minecraft:panda": [ "find_a_panda", "find_brown_panda", "feed_a_panda", "find_all_pandas" ],
	"minecraft:pig": [ "find_a_pig", "dandelion_pig", "feed_a_pig", "find_all_pigs" ],
	"minecraft:piglin": [ "find_a_piglin", "find_a_piglin", "gold_collector" ],
	"minecraft:polar_bear": [ "find_a_polar_bear", "startle_polar_bear", "dandelion_polar_bear" ],
	"minecraft:rabbit": [ "find_a_rabbit", "dandelion_rabbit", "feed_a_rabbit", "find_all_rabbits" ],
	"minecraft:sheep": [ "find_a_sheep", "sheep_grazing", "feed_a_sheep" ],
	"minecraft:sniffer": [ "find_a_sniffer", "dandelion_sniffer", "feed_a_sniffer" ],
	"minecraft:squid": [ "find_a_squid", "find_a_squid", "dandelion_squid" ],
	"minecraft:strider": [ "find_a_strider", "cold_strider", "feed_a_strider" ],
	//"minecraft:trader_llama": [ "find_a_trader_llama", "trader_llama_defender", "feed_a_trader_llama", "find_all_trader_llamas" ],
	"minecraft:turtle": [ "find_a_turtle", "turtle_scute", "feed_a_turtle" ],
	"minecraft:villager_v2": [ "find_a_villager", "zombie_villager_cure", "find_a_villager", "find_all_villagers" ],
	"minecraft:wolf": [ "find_a_wolf", "puppy_tamer", "feed_a_wolf", "find_all_wolves" ],
	"minecraft:zoglin": [ "find_a_zoglin", "zoglin_swimmer", "zoglin_daylight" ],
	"minecraft:zombie": [ "find_a_zombie", "husk_to_zombie", "zombie_to_drowned" ],
	"minecraft:zombie_pigman": [ "find_a_zombie_piglin", "piglin_scared_by_zombie", "overworld_zombie_piglin" ],
	"minecraft:zombie_villager_v2": [ "find_a_zombie_villager", "zombie_villager_cure", "zombie_villager_swimmer" ],
}

export const discoverableBabyMobChallengeEvents = {
	"minecraft:armadillo": {
		"minecraft:threat_detected": "startle_an_armadillo"
	},
	"minecraft:bee": { 
		"collected_nectar": "bee_pollinator"
	},
	"minecraft:camel": {
		"minecraft:start_sitting": "camel_relaxation"
	},
	"minecraft:cat": {
		"minecraft:pet_slept_with_owner": "receive_cat_gift"
	},
	"minecraft:husk": {
		"minecraft:convert_to_zombie": "husk_to_zombie"
	},
	"minecraft:fox": {
		"minecraft:entity_born": "trust_fox"
	},
	"minecraft:hoglin": {
		"escaped_event": "hoglin_scare_fungus"
	},
	"minecraft:llama": {
		"minecraft:mad_at_wolf": "lama_wolf_anger"
	},
	"minecraft:mooshroom": {
		"minecraft:become_brown": "lightning_mooshroom",
		"minecraft:become_red": "lightning_mooshroom"
	},
	"minecraft:mule": {
		"minecraft:entity_born": "mule_discovery"
	},
	"minecraft:polar_bear": {
		"minecraft:on_scared": "startle_polar_bear"
	},
	"minecraft:sheep": {
		"minecraft:on_eat_block": "sheep_grazing"
	},
	"minecraft:strider": {
		"start_suffocating": "cold_strider"
	},
	"minecraft:turtle": {
		"minecraft:ageable_grow_up": "turtle_scute"
	},
	//"minecraft:trader_llama": {
	//	"minecraft:defend_wandering_trader": "trader_llama_defender"
	//},
	"minecraft:villager_v2": {
		"minecraft:entity_transformed": "zombie_villager_cure",
		"minecraft:ageable_grow_up": "villager_grow_up"
	},
	"minecraft:zombie": {
		"minecraft:convert_to_drowned": "zombie_to_drowned"
	},
	"minecraft:piglin": {
		"become_calm_event": "piglin_scared_by_zombie"
	}
}

export const discoverableBabyMobDandelionChallenges = [
	"minecraft:cow",
	"minecraft:donkey",
	"minecraft:glow_squid",
	"minecraft:horse",
	"minecraft:ocelot",
	"minecraft:pig",
	"minecraft:polar_bear",
	"minecraft:rabbit",
	"minecraft:sniffer",
	"minecraft:squid"
]

export const discoverableBabyMobFoodItems = {
	"minecraft:armadillo": [ 
		"minecraft:spider_eye"
	],
	"minecraft:axolotl": [ 
		"minecraft:tropical_fish_bucket"
	],
	"minecraft:bee": [
		"minecraft:poppy",
		"minecraft:blue_orchid",
		"minecraft:allium",
		"minecraft:azure_bluet",
		"minecraft:red_tulip",
		"minecraft:orange_tulip",
		"minecraft:white_tulip",
		"minecraft:pink_tulip",
		"minecraft:oxeye_daisy",
		"minecraft:cornflower",
		"minecraft:lily_of_the_valley",
		"minecraft:dandelion",
		"minecraft:wither_rose",
		"minecraft:sunflower",
		"minecraft:lilac",
		"minecraft:rose_bush",
		"minecraft:peony",
		"minecraft:flowering_azalea",
		"minecraft:azalea_leaves_flowered",
		"minecraft:mangrove_propagule",
		"minecraft:pitcher_plant",
		"minecraft:torchflower",
		"minecraft:cherry_leaves",
		"minecraft:pink_petals",
		"minecraft:wildflowers",
		"minecraft:cactus_flower"
	],
	"minecraft:camel": [ 
		"minecraft:cactus" 
	],
	"minecraft:cat": [ 
		"minecraft:cod",
		"minecraft:salmon" 
	],
	"minecraft:chicken": [
		"minecraft:wheat_seeds",
		"minecraft:beetroot_seeds",
		"minecraft:melon_seeds",
		"minecraft:pumpkin_seeds",
		"minecraft:pitcher_pod",
		"minecraft:torchflower_seeds"
	],
	"minecraft:cow": [ 
		"minecraft:wheat" 
	],
	"minecraft:dolphin": [ 
		"minecraft:cod",
		"minecraft:salmon" 
	],
	"minecraft:donkey": [ 
		"minecraft:wheat", 
		"minecraft:sugar", 
		"minecraft:hay_block", 
		"minecraft:apple", 
		"minecraft:carrot", 
		"minecraft:golden_carrot", 
		"minecraft:golden_apple", 
		"minecraft:enchanted_golden_apple" 
	],
	"minecraft:fox": [ 
		"minecraft:sweet_berries",
		"minecraft:glow_berries" 
	],
	"minecraft:goat": [ 
		"minecraft:wheat" 
	],
	"minecraft:hoglin": [ 
		"minecraft:crimson_fungus" 
	],
	"minecraft:horse": [ 
		"minecraft:wheat", 
		"minecraft:sugar", 
		"minecraft:hay_block", 
		"minecraft:apple", 
		"minecraft:carrot", 
		"minecraft:golden_carrot", 
		"minecraft:golden_apple", 
		"minecraft:enchanted_golden_apple" 
	],
	"minecraft:llama": [ 
		"minecraft:wheat", 
		"minecraft:hay_block"
	],
	"minecraft:mooshroom": [ 
		"minecraft:wheat" 
	],
	"minecraft:mule": [ 
		"minecraft:wheat", 
		"minecraft:sugar", 
		"minecraft:hay_block", 
		"minecraft:apple", 
		"minecraft:carrot", 
		"minecraft:golden_carrot", 
		"minecraft:golden_apple", 
		"minecraft:enchanted_golden_apple" 
	],
	"minecraft:ocelot": [ 
		"minecraft:cod",
		"minecraft:salmon" 
	],
	"minecraft:panda": [ 
		"minecraft:bamboo" 
	],
	"minecraft:pig": [ 
		"minecraft:carrot",
		"minecraft:beetroot",
		"minecraft:potato" 
	],
	"minecraft:rabbit": [ 
		"minecraft:golden_carrot",
		"minecraft:carrot",
		"minecraft:dandelion" 
	],
	"minecraft:sheep": [ 
		"minecraft:wheat" 
	],
	"minecraft:sniffer": [ 
		"minecraft:torchflower_seeds" 
	],
	"minecraft:strider": [ 
		"minecraft:warped_fungus" 
	],
	"minecraft:trader_llama": [ 
		"minecraft:wheat",
		"minecraft:hay_block"
	],
	"minecraft:turtle": [ 
		"minecraft:seagrass" 
	],
	"minecraft:wolf": [
		"minecraft:chicken",
		"minecraft:cooked_chicken",
		"minecraft:beef",
		"minecraft:cooked_beef",
		"minecraft:mutton",
		"minecraft:cooked_mutton",
		"minecraft:porkchop",
		"minecraft:cooked_porkchop",
		"minecraft:rabbit",
		"minecraft:cooked_rabbit",
		"minecraft:rotten_flesh"
	]
}