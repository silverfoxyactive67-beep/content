## Create and initialize all scoreboard objectives used in the map
## Called from:
# "functions/INIT"

#!	Objective Creation

# Primary storage data
scoreboard objectives add noxcrew_ow:var dummy
scoreboard objectives add noxcrew_ow:xp_award dummy

# Jigarbov COMPUTERS integration
scoreboard objectives add noxcrew_ow:jig_computer.addon_stats dummy

#!	Fake player initialization

#? Perminant Storage data
#  Map Start Value
scoreboard players set .mapstart noxcrew_ow:var 0

#Jigarbov COMPUTERS integration
scoreboard players set "noxcrew_ow:owls_tamed" "noxcrew_ow:jig_computer.addon_stats" 0
scoreboard players set "noxcrew_ow:interactions.brewing_hat" "noxcrew_ow:jig_computer.addon_stats" 0
scoreboard players set "noxcrew_ow:interactions.poison_hood" "noxcrew_ow:jig_computer.addon_stats" 0
scoreboard players set "noxcrew_ow:interactions.reading_glasses" "noxcrew_ow:jig_computer.addon_stats" 0
scoreboard players set "noxcrew_ow:interactions.trans_goggles" "noxcrew_ow:jig_computer.addon_stats" 0