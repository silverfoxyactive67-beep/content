# This file allows players to call the current info of the map.

tellraw @a { "rawtext" : [ { "text" : "§c------------------" } ] }
tellraw @a { "rawtext" : [ { "text" : "§4Noxcrew" } ] }
tellraw @a { "rawtext" : [ { "text" : "§6Owl Addon" } ] }
tellraw @a { "rawtext" : [ { "text" : "Version/Status" } ] }
tellraw @a { "rawtext" : [ { "text" : "Behavior Pack Version §2[1, 2, 0]" } ] }
tellraw @a { "rawtext" : [ { "text" : "Resource Pack Version" } ] }
tellraw @a {"rawtext": [{"translate" : "txt.noxcrew.version"}]}
tellraw @a { "rawtext" : [ { "text" : "Have a hug! (.づ◡﹏◡)づ." } ] }
tellraw @a { "rawtext" : [ { "text" : "§c----Licensing-----" } ] }
tellraw @a {"rawtext": [{"translate" : "txt.noxcrew.licence.1"}]}
tellraw @a { "rawtext" : [ { "text" : "§c------------------" } ] }
