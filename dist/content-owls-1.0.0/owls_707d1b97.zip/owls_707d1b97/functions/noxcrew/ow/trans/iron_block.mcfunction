clear @s iron_block 0 1

scoreboard players set @s xp_award 308
function noxcrew/ow/trans/zStatic