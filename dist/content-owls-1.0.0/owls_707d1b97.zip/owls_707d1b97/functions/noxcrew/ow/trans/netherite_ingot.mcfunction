clear @s netherite_ingot 0 1

scoreboard players set @s xp_award 1388
function noxcrew/ow/trans/zStatic