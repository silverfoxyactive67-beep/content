clear @s copper_block 0 1

scoreboard players set @s xp_award 33
function noxcrew/ow/trans/zStatic