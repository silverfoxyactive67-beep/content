clear @s ancient_debris 0 1

scoreboard players set @s xp_award 308
function noxcrew/ow/trans/zStatic