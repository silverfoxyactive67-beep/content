clear @s raw_iron 0 1

scoreboard players set @s xp_award 9
function noxcrew/ow/trans/zStatic