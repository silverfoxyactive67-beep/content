playanimation @s transmutation_particle
playsound noxcrew_ow:owl_trans @a ~ ~ ~