clear @s iron_ingot 0 1

scoreboard players set @s xp_award 48
function noxcrew/ow/trans/zStatic