xp -1L @s
clear @s glass_bottle 0 1
give @s noxcrew_ow:bottled_level
execute at @s positioned ^ ^ ^2 as @e[family=owl,c=1] run playanimation @s transmutation_particle
scoreboard players add "noxcrew_ow:interactions.trans_goggles" "noxcrew_ow:jig_computer.addon_stats" 1