clear @s iron_nugget 0 1

scoreboard players set @s xp_award 0
function noxcrew/ow/trans/zStatic