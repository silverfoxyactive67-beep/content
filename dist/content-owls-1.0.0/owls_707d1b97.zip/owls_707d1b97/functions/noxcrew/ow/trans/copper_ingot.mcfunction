clear @s copper_ingot 0 1

scoreboard players set @s xp_award 9
function noxcrew/ow/trans/zStatic