clear @s gold_block 0 1

scoreboard players set @s xp_award 153
function noxcrew/ow/trans/zStatic