clear @s raw_copper_block 0 1

scoreboard players set @s xp_award 20
function noxcrew/ow/trans/zStatic