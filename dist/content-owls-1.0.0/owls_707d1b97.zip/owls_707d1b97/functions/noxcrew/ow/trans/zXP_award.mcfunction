#! THIS FUNCTION RUNS RECURSIVELY
## Called by all: 	noxcrew/ow/trans/zStatic
## Run by :			Player
## Purpose: 		Awards xp recursively based on the xp_award objective.


xp 1 @s
scoreboard players remove @s xp_award 1
execute as @s at @s if score @s xp_award matches ..7 run summon xp_orb ~ ~ ~
execute as @s if score @s xp_award matches 1.. run function noxcrew/ow/trans/zXP_award