## Called by all: 	noxcrew/ow/trans
## Run by :			Player
## Purpose: 		Trigger the recursive XP function, and play a particle.


## This function is recursive vv
function noxcrew/ow/trans/zXP_award

execute at @s positioned ^ ^ ^2 as @e[family=owl,c=1] at @s run function noxcrew/ow/trans/zEffects
scoreboard players add "noxcrew_ow:interactions.trans_goggles" "noxcrew_ow:jig_computer.addon_stats" 1