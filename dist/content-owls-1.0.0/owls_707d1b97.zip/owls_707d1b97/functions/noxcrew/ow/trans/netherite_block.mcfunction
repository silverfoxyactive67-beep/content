clear @s netherite_block 0 1

scoreboard players set @s xp_award 10260
function noxcrew/ow/trans/zStatic