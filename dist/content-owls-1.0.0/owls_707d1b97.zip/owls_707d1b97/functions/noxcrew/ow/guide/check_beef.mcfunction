## CALLED FROM: behavior_packs\N-OW-BP\dialogue\guide.json
## CALLED BY: NPC Guide Dialogue Button
## Runs when a player wants to trade in beef to the NPC, in exchange for Raw Rabbit.

execute unless entity @s[hasitem={item=minecraft:beef}] run function noxcrew/ow/guide/error
execute if entity @s[hasitem={item=minecraft:beef}] run function noxcrew/ow/guide/complete_beef