## CALLED FROM: behavior_packs\N-OW-BP\functions\noxcrew\ow\guide\check_mutton.mcfunction
## CALLED BY: When a player 
## Gives a player raw rabbit in exchange for beef.

clear @s minecraft:mutton 0 1
##playsound task_complete @s 
give @s minecraft:rabbit