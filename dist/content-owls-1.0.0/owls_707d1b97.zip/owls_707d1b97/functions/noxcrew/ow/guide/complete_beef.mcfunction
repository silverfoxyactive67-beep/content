## CALLED FROM: behavior_packs\N-OW-BP\functions\noxcrew\ow\guide\check_beef.mcfunction
## CALLED BY: When a player 
## Gives a player raw rabbit in exchange for beef.

clear @s minecraft:beef 0 1
##playsound task_complete @s 
give @s minecraft:rabbit