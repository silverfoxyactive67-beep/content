## CALLED FROM: behavior_packs\N-OW-BP\functions\noxcrew\ow\guide\check_pork.mcfunction
## CALLED BY: When a player 
## Gives a player raw rabbit in exchange for porkchop.

clear @s minecraft:porkchop 0 1
##playsound task_complete @s 
give @s minecraft:rabbit