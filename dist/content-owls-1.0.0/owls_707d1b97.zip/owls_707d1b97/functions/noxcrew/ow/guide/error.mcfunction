## CALLED FROM: behavior_packs\N-OW-BP\functions\noxcrew\ow\guide\check_pork.mcfunction and check_beef, and check_mutton in the same folder.
## CALLED BY: NPC Guide Dialogue Button
## Runs when a player wants to trade in beef to the NPC, but they don't have the item.

# Send error message and noise
# Ran as Player

##playsound task_no_item @s TO DO: Add a sound
titleraw @s actionbar {"rawtext": [{"translate" : "noxcrew_ow:txt.guide.4_0.error"}]}