## This plays on the first join of the add-on, then again any time we update the version.
## Called from initializeAddon.ts

tellraw @s {"rawtext": [{"translate" : "noxcrew_ow:txt.install.1"}]}
tellraw @s {"rawtext": [{"translate" : "noxcrew_ow:txt.install.2"}]}
tellraw @s {"rawtext": [{"translate" : "noxcrew_ow:txt.install.3"}]}