effect @a[r=4] regeneration 5 0 true
playsound noxcrew_ow:owl_amulet @a ~ ~ ~