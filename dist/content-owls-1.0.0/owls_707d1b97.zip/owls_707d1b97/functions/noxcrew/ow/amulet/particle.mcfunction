## CALLED FROM: toolbox/parents/entities/owl_base.json
## CALLED BY: Owls with healing amulets
## Runs every 4-8 seconds (or whatever we update the timer to). This command is solely to play particles/effects.

particle noxcrew_ow:warding_amulet ~ ~ ~