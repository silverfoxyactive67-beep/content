## Called by: 	behavior_packs\N-OW-BP\scripts\owlQuestSystem.ts
## Run by :	Player
## Purpose: Trigger if the player has a required item for the quest

scoreboard players set .check noxcrew_ow:var 0

# Night Vision (extended duration)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=6}] run scoreboard players set .check noxcrew_ow:var 1
# Leaping (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=11}] run scoreboard players set .check noxcrew_ow:var 1
# Swiftness (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=15}] run scoreboard players set .check noxcrew_ow:var 1
# Strength (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=33}] run scoreboard players set .check noxcrew_ow:var 1
# Slow Falling (extended duration)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=41}] run scoreboard players set .check noxcrew_ow:var 1
# Turtle Master (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=39}] run scoreboard players set .check noxcrew_ow:var 1
# Water Breathing (extended duration)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:potion,data=20}] run scoreboard players set .check noxcrew_ow:var 1
# Harming (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:splash_potion,data=24}] run scoreboard players set .check noxcrew_ow:var 1
# Fire Resistance (extended duration)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:splash_potion,data=13}] run scoreboard players set .check noxcrew_ow:var 1
# Healing (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:splash_potion,data=22}] run scoreboard players set .check noxcrew_ow:var 1
# Slowness (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:lingering_potion,data=42}] run scoreboard players set .check noxcrew_ow:var 1
# Weakness (enhanced power)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:lingering_potion,data=35}] run scoreboard players set .check noxcrew_ow:var 1
# Poison (enhanced duration)
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=minecraft:lingering_potion,data=26}] run scoreboard players set .check noxcrew_ow:var 1

execute if score .check noxcrew_ow:var matches 0 run scriptevent noxcrew_ow:quest_wrong
execute if score .check noxcrew_ow:var matches 1 run scriptevent noxcrew_ow:quest_increment