## Called by: 	behavior_packs\N-OW-BP\scripts\owlQuestSystem.ts
## Run by :	Player
## Purpose: Trigger if the player has a required item for the quest

scoreboard players set .check noxcrew_ow:var 0

# Feather Checks
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=noxcrew_ow:owl_feather}] run scoreboard players set .check noxcrew_ow:var 1
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=noxcrew_ow:colourful_feather}] run scoreboard players set .check noxcrew_ow:var 1
execute if score .check noxcrew_ow:var matches 0 if entity @s[hasitem={item=noxcrew_ow:mystic_feather}] run scoreboard players set .check noxcrew_ow:var 1

execute if score .check noxcrew_ow:var matches 0 run scriptevent noxcrew_ow:quest_wrong
execute if score .check noxcrew_ow:var matches 1 run scriptevent noxcrew_ow:quest_increment