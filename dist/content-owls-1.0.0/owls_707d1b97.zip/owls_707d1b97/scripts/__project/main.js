// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/di/container.js
var __classPrivateFieldGet = function(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _Container_instances;
var _Container_throw;
var InjectionError = class extends Error {
  /**
   * @param property The type that was being bound to or injected.
   * @param message The error message.
   */
  constructor(property2, message) {
    super(message != null ? `${property2.name}: ${message}` : property2.name);
    this.property = property2;
  }
};
var BIND_SUBCLASSES_KEY = "__noxcrew_bind_subclasses";
var Container = class _Container {
  constructor() {
    _Container_instances.add(this);
    this.types = /* @__PURE__ */ new Map();
  }
  static bindableTypes(type) {
    const out = [];
    let _proto = type.prototype;
    do {
      const ctor = _proto.constructor;
      if (ctor === type || ctor.hasOwnProperty(BIND_SUBCLASSES_KEY)) {
        out.push(ctor);
      }
      _proto = ctor.prototype ? Object.getPrototypeOf(ctor.prototype) : void 0;
    } while (_proto != void 0);
    return out;
  }
  /**
   * Binds an instance to a type.
   * @param instance the instance to bind
   * @param type the constructor of the type to bind, or the instance's own constructor by default
   * @throws InjectionError if an instance has already been bound for the type
   */
  bind(instance, type = instance.constructor) {
    const typesToBind = _Container.bindableTypes(type);
    for (const typeToBind of typesToBind) {
      if (this.types.has(typeToBind)) {
        throw new InjectionError(typeToBind, `Attempted re-registration`);
      }
      this.types.set(typeToBind, instance);
    }
  }
  /**
   * Unbinds a given type's bound instance, ignoring {@link BindSubclasses}-marked superclasse.
   * @param type the constructor of the type to unbind
   * @return true if the type had a bound instance which has been removed, false otherwise
   */
  unbindForType(type) {
    return this.types.delete(type);
  }
  /**
   * Unbinds an instance from a type, as well as any {@link BindSubclasses}-marked superclasses it's also bound to.
   * @param instance the instance to unbind
   * @param type the type to unbind from. Defaults to the instance's own constructor
   * @return true if the instance was bound to the type and was unbound, false otherwise
   */
  unbind(instance, type = instance.constructor) {
    let hasRemovedAType = false;
    for (const typeToUnbind of _Container.bindableTypes(type)) {
      if (this.types.get(typeToUnbind) === instance) {
        this.types.delete(typeToUnbind);
        hasRemovedAType = true;
      }
    }
    return hasRemovedAType;
  }
  /**
   * Eagerly fetches a type's bound instance.
   * @param type the type of object to get
   * @return the instance, or undefined if nothing is bound
   */
  getOrNull(type) {
    return this.types.get(type);
  }
  /**
   * Eagerly fetches a type's bound instance, throwing an {@link InjectionError} if nothing is bound.
   * @param type the type of object to get
   * @return the instance
   * @throws InjectionError if there's nothing bound to the type
   */
  get(type) {
    return this.getOrNull(type) ?? __classPrivateFieldGet(this, _Container_instances, "m", _Container_throw).call(this, type);
  }
  inject(type, nullable = false) {
    const realValue = () => nullable ? this.getOrNull(type) : this.get(type);
    return new Proxy({}, {
      set(target, p, newValue, receiver) {
        const value = realValue();
        if (value === void 0)
          return false;
        return Reflect.set(value, p, newValue, receiver);
      },
      get(target, p, receiver) {
        const value = realValue();
        if (value === void 0)
          return void 0;
        const val = Reflect.get(value, p, receiver);
        return typeof val === "function" ? val.bind(realValue()) : val;
      }
    });
  }
};
_Container_instances = /* @__PURE__ */ new WeakSet(), _Container_throw = function _Container_throw2(key) {
  throw new InjectionError(key, `Attempted to inject unbound type`);
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/util/buildInfo.js
var buildInfo;
async function getBuildInfo() {
  if (buildInfo == null)
    buildInfo = import(
      /*webpackIgnore: true*/
      "noxcrew.creative-toolbox.buildinfo"
    ).then((r) => r.default).catch(() => null);
  return await buildInfo;
}

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/util/getPlayersName.js
import { world } from "@minecraft/server";
function GetPlayerFromName(name) {
  return world.getPlayers({ name })[0];
}

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/util/multimap.js
var Multimap = class extends Map {
  /**
   * Adds a value to a key. If the key doesn't exist, it is created.
   * @param {TKey} key the key to add the value to
   * @param {TVal} value the value to add
   * @returns {Multimap<TKey, TVal>} the Multimap instance
   */
  add(key, value) {
    let array = this.get(key);
    if (!array) {
      array = [];
      super.set(key, array);
    }
    array.push(value);
    return this;
  }
  /**
   * Adds all values from the provided array to a key. If the key doesn't exist, it is created.
   * @param {TKey} key the key to add the values to
   * @param {TVal[]} val the array of values to add
   * @returns {Multimap<TKey, TVal>} The Multimap instance
   */
  addAll(key, val) {
    const existing = this.get(key);
    if (existing == null) {
      this.set(key, val);
      return this;
    }
    existing.push(...val);
    return this;
  }
  /**
   * Removes a value from every element array.
   * @param value the value to remove
   * @return a set of the keys that the element was removed from
   */
  removeValue(value) {
    const keys = /* @__PURE__ */ new Set();
    for (const [key, array] of this) {
      for (let idx = array.indexOf(value); idx != -1; idx = array.indexOf(value)) {
        keys.add(key);
        array.splice(idx, 1);
      }
    }
    return keys;
  }
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/util/propertyKey.js
function property(key) {
  return key;
}

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/module/module.js
var __classPrivateFieldGet2 = function(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = function(receiver, state, value, kind, f) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var _Module_isActive;
var _Module_childModules;
var Module = class {
  constructor(container) {
    this.container = container;
    this.listeners = new Multimap();
    _Module_isActive.set(this, false);
    _Module_childModules.set(this, /* @__PURE__ */ new Set());
    this.setup();
  }
  /** Override this method to add custom setup logic. */
  onActivate() {
  }
  /** Override this method to add custom teardown logic. */
  onDeactivate() {
  }
  /**
   * Listens for an event, tied to the lifecycle of the module.
   * @param signal the signal to listen for events from
   * @param callback the callback to invoke for the event
   * @protected
   */
  listenFor(signal, callback) {
    this.listeners.add(signal, callback);
    if (this.isActive) {
      signal.subscribe(callback);
    }
  }
  get isActive() {
    return __classPrivateFieldGet2(this, _Module_isActive, "f");
  }
  activate() {
    if (__classPrivateFieldGet2(this, _Module_isActive, "f"))
      throw new Error("Module is already loaded");
    try {
      this.onActivate();
      this.listeners.forEach((value, key) => {
        for (const callback of value) {
          key.subscribe(callback);
        }
      });
      __classPrivateFieldSet(this, _Module_isActive, true, "f");
      for (const childModule of __classPrivateFieldGet2(this, _Module_childModules, "f")) {
        childModule.activate();
      }
    } catch (e) {
      console.error(`Failed to load ${this.constructor.name}. Unloading.`);
      console.error(e);
      this.deactivate();
    }
  }
  deactivate() {
    if (!__classPrivateFieldGet2(this, _Module_isActive, "f"))
      throw new Error("Can't unload an already unloaded module");
    try {
      this.onDeactivate();
      this.listeners.forEach((value, key) => {
        for (const callback of value) {
          key.unsubscribe(callback);
        }
      });
      __classPrivateFieldSet(this, _Module_isActive, false, "f");
      for (const childModule of __classPrivateFieldGet2(this, _Module_childModules, "f")) {
        childModule.deactivate();
      }
    } catch (e) {
      console.error(`Failed to unload ${this.constructor.name}:`);
      console.error(e);
    }
  }
  get children() {
    return __classPrivateFieldGet2(this, _Module_childModules, "f");
  }
  /**
   * Registers a module as a child of this module.
   * Its activation state will be synchronised with this module.
   * @param child the module to register
   * @throws Error if the module has already been registered with this module or is already active
   */
  registerChild(child) {
    if (__classPrivateFieldGet2(this, _Module_childModules, "f").has(child))
      throw new Error("Can't re-register an already registered child module");
    if (child.isActive)
      throw new Error("Can't register an already active child module");
    __classPrivateFieldGet2(this, _Module_childModules, "f").add(child);
    if (this.isActive) {
      child.activate();
    }
  }
  /**
   * Unregisters a module as a child of this module.
   * Its activation state will be synchronised with this module.
   * @param child the module to unregister
   * @throws Error if the module has already been registered with this module or is already active
   */
  unregisterChild(child) {
    if (!__classPrivateFieldGet2(this, _Module_childModules, "f").has(child))
      throw new Error("Can't unregister a child module that's not registered");
    __classPrivateFieldGet2(this, _Module_childModules, "f").delete(child);
    if (child.isActive) {
      child.deactivate();
    }
  }
};
_Module_isActive = /* @__PURE__ */ new WeakMap(), _Module_childModules = /* @__PURE__ */ new WeakMap();

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/module/autoload.js
var AutoLoaderModule = class _AutoLoaderModule extends Module {
  constructor(container) {
    super(container);
  }
  setup() {
  }
  static async loadDependency(dependency) {
    return (await import(`${dependency}/__autoload.js`)).default;
  }
  /** Creates an {@link AutoLoaderModule} and auto-loads modules if needed. */
  static async createIfNeeded(entrypoint) {
    const buildInfo2 = await getBuildInfo();
    if (buildInfo2 == null || buildInfo2.autoload.length == 0)
      return;
    const modules = [];
    await Promise.all(buildInfo2.autoload.map(async (moduleName) => {
      try {
        const module = await this.loadDependency(moduleName);
        if (!(module instanceof Module)) {
          throw new TypeError(`Default export was not a module`);
        }
        modules.push(module);
      } catch (e) {
        console.error(`Error while autoloading ${moduleName}:`, e);
      }
    }));
    if (modules.length == 0)
      return;
    const autoloadModule = new _AutoLoaderModule(entrypoint);
    for (const child of modules) {
      autoloadModule.registerChild(child);
    }
    return autoloadModule;
  }
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/debugReport.js
import { system, Player } from "@minecraft/server";
var DebugReportModule = class _DebugReportModule extends Module {
  /**
   * Creates a debug report.
   */
  async createReport() {
    const out = ["---"];
    const buildInfo2 = await getBuildInfo();
    if (buildInfo2 == null) {
      out.push("No build info");
    } else {
      out.push(buildInfo2.buildConfiguration);
      out.push("Modules:");
      for (const [name, version] of Object.entries(buildInfo2.modules)) {
        out.push(`${name} v${version}`);
      }
    }
    out.push("--");
    out.push("Loaded registerables:");
    this.pushRegisterable(this.container, out);
    out.push("---");
    return out.join("\n");
  }
  /**
   * Puts registerable names into {@link out}, recursively adding children if the registerable is also a {@link RegisterableHolder}.
   * @param registerable the registerable
   * @param out the output array
   * @param depth the current parent depth. Should be 0 when calling externally.
   */
  pushRegisterable(registerable, out, depth = 0) {
    out.push(`| `.repeat(depth) + `${registerable.constructor.name}`);
    if ("children" in registerable && registerable.children instanceof Set) {
      for (const child of registerable.children) {
        this.pushRegisterable(child, out, depth + 1);
      }
    }
  }
  setup() {
    this.listenFor(system.afterEvents.scriptEventReceive, (e) => {
      if (e.id != _DebugReportModule.EVENT_NAME || e.initiator instanceof Player)
        return;
      this.createReport().then(console.error);
    });
  }
};
DebugReportModule.EVENT_NAME = "noxcrew.common.scripting:debug";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/module/entrypoint.js
var Entrypoint = class _Entrypoint extends Container {
  constructor() {
    super();
    this.modules = /* @__PURE__ */ new Set();
    this.hasBeenStarted = false;
  }
  get children() {
    return this.modules;
  }
  /**
   * Registers a module. It will be loaded when the entrypoint is launched.
   * @param module the module to register
   */
  register(module) {
    if (module.isActive)
      throw new Error(`Cannot register already active module ${module.constructor.name}!`);
    this.modules.add(module);
    if (this.hasBeenStarted)
      module.activate();
  }
  /**
   * Binds and registers a module.
   * @see Container.bind
   * @see register
   */
  bindAndRegister(module) {
    this.bind(module);
    this.register(module);
  }
  /**
   * Unregisters a module.
   */
  unregister(module) {
    if (!this.modules.delete(module))
      return;
    if (module.isActive)
      module.deactivate();
  }
  /**
   * Launches an entrypoint.
   * @param initFn an init function to bind and register modules with
   */
  static async launch(initFn) {
    const entrypoint = new _Entrypoint();
    await initFn.call(entrypoint);
    const autoloader = await AutoLoaderModule.createIfNeeded(entrypoint);
    if (autoloader != null)
      entrypoint.register(autoloader);
    entrypoint.register(new DebugReportModule(entrypoint));
    for (const module of entrypoint.modules) {
      module.activate();
    }
    entrypoint.hasBeenStarted = true;
    return entrypoint;
  }
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/invokeFunctionOnButtonPress.js
import { world as world2 } from "@minecraft/server";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/invokeFunctionOnUseItem.js
import { world as world3 } from "@minecraft/server";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/tickingModule.js
import { system as system2 } from "@minecraft/server";
var TickingModule = class extends Module {
  constructor(container, tickInterval) {
    super(container);
    this.tickInterval = tickInterval;
  }
  /** This method is not used by {@link TickingModule} and may be overridden. */
  setup() {
  }
  onActivate() {
    this.handle = system2.runInterval(this.tick.bind(this), this.tickInterval);
  }
  /** Must be invoked by subclasses. */
  onDeactivate() {
    if (this.handle != null) {
      system2.clearRun(this.handle);
      this.handle = void 0;
    }
  }
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/playerLocation.js
import { world as world4 } from "@minecraft/server";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/api/events/dispatcher.js
var EventDispatcher = class {
  constructor() {
    this.listeners = [];
  }
  subscribe(callback) {
    this.listeners.push(callback);
    return callback;
  }
  unsubscribe(callback) {
    const index = this.listeners.indexOf(callback);
    if (index == -1)
      return;
    this.listeners.splice(index, 1);
  }
  /**
   * Dispatches an event.
   * @param event the event
   */
  dispatch(event) {
    for (const listener of this.listeners) {
      try {
        listener(event);
      } catch (e) {
        console.error(`Caught exception in event handler: ${e}`);
      }
    }
  }
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/playerLocation.js
var PlayerLocationManager = class _PlayerLocationManager extends TickingModule {
  constructor(container, playerLocations) {
    super(container, 1);
    this.playerLocations = playerLocations;
    this.objective = world4.scoreboard.getObjective("p.loc") ?? world4.scoreboard.addObjective("p.loc", "Player Loc");
  }
  onActivate() {
    super.onActivate();
  }
  /**
   * Loop function, called once after every specified time delay
   *
   * Handles all players leaving, joining, and ticking for given locations
   */
  tick() {
    for (const player of world4.getAllPlayers()) {
      const playerScoreID = player.scoreboardIdentity;
      if (playerScoreID == void 0) {
        this.objective.setScore(player, -1);
        return;
      }
      const currentLocation = this.objective.getScore(playerScoreID) ?? -1;
      if (currentLocation == -1 || !this.playerLocations[currentLocation].bounds(player)) {
        if (currentLocation != -1) {
          this.leaveLocation(player, currentLocation);
        }
        for (let i = 0; i < this.playerLocations.length; ++i) {
          if (i != currentLocation) {
            if (this.playerLocations[i].bounds(player)) {
              this.joinLocation(player, i);
              break;
            }
          }
        }
      } else if (currentLocation == -1) {
        const location = this.playerLocations[currentLocation];
        location.handleTick(player);
        _PlayerLocationManager.events.dispatch({ type: "tick", player, location });
      }
    }
  }
  /**
   * Set player's active room to specified location
   * @param player The player to set
   * @param location The index of the location in the data array
   */
  joinLocation(player, locationIdx) {
    this.objective.setScore(player, locationIdx);
    const location = this.playerLocations[locationIdx];
    location.handleJoin(player);
    _PlayerLocationManager.events.dispatch({ type: "join", player, location });
  }
  /**
   * Clear player's active room from the specified location
   * @param player The player to clear
   * @param location The index of the location in the data array
   */
  leaveLocation(player, locationIdx) {
    this.objective.setScore(player, -1);
    const location = this.playerLocations[locationIdx];
    location.handleLeave(player);
    _PlayerLocationManager.events.dispatch({ type: "leave", player, location });
  }
};
PlayerLocationManager.events = new EventDispatcher();

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/titleManager.js
import { world as world5 } from "@minecraft/server";
var TitleManager = class _TitleManager extends TickingModule {
  constructor(container, titleOptions) {
    super(container, 10);
    this.titleOptions = titleOptions;
    this.playerTitles = /* @__PURE__ */ new Map();
  }
  setup() {
    this.listenFor(world5.afterEvents.playerSpawn, (e) => {
      this.checkPlayerRejoin(e.player);
    });
  }
  tick() {
    this.playerTitles.forEach((val, key) => {
      const player = GetPlayerFromName(key);
      if (player == null)
        return;
      this.sendTitles(player, val);
    });
  }
  //#region Internal Implementation Functions
  /**
   * Display all of a player's highest weight title elements
   * @param player the player to send the elements to
   * @param playerTitle the player's title data
   * @param skipTickCheck if true, ignores the element's tick value and always prints the element
   */
  sendTitles(player, playerTitle, skipTickCheck = false) {
    const titleText = this.getStringFromElement(playerTitle, "title", skipTickCheck);
    const subtitleText = this.getStringFromElement(playerTitle, "subtitle", skipTickCheck);
    const actionbarText = this.getStringFromElement(playerTitle, "actionbar", skipTickCheck);
    if (titleText != void 0) {
      player.onScreenDisplay.setTitle(titleText, _TitleManager.titleTimes);
    }
    if (subtitleText != void 0) {
      if (titleText == void 0) {
        player.onScreenDisplay.setTitle(" ", _TitleManager.titleTimes);
      }
      player.onScreenDisplay.updateSubtitle(subtitleText);
    }
    if (actionbarText != void 0) {
      player.onScreenDisplay.setActionBar(actionbarText);
    }
  }
  /**
   * Converts title element to printable text
   * @param playerTitle player's title data
   * @param type which element to use
   * @param skipTickCheck if true, ignores the element's tick value and always prints the element
   * @returns printable text, either as string or as translated rawtext object
   */
  getStringFromElement(playerTitle, type, skipTickCheck) {
    const element = playerTitle[type];
    if (element == void 0) {
      return void 0;
    }
    if (!skipTickCheck && !element.tick) {
      return void 0;
    }
    return element.text;
  }
  /**
   * Find player's highest weight version of each element from available active titles and apply new titles
   * @param player the player reciving the titles
   * @param playerTitle the player's title data
   */
  findHighestPriorityTitles(player, playerTitle) {
    playerTitle.activeTitles.sort((a, b) => this.titleOptions.get(b).weight - this.titleOptions.get(a).weight);
    const groups = playerTitle.activeTitles.map((name) => this.titleOptions.get(name));
    playerTitle.title = groups.find((it) => !!it?.title)?.title;
    playerTitle.subtitle = groups.find((it) => !!it?.subtitle)?.subtitle;
    playerTitle.actionbar = groups.find((it) => !!it?.actionbar)?.actionbar;
    this.sendTitles(player, playerTitle, true);
  }
  /**
   * Check if player has titles on rejoin and resend
   * @param player the player reciving the titles
   */
  checkPlayerRejoin(player) {
    let playerTitle = this.playerTitles.get(player.name);
    if (playerTitle == void 0) {
      const storedTitles = player.getDynamicProperty(_TitleManager.titleStorageId);
      if (typeof storedTitles !== "string")
        return;
      const titleList = storedTitles.split(",");
      playerTitle = this.addPlayerToList(player, titleList);
    }
    this.findHighestPriorityTitles(player, playerTitle);
  }
  /**
   * Give player a new entry in the title list
   * @param player player recieving entry
   * @param activeTitles currently active titles, defaults to empty
   * @returns player's new title entry
   */
  addPlayerToList(player, activeTitles = []) {
    const playerTitle = { activeTitles, title: void 0, subtitle: void 0, actionbar: void 0 };
    this.playerTitles.set(player.name, playerTitle);
    return playerTitle;
  }
  //#endregion
  //#region Pubic Accessor Functions
  /**
   * Add new title to player's active title list and recheck/resend priority elements
   * @param player player recieving the title
   * @param title the title's name
   */
  add(player, title) {
    if (!this.titleOptions.has(title)) {
      return;
    }
    let playerTitle = this.playerTitles.get(player.name);
    if (playerTitle == void 0) {
      playerTitle = this.addPlayerToList(player);
    } else if (playerTitle.activeTitles.includes(title)) {
      return;
    }
    playerTitle.activeTitles.push(title);
    this.findHighestPriorityTitles(player, playerTitle);
    player.setDynamicProperty(_TitleManager.titleStorageId, playerTitle.activeTitles.toString());
  }
  /**
   * Remove active title from player's active title list and recheck/resend priority elements
   * @param player player losing the title
   * @param title the title's name
   */
  remove(player, title) {
    const playerTitle = this.playerTitles.get(player.name);
    if (playerTitle == void 0 || !playerTitle.activeTitles.includes(title)) {
      return;
    }
    const findIndex = playerTitle.activeTitles.indexOf(title, 0);
    playerTitle.activeTitles.splice(findIndex, 1);
    if (playerTitle.activeTitles.length == 0) {
      this.playerTitles.delete(player.name);
      player.setDynamicProperty(_TitleManager.titleStorageId, void 0);
      return;
    }
    this.findHighestPriorityTitles(player, playerTitle);
    player.setDynamicProperty(_TitleManager.titleStorageId, playerTitle.activeTitles.toString());
  }
  /**
   * Reset the whole of the players title list to make sure the player is properly reset and done with titles
   * @param player player losing the title
   */
  reset(player) {
    const playerTitle = this.playerTitles.get(player.name);
    if (playerTitle == void 0) {
      return;
    }
    if (playerTitle.activeTitles.length >= 0) {
      this.playerTitles.delete(player.name);
      player.setDynamicProperty(_TitleManager.titleStorageId, void 0);
      return;
    }
  }
};
TitleManager.titleTimes = {
  stayDuration: 20,
  fadeInDuration: 0,
  fadeOutDuration: 4
};
TitleManager.titleStorageId = "noxcrew.proj:activeTitles";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/titleManagerV2.js
import { world as world6 } from "@minecraft/server";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/util/scopedTimer.js
import { system as system3 } from "@minecraft/server";
var ScopedTimer = class _ScopedTimer extends Module {
  constructor(container, timeout2, action, repeating = false) {
    super(container);
    this.timeout = timeout2;
    this.action = action;
    this.repeating = repeating;
    this.handle = null;
  }
  setup() {
  }
  cancel() {
    if (this.handle != null) {
      system3.clearRun(this.handle);
    }
    this.handle = null;
  }
  onActivate() {
    this.handle = system3[this.repeating ? "runInterval" : "runTimeout"](() => this.action(this.cancel.bind(this)), this.timeout);
  }
  onDeactivate() {
    this.cancel();
  }
  static schedule(module, timeout2, action, repeating = false) {
    const timer = new _ScopedTimer(module.container, timeout2, action, repeating);
    module.registerChild(timer);
  }
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/titleManagerV2.js
var TitleManagerV2 = class _TitleManagerV2 extends TickingModule {
  constructor(container) {
    super(container, 15);
    this.counter = 0;
    this.registeredTitles = /* @__PURE__ */ new Map();
    this.playerTitles = new Multimap();
    this.tickingTitles = /* @__PURE__ */ new Map();
  }
  setup() {
  }
  /**
   * Adds a title event.
   * @returns a unique handle for the title
   */
  addTitle(event) {
    const newTitleId = ++this.counter;
    this.registeredTitles.set(newTitleId, event);
    for (const target of event.targets ?? world6.getAllPlayers()) {
      this.playerTitles.add(target.id, newTitleId);
      this.playerTitles.get(target.id)?.sort((one, two) => (this.registeredTitles.get(two)?.weight ?? 0) - (this.registeredTitles.get(one)?.weight ?? 0));
      this.updateTitles(target.id);
    }
    if (event.type == "one-off") {
      ScopedTimer.schedule(this, event.duration, () => this.removeTitle(newTitleId));
    }
    return newTitleId;
  }
  /**
   * Removes a title event.
   * @param event the title event's handle, as returned by {@link add}
   */
  removeTitle(event) {
    for (const player of this.playerTitles.removeValue(event)) {
      this.updateTitles(player);
    }
  }
  /** Replaces all text components for a registered title. */
  replaceTitle(handle, titles) {
    const event = this.registeredTitles.get(handle);
    if (event == null)
      return;
    event.components = titles;
    this.tick();
  }
  updateTitles(playerId) {
    const player = world6.getEntity(playerId);
    if (player == void 0) {
      this.playerTitles.delete(playerId);
      return;
    }
    const titleIds = this.playerTitles.get(playerId);
    if (titleIds == void 0)
      return;
    const titles = titleIds.map((id) => [id, this.registeredTitles.get(id)]);
    const title = titles.find((it) => !!it[1]?.components.title);
    const subtitle = titles.find((it) => !!it[1]?.components.subtitle);
    const actionbar = titles.find((it) => !!it[1]?.components.actionbar);
    const titleIsUiTrigger = title?.[1]?.type == "one-off" && title[1].isUi == true;
    this.tickingTitles.set(playerId, {
      title: titleIsUiTrigger ? void 0 : title?.[0],
      subtitle: subtitle?.[0],
      actionbar: actionbar?.[0]
    });
    this.sendTitles(player, {
      title: title?.[1]?.components.title,
      subtitle: subtitle?.[1]?.components.subtitle,
      actionbar: subtitle?.[1]?.components.actionbar
    });
  }
  sendTitles(player, titles) {
    if (titles.title != void 0) {
      player.onScreenDisplay.setTitle(titles.title, _TitleManagerV2.titleTimes);
    }
    if (titles.subtitle != void 0) {
      if (titles.title == void 0) {
        player.onScreenDisplay.setTitle(" ", _TitleManagerV2.titleTimes);
      }
      player.onScreenDisplay.updateSubtitle(titles.subtitle);
    }
    if (titles.actionbar != void 0) {
      player.onScreenDisplay.setActionBar(titles.actionbar);
    }
  }
  tick() {
    for (const [playerId, titles] of this.tickingTitles) {
      const player = world6.getEntity(playerId);
      if (player == void 0)
        continue;
      const title = titles.title ? this.registeredTitles.get(titles.title) : void 0;
      const subtitle = titles.subtitle ? this.registeredTitles.get(titles.subtitle) : void 0;
      const actionbar = titles.actionbar ? this.registeredTitles.get(titles.actionbar) : void 0;
      this.sendTitles(player, {
        title: title?.components.title,
        subtitle: subtitle?.components.subtitle,
        actionbar: actionbar?.components.actionbar
      });
    }
  }
};
TitleManagerV2.titleTimes = {
  stayDuration: 20,
  fadeInDuration: 0,
  fadeOutDuration: 4
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/sequence/target.js
import { Player as Player2 } from "@minecraft/server";

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/sequence/manager.js
import { world as world7 } from "@minecraft/server";
var __classPrivateFieldGet3 = function(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _SequenceManager_instances;
var _SequenceManager_runningSequences;
var _SequenceManager_callbacks;
var _SequenceManager_stop;
_SequenceManager_runningSequences = /* @__PURE__ */ new WeakMap(), _SequenceManager_callbacks = /* @__PURE__ */ new WeakMap(), _SequenceManager_instances = /* @__PURE__ */ new WeakSet(), _SequenceManager_stop = function _SequenceManager_stop2(instance, success) {
  __classPrivateFieldGet3(this, _SequenceManager_runningSequences, "f").delete(instance);
  __classPrivateFieldGet3(this, _SequenceManager_callbacks, "f").get(instance)?.forEach((callback) => callback(success));
};

// ../../../../../../../../home/node/.creative-toolbox-packages/noxcrew.common.scripting/ct@0.19.2/scripts/modules/sequence/multistage.js
import { world as world8 } from "@minecraft/server";
var STAGE_CONDITION = Symbol();

// initializeAddon.js
import { world as world9 } from "@minecraft/server";
var InitializeAddon = class _InitializeAddon extends Module {
  setup() {
    world9.scoreboard.getObjective(_InitializeAddon.OBJ_VAR) ?? world9.scoreboard.addObjective(_InitializeAddon.OBJ_VAR, "");
    world9.scoreboard.getObjective(_InitializeAddon.OBJ_JIGCOMP) ?? world9.scoreboard.addObjective(_InitializeAddon.OBJ_JIGCOMP, "");
    this.listenFor(world9.afterEvents.playerSpawn, (e) => {
      const player = e.player;
      const playerVersion = player.getDynamicProperty(_InitializeAddon.PLAYER_VERSION) ?? "0.0.0";
      if (e.initialSpawn && playerVersion !== _InitializeAddon.ADDON_VERSION) {
        this.giveTutorialBook(player);
        player.setDynamicProperty(_InitializeAddon.PLAYER_VERSION, _InitializeAddon.ADDON_VERSION);
        player.runCommandAsync("function noxcrew/ow/install_message");
      }
    });
  }
  giveTutorialBook(player) {
    player.runCommand(_InitializeAddon.TUTORIAL_BOOK);
  }
  fixRecipeUnlock(player) {
  }
};
InitializeAddon.ADDON_VERSION = "0.0.2";
InitializeAddon.ADDON_IDENTIFIER = "noxcrew_ow";
InitializeAddon.PLAYER_VERSION = property("noxcrew_ow:version");
InitializeAddon.TUTORIAL_BOOK = 'loot spawn ~ ~ ~ loot "noxcrew/ow/tutorial"';
InitializeAddon.OBJ_VAR = "noxcrew_ow:var";
InitializeAddon.OBJ_JIGCOMP = "noxcrew_ow:jig_computer.addon_stats";

// owlAddon.js
import { EntityInventoryComponent, ItemStack as ItemStack2, Player as Player3, system as system5, world as world10 } from "@minecraft/server";
import { FormCancelationReason, ModalFormData } from "@minecraft/server-ui";

// util/container.js
import { EntityComponentTypes, ItemStack } from "@minecraft/server";
function* allItemsIn(container) {
  for (let i = 0; i < container.size; i++) {
    const item = container.getItem(i);
    if (item != void 0)
      yield item;
  }
}
function reduceItemStack(player, item, slot) {
  const inv = player.getComponent(EntityComponentTypes.Inventory).container;
  const newItem = item.amount > 1 ? new ItemStack(item.typeId, item.amount - 1) : void 0;
  inv?.setItem(slot, newItem);
}

// util/timeout.js
import { system as system4 } from "@minecraft/server";
function timeout(tick) {
  return new Promise((resolve) => {
    system4.runTimeout(resolve, tick);
  });
}

// owlAddon.js
var OwlAddon = class extends Module {
  setup() {
    this.listenFor(world10.afterEvents.itemUse, (e) => {
      const item = e.itemStack;
      if (item.typeId !== "noxcrew_ow:bottled_level")
        return;
      e.source.addLevels(1);
      e.source.playSound("random.levelup");
      reduceItemStack(e.source, item, e.source.selectedSlotIndex);
    });
    this.listenFor(system5.afterEvents.scriptEventReceive, (e) => {
      if (e.id === "noxcrew_ow:drop_item") {
        e.sourceEntity?.dimension.spawnItem(new ItemStack2(`${e.sourceEntity.typeId}_spawn_egg`), e.sourceEntity.location);
        e.sourceEntity?.remove();
      } else if (e.id === "noxcrew_ow:convert_food") {
        if (!(e.initiator instanceof Player3))
          return;
        const foodItem = e.message;
        if (foodItem.length <= 0)
          return;
        const foodAmount = this.checkFoodConvert(e.initiator, foodItem);
        if (foodAmount === 0) {
          e.initiator.runCommand("function noxcrew/ow/guide/error");
          return;
        }
        this.openUiSlider(e.initiator, foodItem, foodAmount);
      }
    });
  }
  checkFoodConvert(player, food) {
    const inventory = player.getComponent(EntityInventoryComponent.componentId).container;
    if (inventory == null)
      return 0;
    let count = 0;
    for (const item of allItemsIn(inventory)) {
      if (item.typeId === `minecraft:${food}`)
        count += item.amount;
    }
    return count;
  }
  async openUiSlider(player, food, amount) {
    const foodConverter = new ModalFormData();
    foodConverter.title({ translate: "noxcrew_ow:txt.title.dia.owl_guide" });
    foodConverter.slider({ translate: "noxcrew_ow:txt.owl_guide.conversion" }, 1, amount, 1, 1);
    const foodConverterResult = await foodConverter.show(player);
    if (foodConverterResult.canceled && foodConverterResult.cancelationReason === FormCancelationReason.UserBusy) {
      await timeout(5);
      this.openUiSlider(player, food, amount);
      return;
    }
    if (foodConverterResult.formValues == null)
      return;
    const inventory = player.getComponent(EntityInventoryComponent.componentId).container;
    if (!inventory)
      return;
    let convertAmount = foodConverterResult.formValues[0];
    for (let i = 0; i < inventory.size; i++) {
      let item = inventory.getItem(i);
      if (!item)
        continue;
      if (item.typeId === `minecraft:${food}`) {
        if (convertAmount <= 0)
          return;
        const convert = convertAmount - item.amount;
        if (convert >= 0) {
          inventory.setItem(i, new ItemStack2("minecraft:rabbit", item.amount));
        } else {
          inventory.setItem(i, new ItemStack2(item.type, item.amount - convertAmount));
          inventory.addItem(new ItemStack2("minecraft:rabbit", convertAmount));
        }
        convertAmount -= item.amount;
      }
    }
  }
};

// owlQuestSystem.js
import { EnchantmentType, EntityComponentTypes as EntityComponentTypes2, ItemComponentTypes, Player as Player4, system as system6 } from "@minecraft/server";

// util/prefix.js
var PREFIX = "noxcrew_ow:";
var prefix_default = PREFIX;

// owlQuestSystem.js
var QUEST_STAGES = {
  1: "noxcrew/ow/quest/1",
  2: "noxcrew_ow:crafting_book_spawn_egg",
  3: "noxcrew_ow:brewing_hat",
  4: "noxcrew/ow/quest/3",
  5: "noxcrew_ow:colourful_feather",
  6: "noxcrew_ow:reading_glasses",
  7: "minecraft:enchanted_book",
  8: "noxcrew_ow:mystic_feather",
  9: "noxcrew_ow:battle_helmet"
};
var ENCHANTMENTS = [
  "quick_charge",
  "luck_of_the_sea",
  "thorns",
  "lure",
  "fire_aspect",
  "unbreaking",
  "knockback",
  "frost_walker",
  "feather_falling",
  "looting",
  "soul_speed",
  "fortune",
  "silk_touch",
  "depth_strider",
  "swift_sneak"
];
var owlQuestSystem = class _owlQuestSystem extends Module {
  setup() {
    this.listenFor(system6.afterEvents.scriptEventReceive, (e) => {
      if (!e.id.startsWith(prefix_default))
        return;
      const eventName = e.id.substring(prefix_default.length);
      if (e.initiator instanceof Player4) {
        const player_stage = e.initiator.getDynamicProperty(_owlQuestSystem.QUEST_STAGE) ?? 1;
        if (eventName === "quest_guide") {
          if (e.sourceEntity?.typeId !== "noxcrew_ow:owl_guide")
            return;
          e.sourceEntity.runCommandAsync(`dialogue open @s "${e.initiator.name}" noxcrew_ow:guide_quest.${player_stage}.0`);
        } else if (eventName === "quest_progress") {
          if (player_stage === 1 || player_stage === 4) {
            e.initiator.runCommandAsync(`function ${QUEST_STAGES[player_stage]}`);
          } else if (player_stage === 7) {
            if (!this.lookForEnchanments(QUEST_STAGES[player_stage], e.initiator)) {
              this.failedStage(e.initiator);
            } else
              this.completeStage(e.initiator, player_stage);
          } else {
            if (!this.lookForItems(QUEST_STAGES[player_stage], e.initiator)) {
              this.failedStage(e.initiator);
            } else
              this.completeStage(e.initiator, player_stage);
          }
        }
      }
      if (eventName === "quest_increment") {
        if (!(e.sourceEntity instanceof Player4))
          return;
        const player_stage = e.sourceEntity.getDynamicProperty(_owlQuestSystem.QUEST_STAGE) ?? 1;
        this.completeStage(e.sourceEntity, player_stage);
      } else if (eventName === "quest_decrement") {
        if (!(e.sourceEntity instanceof Player4))
          return;
        const player_stage = e.sourceEntity.getDynamicProperty(_owlQuestSystem.QUEST_STAGE) ?? 1;
        const newStage = player_stage - 1;
        if (newStage === 0)
          return;
        e.sourceEntity.setDynamicProperty(_owlQuestSystem.QUEST_STAGE, newStage);
      } else if (eventName === "quest_wrong") {
        if (!(e.sourceEntity instanceof Player4))
          return;
        this.failedStage(e.sourceEntity);
      }
    });
  }
  failedStage(player) {
    player.sendMessage({ translate: "noxcrew_ow:txt.owl_guide.error" });
  }
  completeStage(player, stage) {
    player.sendMessage({ translate: "noxcrew_ow:txt.owl_guide.complete" });
    player.setDynamicProperty(_owlQuestSystem.QUEST_STAGE, stage + 1);
  }
  lookForItems(itemName, player) {
    const container = player.getComponent(EntityComponentTypes2.Inventory).container;
    if (!container)
      return false;
    for (let i = 0; i < container.size; i++) {
      if (container.getItem(i)?.typeId !== itemName)
        continue;
      return true;
    }
    return false;
  }
  lookForEnchanments(itemName, player) {
    const container = player.getComponent(EntityComponentTypes2.Inventory).container;
    if (!container)
      return false;
    for (let i = 0; i < container.size; i++) {
      const item = container.getItem(i);
      if (!item)
        continue;
      if (item.typeId !== itemName)
        continue;
      for (const id of ENCHANTMENTS) {
        const enchantment = item.getComponent(ItemComponentTypes.Enchantable);
        if (!enchantment.getEnchantment(new EnchantmentType(id)))
          continue;
        return true;
      }
    }
    return false;
  }
};
owlQuestSystem.QUEST_STAGE = property("noxcrew_ow:quest_stage");

// main.js
function main() {
  this.register(new InitializeAddon(this));
  this.register(new OwlAddon(this));
  this.register(new owlQuestSystem(this));
}
Entrypoint.launch(main);
//! STOLE FROM MOJANG REPLACE WHEN WE IMPLEMENT THIS OURSELVES
//! FIXME [Lyfeless]: Adjust this system to use world properties rather than scoreboard
