const _0x21f734 = _0x3124;
(function (_0x391aa1, _0x26337f) {
    const _0x57ea1a = _0x3124, _0x314042 = _0x391aa1();
    while (!![]) {
        try {
            const _0xb5d0e0 = parseInt(_0x57ea1a(0x9f3)) / 0x1 * (parseInt(_0x57ea1a(0xa1a)) / 0x2) + -parseInt(_0x57ea1a(0x6e0)) / 0x3 + parseInt(_0x57ea1a(0xba7)) / 0x4 * (parseInt(_0x57ea1a(0xae6)) / 0x5) + parseInt(_0x57ea1a(0x7e9)) / 0x6 * (-parseInt(_0x57ea1a(0x7ed)) / 0x7) + -parseInt(_0x57ea1a(0x50d)) / 0x8 + parseInt(_0x57ea1a(0x877)) / 0x9 + parseInt(_0x57ea1a(0x650)) / 0xa * (parseInt(_0x57ea1a(0xaa2)) / 0xb);
            if (_0xb5d0e0 === _0x26337f)
                break;
            else
                _0x314042['push'](_0x314042['shift']());
        } catch (_0x26c9f5) {
            _0x314042['push'](_0x314042['shift']());
        }
    }
}(_0x4213, 0x58e89));
var _0x556a22 = Object[_0x21f734(0x6b9)], _0x13f408 = (_0x24f0c7, _0x18d9ba, _0x18f4dd) => _0x18d9ba in _0x24f0c7 ? _0x556a22(_0x24f0c7, _0x18d9ba, {
        'enumerable': !![],
        'configurable': !![],
        'writable': !![],
        'value': _0x18f4dd
    }) : _0x24f0c7[_0x18d9ba] = _0x18f4dd, _0x25e7d0 = (_0x32dbaa, _0x30bb6b, _0x3402a7) => {
        const _0x46a912 = _0x21f734, _0x17b00b = {
                'jpeCI': function (_0x3ef7b2, _0x4e1598, _0x40c346, _0x3d9445) {
                    return _0x3ef7b2(_0x4e1598, _0x40c346, _0x3d9445);
                },
                'PSePI': function (_0x4e1c32, _0x201f2b) {
                    return _0x4e1c32 + _0x201f2b;
                }
            };
        return _0x17b00b[_0x46a912(0x938)](_0x13f408, _0x32dbaa, typeof _0x30bb6b !== _0x46a912(0x8c9) ? _0x17b00b[_0x46a912(0xc20)](_0x30bb6b, '') : _0x30bb6b, _0x3402a7), _0x3402a7;
    }, _0x2e442a = class {
        constructor(_0x1c365c) {
            const _0x35dddf = _0x21f734, _0x33604d = {
                    'bxqyr': function (_0x47a234, _0x78871e, _0x30faef, _0x3cec59) {
                        return _0x47a234(_0x78871e, _0x30faef, _0x3cec59);
                    }
                };
            this[_0x35dddf(0x497)] = _0x1c365c, _0x33604d[_0x35dddf(0x5a7)](_0x25e7d0, this, _0x35dddf(0x48b), () => {
                const _0x4afc10 = _0x35dddf;
                console[_0x4afc10(0x962)]('[' + this[_0x4afc10(0x497)] + ']\x20Initializing...');
                if (this[_0x4afc10(0x9a6)])
                    try {
                        this[_0x4afc10(0x9a6)]();
                    } catch (_0x3f5cd6) {
                        console[_0x4afc10(0x4b1)]('[' + this['name'] + _0x4afc10(0x62b) + _0x3f5cd6);
                    }
                console[_0x4afc10(0x962)]('[' + this['name'] + _0x4afc10(0x400));
            });
        }
    };
import {
    BlockExplodeAfterEvent as _0x5aab8a,
    ItemStack as _0x3c7a3f
} from '@minecraft/server';
function _0x3124(_0x1f0a98, _0x46e372) {
    const _0x421383 = _0x4213();
    return _0x3124 = function (_0x3124aa, _0x3d804e) {
        _0x3124aa = _0x3124aa - 0x1a4;
        let _0x25680d = _0x421383[_0x3124aa];
        return _0x25680d;
    }, _0x3124(_0x1f0a98, _0x46e372);
}
import { world } from '@minecraft/server';
var _0x207994 = _0x21f734(0x7e0), _0x21d453 = [_0x21f734(0xb7a)], _0x4f7515 = _0x21f734(0x7e5), _0x3fa9b2 = class {
        static [_0x21f734(0x48b)]() {
            const _0x29abd9 = _0x21f734;
            world[_0x29abd9(0x959)][_0x29abd9(0x398)][_0x29abd9(0x725)](_0x21bf10 => {
                const _0x4029c2 = _0x29abd9;
                _0x21bf10[_0x4029c2(0x2ee)]['registerCustomComponent'](_0x207994 + _0x4029c2(0x36c), {
                    'beforeOnPlayerPlace': _0x2ea876 => this[_0x4029c2(0x3cf)](_0x2ea876),
                    'onPlace': _0x50c7ac => this[_0x4029c2(0x5ff)](_0x50c7ac),
                    'onPlayerDestroy': _0x5e33d9 => this['handleOnDestroy'](_0x5e33d9)
                });
            }), world[_0x29abd9(0x327)][_0x29abd9(0xb88)][_0x29abd9(0x725)](_0x1e711d => {
                this['handleOnDestroy'](_0x1e711d);
            });
        }
        static [_0x21f734(0x3cf)](_0x5b614e) {
            const _0x721c70 = _0x21f734, _0x17ac88 = {
                    'SERwr': function (_0x3940a4, _0x4b2a69) {
                        return _0x3940a4 != _0x4b2a69;
                    },
                    'nhtZu': function (_0x572af7, _0x5dc549) {
                        return _0x572af7 != _0x5dc549;
                    },
                    'EazHW': function (_0x33eb06, _0x598bff) {
                        return _0x33eb06 === _0x598bff;
                    },
                    'JyOeS': function (_0xcad178, _0x13dc48) {
                        return _0xcad178 != _0x13dc48;
                    }
                }, _0xb50f91 = _0x5b614e['block']['north'](), _0x470366 = _0x5b614e['block'][_0x721c70(0x6a6)](), _0x164a5e = _0x5b614e['block'][_0x721c70(0x7bd)](), _0x198a1e = _0x5b614e['block']['west'](), _0x381309 = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0xc08)]['id'], _0x147a96 = _0x5b614e['permutationToPlace']['getState'](_0x207994 + _0x721c70(0x446)), _0x3960c7 = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0x30a)](_0x207994 + _0x721c70(0x236)), _0x3e279b = _0x5b614e['permutationToPlace'][_0x721c70(0x30a)](_0x207994 + _0x721c70(0x1ac)), _0x27cb61 = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0x30a)](_0x207994 + ':connect_west');
            _0x17ac88[_0x721c70(0x361)](_0x147a96, void 0x0) && _0xb50f91?.[_0x721c70(0x206)](this[_0x721c70(0x82d)]) && _0xb50f91[_0x721c70(0x1b9)] === _0x381309 && (_0x5b614e[_0x721c70(0x2c1)] = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0x9d1)](_0x207994 + _0x721c70(0x446), !![])), _0x17ac88[_0x721c70(0x361)](_0x3960c7, void 0x0) && _0x470366?.[_0x721c70(0x206)](this[_0x721c70(0x82d)]) && _0x470366[_0x721c70(0x1b9)] === _0x381309 && (_0x5b614e[_0x721c70(0x2c1)] = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0x9d1)](_0x207994 + _0x721c70(0x236), !![])), _0x17ac88[_0x721c70(0x270)](_0x3e279b, void 0x0) && _0x164a5e?.['hasTag'](this[_0x721c70(0x82d)]) && _0x17ac88['EazHW'](_0x164a5e[_0x721c70(0x1b9)], _0x381309) && (_0x5b614e[_0x721c70(0x2c1)] = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0x9d1)](_0x207994 + _0x721c70(0x1ac), !![])), _0x17ac88['JyOeS'](_0x27cb61, void 0x0) && _0x198a1e?.[_0x721c70(0x206)](this['tag']) && _0x17ac88[_0x721c70(0x3be)](_0x198a1e[_0x721c70(0x1b9)], _0x381309) && (_0x5b614e[_0x721c70(0x2c1)] = _0x5b614e[_0x721c70(0x2c1)][_0x721c70(0x9d1)](_0x207994 + ':connect_west', !![])), this['determineLegsBeforePlacement'](_0x5b614e, _0xb50f91, _0x470366, _0x164a5e, _0x198a1e);
        }
        static [_0x21f734(0x5ff)](_0x483773) {
            const _0x3f6db9 = _0x21f734, _0x193c17 = {
                    'KRyDc': function (_0x3de55c, _0x341884) {
                        return _0x3de55c != _0x341884;
                    },
                    'rKpMW': function (_0x4d25e1, _0x580b8b) {
                        return _0x4d25e1 === _0x580b8b;
                    },
                    'gXqel': function (_0x2a0c67, _0x1abd87) {
                        return _0x2a0c67 != _0x1abd87;
                    },
                    'oFSTo': function (_0x31dd90, _0x5a8258) {
                        return _0x31dd90 != _0x5a8258;
                    },
                    'eQxCj': function (_0x2fb12d, _0x4a6e03) {
                        return _0x2fb12d === _0x4a6e03;
                    }
                }, _0x18dedd = _0x483773['block'];
            try {
                const _0x239196 = _0x18dedd[_0x3f6db9(0x571)](), _0x1dcf58 = _0x18dedd[_0x3f6db9(0x6a6)](), _0x299b58 = _0x18dedd['east'](), _0x4aaa14 = _0x18dedd[_0x3f6db9(0x709)]();
                this['determineLegs'](_0x239196), this['determineLegs'](_0x239196['east']()), this[_0x3f6db9(0x978)](_0x239196[_0x3f6db9(0x709)]()), this['determineLegs'](_0x1dcf58), this[_0x3f6db9(0x978)](_0x1dcf58[_0x3f6db9(0x7bd)]()), this[_0x3f6db9(0x978)](_0x1dcf58[_0x3f6db9(0x709)]()), this[_0x3f6db9(0x978)](_0x299b58), this[_0x3f6db9(0x978)](_0x4aaa14);
                const _0x3ab376 = _0x18dedd['permutation'][_0x3f6db9(0x30a)](_0x207994 + ':connect_north'), _0x21bb49 = _0x18dedd[_0x3f6db9(0x5fa)]['getState'](_0x207994 + ':connect_south'), _0x367aa3 = _0x18dedd[_0x3f6db9(0x5fa)][_0x3f6db9(0x30a)](_0x207994 + _0x3f6db9(0x1ac)), _0x4f3b35 = _0x18dedd[_0x3f6db9(0x5fa)][_0x3f6db9(0x30a)](_0x207994 + _0x3f6db9(0xa41));
                _0x193c17[_0x3f6db9(0x486)](_0x3ab376, void 0x0) && _0x239196?.['hasTag'](this[_0x3f6db9(0x82d)]) && _0x239196[_0x3f6db9(0x1b9)] === _0x18dedd[_0x3f6db9(0x1b9)] && _0x239196[_0x3f6db9(0x772)](_0x239196['permutation'][_0x3f6db9(0x9d1)](_0x207994 + ':connect_south', !![])), _0x193c17['KRyDc'](_0x21bb49, void 0x0) && _0x1dcf58?.[_0x3f6db9(0x206)](this[_0x3f6db9(0x82d)]) && _0x193c17['rKpMW'](_0x1dcf58[_0x3f6db9(0x1b9)], _0x18dedd[_0x3f6db9(0x1b9)]) && _0x1dcf58[_0x3f6db9(0x772)](_0x1dcf58[_0x3f6db9(0x5fa)][_0x3f6db9(0x9d1)](_0x207994 + _0x3f6db9(0x446), !![])), _0x193c17[_0x3f6db9(0x5aa)](_0x367aa3, void 0x0) && _0x299b58?.[_0x3f6db9(0x206)](this[_0x3f6db9(0x82d)]) && _0x299b58[_0x3f6db9(0x1b9)] === _0x18dedd[_0x3f6db9(0x1b9)] && _0x299b58[_0x3f6db9(0x772)](_0x299b58[_0x3f6db9(0x5fa)][_0x3f6db9(0x9d1)](_0x207994 + _0x3f6db9(0xa41), !![])), _0x193c17[_0x3f6db9(0xa91)](_0x4f3b35, void 0x0) && _0x4aaa14?.[_0x3f6db9(0x206)](this['tag']) && _0x193c17['eQxCj'](_0x4aaa14['typeId'], _0x18dedd[_0x3f6db9(0x1b9)]) && _0x4aaa14[_0x3f6db9(0x772)](_0x4aaa14['permutation'][_0x3f6db9(0x9d1)](_0x207994 + _0x3f6db9(0x1ac), !![]));
            } catch (_0x30cadd) {
            }
        }
        static [_0x21f734(0xbfe)](_0x5ab9b8) {
            const _0x170c9a = _0x21f734, _0x8e3533 = {
                    'mxlLg': function (_0x1687ef, _0x567146) {
                        return _0x1687ef != _0x567146;
                    }
                }, _0x187612 = _0x5ab9b8[_0x170c9a(0x87b)];
            try {
                const _0x967d58 = _0x187612[_0x170c9a(0x571)](), _0x21ec4a = _0x187612[_0x170c9a(0x6a6)](), _0x461a76 = _0x187612['east'](), _0x242d98 = _0x187612[_0x170c9a(0x709)]();
                this[_0x170c9a(0x978)](_0x967d58), this[_0x170c9a(0x978)](_0x967d58[_0x170c9a(0x7bd)]()), this['determineLegs'](_0x967d58['west']()), this[_0x170c9a(0x978)](_0x21ec4a), this[_0x170c9a(0x978)](_0x21ec4a[_0x170c9a(0x7bd)]()), this[_0x170c9a(0x978)](_0x21ec4a[_0x170c9a(0x709)]()), this['determineLegs'](_0x461a76), this[_0x170c9a(0x978)](_0x242d98);
                const _0x23269f = _0x967d58?.[_0x170c9a(0x5fa)]['getState'](_0x207994 + _0x170c9a(0x446)), _0x3cc2fd = _0x21ec4a?.[_0x170c9a(0x5fa)][_0x170c9a(0x30a)](_0x207994 + _0x170c9a(0x236)), _0x42b0 = _0x461a76?.[_0x170c9a(0x5fa)][_0x170c9a(0x30a)](_0x207994 + ':connect_east'), _0x1917ac = _0x242d98?.[_0x170c9a(0x5fa)][_0x170c9a(0x30a)](_0x207994 + ':connect_west');
                _0x23269f != void 0x0 && _0x967d58?.[_0x170c9a(0x206)](this[_0x170c9a(0x82d)]) && _0x967d58[_0x170c9a(0x772)](_0x967d58[_0x170c9a(0x5fa)]['withState'](_0x207994 + _0x170c9a(0x236), ![])), _0x3cc2fd != void 0x0 && _0x21ec4a?.[_0x170c9a(0x206)](this['tag']) && _0x21ec4a[_0x170c9a(0x772)](_0x21ec4a[_0x170c9a(0x5fa)]['withState'](_0x207994 + _0x170c9a(0x446), ![])), _0x42b0 != void 0x0 && _0x461a76?.[_0x170c9a(0x206)](this[_0x170c9a(0x82d)]) && _0x461a76[_0x170c9a(0x772)](_0x461a76['permutation']['withState'](_0x207994 + _0x170c9a(0xa41), ![])), _0x8e3533['mxlLg'](_0x1917ac, void 0x0) && _0x242d98?.[_0x170c9a(0x206)](this['tag']) && _0x242d98[_0x170c9a(0x772)](_0x242d98[_0x170c9a(0x5fa)][_0x170c9a(0x9d1)](_0x207994 + ':connect_east', ![]));
            } catch (_0x597e3b) {
            }
        }
        static [_0x21f734(0xb05)](_0x51ee88, _0x46d67b, _0x4cbf49, _0x310dde, _0x52b933) {
            const _0x15d926 = _0x21f734, _0x4fe37f = {
                    'psAcy': function (_0x5b03cb, _0x25202a) {
                        return _0x5b03cb && _0x25202a;
                    },
                    'hHigQ': function (_0x4f3500, _0x137581) {
                        return _0x4f3500 === _0x137581;
                    },
                    'dQfJm': function (_0x2a4bca, _0x5cf1f) {
                        return _0x2a4bca === _0x5cf1f;
                    }
                }, _0x362972 = _0x46d67b?.['hasTag'](this[_0x15d926(0x82d)]), _0x12959e = _0x46d67b?.[_0x15d926(0x7bd)]()?.['hasTag'](this[_0x15d926(0x82d)]), _0x101e65 = _0x46d67b?.[_0x15d926(0x709)]()?.[_0x15d926(0x206)](this['tag']), _0x49bfce = _0x310dde?.[_0x15d926(0x206)](this[_0x15d926(0x82d)]), _0x570034 = _0x52b933?.[_0x15d926(0x206)](this[_0x15d926(0x82d)]), _0x115418 = _0x4cbf49?.[_0x15d926(0x206)](this[_0x15d926(0x82d)]), _0x49a89e = _0x4cbf49?.[_0x15d926(0x7bd)]()?.[_0x15d926(0x206)](this[_0x15d926(0x82d)]), _0x3e30ba = _0x4cbf49?.[_0x15d926(0x709)]()?.[_0x15d926(0x206)](this[_0x15d926(0x82d)]), _0x8c2963 = _0x51ee88['permutationToPlace']['type']['id'];
            _0x46d67b?.['hasTag'](this[_0x15d926(0x82d)]) && _0x46d67b[_0x15d926(0x1b9)] === _0x8c2963 && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + ':leg_ne', ![]), _0x51ee88['permutationToPlace'] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x8f8), ![]), _0x362972 && _0x570034 && !_0x101e65 && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88['permutationToPlace'][_0x15d926(0x9d1)](_0x207994 + ':leg_nw', !![])), _0x4fe37f[_0x15d926(0x5f0)](_0x362972, _0x49bfce) && !_0x12959e && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0xacc), !![]))), _0x310dde?.['hasTag'](this[_0x15d926(0x82d)]) && _0x4fe37f[_0x15d926(0xa4d)](_0x310dde[_0x15d926(0x1b9)], _0x8c2963) && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88['permutationToPlace']['withState'](_0x207994 + ':leg_ne', ![]), _0x51ee88['permutationToPlace'] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x1f2), ![]), _0x4fe37f[_0x15d926(0x5f0)](_0x49bfce, _0x115418) && !_0x49a89e && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + ':leg_se', !![])), _0x4fe37f['psAcy'](_0x49bfce, _0x362972) && !_0x12959e && (_0x51ee88['permutationToPlace'] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + ':leg_ne', !![]))), _0x4cbf49?.[_0x15d926(0x206)](this['tag']) && _0x4fe37f['dQfJm'](_0x4cbf49['typeId'], _0x8c2963) && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88['permutationToPlace']['withState'](_0x207994 + ':leg_se', ![]), _0x51ee88[_0x15d926(0x2c1)] = _0x51ee88['permutationToPlace'][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x3ca), ![]), _0x115418 && _0x49bfce && !_0x49a89e && (_0x51ee88['permutationToPlace'] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x1f2), !![])), _0x4fe37f[_0x15d926(0x5f0)](_0x115418, _0x570034) && !_0x3e30ba && (_0x51ee88['permutationToPlace'] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x3ca), !![]))), _0x52b933?.[_0x15d926(0x206)](this[_0x15d926(0x82d)]) && _0x4fe37f['dQfJm'](_0x52b933[_0x15d926(0x1b9)], _0x8c2963) && (_0x51ee88['permutationToPlace'] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x8f8), ![]), _0x51ee88[_0x15d926(0x2c1)] = _0x51ee88['permutationToPlace'][_0x15d926(0x9d1)](_0x207994 + _0x15d926(0x3ca), ![]), _0x4fe37f[_0x15d926(0x5f0)](_0x570034, _0x115418) && !_0x3e30ba && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88['permutationToPlace']['withState'](_0x207994 + ':leg_sw', !![])), _0x4fe37f[_0x15d926(0x5f0)](_0x570034, _0x362972) && !_0x101e65 && (_0x51ee88[_0x15d926(0x2c1)] = _0x51ee88[_0x15d926(0x2c1)][_0x15d926(0x9d1)](_0x207994 + ':leg_nw', !![])));
        }
        static [_0x21f734(0x978)](_0x2748af) {
            const _0x487722 = _0x21f734, _0x2c9c09 = {
                    'mLHPH': function (_0x3bf68a, _0x520a4f) {
                        return _0x3bf68a === _0x520a4f;
                    },
                    'stsDT': function (_0x1d192c, _0xc518ac) {
                        return _0x1d192c === _0xc518ac;
                    },
                    'PkXlC': function (_0x2b19f7, _0x592321) {
                        return _0x2b19f7 === _0x592321;
                    },
                    'nMzHw': function (_0x446e84, _0x19b7ea) {
                        return _0x446e84 === _0x19b7ea;
                    },
                    'PheAE': function (_0x40a2c3, _0x532432) {
                        return _0x40a2c3 && _0x532432;
                    },
                    'oMrTt': _0x487722(0x62d),
                    'xvKPJ': function (_0x5b3792, _0x42a0f4) {
                        return _0x5b3792 && _0x42a0f4;
                    },
                    'iaJPr': function (_0x57a0f6, _0x4fa144) {
                        return _0x57a0f6 && _0x4fa144;
                    },
                    'GpBtR': function (_0x5ef29b, _0x4e66f9) {
                        return _0x5ef29b && _0x4e66f9;
                    }
                };
            if (!_0x2748af[_0x487722(0x206)](this['tag']))
                return;
            const _0x19d275 = _0x2748af[_0x487722(0x571)](), _0x1fe70f = _0x2748af[_0x487722(0x571)]()?.[_0x487722(0x7bd)](), _0x3d671d = _0x2748af[_0x487722(0x571)]()?.[_0x487722(0x709)](), _0x226262 = _0x2748af[_0x487722(0x6a6)](), _0x2fc1a5 = _0x2748af[_0x487722(0x6a6)]()?.['east'](), _0x4b0bee = _0x2748af[_0x487722(0x6a6)]()?.[_0x487722(0x709)](), _0x31ffb4 = _0x2748af[_0x487722(0x7bd)](), _0x184c08 = _0x2748af['west'](), _0x59b5bc = _0x19d275?.['hasTag'](this[_0x487722(0x82d)]) && _0x2c9c09[_0x487722(0xbb2)](_0x19d275[_0x487722(0x1b9)], _0x2748af[_0x487722(0x1b9)]), _0x190b50 = _0x1fe70f?.[_0x487722(0x206)](this[_0x487722(0x82d)]) && _0x2c9c09[_0x487722(0x1da)](_0x1fe70f['typeId'], _0x2748af[_0x487722(0x1b9)]), _0x263d02 = _0x3d671d?.['hasTag'](this['tag']) && _0x3d671d[_0x487722(0x1b9)] === _0x2748af[_0x487722(0x1b9)], _0x1883b = _0x31ffb4?.[_0x487722(0x206)](this[_0x487722(0x82d)]) && _0x2c9c09[_0x487722(0xa83)](_0x31ffb4['typeId'], _0x2748af['typeId']), _0x34a174 = _0x184c08?.[_0x487722(0x206)](this[_0x487722(0x82d)]) && _0x2c9c09[_0x487722(0x95a)](_0x184c08[_0x487722(0x1b9)], _0x2748af[_0x487722(0x1b9)]), _0x2c491f = _0x226262?.['hasTag'](this['tag']) && _0x226262[_0x487722(0x1b9)] === _0x2748af[_0x487722(0x1b9)], _0x21cb42 = _0x2fc1a5?.[_0x487722(0x206)](this[_0x487722(0x82d)]) && _0x2c9c09[_0x487722(0xbb2)](_0x2fc1a5['typeId'], _0x2748af['typeId']), _0x22f088 = _0x4b0bee?.[_0x487722(0x206)](this['tag']) && _0x2c9c09[_0x487722(0xa83)](_0x4b0bee[_0x487722(0x1b9)], _0x2748af[_0x487722(0x1b9)]);
            if (_0x19d275) {
                const _0x1a0b21 = _0x487722(0x70c)[_0x487722(0x1f5)]('|');
                let _0x312480 = 0x0;
                while (!![]) {
                    switch (_0x1a0b21[_0x312480++]) {
                    case '0':
                        _0x2c9c09['PheAE'](_0x59b5bc, _0x1883b) && _0x190b50 && _0x2748af['setPermutation'](_0x2748af['permutation'][_0x487722(0x9d1)](_0x207994 + _0x487722(0xacc), !_0x59b5bc));
                        continue;
                    case '1':
                        _0x59b5bc && _0x1883b && !_0x190b50 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0xacc), _0x59b5bc));
                        continue;
                    case '2':
                        !_0x34a174 && _0x2748af[_0x487722(0x772)](_0x2748af['permutation'][_0x487722(0x9d1)](_0x207994 + _0x487722(0x8f8), !_0x59b5bc));
                        continue;
                    case '3':
                        !_0x1883b && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + ':leg_ne', !_0x59b5bc));
                        continue;
                    case '4':
                        _0x2c9c09['PheAE'](_0x59b5bc, _0x34a174) && _0x263d02 && _0x2748af[_0x487722(0x772)](_0x2748af['permutation'][_0x487722(0x9d1)](_0x207994 + _0x487722(0x8f8), !_0x59b5bc));
                        continue;
                    case '5':
                        _0x59b5bc && _0x34a174 && !_0x263d02 && _0x2748af[_0x487722(0x772)](_0x2748af['permutation'][_0x487722(0x9d1)](_0x207994 + ':leg_nw', _0x59b5bc));
                        continue;
                    }
                    break;
                }
            }
            if (_0x31ffb4) {
                const _0x3a40df = _0x2c9c09['oMrTt']['split']('|');
                let _0x168d7e = 0x0;
                while (!![]) {
                    switch (_0x3a40df[_0x168d7e++]) {
                    case '0':
                        !_0x59b5bc && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0xacc), !_0x1883b));
                        continue;
                    case '1':
                        _0x1883b && _0x2c491f && !_0x21cb42 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)][_0x487722(0x9d1)](_0x207994 + _0x487722(0x1f2), _0x2c491f));
                        continue;
                    case '2':
                        _0x2c9c09[_0x487722(0x279)](_0x1883b, _0x59b5bc) && !_0x190b50 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)][_0x487722(0x9d1)](_0x207994 + ':leg_ne', _0x1883b));
                        continue;
                    case '3':
                        !_0x2c491f && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0x1f2), !_0x1883b));
                        continue;
                    case '4':
                        _0x2c9c09[_0x487722(0xbc1)](_0x1883b, _0x2c491f) && _0x21cb42 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0x1f2), !_0x1883b));
                        continue;
                    case '5':
                        _0x2c9c09['PheAE'](_0x1883b, _0x59b5bc) && _0x190b50 && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)][_0x487722(0x9d1)](_0x207994 + _0x487722(0xacc), !_0x1883b));
                        continue;
                    }
                    break;
                }
            }
            _0x226262 && (!_0x1883b && _0x2748af[_0x487722(0x772)](_0x2748af['permutation']['withState'](_0x207994 + ':leg_se', !_0x2c491f)), !_0x34a174 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + ':leg_sw', !_0x2c491f)), _0x2c9c09['xvKPJ'](_0x2c491f, _0x1883b) && !_0x21cb42 && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0x1f2), _0x2c491f)), _0x2c491f && _0x34a174 && !_0x22f088 && _0x2748af['setPermutation'](_0x2748af['permutation'][_0x487722(0x9d1)](_0x207994 + _0x487722(0x3ca), _0x2c491f)), _0x2c9c09[_0x487722(0x279)](_0x2c491f, _0x34a174) && _0x22f088 && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0x3ca), !_0x2c491f)), _0x2c9c09[_0x487722(0xaf6)](_0x2c491f, _0x1883b) && _0x21cb42 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)][_0x487722(0x9d1)](_0x207994 + ':leg_se', !_0x2c491f))), _0x184c08 && (!_0x59b5bc && _0x2748af[_0x487722(0x772)](_0x2748af['permutation']['withState'](_0x207994 + _0x487722(0x8f8), !_0x34a174)), !_0x2c491f && _0x2748af['setPermutation'](_0x2748af['permutation'][_0x487722(0x9d1)](_0x207994 + ':leg_sw', !_0x34a174)), _0x34a174 && _0x2c491f && !_0x22f088 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0x3ca), _0x2c491f)), _0x2c9c09[_0x487722(0x279)](_0x34a174, _0x59b5bc) && !_0x263d02 && _0x2748af['setPermutation'](_0x2748af[_0x487722(0x5fa)]['withState'](_0x207994 + _0x487722(0x8f8), _0x34a174)), _0x2c9c09['GpBtR'](_0x34a174, _0x59b5bc) && _0x263d02 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)][_0x487722(0x9d1)](_0x207994 + _0x487722(0x8f8), !_0x34a174)), _0x2c9c09[_0x487722(0xaf6)](_0x34a174, _0x2c491f) && _0x22f088 && _0x2748af[_0x487722(0x772)](_0x2748af[_0x487722(0x5fa)][_0x487722(0x9d1)](_0x207994 + _0x487722(0x3ca), !_0x34a174)));
        }
    };
_0x25e7d0(_0x3fa9b2, 'tag', _0x207994 + _0x21f734(0x36c));
import {
    Block as _0x1ad9ab,
    BlockComponentOnPlaceEvent as _0x6a3022,
    BlockComponentPlayerDestroyEvent as _0x1ee50e,
    BlockExplodeAfterEvent as _0x147cc5,
    world as _0x545676
} from '@minecraft/server';
var _0xa93c07 = class {
    static [_0x21f734(0x48b)]() {
        const _0xcd12fa = _0x21f734, _0x13c35d = {
                'txKbj': function (_0x426fbc, _0x371325) {
                    return _0x426fbc != _0x371325;
                },
                'lDeJR': _0xcd12fa(0x234)
            };
        _0x545676[_0xcd12fa(0x959)]['worldInitialize'][_0xcd12fa(0x725)](_0x5d6208 => {
            const _0x161959 = _0xcd12fa;
            _0x5d6208[_0x161959(0x2ee)][_0x161959(0x565)](_0x207994 + _0x161959(0x48c), {
                'beforeOnPlayerPlace': _0x3d7a6d => this['handleBeforePlacement'](_0x3d7a6d),
                'onPlayerDestroy': _0x5a17ae => {
                    const _0x56b725 = _0x161959;
                    if (_0x13c35d[_0x56b725(0x274)](_0x5a17ae['destroyedBlockPermutation'][_0x56b725(0x30a)](_0x207994 + _0x56b725(0x6f3)), _0x13c35d[_0x56b725(0x331)]))
                        this[_0x56b725(0xbf4)](_0x5a17ae);
                },
                'onPlace': _0x32b167 => {
                    const _0x2ee0c1 = _0x161959;
                    if (_0x13c35d[_0x2ee0c1(0x274)](_0x32b167['block'][_0x2ee0c1(0x5fa)][_0x2ee0c1(0x30a)](_0x207994 + _0x2ee0c1(0x6f3)), _0x13c35d[_0x2ee0c1(0x331)]))
                        this[_0x2ee0c1(0xbf4)](_0x32b167);
                }
            });
        }), _0x545676['afterEvents'][_0xcd12fa(0xb88)][_0xcd12fa(0x725)](_0x288b15 => {
            const _0x1b9faa = _0xcd12fa;
            _0x288b15[_0x1b9faa(0x70f)][_0x1b9faa(0x206)](_0x207994 + ':chair') && this[_0x1b9faa(0xbf4)](_0x288b15);
        });
    }
    static [_0x21f734(0x3cf)](_0x5674fc) {
        const _0xc51674 = _0x21f734, _0x4ce106 = {
                'TWhuW': function (_0x59eab0, _0x565286) {
                    return _0x59eab0 || _0x565286;
                },
                'NoAZk': _0xc51674(0xba4),
                'zbKdk': _0xc51674(0x45f),
                'FQwUj': _0xc51674(0x9c6)
            }, _0x2f3428 = _0x5674fc[_0xc51674(0x87b)], _0x3919a8 = _0x5674fc[_0xc51674(0x848)], _0x29d7f1 = _0x5674fc[_0xc51674(0x2c1)];
        if (_0x4ce106[_0xc51674(0xbbe)](!_0x2f3428, !_0x3919a8))
            return;
        const _0x57f63b = _0x5674fc['permutationToPlace'][_0xc51674(0x30a)](_0x4ce106[_0xc51674(0x1fe)]);
        if (_0x3919a8['isSneaking']) {
            _0x5674fc['permutationToPlace'] = _0x5674fc[_0xc51674(0x2c1)][_0xc51674(0x9d1)](_0x207994 + _0xc51674(0x6f3), 'sneaked');
            return;
        }
        const _0x10bd9d = this['validDirections'](_0x2f3428, _0x57f63b, _0x4ce106[_0xc51674(0x4ea)]), _0x4c8851 = this[_0xc51674(0x7b0)](_0x2f3428, _0x57f63b, _0xc51674(0x1a4)), _0x5155b3 = this[_0xc51674(0x7b0)](_0x2f3428, _0x57f63b, _0x4ce106['FQwUj']), _0x586252 = this[_0xc51674(0x1ed)](_0x29d7f1, _0x57f63b, _0x10bd9d, _0x4c8851, _0x5155b3);
        _0x5674fc['permutationToPlace'] = _0x5674fc['permutationToPlace'][_0xc51674(0x9d1)](_0x207994 + _0xc51674(0x6f3), _0x586252);
    }
    static [_0x21f734(0xbf4)](_0x1973d7) {
        const _0x3ed69a = _0x21f734, _0x20af8f = {
                'QbfGa': function (_0x5c6b01, _0x1e004e) {
                    return _0x5c6b01 === _0x1e004e;
                },
                'UOdXt': function (_0x303227, _0x28b942) {
                    return _0x303227 != _0x28b942;
                },
                'VafDS': _0x3ed69a(0x234),
                'Dkgju': _0x3ed69a(0xba4),
                'fnWeY': _0x3ed69a(0x45f),
                'HvfOz': 'right',
                'IIRZV': function (_0x51b1a6, _0x102bf9) {
                    return _0x51b1a6 instanceof _0x102bf9;
                },
                'xQmGg': '5|1|4|2|0|3',
                'yDYmY': 'front',
                'YUYcF': function (_0x449067, _0x3b3332) {
                    return _0x449067 instanceof _0x3b3332;
                },
                'CekJB': function (_0x66ab88, _0x17b712) {
                    return _0x66ab88 === _0x17b712;
                },
                'WVJuM': function (_0x18ceb0, _0x21990f) {
                    return _0x18ceb0 != _0x21990f;
                }
            };
        let _0x234195, _0x3bc844, _0x299fde, _0x39d226, _0xf1936f, _0x2e59d8, _0x5108f0;
        if (_0x20af8f[_0x3ed69a(0x1ec)](_0x1973d7, _0x6a3022)) {
            const _0x2f1a15 = _0x20af8f[_0x3ed69a(0x281)][_0x3ed69a(0x1f5)]('|');
            let _0x66a1c = 0x0;
            while (!![]) {
                switch (_0x2f1a15[_0x66a1c++]) {
                case '0':
                    _0x39d226 = this[_0x3ed69a(0x7b0)](_0x234195, _0x3bc844, _0x20af8f[_0x3ed69a(0x482)]);
                    continue;
                case '1':
                    _0x2e59d8 = _0x234195['typeId'];
                    continue;
                case '2':
                    _0x299fde = this['validDirections'](_0x234195, _0x3bc844, _0x20af8f[_0x3ed69a(0x60f)]);
                    continue;
                case '3':
                    _0xf1936f = this[_0x3ed69a(0x7b0)](_0x234195, _0x3bc844, _0x20af8f['yDYmY']);
                    continue;
                case '4':
                    _0x3bc844 = _0x234195[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x20af8f[_0x3ed69a(0x59f)]);
                    continue;
                case '5':
                    _0x234195 = _0x1973d7[_0x3ed69a(0x87b)];
                    continue;
                }
                break;
            }
        }
        if (_0x20af8f['YUYcF'](_0x1973d7, _0x1ee50e) || _0x20af8f[_0x3ed69a(0x1ec)](_0x1973d7, _0x147cc5)) {
            const _0x295ede = _0x1973d7['block'];
            _0x20af8f[_0x3ed69a(0x1ec)](_0x1973d7, _0x1ee50e) ? _0x234195 = _0x1973d7[_0x3ed69a(0x2f4)] : _0x234195 = _0x1973d7[_0x3ed69a(0x70f)], _0x2e59d8 = _0x234195[_0x3ed69a(0xc08)]['id'], _0x3bc844 = _0x234195['getState'](_0x20af8f[_0x3ed69a(0x59f)]), _0x299fde = this[_0x3ed69a(0x7b0)](_0x295ede, _0x3bc844, _0x20af8f[_0x3ed69a(0x60f)]), _0x39d226 = this[_0x3ed69a(0x7b0)](_0x295ede, _0x3bc844, _0x20af8f[_0x3ed69a(0x482)]), _0xf1936f = this[_0x3ed69a(0x7b0)](_0x295ede, _0x3bc844, _0x20af8f[_0x3ed69a(0x724)]), _0x5108f0 = this[_0x3ed69a(0x1ed)](_0x234195, _0x3bc844, _0x299fde, _0x39d226, _0xf1936f);
        }
        if (_0x299fde && _0x20af8f[_0x3ed69a(0x7ac)](_0x299fde['typeId'], _0x2e59d8) && _0x299fde[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x207994 + _0x3ed69a(0x6f3)) != _0x3ed69a(0x234)) {
            _0x3bc844 = _0x299fde[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x3ed69a(0xba4));
            const _0x1d45e6 = this[_0x3ed69a(0x7b0)](_0x299fde, _0x3bc844, _0x20af8f[_0x3ed69a(0x60f)]), _0x509fa5 = this[_0x3ed69a(0x7b0)](_0x299fde, _0x3bc844, _0x20af8f[_0x3ed69a(0x482)]), _0x4f953f = this[_0x3ed69a(0x7b0)](_0x299fde, _0x3bc844, _0x20af8f['yDYmY']);
            _0x5108f0 = this[_0x3ed69a(0x1ed)](_0x299fde, _0x3bc844, _0x1d45e6, _0x509fa5, _0x4f953f), _0x299fde[_0x3ed69a(0x772)](_0x299fde[_0x3ed69a(0x5fa)]['withState'](_0x207994 + _0x3ed69a(0x6f3), _0x5108f0));
        }
        if (_0x39d226 && _0x39d226['typeId'] === _0x2e59d8 && _0x20af8f[_0x3ed69a(0x6ee)](_0x39d226['permutation']['getState'](_0x207994 + _0x3ed69a(0x6f3)), _0x20af8f['VafDS'])) {
            _0x3bc844 = _0x39d226[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x20af8f[_0x3ed69a(0x59f)]);
            const _0x5e18bd = this[_0x3ed69a(0x7b0)](_0x39d226, _0x3bc844, _0x20af8f['fnWeY']), _0x654391 = this[_0x3ed69a(0x7b0)](_0x39d226, _0x3bc844, _0x20af8f[_0x3ed69a(0x482)]), _0x5bef30 = this['validDirections'](_0x39d226, _0x3bc844, _0x20af8f[_0x3ed69a(0x724)]);
            _0x5108f0 = this[_0x3ed69a(0x1ed)](_0x39d226, _0x3bc844, _0x5e18bd, _0x654391, _0x5bef30), _0x39d226[_0x3ed69a(0x772)](_0x39d226[_0x3ed69a(0x5fa)][_0x3ed69a(0x9d1)](_0x207994 + ':connect', _0x5108f0));
        }
        if (_0xf1936f && _0x20af8f['QbfGa'](_0xf1936f['typeId'], _0x2e59d8) && _0x20af8f['WVJuM'](_0xf1936f['permutation'][_0x3ed69a(0x30a)](_0x207994 + ':connect'), _0x3ed69a(0x234))) {
            _0x3bc844 = _0xf1936f[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x20af8f['Dkgju']);
            const _0x5e31ea = this[_0x3ed69a(0x7b0)](_0xf1936f, _0x3bc844, _0x3ed69a(0x45f)), _0x469171 = this[_0x3ed69a(0x7b0)](_0xf1936f, _0x3bc844, _0x20af8f[_0x3ed69a(0x482)]), _0x2b2376 = this[_0x3ed69a(0x7b0)](_0xf1936f, _0x3bc844, _0x20af8f['yDYmY']);
            _0x5108f0 = this[_0x3ed69a(0x1ed)](_0xf1936f, _0x3bc844, _0x5e31ea, _0x469171, _0x2b2376), _0xf1936f[_0x3ed69a(0x772)](_0xf1936f[_0x3ed69a(0x5fa)][_0x3ed69a(0x9d1)](_0x207994 + ':connect', _0x5108f0));
        }
        const _0x561f79 = [
            _0x299fde,
            _0x39d226,
            _0xf1936f
        ]['filter'](_0x2d78c0 => _0x2d78c0 && _0x2d78c0[_0x3ed69a(0x1b9)] === _0x2e59d8 && _0x2d78c0[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x207994 + _0x3ed69a(0x6f3)) != _0x3ed69a(0x234));
        for (const _0x3dfc31 of _0x561f79) {
            if (!_0x3dfc31)
                continue;
            const _0x177fe5 = _0x3dfc31[_0x3ed69a(0x5fa)][_0x3ed69a(0x30a)](_0x20af8f['Dkgju']), _0x2ebe6e = this[_0x3ed69a(0x7b0)](_0x3dfc31, _0x177fe5, _0x20af8f[_0x3ed69a(0x60f)]), _0x168700 = this['validDirections'](_0x3dfc31, _0x177fe5, _0x20af8f[_0x3ed69a(0x482)]), _0x45473e = this[_0x3ed69a(0x7b0)](_0x3dfc31, _0x177fe5, _0x3ed69a(0x9c6));
            [
                _0x2ebe6e,
                _0x168700,
                _0x45473e
            ][_0x3ed69a(0x3e1)](_0x4ee9c1 => {
                const _0x3ce08b = _0x3ed69a;
                if (_0x4ee9c1 && _0x20af8f[_0x3ce08b(0xa76)](_0x4ee9c1[_0x3ce08b(0x1b9)], _0x2e59d8) && _0x20af8f[_0x3ce08b(0x6ee)](_0x4ee9c1['permutation'][_0x3ce08b(0x30a)](_0x207994 + _0x3ce08b(0x6f3)), _0x20af8f[_0x3ce08b(0x835)])) {
                    const _0x8fc49b = _0x4ee9c1[_0x3ce08b(0x5fa)]['getState'](_0x20af8f['Dkgju']), _0x3aa971 = this[_0x3ce08b(0x7b0)](_0x4ee9c1, _0x8fc49b, _0x20af8f[_0x3ce08b(0x60f)]), _0x5d2835 = this[_0x3ce08b(0x7b0)](_0x4ee9c1, _0x8fc49b, _0x20af8f[_0x3ce08b(0x482)]), _0x2d385d = this[_0x3ce08b(0x7b0)](_0x4ee9c1, _0x8fc49b, 'front'), _0x5e82df = this[_0x3ce08b(0x1ed)](_0x4ee9c1, _0x8fc49b, _0x3aa971, _0x5d2835, _0x2d385d);
                    _0x4ee9c1[_0x3ce08b(0x772)](_0x4ee9c1[_0x3ce08b(0x5fa)]['withState'](_0x207994 + _0x3ce08b(0x6f3), _0x5e82df));
                }
            });
        }
    }
    static [_0x21f734(0x1ed)](_0x57f8c5, _0x5e4580, _0x333847, _0xc4fdca, _0x46fd1b) {
        const _0x2a969b = _0x21f734, _0xdc0674 = {
                'tGcyG': 'minecraft:cardinal_direction',
                'xTkkT': function (_0xf81067, _0x399292) {
                    return _0xf81067 == _0x399292;
                },
                'GattS': 'sneaked',
                'hmVxV': function (_0x2a1830, _0x352b40) {
                    return _0x2a1830 == _0x352b40;
                },
                'JBohw': function (_0xcb846d, _0x4d2364) {
                    return _0xcb846d === _0x4d2364;
                },
                'EhRnB': _0x2a969b(0x7bd),
                'jFtle': _0x2a969b(0x63c),
                'bKifT': function (_0x1c8d04, _0x29e0d4) {
                    return _0x1c8d04 === _0x29e0d4;
                },
                'zvBKM': function (_0x4873a7, _0x15f74c) {
                    return _0x4873a7 === _0x15f74c;
                },
                'BYUOE': function (_0x1e73ca, _0x46a1e3) {
                    return _0x1e73ca === _0x46a1e3;
                },
                'dcxEs': 'corner_se',
                'MkdGu': function (_0x38edf4, _0x165af0) {
                    return _0x38edf4 === _0x165af0;
                },
                'SSnIF': function (_0x12630e, _0x4b7417) {
                    return _0x12630e === _0x4b7417;
                },
                'wSBKa': 'south',
                'MrPzD': _0x2a969b(0xb24),
                'gGcLY': function (_0x321fc6, _0x13eb95) {
                    return _0x321fc6 === _0x13eb95;
                },
                'EQyNF': 'west',
                'SlUXi': 'north',
                'NsxhS': _0x2a969b(0x7c4),
                'UYToy': _0x2a969b(0x5d2),
                'dYrsv': function (_0xd80d47, _0x91ad1a) {
                    return _0xd80d47 !== _0x91ad1a;
                },
                'mzabg': function (_0x41b737, _0x33ae06) {
                    return _0x41b737 !== _0x33ae06;
                },
                'hZOey': function (_0x146b61, _0x8c1c50) {
                    return _0x146b61 === _0x8c1c50;
                },
                'oYVkg': 'single',
                'yNXCZ': function (_0x196c62, _0x18bfab) {
                    return _0x196c62 !== _0x18bfab;
                },
                'Qwafo': function (_0x2c3c2d, _0x206b5b) {
                    return _0x2c3c2d === _0x206b5b;
                },
                'tcamY': function (_0x8e355d, _0x1e39c5) {
                    return _0x8e355d === _0x1e39c5;
                },
                'tJkxh': function (_0x25747e, _0x57597b) {
                    return _0x25747e !== _0x57597b;
                },
                'DOjzL': function (_0x43ec0e, _0x2bf2f0) {
                    return _0x43ec0e !== _0x2bf2f0;
                },
                'OanEf': function (_0xda85bc, _0x5781ce) {
                    return _0xda85bc === _0x5781ce;
                },
                'DwHSz': function (_0x11505f, _0x190075) {
                    return _0x11505f === _0x190075;
                },
                'bmbUU': function (_0x21bc0c, _0x153689) {
                    return _0x21bc0c === _0x153689;
                },
                'xOPUg': function (_0x2c3937, _0x4578d2) {
                    return _0x2c3937 === _0x4578d2;
                },
                'LKioC': function (_0x5e22fc, _0x33ffdd) {
                    return _0x5e22fc === _0x33ffdd;
                },
                'NyCGi': function (_0x1f3de0, _0x3ecc3f) {
                    return _0x1f3de0 === _0x3ecc3f;
                },
                'lTYQJ': function (_0x598cf9, _0x444436) {
                    return _0x598cf9 === _0x444436;
                },
                'hJENg': function (_0x4c626f, _0x2f4f99) {
                    return _0x4c626f === _0x2f4f99;
                },
                'ZvecN': function (_0x69e5e5, _0xff61f3) {
                    return _0x69e5e5 === _0xff61f3;
                },
                'VGoZH': function (_0x37b437, _0x1be98f) {
                    return _0x37b437 === _0x1be98f;
                },
                'WLPAn': 'corner',
                'EMxUi': function (_0x54e1b6, _0xa40783) {
                    return _0x54e1b6 === _0xa40783;
                },
                'mEGOZ': function (_0x3e31c1, _0x270eba) {
                    return _0x3e31c1 === _0x270eba;
                },
                'NQPvi': function (_0x3d8808, _0x3742a8) {
                    return _0x3d8808 === _0x3742a8;
                },
                'KssIw': function (_0x2992bd, _0x55412c) {
                    return _0x2992bd === _0x55412c;
                },
                'cctEN': function (_0x2411b0, _0x577377) {
                    return _0x2411b0 === _0x577377;
                },
                'FCGtQ': function (_0x1b8980, _0x486fe0) {
                    return _0x1b8980 === _0x486fe0;
                },
                'BMZkz': function (_0x37dced, _0x4386fa) {
                    return _0x37dced === _0x4386fa;
                },
                'dUSyk': function (_0x26d5df, _0x402ef0) {
                    return _0x26d5df === _0x402ef0;
                },
                'yfsei': function (_0xbbe02c, _0x18f4ab) {
                    return _0xbbe02c === _0x18f4ab;
                },
                'LlELP': function (_0x108354, _0x2b73df) {
                    return _0x108354 === _0x2b73df;
                },
                'kLKBA': function (_0x7e592c, _0x1ac9ca) {
                    return _0x7e592c === _0x1ac9ca;
                },
                'yHles': function (_0xed337c, _0x36bac1) {
                    return _0xed337c === _0x36bac1;
                },
                'lQzCZ': function (_0x3aafd6, _0x5a40bf) {
                    return _0x3aafd6 === _0x5a40bf;
                },
                'sXJQe': function (_0x35aa25, _0xfd8c2a) {
                    return _0x35aa25 === _0xfd8c2a;
                },
                'qYCxL': function (_0x20a9cb, _0xbee504) {
                    return _0x20a9cb === _0xbee504;
                },
                'YDEnS': function (_0x132bd4, _0x1c4850) {
                    return _0x132bd4 === _0x1c4850;
                },
                'OAPzX': function (_0x4c95f9, _0x47630d) {
                    return _0x4c95f9 === _0x47630d;
                },
                'ZORxK': function (_0x14f42a, _0x208856) {
                    return _0x14f42a === _0x208856;
                },
                'uUJUj': function (_0x31d7b6, _0x54b3fa) {
                    return _0x31d7b6 === _0x54b3fa;
                },
                'xkraW': function (_0x353ff1, _0x101ed3) {
                    return _0x353ff1 == _0x101ed3;
                },
                'BolWS': _0x2a969b(0x777),
                'Ljatk': function (_0x235e6e, _0x2750a0) {
                    return _0x235e6e == _0x2750a0;
                },
                'SwUvs': function (_0x22f6e0, _0x2413dd) {
                    return _0x22f6e0 != _0x2413dd;
                },
                'OAYMU': function (_0x5dbbe7, _0x1395f2) {
                    return _0x5dbbe7 == _0x1395f2;
                },
                'RewFs': _0x2a969b(0x7f1),
                'ttzbG': function (_0xd76be0, _0x1f662f) {
                    return _0xd76be0 == _0x1f662f;
                },
                'qXVpT': function (_0x345119, _0x40262b) {
                    return _0x345119 == _0x40262b;
                },
                'zUFeK': function (_0x3af908, _0x4197a7) {
                    return _0x3af908 == _0x4197a7;
                },
                'AIciX': function (_0x3e6238, _0x4ffbd9) {
                    return _0x3e6238 != _0x4ffbd9;
                }
            }, _0x51d1cd = _0x333847['permutation'][_0x2a969b(0x30a)](_0xdc0674[_0x2a969b(0x1e5)]), _0x1f8ab7 = _0xc4fdca[_0x2a969b(0x5fa)][_0x2a969b(0x30a)](_0xdc0674[_0x2a969b(0x1e5)]), _0x3212e1 = _0x46fd1b[_0x2a969b(0x5fa)]['getState']('minecraft:cardinal_direction'), _0x2f56e9 = _0xdc0674[_0x2a969b(0x1ba)](_0x333847[_0x2a969b(0x5fa)][_0x2a969b(0x30a)](_0x207994 + _0x2a969b(0x6f3)), _0x2a969b(0x234)), _0x32aedc = _0xdc0674[_0x2a969b(0x1ba)](_0xc4fdca[_0x2a969b(0x5fa)][_0x2a969b(0x30a)](_0x207994 + _0x2a969b(0x6f3)), _0xdc0674[_0x2a969b(0x5f3)]), _0x3b3c53 = _0xdc0674['hmVxV'](_0x46fd1b[_0x2a969b(0x5fa)][_0x2a969b(0x30a)](_0x207994 + _0x2a969b(0x6f3)), _0xdc0674[_0x2a969b(0x5f3)]);
        let _0x415a52, _0x70c3a4;
        _0x57f8c5 instanceof _0x1ad9ab ? (_0x415a52 = _0x57f8c5['typeId'], _0x70c3a4 = _0x57f8c5[_0x2a969b(0x5fa)][_0x2a969b(0x30a)](_0x207994 + _0x2a969b(0x6f3))) : (_0x415a52 = _0x57f8c5[_0x2a969b(0xc08)]['id'], _0x70c3a4 = _0x57f8c5['getState'](_0x207994 + _0x2a969b(0x6f3)));
        const _0x189806 = _0x333847['typeId'], _0x26d12a = _0xc4fdca[_0x2a969b(0x1b9)], _0x118634 = _0x46fd1b['typeId'], _0x1cdb9a = _0x333847['permutation']['getState'](_0x207994 + _0x2a969b(0x6f3)), _0x4d4717 = _0xc4fdca[_0x2a969b(0x5fa)]['getState'](_0x207994 + _0x2a969b(0x6f3)), _0x2b0ed9 = _0x46fd1b[_0x2a969b(0x5fa)][_0x2a969b(0x30a)](_0x207994 + _0x2a969b(0x6f3));
        if (_0x70c3a4 === _0x2a969b(0x63c)) {
            if (_0x51d1cd === _0x5e4580 && _0xdc0674['JBohw'](_0x3212e1, _0xdc0674[_0x2a969b(0x453)]) && !_0x2f56e9 && !_0x3b3c53)
                return _0xdc0674[_0x2a969b(0x1d7)];
            if (_0xdc0674[_0x2a969b(0xb6c)](_0x1f8ab7, _0x5e4580) && _0xdc0674['zvBKM'](_0x3212e1, _0x2a969b(0x571)) && !_0x32aedc && !_0x3b3c53)
                return _0x2a969b(0x63c);
        }
        if (_0xdc0674[_0x2a969b(0xafe)](_0x70c3a4, _0xdc0674[_0x2a969b(0xaba)])) {
            if (_0xdc0674['MkdGu'](_0x1f8ab7, _0x5e4580) && _0xdc0674[_0x2a969b(0x265)](_0x3212e1, _0xdc0674[_0x2a969b(0x887)]) && !_0x32aedc && !_0x3b3c53)
                return _0xdc0674['dcxEs'];
            if (_0xdc0674[_0x2a969b(0xafe)](_0x51d1cd, _0x5e4580) && _0xdc0674[_0x2a969b(0x900)](_0x3212e1, _0xdc0674[_0x2a969b(0x453)]) && !_0x2f56e9 && !_0x3b3c53)
                return _0xdc0674[_0x2a969b(0xaba)];
        }
        if (_0xdc0674[_0x2a969b(0xafe)](_0x70c3a4, _0xdc0674[_0x2a969b(0x9f2)])) {
            if (_0xdc0674[_0x2a969b(0x60d)](_0x1f8ab7, _0x5e4580) && _0xdc0674[_0x2a969b(0x3d3)](_0x3212e1, _0xdc0674['EQyNF']) && !_0x32aedc && !_0x3b3c53)
                return _0xdc0674[_0x2a969b(0x9f2)];
            if (_0x51d1cd === _0x5e4580 && _0x3212e1 === _0xdc0674[_0x2a969b(0x887)] && !_0x2f56e9 && !_0x3b3c53)
                return _0xdc0674[_0x2a969b(0x9f2)];
        }
        if (_0xdc0674[_0x2a969b(0xafe)](_0x70c3a4, _0x2a969b(0x7c4))) {
            if (_0xdc0674[_0x2a969b(0xb6c)](_0x51d1cd, _0x5e4580) && _0xdc0674[_0x2a969b(0x900)](_0x3212e1, _0xdc0674[_0x2a969b(0xa80)]) && !_0x2f56e9 && !_0x3b3c53)
                return _0xdc0674[_0x2a969b(0xac4)];
            if (_0x1f8ab7 === _0x5e4580 && _0xdc0674[_0x2a969b(0xafe)](_0x3212e1, _0xdc0674[_0x2a969b(0x7dd)]) && !_0x32aedc && !_0x3b3c53)
                return _0xdc0674['NsxhS'];
        }
        if (_0x415a52 === _0x118634) {
            if (_0xdc0674['MkdGu'](_0x70c3a4, _0xdc0674[_0x2a969b(0x3df)]) && _0xdc0674['dYrsv'](_0x5e4580, _0x3212e1) && !_0x3b3c53)
                return _0xdc0674[_0x2a969b(0x3df)];
        }
        if (_0xdc0674[_0x2a969b(0x3d3)](_0x415a52, _0x26d12a) && (_0xdc0674[_0x2a969b(0x269)](_0x51d1cd, _0x5e4580) || _0xdc0674['dYrsv'](_0x415a52, _0x189806) || _0x2f56e9)) {
            if (_0xdc0674[_0x2a969b(0xb39)](_0x5e4580, _0xdc0674[_0x2a969b(0xa80)]) && _0xdc0674[_0x2a969b(0xafe)](_0x1f8ab7, _0xdc0674[_0x2a969b(0x453)]) && _0xdc0674[_0x2a969b(0xb39)](_0x4d4717, _0xdc0674[_0x2a969b(0x3df)]))
                return _0xdc0674[_0x2a969b(0x984)];
        }
        if (_0xdc0674['SSnIF'](_0x415a52, _0x189806) && (_0xdc0674['yNXCZ'](_0x1f8ab7, _0x5e4580) || _0xdc0674[_0x2a969b(0x269)](_0x415a52, _0x26d12a) || _0x32aedc)) {
            if (_0xdc0674[_0x2a969b(0x60d)](_0x5e4580, _0xdc0674[_0x2a969b(0xa80)]) && _0xdc0674[_0x2a969b(0x98f)](_0x51d1cd, _0x2a969b(0x709)) && _0xdc0674[_0x2a969b(0x290)](_0x1cdb9a, _0xdc0674['UYToy']))
                return _0xdc0674[_0x2a969b(0x984)];
        }
        if (_0xdc0674[_0x2a969b(0x290)](_0x415a52, _0x26d12a) && (_0x51d1cd !== _0x5e4580 || _0x415a52 !== _0x189806 || _0x2f56e9)) {
            if (_0xdc0674[_0x2a969b(0xab2)](_0x5e4580, _0xdc0674[_0x2a969b(0x453)]) && _0x1f8ab7 === _0xdc0674[_0x2a969b(0x887)] && _0x4d4717 === _0xdc0674[_0x2a969b(0x3df)])
                return _0xdc0674[_0x2a969b(0x984)];
        }
        if (_0xdc0674[_0x2a969b(0xb39)](_0x415a52, _0x189806) && (_0xdc0674[_0x2a969b(0x93b)](_0x1f8ab7, _0x5e4580) || _0xdc0674[_0x2a969b(0xb78)](_0x415a52, _0x26d12a) || _0x32aedc)) {
            if (_0xdc0674[_0x2a969b(0xafe)](_0x5e4580, _0xdc0674[_0x2a969b(0x453)]) && _0xdc0674['OanEf'](_0x51d1cd, _0xdc0674[_0x2a969b(0xa80)]) && _0x1cdb9a === _0x2a969b(0x5d2))
                return _0x2a969b(0x9e9);
        }
        if (_0xdc0674[_0x2a969b(0xb87)](_0x415a52, _0x26d12a) && (_0x51d1cd !== _0x5e4580 || _0x415a52 !== _0x189806 || _0x2f56e9)) {
            if (_0xdc0674[_0x2a969b(0x265)](_0x5e4580, _0xdc0674[_0x2a969b(0x887)]) && _0xdc0674['bmbUU'](_0x1f8ab7, _0xdc0674[_0x2a969b(0x7dd)]) && _0xdc0674[_0x2a969b(0x7bf)](_0x4d4717, 'inner'))
                return _0xdc0674['oYVkg'];
        }
        if (_0xdc0674[_0x2a969b(0x329)](_0x415a52, _0x189806) && (_0xdc0674['tJkxh'](_0x1f8ab7, _0x5e4580) || _0xdc0674[_0x2a969b(0x332)](_0x415a52, _0x26d12a) || _0x32aedc)) {
            if (_0xdc0674['xOPUg'](_0x5e4580, 'south') && _0xdc0674[_0x2a969b(0xb31)](_0x51d1cd, _0x2a969b(0x7bd)) && _0xdc0674[_0x2a969b(0xb87)](_0x1cdb9a, _0xdc0674[_0x2a969b(0x3df)]))
                return _0x2a969b(0x9e9);
        }
        if (_0xdc0674[_0x2a969b(0x8da)](_0x415a52, _0x26d12a) && (_0xdc0674[_0x2a969b(0x93b)](_0x51d1cd, _0x5e4580) || _0xdc0674[_0x2a969b(0x332)](_0x415a52, _0x189806) || _0x2f56e9)) {
            if (_0xdc0674['DwHSz'](_0x5e4580, _0x2a969b(0x709)) && _0x1f8ab7 === _0x2a969b(0x571) && _0xdc0674[_0x2a969b(0xb39)](_0x4d4717, _0x2a969b(0x5d2)))
                return _0x2a969b(0x9e9);
        }
        if (_0x415a52 === _0x189806 && (_0xdc0674[_0x2a969b(0x93b)](_0x1f8ab7, _0x5e4580) || _0xdc0674['tJkxh'](_0x415a52, _0x26d12a) || _0x32aedc)) {
            if (_0xdc0674['lTYQJ'](_0x5e4580, _0xdc0674[_0x2a969b(0x7dd)]) && _0x51d1cd === _0xdc0674[_0x2a969b(0x887)] && _0xdc0674['hJENg'](_0x1cdb9a, 'inner'))
                return _0xdc0674[_0x2a969b(0x984)];
        }
        if (_0xdc0674['ZvecN'](_0x415a52, _0x26d12a) && _0x415a52 !== _0x189806 && _0xdc0674[_0x2a969b(0xbc9)](_0x415a52, _0x118634) && !_0x3b3c53 && !_0x32aedc && !_0x2b0ed9[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0x31d)]) && !_0x4d4717[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0x31d)])) {
            if (_0xdc0674[_0x2a969b(0xb31)](_0x5e4580, _0x2a969b(0x571)) && _0xdc0674[_0x2a969b(0x265)](_0x1f8ab7, _0xdc0674[_0x2a969b(0x453)]) && _0xdc0674['EMxUi'](_0x3212e1, _0xdc0674[_0x2a969b(0x7dd)]))
                return _0xdc0674[_0x2a969b(0xac4)];
            if (_0xdc0674[_0x2a969b(0xb6c)](_0x5e4580, _0xdc0674[_0x2a969b(0x453)]) && _0xdc0674[_0x2a969b(0x77d)](_0x1f8ab7, _0x2a969b(0x6a6)) && _0x3212e1 === _0xdc0674[_0x2a969b(0xa80)])
                return 'corner_ne';
            if (_0x5e4580 === _0x2a969b(0x6a6) && _0x1f8ab7 === 'west' && _0xdc0674[_0x2a969b(0x539)](_0x3212e1, _0xdc0674[_0x2a969b(0x453)]))
                return _0xdc0674[_0x2a969b(0xaba)];
            if (_0x5e4580 === _0x2a969b(0x709) && _0xdc0674[_0x2a969b(0x98f)](_0x1f8ab7, _0x2a969b(0x571)) && _0xdc0674[_0x2a969b(0x899)](_0x3212e1, _0x2a969b(0x6a6)))
                return _0xdc0674['MrPzD'];
        }
        if (_0xdc0674['SSnIF'](_0x415a52, _0x189806) && _0xdc0674[_0x2a969b(0x38c)](_0x415a52, _0x26d12a) && !_0x2f56e9 && !_0x32aedc && !_0x4d4717[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0x31d)]) && !_0x1cdb9a[_0x2a969b(0x620)]('corner')) {
            if (_0xdc0674[_0x2a969b(0x77d)](_0x5e4580, _0x51d1cd) && _0xdc0674[_0x2a969b(0x44e)](_0x5e4580, _0x1f8ab7))
                return _0xdc0674[_0x2a969b(0x3df)];
        }
        if (_0xdc0674[_0x2a969b(0x210)](_0x415a52, _0x189806) && _0xdc0674[_0x2a969b(0xb43)](_0x415a52, _0x118634) && !_0x2f56e9 && !_0x3b3c53 && !_0x1cdb9a[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0x31d)]) && !_0x2b0ed9[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0x31d)])) {
            if (_0x5e4580 === _0xdc0674[_0x2a969b(0xa80)]) {
                if (_0xdc0674[_0x2a969b(0x8d3)](_0x51d1cd, _0x5e4580) && _0xdc0674['yfsei'](_0x3212e1, _0x2a969b(0x7bd)))
                    return _0xdc0674[_0x2a969b(0x1d7)];
            }
            if (_0x5e4580 === _0xdc0674[_0x2a969b(0x887)]) {
                if (_0xdc0674[_0x2a969b(0x730)](_0x51d1cd, _0x5e4580) && _0xdc0674[_0x2a969b(0xafe)](_0x3212e1, _0x2a969b(0x709)))
                    return _0xdc0674[_0x2a969b(0x9f2)];
            }
            if (_0xdc0674['kLKBA'](_0x5e4580, _0xdc0674[_0x2a969b(0x453)])) {
                if (_0x51d1cd === _0x5e4580 && _0xdc0674[_0x2a969b(0xaf0)](_0x3212e1, _0xdc0674[_0x2a969b(0x887)]))
                    return _0xdc0674[_0x2a969b(0xaba)];
            }
            if (_0xdc0674[_0x2a969b(0x3d3)](_0x5e4580, _0xdc0674[_0x2a969b(0x7dd)])) {
                if (_0xdc0674[_0x2a969b(0xbc9)](_0x51d1cd, _0x5e4580) && _0xdc0674[_0x2a969b(0x363)](_0x3212e1, _0x2a969b(0x571)))
                    return _0xdc0674[_0x2a969b(0xac4)];
            }
        }
        if (_0xdc0674[_0x2a969b(0xab9)](_0x415a52, _0x26d12a) && _0xdc0674[_0x2a969b(0x95c)](_0x415a52, _0x118634) && !_0x3b3c53 && !_0x32aedc && !_0x2b0ed9[_0x2a969b(0x620)](_0xdc0674['WLPAn']) && !_0x4d4717['includes'](_0xdc0674[_0x2a969b(0x31d)])) {
            if (_0xdc0674[_0x2a969b(0x210)](_0x5e4580, 'north')) {
                if (_0xdc0674[_0x2a969b(0xb6c)](_0x1f8ab7, _0x5e4580) && _0xdc0674[_0x2a969b(0xafe)](_0x3212e1, _0xdc0674[_0x2a969b(0x7dd)]))
                    return _0xdc0674[_0x2a969b(0xac4)];
            }
            if (_0xdc0674[_0x2a969b(0x80e)](_0x5e4580, _0xdc0674[_0x2a969b(0x887)])) {
                if (_0xdc0674[_0x2a969b(0xb29)](_0x1f8ab7, _0x5e4580) && _0x3212e1 === _0xdc0674[_0x2a969b(0x453)])
                    return _0xdc0674[_0x2a969b(0xaba)];
            }
            if (_0xdc0674['YDEnS'](_0x5e4580, _0xdc0674[_0x2a969b(0x453)])) {
                if (_0xdc0674[_0x2a969b(0x3d2)](_0x1f8ab7, _0x5e4580) && _0xdc0674['OanEf'](_0x3212e1, _0xdc0674[_0x2a969b(0xa80)]))
                    return _0xdc0674[_0x2a969b(0x1d7)];
            }
            if (_0xdc0674[_0x2a969b(0xb29)](_0x5e4580, _0x2a969b(0x709))) {
                if (_0xdc0674[_0x2a969b(0x5fc)](_0x1f8ab7, _0x5e4580) && _0xdc0674[_0x2a969b(0xbe0)](_0x3212e1, _0xdc0674['wSBKa']))
                    return _0x2a969b(0xb24);
            }
        }
        if (_0x26d12a == _0x415a52 && _0x189806 == _0x415a52 && !_0x2f56e9 && !_0x32aedc) {
            const _0xc6db8a = [_0x5e4580], _0x3c8014 = [_0x5e4580];
            switch (_0x5e4580) {
            case _0xdc0674[_0x2a969b(0xa80)]:
                _0xc6db8a[_0x2a969b(0x28e)](_0xdc0674['EQyNF']), _0x3c8014[_0x2a969b(0x28e)](_0xdc0674[_0x2a969b(0x453)]);
                break;
            case _0x2a969b(0x6a6):
                _0xc6db8a['push'](_0xdc0674[_0x2a969b(0x453)]), _0x3c8014[_0x2a969b(0x28e)](_0xdc0674[_0x2a969b(0x7dd)]);
                break;
            case _0xdc0674[_0x2a969b(0x453)]:
                _0xc6db8a[_0x2a969b(0x28e)]('north'), _0x3c8014['push'](_0xdc0674['wSBKa']);
                break;
            case _0xdc0674['EQyNF']:
                _0xc6db8a['push'](_0xdc0674[_0x2a969b(0x887)]), _0x3c8014[_0x2a969b(0x28e)](_0xdc0674[_0x2a969b(0xa80)]);
                break;
            }
            if (_0xdc0674[_0x2a969b(0x5cd)](_0x5e4580, _0x51d1cd) && _0x5e4580 === _0x1f8ab7)
                return _0xdc0674[_0x2a969b(0x3df)];
            if ((_0x5e4580 == _0x51d1cd || (_0x1cdb9a[_0x2a969b(0x620)](_0x2a969b(0x906)) || _0xdc0674[_0x2a969b(0x8d9)](_0x1cdb9a, _0xdc0674[_0x2a969b(0x3df)]) || _0x1cdb9a[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0xa79)])) && _0xc6db8a[_0x2a969b(0x620)](_0x51d1cd)) && (_0x5e4580 == _0x1f8ab7 || (_0x4d4717[_0x2a969b(0x620)](_0x2a969b(0x906)) || _0xdc0674[_0x2a969b(0xb21)](_0x4d4717, _0xdc0674[_0x2a969b(0x3df)]) || _0x4d4717[_0x2a969b(0x620)](_0xdc0674['BolWS'])) && _0x3c8014['includes'](_0x1f8ab7)))
                return _0xdc0674[_0x2a969b(0x3df)];
        }
        let _0x2ef6fc = _0x2a969b(0x571), _0xb41a79 = _0xdc0674['SlUXi'], _0x105ff2 = '', _0x3879fb = '';
        switch (_0x5e4580) {
        case _0x2a969b(0x571):
            _0x2ef6fc = _0x2a969b(0x709), _0xb41a79 = _0xdc0674[_0x2a969b(0x453)], _0x105ff2 = _0xdc0674[_0x2a969b(0xac4)], _0x3879fb = _0xdc0674[_0x2a969b(0x1d7)];
            break;
        case _0xdc0674[_0x2a969b(0x887)]:
            _0x2ef6fc = _0xdc0674[_0x2a969b(0x453)], _0xb41a79 = _0xdc0674[_0x2a969b(0x7dd)], _0x105ff2 = _0xdc0674[_0x2a969b(0xaba)], _0x3879fb = _0xdc0674[_0x2a969b(0x9f2)];
            break;
        case _0xdc0674[_0x2a969b(0x453)]:
            _0x2ef6fc = _0x2a969b(0x571), _0xb41a79 = _0x2a969b(0x6a6), _0x105ff2 = _0x2a969b(0x63c), _0x3879fb = _0xdc0674['dcxEs'];
            break;
        case _0xdc0674[_0x2a969b(0x7dd)]:
            _0x2ef6fc = _0xdc0674[_0x2a969b(0x887)], _0xb41a79 = _0xdc0674[_0x2a969b(0xa80)], _0x105ff2 = _0xdc0674['MrPzD'], _0x3879fb = _0xdc0674['NsxhS'];
            break;
        }
        if ((_0xdc0674['SwUvs'](_0x189806, _0x415a52) || _0x51d1cd != _0x5e4580 || _0x2f56e9) && _0xdc0674[_0x2a969b(0x814)](_0x26d12a, _0x415a52) && (_0x1f8ab7 == _0x5e4580 || (_0x4d4717[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0x31d)]) || _0x4d4717 == _0xdc0674[_0x2a969b(0x3df)] || _0x4d4717[_0x2a969b(0x620)](_0x2a969b(0x777))) && _0x1f8ab7 == _0xb41a79) && !_0x32aedc && !(_0x4d4717['includes'](_0x2a969b(0x906)) && _0x3879fb != _0x4d4717))
            return _0xdc0674[_0x2a969b(0x711)];
        if ((_0x26d12a != _0x415a52 || _0x1f8ab7 != _0x5e4580 || _0x32aedc) && _0xdc0674[_0x2a969b(0x814)](_0x189806, _0x415a52) && (_0xdc0674[_0x2a969b(0x77a)](_0x51d1cd, _0x5e4580) || (_0x1cdb9a['includes'](_0xdc0674[_0x2a969b(0x31d)]) || _0xdc0674[_0x2a969b(0xae2)](_0x1cdb9a, _0xdc0674[_0x2a969b(0x3df)]) || _0x1cdb9a[_0x2a969b(0x620)](_0xdc0674[_0x2a969b(0xa79)])) && _0xdc0674['zUFeK'](_0x51d1cd, _0x2ef6fc)) && !_0x2f56e9 && !(_0x1cdb9a[_0x2a969b(0x620)](_0xdc0674['WLPAn']) && _0xdc0674['AIciX'](_0x105ff2, _0x1cdb9a)))
            return _0x2a969b(0x886);
        return _0xdc0674[_0x2a969b(0x984)];
    }
    static [_0x21f734(0x7b0)](_0x57bde9, _0x2feb4d, _0x5d5122) {
        const _0x30f0ea = _0x21f734, _0x187680 = {
                'QwROg': _0x30f0ea(0x571),
                'DIGfI': function (_0x499181, _0x2cd4c9) {
                    return _0x499181 === _0x2cd4c9;
                },
                'HBCRg': 'left',
                'KKhyD': function (_0x75e947, _0x54bc63) {
                    return _0x75e947 === _0x54bc63;
                },
                'SrSMF': _0x30f0ea(0x9c6),
                'ojsoV': _0x30f0ea(0x6a6),
                'UDCnM': _0x30f0ea(0x1a4),
                'PpdAZ': _0x30f0ea(0x7bd),
                'nenGI': 'west',
                'cUmey': function (_0x42a7a9, _0x5f2750) {
                    return _0x42a7a9 === _0x5f2750;
                }
            };
        if (_0x2feb4d === _0x187680['QwROg']) {
            if (_0x187680[_0x30f0ea(0x4a6)](_0x5d5122, _0x187680[_0x30f0ea(0xb58)]))
                return _0x57bde9[_0x30f0ea(0x709)]();
            if (_0x5d5122 === _0x30f0ea(0x1a4))
                return _0x57bde9[_0x30f0ea(0x7bd)]();
            if (_0x187680[_0x30f0ea(0xbce)](_0x5d5122, _0x187680['SrSMF']))
                return _0x57bde9['south']();
        }
        if (_0x187680[_0x30f0ea(0xbce)](_0x2feb4d, _0x187680['ojsoV'])) {
            if (_0x187680[_0x30f0ea(0xbce)](_0x5d5122, _0x30f0ea(0x45f)))
                return _0x57bde9['east']();
            if (_0x187680[_0x30f0ea(0xbce)](_0x5d5122, _0x187680[_0x30f0ea(0x21d)]))
                return _0x57bde9[_0x30f0ea(0x709)]();
            if (_0x187680[_0x30f0ea(0x4a6)](_0x5d5122, _0x30f0ea(0x9c6)))
                return _0x57bde9[_0x30f0ea(0x571)]();
        }
        if (_0x2feb4d === _0x187680[_0x30f0ea(0xaad)]) {
            if (_0x187680[_0x30f0ea(0x4a6)](_0x5d5122, _0x187680[_0x30f0ea(0xb58)]))
                return _0x57bde9[_0x30f0ea(0x571)]();
            if (_0x187680[_0x30f0ea(0xbce)](_0x5d5122, _0x30f0ea(0x1a4)))
                return _0x57bde9[_0x30f0ea(0x6a6)]();
            if (_0x5d5122 === _0x187680[_0x30f0ea(0x347)])
                return _0x57bde9['west']();
        }
        if (_0x2feb4d === _0x187680[_0x30f0ea(0x262)]) {
            if (_0x187680['KKhyD'](_0x5d5122, _0x187680[_0x30f0ea(0xb58)]))
                return _0x57bde9[_0x30f0ea(0x6a6)]();
            if (_0x187680[_0x30f0ea(0xa9b)](_0x5d5122, _0x30f0ea(0x1a4)))
                return _0x57bde9[_0x30f0ea(0x571)]();
            if (_0x187680[_0x30f0ea(0x4a6)](_0x5d5122, _0x187680[_0x30f0ea(0x347)]))
                return _0x57bde9[_0x30f0ea(0x7bd)]();
        }
    }
};
import {
    EquipmentSlot as _0x50f8fd,
    system as _0x4227d9,
    world as _0x251fff
} from '@minecraft/server';
import {
    EquipmentSlot,
    ItemStack,
    Player,
    GameMode,
    world as _0x362f98,
    EnchantmentTypes,
    MinecraftDimensionTypes,
    system
} from '@minecraft/server';
var _0x443f8d = [
        'minecraft:structure_void',
        _0x21f734(0x1a5),
        _0x21f734(0xa68),
        _0x21f734(0x7fa),
        'minecraft:fern',
        'minecraft:large_fern',
        _0x21f734(0x4ce),
        _0x21f734(0x912),
        _0x21f734(0x34e),
        _0x21f734(0xad2),
        _0x21f734(0x2bd),
        _0x21f734(0x822),
        _0x21f734(0x484),
        _0x21f734(0x98e),
        _0x21f734(0x48e),
        _0x21f734(0x862),
        _0x21f734(0x4b0),
        _0x21f734(0x558),
        _0x21f734(0x222),
        _0x21f734(0xa97),
        _0x21f734(0x738),
        _0x21f734(0x33e),
        _0x21f734(0x5e8),
        _0x21f734(0x8fe),
        _0x21f734(0x7a5),
        _0x21f734(0xa07),
        _0x21f734(0x3a4),
        _0x21f734(0xb0a),
        _0x21f734(0x6d8),
        _0x21f734(0xb0c),
        _0x21f734(0x81a),
        _0x21f734(0x3b4),
        'minecraft:flower_pot',
        _0x21f734(0x33d),
        _0x21f734(0x5d0),
        'minecraft:warped_fungus',
        'minecraft:hanging_roots',
        _0x21f734(0xaca),
        _0x21f734(0x8f5),
        _0x21f734(0x1e4),
        _0x21f734(0x65c),
        _0x21f734(0x5b2),
        'minecraft:nether_wart',
        _0x21f734(0xb54),
        _0x21f734(0xb6d),
        'minecraft:pumpkin_stem',
        _0x21f734(0xbb5),
        _0x21f734(0x3c6),
        _0x21f734(0x671),
        _0x21f734(0x5db),
        _0x21f734(0xbde),
        _0x21f734(0x3a3),
        _0x21f734(0x3a1),
        _0x21f734(0x6ea),
        _0x21f734(0x817),
        _0x21f734(0xbac),
        'minecraft:birch_sapling',
        _0x21f734(0x286),
        _0x21f734(0x504),
        'minecraft:dark_oak_sapling',
        'minecraft:cherry_sapling',
        _0x21f734(0x963),
        _0x21f734(0x73c),
        _0x21f734(0xa03),
        _0x21f734(0x50e)
    ], _0xc0f2fe = [
        'minecraft:glass',
        'minecraft:glass_pane',
        _0x21f734(0x745),
        'minecraft:chain',
        _0x21f734(0xa1b),
        _0x21f734(0x88c),
        _0x21f734(0x3e9),
        _0x21f734(0xbcb),
        _0x21f734(0x4a4),
        _0x21f734(0xb83),
        _0x21f734(0x7a7),
        _0x21f734(0x9fd),
        _0x21f734(0x4ca),
        'minecraft:gray_stained_glass_pane',
        _0x21f734(0x6a3),
        _0x21f734(0x406),
        _0x21f734(0x449),
        'minecraft:light_blue_stained_glass_pane',
        _0x21f734(0x2e2),
        _0x21f734(0x3f8),
        _0x21f734(0x38d),
        _0x21f734(0x8e0),
        'minecraft:magenta_stained_glass',
        _0x21f734(0xbdf),
        _0x21f734(0xae9),
        _0x21f734(0x2b7),
        _0x21f734(0xb1f),
        'minecraft:pink_stained_glass_pane',
        _0x21f734(0xa58),
        _0x21f734(0x734),
        _0x21f734(0x1fb),
        _0x21f734(0xb8b),
        _0x21f734(0x60e),
        _0x21f734(0x7ce),
        _0x21f734(0x25a)
    ], _0x3d5897 = ['minecraft:stone_brick_wall'], _0x29ec27 = [
        'minecraft:iron_door',
        _0x21f734(0x9ff),
        'minecraft:wooden_trapdoor',
        _0x21f734(0x30f),
        'minecraft:oak_door',
        _0x21f734(0x787),
        _0x21f734(0x851),
        _0x21f734(0x485),
        _0x21f734(0x5e4),
        _0x21f734(0x380),
        _0x21f734(0x7c3),
        'minecraft:pale_oak_door',
        _0x21f734(0x937),
        _0x21f734(0x534),
        _0x21f734(0x8f9)
    ], _0x493aa0 = [
        _0x21f734(0x30c),
        _0x21f734(0x303),
        'minecraft:light_gray_bundle',
        _0x21f734(0x6e3),
        _0x21f734(0x3d1),
        _0x21f734(0x2e5),
        _0x21f734(0x8a1),
        _0x21f734(0xb5d),
        _0x21f734(0x5d1),
        _0x21f734(0x437),
        'minecraft:magenta_bundle',
        _0x21f734(0x66a),
        'minecraft:purple_bundle',
        _0x21f734(0x20b),
        _0x21f734(0x7ab),
        _0x21f734(0x9a7),
        _0x21f734(0x91b)
    ], _0x1a76fc = [
        _0x21f734(0x9e1),
        _0x21f734(0x272),
        _0x21f734(0x7f4),
        _0x21f734(0xb2b),
        _0x21f734(0x9cb),
        _0x21f734(0x646),
        _0x21f734(0xa1d),
        _0x21f734(0x926),
        _0x21f734(0x901),
        'minecraft:crimson_stairs',
        'minecraft:brick_stairs',
        _0x21f734(0xada),
        _0x21f734(0xb53),
        _0x21f734(0x7fb),
        'minecraft:mossy_cobblestone_stairs',
        'minecraft:granite_stairs',
        _0x21f734(0x3ad),
        _0x21f734(0x5da),
        'minecraft:prismarine_stairs',
        _0x21f734(0x458),
        'minecraft:sandstone_stairs',
        'minecraft:nether_brick_stairs',
        'minecraft:end_stone_brick_stairs',
        'minecraft:blackstone_stairs',
        _0x21f734(0xb89),
        'minecraft:polished_blackstone_brick_stairs',
        _0x21f734(0x8cf),
        _0x21f734(0x345),
        'minecraft:deepslate_tile_stairs',
        _0x21f734(0xa15),
        _0x21f734(0x36e),
        'minecraft:tuff_brick_stairs',
        _0x21f734(0x456),
        _0x21f734(0x9d8),
        _0x21f734(0x952),
        _0x21f734(0x337)
    ], _0x4f553c = [
        _0x21f734(0xa5a),
        _0x21f734(0x385),
        _0x21f734(0x419),
        'minecraft:jungle_slab',
        'minecraft:acacia_slab',
        _0x21f734(0x6fc),
        _0x21f734(0x42d),
        _0x21f734(0xa84),
        'minecraft:warped_slab',
        _0x21f734(0x2d9),
        _0x21f734(0x505),
        _0x21f734(0xb2d),
        _0x21f734(0x790),
        _0x21f734(0x4aa),
        _0x21f734(0x56b),
        _0x21f734(0x929),
        _0x21f734(0x3eb),
        _0x21f734(0x720),
        'minecraft:prismarine_slab',
        'minecraft:red_sandstone_slab',
        _0x21f734(0x84f),
        'minecraft:nether_brick_slab',
        _0x21f734(0xb11),
        _0x21f734(0xb7b),
        _0x21f734(0x224),
        'minecraft:polished_blackstone_brick_slab',
        _0x21f734(0xad9),
        _0x21f734(0x636),
        _0x21f734(0x8ac),
        _0x21f734(0x5b4),
        _0x21f734(0x80a),
        'minecraft:tuff_brick_slab',
        _0x21f734(0x49f),
        'minecraft:mud_brick_slab',
        'minecraft:resin_brick_slab',
        _0x21f734(0x6f2)
    ], _0x3314c6 = [
        _0x21f734(0xbfb),
        _0x21f734(0x3f8),
        _0x21f734(0x8f2),
        _0x21f734(0x9fd),
        _0x21f734(0x625),
        _0x21f734(0xbcb),
        _0x21f734(0x734),
        'minecraft:magenta_stained_glass_pane',
        _0x21f734(0x8dd),
        _0x21f734(0xb8b),
        _0x21f734(0x2b7),
        _0x21f734(0x7ce),
        _0x21f734(0x8e0),
        _0x21f734(0x406),
        'minecraft:white_stained_glass_pane',
        _0x21f734(0x88c),
        _0x21f734(0xb83)
    ], _0x4bc2ab = [
        'minecraft:oak_leaves',
        _0x21f734(0x804),
        _0x21f734(0xad6),
        'minecraft:jungle_leaves',
        'minecraft:acacia_leaves',
        _0x21f734(0x764),
        _0x21f734(0x979),
        _0x21f734(0x32b),
        _0x21f734(0x5dd),
        _0x21f734(0x1e3)
    ], _0x5d2db2 = [
        ..._0x443f8d,
        ..._0x4f553c,
        ..._0x1a76fc,
        ..._0x4bc2ab,
        ..._0x3314c6,
        _0x21f734(0x745)
    ];
function _0x5a3f62(_0x457422) {
    const _0x171631 = _0x21f734, _0x2cca29 = {
            'pBfjy': function (_0x4a48af, _0x191099) {
                return _0x4a48af / _0x191099;
            }
        };
    return _0x457422 * _0x2cca29[_0x171631(0xa93)](Math['PI'], 0xb4);
}
var _0x590054 = class _0x12ec7d {
        constructor(_0x467426, _0x4d220f, _0x44d7b9) {
            this['x'] = _0x467426, this['y'] = _0x4d220f, this['z'] = _0x44d7b9;
        }
        static [_0x21f734(0xb1d)](_0x387bd7, _0x14dc5f, _0x2369d7, _0x37f668 = ![]) {
            const _0x455aae = _0x21f734, _0x3e06c9 = {
                    'pNJvX': function (_0x313312, _0x31afcc) {
                        return _0x313312 < _0x31afcc;
                    },
                    'PhJvv': function (_0x10546e, _0x5a1e2d) {
                        return _0x10546e * _0x5a1e2d;
                    },
                    'rkRKZ': function (_0x4c3cd8, _0x53cf7c) {
                        return _0x4c3cd8 - _0x53cf7c;
                    },
                    'mkHwF': function (_0x21fcb9, _0x450ceb) {
                        return _0x21fcb9 + _0x450ceb;
                    }
                };
            let _0x1dcbb7 = [];
            for (let _0x74cb97 = 0x0; _0x3e06c9[_0x455aae(0xb16)](_0x74cb97, _0x2369d7); _0x74cb97++) {
                const _0x3168e0 = _0x3e06c9[_0x455aae(0x79e)](_0x3e06c9['PhJvv'](Math[_0x455aae(0xaab)](), 0x2), Math['PI']), _0x27357a = Math[_0x455aae(0x30b)](_0x3e06c9[_0x455aae(0x356)](_0x3e06c9[_0x455aae(0x79e)](0x2, Math[_0x455aae(0xaab)]()), 0x1));
                let _0x3ede05 = _0x14dc5f;
                _0x37f668 ? _0x3ede05 *= Math['cbrt'](Math['random']()) : _0x3ede05 *= Math[_0x455aae(0xaab)]();
                const _0x31bcf3 = _0x3e06c9[_0x455aae(0xae3)](_0x387bd7['x'], _0x3e06c9['PhJvv'](_0x3e06c9[_0x455aae(0x79e)](_0x3ede05, Math[_0x455aae(0x884)](_0x27357a)), Math[_0x455aae(0xa96)](_0x3168e0))), _0x56cbdd = _0x387bd7['y'] + _0x3e06c9['PhJvv'](_0x3e06c9[_0x455aae(0x79e)](_0x3ede05, Math[_0x455aae(0x884)](_0x27357a)), Math['sin'](_0x3168e0)), _0x18f44b = _0x3e06c9[_0x455aae(0xae3)](_0x387bd7['z'], _0x3e06c9['PhJvv'](_0x3ede05, Math[_0x455aae(0xa96)](_0x27357a)));
                _0x1dcbb7[_0x455aae(0x28e)](new _0x12ec7d(_0x31bcf3, _0x56cbdd, _0x18f44b));
            }
            return _0x1dcbb7;
        }
        static [_0x21f734(0xb0f)](_0x15268d, _0x608606, _0x48e652, _0x24f8fd, _0x33f38c = ![]) {
            const _0x5d7847 = _0x21f734, _0xa11d40 = {
                    'IATuL': function (_0x46ab0c, _0x362a19) {
                        return _0x46ab0c < _0x362a19;
                    },
                    'tLsNL': function (_0x53f917, _0x2733c2) {
                        return _0x53f917 * _0x2733c2;
                    },
                    'iBYIT': function (_0x493394, _0x433afc) {
                        return _0x493394 + _0x433afc;
                    },
                    'IlGPX': function (_0x17a8ee, _0x18ee1a) {
                        return _0x17a8ee - _0x18ee1a;
                    },
                    'cqGbC': function (_0x8169a6, _0x5dab7d) {
                        return _0x8169a6 / _0x5dab7d;
                    },
                    'nBfsm': function (_0x5a5386, _0x3f96e1) {
                        return _0x5a5386 * _0x3f96e1;
                    },
                    'dPzjv': function (_0x3e2a40, _0x445903) {
                        return _0x3e2a40 + _0x445903;
                    },
                    'nwqtt': function (_0x22215d, _0xec493b) {
                        return _0x22215d * _0xec493b;
                    }
                };
            let _0x1fa2c1 = [];
            for (let _0x44a015 = 0x0; _0xa11d40['IATuL'](_0x44a015, _0x24f8fd); _0x44a015++) {
                const _0x1d7d51 = _0xa11d40['tLsNL'](Math[_0x5d7847(0xaab)](), 0x2) * Math['PI'], _0x84a0fd = _0xa11d40[_0x5d7847(0xbda)](_0xa11d40[_0x5d7847(0x5d6)](_0x15268d['y'], _0xa11d40[_0x5d7847(0x644)](_0x48e652, 0x2)), _0xa11d40['tLsNL'](Math[_0x5d7847(0xaab)](), _0x48e652)), _0x5cf90c = _0x33f38c ? _0x608606 : _0xa11d40[_0x5d7847(0x4e9)](Math[_0x5d7847(0xaab)](), _0x608606), _0x550073 = _0xa11d40[_0x5d7847(0xbda)](_0x15268d['x'], _0xa11d40['nBfsm'](_0x5cf90c, Math[_0x5d7847(0xa96)](_0x1d7d51))), _0x138495 = _0xa11d40[_0x5d7847(0x7d9)](_0x15268d['z'], _0xa11d40['nwqtt'](_0x5cf90c, Math['sin'](_0x1d7d51)));
                _0x1fa2c1[_0x5d7847(0x28e)](new _0x12ec7d(_0x550073, _0x84a0fd, _0x138495));
            }
            return _0x1fa2c1;
        }
        static [_0x21f734(0x610)](_0x4fcab4) {
            return new _0x12ec7d(_0x4fcab4['x'], _0x4fcab4['y'], _0x4fcab4['z']);
        }
        static [_0x21f734(0xb77)](_0xccf7e7, _0x538e4c) {
            const _0x378cd5 = _0x21f734, _0xf1e6ed = {
                    'Cgoea': function (_0x118b72, _0x3dd53e) {
                        return _0x118b72 * _0x3dd53e;
                    },
                    'MrDoV': function (_0x18672c, _0x27bdfc) {
                        return _0x18672c + _0x27bdfc;
                    },
                    'KoDZS': function (_0x30ca8e, _0x30fe01) {
                        return _0x30ca8e + _0x30fe01;
                    }
                }, _0x4748f0 = Math[_0x378cd5(0xaab)]() * 0x2 * Math['PI'], _0xd6112b = _0xf1e6ed[_0x378cd5(0xa66)](Math[_0x378cd5(0xaab)](), _0x538e4c), _0x33700f = _0xf1e6ed[_0x378cd5(0x52c)](_0xccf7e7['x'], Math[_0x378cd5(0xa96)](_0x4748f0) * _0xd6112b), _0x51618c = _0xf1e6ed[_0x378cd5(0x23f)](_0xccf7e7['z'], _0xf1e6ed[_0x378cd5(0xa66)](Math[_0x378cd5(0x884)](_0x4748f0), _0xd6112b));
            return new _0x12ec7d(_0x33700f, _0xccf7e7['y'], _0x51618c);
        }
        [_0x21f734(0x3e6)](_0x3b3386) {
            const _0x15fc4e = _0x21f734, _0x12bbfe = {
                    'rJujt': function (_0x147920, _0x1efdf1) {
                        return _0x147920 - _0x1efdf1;
                    },
                    'GvEob': function (_0x4ed049, _0xbb4cee) {
                        return _0x4ed049 - _0xbb4cee;
                    },
                    'UtBSS': function (_0x4018f8, _0x367652) {
                        return _0x4018f8 - _0x367652;
                    },
                    'MhuIX': function (_0x46123f, _0x4b3434) {
                        return _0x46123f + _0x4b3434;
                    },
                    'rqWgQ': function (_0x455c2f, _0x1debab) {
                        return _0x455c2f * _0x1debab;
                    },
                    'fCaNz': function (_0x4906e6, _0x3db06c) {
                        return _0x4906e6 * _0x3db06c;
                    }
                }, _0x403b5a = _0x12bbfe['rJujt'](this['x'], _0x3b3386['x']), _0x10a3ea = _0x12bbfe[_0x15fc4e(0x97c)](this['y'], _0x3b3386['y']), _0x1dd62e = _0x12bbfe[_0x15fc4e(0xa6f)](this['z'], _0x3b3386['z']);
            return Math[_0x15fc4e(0x2f8)](_0x12bbfe['MhuIX'](_0x12bbfe[_0x15fc4e(0xb86)](_0x403b5a, _0x403b5a), _0x12bbfe[_0x15fc4e(0xa01)](_0x10a3ea, _0x10a3ea)) + _0x1dd62e * _0x1dd62e);
        }
        [_0x21f734(0x65f)](_0x190c2d) {
            const _0x51e12a = {
                'kKEEq': function (_0x38a744, _0x12f462) {
                    return _0x38a744 + _0x12f462;
                }
            };
            return new _0x12ec7d(this['x'] + _0x190c2d['x'], _0x51e12a['kKEEq'](this['y'], _0x190c2d['y']), this['z'] + _0x190c2d['z']);
        }
        [_0x21f734(0x71b)](_0x37f731) {
            const _0x3668a8 = _0x21f734, _0x5804c6 = {
                    'yFzpD': function (_0x1fcd99, _0x8f3e73) {
                        return _0x1fcd99 - _0x8f3e73;
                    },
                    'iTDMy': function (_0x3e2e87, _0x5e9933) {
                        return _0x3e2e87 - _0x5e9933;
                    }
                };
            return new _0x12ec7d(this['x'] - _0x37f731['x'], _0x5804c6['yFzpD'](this['y'], _0x37f731['y']), _0x5804c6[_0x3668a8(0x850)](this['z'], _0x37f731['z']));
        }
        [_0x21f734(0x8b8)](_0x44b190) {
            const _0x177934 = _0x21f734, _0x45e0e2 = {
                    'SAvHu': function (_0x59367f, _0x529269) {
                        return _0x59367f * _0x529269;
                    },
                    'YXRLj': function (_0x33ef00, _0x3bb8da) {
                        return _0x33ef00 * _0x3bb8da;
                    },
                    'bCBzC': function (_0x200008, _0x3c8990) {
                        return _0x200008 * _0x3c8990;
                    }
                };
            return new _0x12ec7d(_0x45e0e2['SAvHu'](this['x'], _0x44b190), _0x45e0e2[_0x177934(0x45b)](this['y'], _0x44b190), _0x45e0e2[_0x177934(0x62a)](this['z'], _0x44b190));
        }
        [_0x21f734(0x51f)]() {
            const _0x57e5a0 = _0x21f734, _0x4ad482 = {
                    'WKzEh': function (_0x37d62e, _0x4aae4c) {
                        return _0x37d62e + _0x4aae4c;
                    },
                    'xqrmk': function (_0x5f4462, _0x3f43eb) {
                        return _0x5f4462 ** _0x3f43eb;
                    },
                    'YRPiT': function (_0x18ead9, _0x557879) {
                        return _0x18ead9 ** _0x557879;
                    },
                    'TPseB': function (_0x4026fa, _0x1c65bb) {
                        return _0x4026fa ** _0x1c65bb;
                    }
                };
            return Math[_0x57e5a0(0x2f8)](_0x4ad482['WKzEh'](_0x4ad482[_0x57e5a0(0x706)](_0x4ad482[_0x57e5a0(0x439)](this['x'], 0x2), _0x4ad482[_0x57e5a0(0x6f5)](this['y'], 0x2)), _0x4ad482[_0x57e5a0(0x46a)](this['z'], 0x2)));
        }
        [_0x21f734(0x5c4)]() {
            const _0x198d44 = _0x21f734, _0x36ba77 = {
                    'lacrn': function (_0xe311c7, _0x5389c8) {
                        return _0xe311c7 / _0x5389c8;
                    },
                    'SwTOP': function (_0x45b372, _0x19edca) {
                        return _0x45b372 / _0x19edca;
                    }
                }, _0x503974 = this['length']();
            return new _0x12ec7d(_0x36ba77[_0x198d44(0x736)](this['x'], _0x503974), _0x36ba77['lacrn'](this['y'], _0x503974), _0x36ba77[_0x198d44(0xb09)](this['z'], _0x503974));
        }
        [_0x21f734(0x358)](_0x3f04ba) {
            const _0x1fbc17 = _0x21f734, _0xe20de3 = {
                    'edcZr': function (_0x137d71, _0x40dd4f) {
                        return _0x137d71 + _0x40dd4f;
                    },
                    'TJUrw': function (_0x28d6da, _0x5531f4) {
                        return _0x28d6da * _0x5531f4;
                    },
                    'osRMn': function (_0x4a219f, _0x38d44b) {
                        return _0x4a219f * _0x38d44b;
                    }
                };
            return _0xe20de3[_0x1fbc17(0x267)](_0xe20de3[_0x1fbc17(0x9a4)](this['x'], _0x3f04ba['x']) + _0xe20de3['osRMn'](this['y'], _0x3f04ba['y']), _0xe20de3['TJUrw'](this['z'], _0x3f04ba['z']));
        }
        [_0x21f734(0x2c3)](_0x4f430e) {
            return new _0x12ec7d(this['x'], this['y'] + _0x4f430e, this['z']);
        }
        ['cross'](_0x56aa5d) {
            const _0x2b897d = _0x21f734, _0x590d2d = {
                    'nVzFW': function (_0x495be0, _0x4a5cb5) {
                        return _0x495be0 - _0x4a5cb5;
                    },
                    'apEQl': function (_0xb783d1, _0x48dd69) {
                        return _0xb783d1 * _0x48dd69;
                    },
                    'sHrZw': function (_0x17b702, _0x169bda) {
                        return _0x17b702 * _0x169bda;
                    },
                    'oKXcF': function (_0x3430b4, _0x16a827) {
                        return _0x3430b4 - _0x16a827;
                    },
                    'Tanfg': function (_0x3c3039, _0x1eef9c) {
                        return _0x3c3039 * _0x1eef9c;
                    }
                };
            return new _0x12ec7d(_0x590d2d[_0x2b897d(0x9fb)](_0x590d2d[_0x2b897d(0x21a)](this['y'], _0x56aa5d['z']), this['z'] * _0x56aa5d['y']), this['z'] * _0x56aa5d['x'] - _0x590d2d[_0x2b897d(0x958)](this['x'], _0x56aa5d['z']), _0x590d2d[_0x2b897d(0x72f)](_0x590d2d[_0x2b897d(0x1dd)](this['x'], _0x56aa5d['y']), this['y'] * _0x56aa5d['x']));
        }
        [_0x21f734(0xb0d)](_0x7e1969) {
            const _0xd81bf6 = _0x21f734, _0x3081e8 = {
                    'wJoft': function (_0x788f68, _0x498388) {
                        return _0x788f68 / _0x498388;
                    },
                    'QjcQP': function (_0x395b6d, _0x1a6b23) {
                        return _0x395b6d < _0x1a6b23;
                    }
                }, _0x4ca2b2 = this[_0xd81bf6(0x358)](_0x7e1969), _0xac5462 = this[_0xd81bf6(0x51f)](), _0x41cf06 = _0x7e1969[_0xd81bf6(0x51f)](), _0x5a857c = _0x3081e8[_0xd81bf6(0x336)](_0x4ca2b2, _0xac5462 * _0x41cf06), _0x31f978 = Math[_0xd81bf6(0x30b)](_0x5a857c) * (0xb4 / Math['PI']), _0x5aab85 = this[_0xd81bf6(0xa5b)](_0x7e1969);
            if (_0x3081e8[_0xd81bf6(0xba6)](_0x5aab85['y'], 0x0))
                return -_0x31f978;
            return _0x31f978;
        }
        [_0x21f734(0x661)](_0x574fba) {
            const _0x4e1022 = _0x21f734, _0x49c6a6 = {
                    'EgrLh': function (_0x3c0240, _0x40a5d2) {
                        return _0x3c0240(_0x40a5d2);
                    },
                    'OkFTO': function (_0x7095b4, _0x323bb5) {
                        return _0x7095b4 * _0x323bb5;
                    }
                }, _0x3d311b = _0x49c6a6[_0x4e1022(0x348)](_0x5a3f62, _0x574fba);
            return new _0x12ec7d(this['x'] * Math['cos'](_0x3d311b), this['y'] - Math[_0x4e1022(0x884)](_0x3d311b), _0x49c6a6['OkFTO'](this['z'], Math['cos'](_0x3d311b)));
        }
        [_0x21f734(0x4bc)](_0x136790) {
            const _0x51f9a4 = _0x21f734, _0xf3cf36 = {
                    'HdEyC': function (_0x410d71, _0x3fcfa4) {
                        return _0x410d71(_0x3fcfa4);
                    },
                    'OXCDl': function (_0x19f9e2, _0x5345fc) {
                        return _0x19f9e2 - _0x5345fc;
                    },
                    'uqEAp': function (_0x5d9ba8, _0x17509d) {
                        return _0x5d9ba8 * _0x17509d;
                    },
                    'uOZnN': function (_0x240446, _0x3f67fd) {
                        return _0x240446 * _0x3f67fd;
                    }
                }, _0xe842f5 = _0xf3cf36[_0x51f9a4(0x83c)](_0x5a3f62, _0x136790);
            return new _0x12ec7d(_0xf3cf36[_0x51f9a4(0x83a)](_0xf3cf36['uqEAp'](this['x'], Math[_0x51f9a4(0xa96)](_0xe842f5)), _0xf3cf36[_0x51f9a4(0xae7)](this['z'], Math['sin'](_0xe842f5))), this['y'], this['x'] * Math['sin'](_0xe842f5) + _0xf3cf36[_0x51f9a4(0x46e)](this['z'], Math['cos'](_0xe842f5)));
        }
        [_0x21f734(0x48d)](_0x41b8d5) {
            const _0x456dbb = _0x21f734;
            return this[_0x456dbb(0x661)](_0x41b8d5['x'])[_0x456dbb(0x4bc)](_0x41b8d5['y']);
        }
        ['roundAll']() {
            const _0x48bad4 = _0x21f734;
            return new _0x12ec7d(Math['round'](this['x']), Math[_0x48bad4(0x75a)](this['y']), Math[_0x48bad4(0x75a)](this['z']));
        }
        [_0x21f734(0x351)]() {
            const _0x1c5e80 = _0x21f734;
            return new _0x12ec7d(Math[_0x1c5e80(0x904)](this['x']), Math[_0x1c5e80(0x904)](this['y']), Math[_0x1c5e80(0x904)](this['z']));
        }
        [_0x21f734(0xa22)]() {
            const _0x36218c = _0x21f734;
            return new _0x12ec7d(Math[_0x36218c(0xa22)](this['x']), Math[_0x36218c(0xa22)](this['y']), Math[_0x36218c(0xa22)](this['z']));
        }
        [_0x21f734(0x80d)](_0x15e805) {
            const _0x164559 = _0x21f734, _0x1e5da5 = {
                    'xbNtn': function (_0x1c2956, _0x4ad4ac) {
                        return _0x1c2956 === _0x4ad4ac;
                    },
                    'puqQv': function (_0x1c34d8, _0x51a7a4) {
                        return _0x1c34d8 === _0x51a7a4;
                    }
                };
            return _0x1e5da5['xbNtn'](this['x'], _0x15e805['x']) && _0x1e5da5[_0x164559(0x748)](this['y'], _0x15e805['y']) && _0x1e5da5[_0x164559(0x748)](this['z'], _0x15e805['z']);
        }
        [_0x21f734(0x948)]() {
            const _0x16ee49 = _0x21f734;
            return _0x16ee49(0xa05) + this['x'] + ',\x20' + this['y'] + ',\x20' + this['z'] + ')';
        }
        [_0x21f734(0xaa5)](_0x53c61f) {
            const _0x2e40e4 = _0x21f734, _0x1b734b = {
                    'PnkRE': function (_0x33f43b, _0x3df1a8) {
                        return _0x33f43b * _0x3df1a8;
                    },
                    'XqLZh': function (_0x258f6f, _0x4e528e) {
                        return _0x258f6f * _0x4e528e;
                    },
                    'gJSql': function (_0x849a65, _0x12a84a) {
                        return _0x849a65 * _0x12a84a;
                    }
                };
            return new _0x12ec7d(_0x1b734b[_0x2e40e4(0x7d4)](this['x'], _0x53c61f), _0x1b734b[_0x2e40e4(0x5a5)](this['y'], _0x53c61f), _0x1b734b[_0x2e40e4(0x885)](this['z'], _0x53c61f));
        }
        static [_0x21f734(0x801)](_0x169272, _0x10891b) {
            const _0x1ea05e = _0x21f734, _0x29eac5 = {
                    'SDNaV': function (_0x5c0217, _0x55b72f) {
                        return _0x5c0217 + _0x55b72f;
                    },
                    'CGtsy': function (_0xa35fda, _0x22e1a6) {
                        return _0xa35fda ** _0x22e1a6;
                    },
                    'ZNMPE': function (_0x3a3688, _0x302365) {
                        return _0x3a3688 - _0x302365;
                    },
                    'MOEFI': function (_0x5ded73, _0x223137) {
                        return _0x5ded73 - _0x223137;
                    }
                };
            return Math[_0x1ea05e(0x2f8)](_0x29eac5[_0x1ea05e(0x2f6)](_0x29eac5[_0x1ea05e(0x2f6)](_0x29eac5[_0x1ea05e(0xa40)](_0x29eac5[_0x1ea05e(0x72c)](_0x169272['x'], _0x10891b['x']), 0x2), _0x29eac5[_0x1ea05e(0x56c)](_0x169272['y'], _0x10891b['y']) ** 0x2), _0x29eac5[_0x1ea05e(0xa40)](_0x29eac5[_0x1ea05e(0x56c)](_0x169272['z'], _0x10891b['z']), 0x2)));
        }
    }, _0x5d0809 = {
        'overworld': _0x362f98[_0x21f734(0xaec)](MinecraftDimensionTypes[_0x21f734(0x1df)]),
        'nether': _0x362f98[_0x21f734(0xaec)](MinecraftDimensionTypes['nether']),
        'the_end': _0x362f98[_0x21f734(0xaec)](MinecraftDimensionTypes[_0x21f734(0xa61)])
    };
function _0x59bdcb(_0x5314a5, _0x1a9abf) {
    const _0x11c5ff = _0x21f734, _0x1c70ec = { 'yVghn': _0x11c5ff(0x4e1) }, _0x2cb7e7 = _0x5314a5[_0x11c5ff(0x3cc)](_0x1c70ec[_0x11c5ff(0x8b4)]);
    if (!_0x2cb7e7)
        return void 0x0;
    return _0x2cb7e7[_0x11c5ff(0x72d)](_0x1a9abf);
}
function _0x5c2500(_0x318a91, _0x38db9f, _0x2d57f6) {
    const _0x53c87d = _0x21f734, _0x7ff9b2 = { 'TXWPe': _0x53c87d(0x4e1) }, _0x5784bf = _0x318a91[_0x53c87d(0x3cc)](_0x7ff9b2[_0x53c87d(0x4b4)]);
    _0x5784bf[_0x53c87d(0x9d4)](_0x38db9f, _0x2d57f6);
}
function _0x467466(_0x44f917, _0xbd7b4, _0x44ee71) {
    const _0x22cd75 = _0x21f734, _0x58e7fa = {
            'EBhOs': _0x22cd75(0xb63),
            'PfULg': function (_0x5db709, _0x2e09a6) {
                return _0x5db709 < _0x2e09a6;
            },
            'EFIHG': function (_0x120fa4, _0x570b0f) {
                return _0x120fa4 === _0x570b0f;
            },
            'hAQJy': function (_0x1ccb18, _0x47b93e) {
                return _0x1ccb18 - _0x47b93e;
            },
            'KGFoc': function (_0x571813, _0x16d7ba) {
                return _0x571813 >= _0x16d7ba;
            }
        }, _0x1ed4d1 = _0x44f917[_0x22cd75(0x3cc)](_0x58e7fa['EBhOs']), _0x1a978e = _0x1ed4d1?.[_0x22cd75(0xa39)];
    if (!_0x1a978e) {
        _0x44f917['dimension'][_0x22cd75(0x220)](_0xbd7b4, _0x44f917[_0x22cd75(0x2c0)]);
        return;
    }
    if (_0x1ed4d1['container']['emptySlotsCount'] === 0x0) {
        let _0x360a42 = 0x0;
        for (let _0x38a033 = 0x0; _0x58e7fa[_0x22cd75(0xb4e)](_0x38a033, _0x1a978e['size']); _0x38a033++) {
            const _0x504337 = _0x1a978e[_0x22cd75(0x76b)](_0x38a033);
            if (_0x58e7fa['EFIHG'](_0x504337['getItem']()?.[_0x22cd75(0x1b9)], _0xbd7b4[_0x22cd75(0x1b9)])) {
                _0x360a42 += Math['max'](_0x58e7fa[_0x22cd75(0xa46)](_0x504337[_0x22cd75(0xa57)], _0x504337[_0x22cd75(0x5c5)]), 0x0);
                if (_0x58e7fa[_0x22cd75(0x53f)](_0x360a42, _0xbd7b4['amount']))
                    break;
            }
        }
        const _0x24fe4b = _0xbd7b4['amount'] - _0x360a42;
        if (_0x24fe4b > 0x0) {
            const _0x14cdbf = _0xbd7b4[_0x22cd75(0x733)]();
            _0x14cdbf[_0x22cd75(0x5c5)] = _0x24fe4b;
            const _0x219963 = _0x44f917[_0x22cd75(0x2c0)];
            _0x44ee71?.[_0x22cd75(0x24e)] && (_0x219963['x'] += _0x44ee71[_0x22cd75(0x24e)]['x'], _0x219963['y'] += _0x44ee71[_0x22cd75(0x24e)]['y'], _0x219963['z'] += _0x44ee71[_0x22cd75(0x24e)]['z']);
            const _0x592f84 = _0x44f917[_0x22cd75(0xb28)]['spawnItem'](_0x14cdbf, _0x219963);
            _0x44ee71?.[_0x22cd75(0x77f)]?.(_0x592f84);
        }
    }
    _0x1ed4d1[_0x22cd75(0xa39)][_0x22cd75(0xbef)](_0xbd7b4);
}
function _0x2c8ecf(_0x1bf2f5, _0x9f400d, _0x1256cc = 0x1, _0x379480) {
    const _0x90dbd8 = _0x21f734, _0xcc3d4d = {
            'hBlNV': _0x90dbd8(0xb63),
            'BnKwT': function (_0x19b683, _0x86760c) {
                return _0x19b683 instanceof _0x86760c;
            },
            'ReCzf': function (_0x3357ca, _0x19b210) {
                return _0x3357ca === _0x19b210;
            },
            'McfQK': function (_0x4c2cb4, _0x2e8f06) {
                return _0x4c2cb4 < _0x2e8f06;
            },
            'iCFro': function (_0x46c886, _0xade26b) {
                return _0x46c886 > _0xade26b;
            },
            'lXIZS': function (_0x49f0b4, _0x38dba3) {
                return _0x49f0b4 <= _0x38dba3;
            }
        }, _0x29c11b = _0x1bf2f5['getComponent'](_0xcc3d4d['hBlNV']), _0x25ef4a = _0x29c11b?.[_0x90dbd8(0xa39)];
    if (_0xcc3d4d[_0x90dbd8(0x642)](_0x1bf2f5, Player) && _0x379480 && _0xcc3d4d[_0x90dbd8(0x503)](_0x1bf2f5[_0x90dbd8(0x271)](), GameMode['creative']))
        return !![];
    if (!_0x25ef4a)
        return ![];
    let _0x1f918c = _0x1256cc;
    for (let _0x46b635 = 0x0; _0xcc3d4d[_0x90dbd8(0x5bd)](_0x46b635, _0x25ef4a[_0x90dbd8(0x87e)]); _0x46b635++) {
        const _0x254036 = _0x25ef4a[_0x90dbd8(0x76b)](_0x46b635), _0x586e1d = _0x254036[_0x90dbd8(0x5cb)]();
        if (_0xcc3d4d[_0x90dbd8(0x503)](_0x586e1d?.[_0x90dbd8(0x1b9)], _0x9f400d)) {
            if (_0xcc3d4d['iCFro'](_0x586e1d['amount'], _0x1f918c))
                return _0x586e1d['amount'] -= _0x1f918c, _0x254036[_0x90dbd8(0x5a6)](_0x586e1d), !![];
            else {
                _0x1f918c -= _0x586e1d[_0x90dbd8(0x5c5)], _0x254036[_0x90dbd8(0x5a6)](void 0x0);
                if (_0xcc3d4d[_0x90dbd8(0xb5a)](_0x1f918c, 0x0))
                    return !![];
            }
        }
    }
    return _0xcc3d4d[_0x90dbd8(0xb5a)](_0x1f918c, 0x0);
}
function _0x2108be(_0x44e44f, _0x2af91b) {
    const _0x142931 = _0x21f734, _0x955e07 = {
            'ndwTR': function (_0x566ca0, _0x2b6f2f) {
                return _0x566ca0 === _0x2b6f2f;
            },
            'zUtFG': _0x142931(0x6df),
            'TUXgx': function (_0x222a4c, _0x34b6e2) {
                return _0x222a4c && _0x34b6e2;
            },
            'SnUQc': _0x142931(0x810),
            'raSoB': _0x142931(0x4ef),
            'twmGW': function (_0x213bb8, _0xc70cd6) {
                return _0x213bb8 / _0xc70cd6;
            },
            'itOXX': function (_0x143f0a, _0x3f7a06) {
                return _0x143f0a < _0x3f7a06;
            },
            'QAInT': function (_0x5e8125, _0x5afb25) {
                return _0x5e8125 === _0x5afb25;
            },
            'OVzfS': function (_0x5bf9de, _0x2cc050, _0x3b2b1f, _0x28d99f) {
                return _0x5bf9de(_0x2cc050, _0x3b2b1f, _0x28d99f);
            },
            'bPWah': _0x142931(0x7ea)
        }, _0x55cad0 = !_0x955e07[_0x142931(0x86f)](_0x2af91b?.[_0x142931(0x73a)], ![]);
    if (_0x55cad0 && _0x955e07[_0x142931(0x86f)](_0x44e44f[_0x142931(0x271)](), GameMode[_0x142931(0x805)]))
        return !![];
    const _0x560063 = _0x59bdcb(_0x44e44f, EquipmentSlot[_0x142931(0xc15)]), _0x43cb40 = _0x560063?.[_0x142931(0x3cc)](_0x955e07['zUtFG']);
    if (_0x955e07[_0x142931(0x550)](_0x560063, _0x43cb40)) {
        let _0x1455bd;
        const _0x4f6fef = _0x560063[_0x142931(0x3cc)](_0x955e07['SnUQc']);
        _0x4f6fef ? _0x1455bd = _0x4f6fef[_0x142931(0x928)](_0x955e07[_0x142931(0x837)])?.['level'] ?? 0x0 : _0x1455bd = 0x0;
        const _0x13473b = _0x955e07['twmGW'](0x1, 0x1 + _0x1455bd);
        if (_0x955e07[_0x142931(0x346)](Math['random'](), _0x13473b))
            return _0x955e07[_0x142931(0xa47)](_0x43cb40[_0x142931(0x91f)], _0x43cb40[_0x142931(0x20e)]) ? (_0x955e07[_0x142931(0x627)](_0x5c2500, _0x44e44f, EquipmentSlot[_0x142931(0xc15)], _0x2af91b?.[_0x142931(0x8a4)] ? new ItemStack(_0x2af91b[_0x142931(0x8a4)], _0x560063['amount']) : void 0x0), _0x362f98[_0x142931(0xa70)](_0x2af91b?.['destructionSound'] || _0x955e07['bPWah'], _0x44e44f['location'])) : (_0x43cb40[_0x142931(0x91f)]++, _0x5c2500(_0x44e44f, EquipmentSlot[_0x142931(0xc15)], _0x560063)), !![];
    }
    return ![];
}
function _0xed22af(_0x52ea3e, _0x23474a = 0x1, _0x1e3df3 = ![]) {
    const _0x27b161 = _0x21f734, _0x51d06f = {
            'XQCes': function (_0x14a1c1, _0x5d0106) {
                return _0x14a1c1 === _0x5d0106;
            },
            'EldUV': function (_0x810f90, _0x45d64d) {
                return _0x810f90 > _0x45d64d;
            },
            'qtnfy': function (_0x4bb707, _0x540cbc, _0x2e528c, _0x3a0095) {
                return _0x4bb707(_0x540cbc, _0x2e528c, _0x3a0095);
            }
        };
    if (_0x1e3df3 && _0x51d06f['XQCes'](_0x52ea3e[_0x27b161(0x271)](), GameMode['creative']))
        return !![];
    const _0x1c1190 = _0x59bdcb(_0x52ea3e, EquipmentSlot['Mainhand']);
    if (_0x1c1190)
        return _0x51d06f[_0x27b161(0x846)](_0x1c1190[_0x27b161(0x5c5)], _0x23474a) ? (_0x1c1190['amount'] -= _0x23474a, _0x51d06f[_0x27b161(0x8e6)](_0x5c2500, _0x52ea3e, EquipmentSlot[_0x27b161(0xc15)], _0x1c1190)) : _0x5c2500(_0x52ea3e, EquipmentSlot[_0x27b161(0xc15)], void 0x0), !![];
    return ![];
}
function _0x17e1c1(_0x5697a7) {
    const _0x22cc69 = _0x21f734, _0x16ec6b = {
            'JXpJU': function (_0x32f29d, _0x32ade8) {
                return _0x32f29d > _0x32ade8;
            },
            'uJmQI': _0x22cc69(0x709),
            'DTHKO': function (_0x5c8643, _0x1b3c29) {
                return _0x5c8643 > _0x1b3c29;
            },
            'DMyRn': _0x22cc69(0x6a6),
            'kBbyF': _0x22cc69(0x571)
        }, {
            x: _0xe0cae5,
            z: _0x113062
        } = _0x5697a7;
    return _0x16ec6b['JXpJU'](Math[_0x22cc69(0xa22)](_0xe0cae5), Math[_0x22cc69(0xa22)](_0x113062)) ? _0xe0cae5 > 0x0 ? 'east' : _0x16ec6b[_0x22cc69(0x3a8)] : _0x16ec6b[_0x22cc69(0x570)](_0x113062, 0x0) ? _0x16ec6b['DMyRn'] : _0x16ec6b[_0x22cc69(0x2e9)];
}
function _0x467cb6(_0x1ded8c, _0x50400d) {
    const _0x39c46f = _0x21f734, _0x20f744 = {
            'gdrDi': _0x39c46f(0x93d),
            'GFxYI': function (_0x51f852, _0x560086) {
                return _0x51f852 === _0x560086;
            }
        };
    let _0x20d10d = 0x0;
    const _0x2f8c48 = _0x1ded8c['getComponent'](_0x20f744[_0x39c46f(0x860)]);
    for (let _0x350b70 = 0x0; _0x350b70 < _0x2f8c48[_0x39c46f(0x94f)]; _0x350b70++) {
        const _0x14deb9 = _0x2f8c48[_0x39c46f(0xa39)]?.['getItem'](_0x350b70);
        _0x14deb9 && _0x20f744[_0x39c46f(0x251)](_0x14deb9[_0x39c46f(0x1b9)], _0x50400d) && (_0x20d10d += _0x14deb9[_0x39c46f(0x5c5)]);
    }
    return _0x20d10d;
}
function _0x1451f2(_0x4c341a, _0x32fcc3) {
    const _0x2139e6 = _0x21f734, _0x1db47e = {
            'qSAbC': 'inventory',
            'GJLSJ': _0x2139e6(0x328),
            'qBMqV': _0x2139e6(0x360),
            'dfnLH': _0x2139e6(0x579),
            'iwJRW': _0x2139e6(0xa20),
            'NhpCP': _0x2139e6(0x204),
            'BaanW': _0x2139e6(0x7aa),
            'iwvtP': _0x2139e6(0x3bd),
            'GAqTr': function (_0x4a8ef7, _0x4423aa) {
                return _0x4a8ef7 < _0x4423aa;
            }
        }, _0x3cf2dd = _0x4c341a[_0x2139e6(0x3cc)](_0x1db47e['qSAbC']);
    let _0x5dafcb = _0x3cf2dd['container'];
    if (!_0x5dafcb)
        return;
    let _0x473a5b = _0x5dafcb[_0x2139e6(0x87e)];
    const _0x4121be = [], _0x28c365 = [
            _0x1db47e[_0x2139e6(0x79c)],
            _0x1db47e[_0x2139e6(0x9fa)],
            _0x1db47e[_0x2139e6(0x365)],
            _0x2139e6(0x7af),
            _0x1db47e['iwJRW']
        ];
    let _0x4b999a = [];
    for (let _0x440070 = 0x0; _0x440070 < _0x28c365['length']; _0x440070++) {
        const _0x1e936d = _0x4c341a[_0x2139e6(0x3cc)](_0x1db47e['NhpCP']);
        if (!_0x1e936d)
            continue;
        const _0x449450 = _0x1e936d[_0x2139e6(0x72d)](_0x28c365[_0x440070]);
        if (!_0x449450) {
            _0x4b999a[_0x2139e6(0x28e)](null);
            continue;
        }
        const _0x2b3573 = {
            'typeId': _0x449450[_0x2139e6(0x1b9)],
            'props': {
                'amount': _0x449450[_0x2139e6(0x5c5)],
                'keepOnDeath': _0x449450['keepOnDeath'],
                'lockMode': _0x449450[_0x2139e6(0x1fd)],
                'nameTag': _0x449450['nameTag']
            },
            'lore': _0x449450[_0x2139e6(0x7bb)](),
            'components': {}
        };
        if (_0x449450['nameTag'])
            _0x2b3573[_0x2139e6(0xb06)][_0x2139e6(0xac1)] = _0x449450[_0x2139e6(0xac1)];
        if (_0x449450[_0x2139e6(0x211)](_0x1db47e[_0x2139e6(0x452)])) {
            const _0x58f597 = _0x449450[_0x2139e6(0x3cc)](_0x1db47e[_0x2139e6(0x452)]);
            _0x58f597 && (_0x2b3573[_0x2139e6(0x99d)][_0x2139e6(0x7aa)] = _0x58f597[_0x2139e6(0x7ca)]()[_0x2139e6(0x2dc)](_0x2c631a => ({
                'type': _0x2c631a[_0x2139e6(0xc08)]['id'],
                'level': _0x2c631a[_0x2139e6(0x98d)]
            })));
        }
        if (_0x449450[_0x2139e6(0x211)](_0x1db47e[_0x2139e6(0x529)])) {
            const _0x27088e = _0x449450['getComponent'](_0x1db47e['iwvtP']);
            _0x2b3573[_0x2139e6(0x99d)]['durability'] = _0x27088e[_0x2139e6(0x91f)];
        }
        _0x4b999a['push'](_0x2b3573);
    }
    _0x362f98[_0x2139e6(0x483)](_0x2139e6(0x78f) + _0x32fcc3, JSON[_0x2139e6(0x464)](_0x4b999a));
    for (let _0x309031 = 0x0; _0x1db47e[_0x2139e6(0x205)](_0x309031, _0x473a5b); _0x309031++) {
        const _0x2ae66b = _0x5dafcb['getItem'](_0x309031);
        if (!_0x2ae66b) {
            _0x4121be[_0x2139e6(0x28e)](null);
            continue;
        }
        const _0x3ff0ef = {
            'typeId': _0x2ae66b[_0x2139e6(0x1b9)],
            'props': {
                'amount': _0x2ae66b[_0x2139e6(0x5c5)],
                'keepOnDeath': _0x2ae66b[_0x2139e6(0x4dc)],
                'lockMode': _0x2ae66b['lockMode'],
                'nameTag': _0x2ae66b[_0x2139e6(0xac1)]
            },
            'lore': _0x2ae66b[_0x2139e6(0x7bb)](),
            'components': {}
        };
        if (_0x2ae66b[_0x2139e6(0xac1)])
            _0x3ff0ef['props'][_0x2139e6(0xac1)] = _0x2ae66b['nameTag'];
        if (_0x2ae66b[_0x2139e6(0x211)]('enchantable')) {
            const _0x36765d = _0x2ae66b[_0x2139e6(0x3cc)](_0x1db47e['BaanW']);
            _0x36765d && (_0x3ff0ef['components'][_0x2139e6(0x7aa)] = _0x36765d[_0x2139e6(0x7ca)]()[_0x2139e6(0x2dc)](_0x3719b6 => ({
                'type': _0x3719b6[_0x2139e6(0xc08)]['id'],
                'level': _0x3719b6[_0x2139e6(0x98d)]
            })));
        }
        if (_0x2ae66b[_0x2139e6(0x211)](_0x1db47e['iwvtP'])) {
            const _0x37f3d8 = _0x2ae66b['getComponent']('durability');
            _0x3ff0ef[_0x2139e6(0x99d)][_0x2139e6(0x3bd)] = _0x37f3d8['damage'];
        }
        _0x4121be[_0x2139e6(0x28e)](_0x3ff0ef);
    }
    return _0x362f98['setDynamicProperty'](_0x2139e6(0x540) + _0x32fcc3, JSON[_0x2139e6(0x464)](_0x4121be)), {
        'items': _0x4121be,
        'wornArmor': _0x4b999a
    };
}
function _0x4ffe09(_0x16c63d, _0x3e9b09, _0x26878f) {
    const _0x4254aa = _0x21f734, _0x3363f9 = {
            'uklUZ': function (_0x145cc9, _0x303084) {
                return _0x145cc9 < _0x303084;
            },
            'gvdEf': function (_0x19c1c0, _0x51752a) {
                return _0x19c1c0 !== _0x51752a;
            },
            'CPFRZ': function (_0x3fb045, _0x33c776) {
                return _0x3fb045 !== _0x33c776;
            },
            'sdMGa': _0x4254aa(0x7aa),
            'oABHS': _0x4254aa(0x3bd),
            'IZpTF': function (_0x81d68a, _0x378ff2) {
                return _0x81d68a < _0x378ff2;
            },
            'ayZSm': function (_0x3dc8ee, _0x4c02dc) {
                return _0x3dc8ee !== _0x4c02dc;
            },
            'JdiKX': function (_0x39ee81, _0x5e4bbb) {
                return _0x39ee81 !== _0x5e4bbb;
            },
            'ZWPaz': function (_0x214d93, _0x3ce281) {
                return _0x214d93 !== _0x3ce281;
            }
        };
    try {
        const _0x32ab7c = JSON[_0x4254aa(0x438)](_0x362f98[_0x4254aa(0xb95)](_0x4254aa(0x540) + _0x16c63d) ?? '[]'), _0x58b4ca = JSON[_0x4254aa(0x438)](_0x362f98[_0x4254aa(0xb95)](_0x4254aa(0x78f) + _0x16c63d) ?? '[]');
        for (let _0xd73eab = 0x0; _0x3363f9['uklUZ'](_0xd73eab, _0x32ab7c[_0x4254aa(0x51f)]); _0xd73eab++) {
            const _0x23324d = _0x32ab7c[_0xd73eab];
            if (!_0x23324d)
                continue;
            try {
                const _0x2593f8 = new ItemStack(_0x23324d[_0x4254aa(0x1b9)], _0x23324d[_0x4254aa(0xb06)]['amount']);
                if (_0x493aa0[_0x4254aa(0x620)](_0x23324d[_0x4254aa(0x1b9)]))
                    continue;
                if (_0x23324d[_0x4254aa(0xb06)]['keepOnDeath'] !== void 0x0)
                    _0x2593f8[_0x4254aa(0x4dc)] = _0x23324d[_0x4254aa(0xb06)]['keepOnDeath'];
                if (_0x3363f9[_0x4254aa(0x97b)](_0x23324d[_0x4254aa(0xb06)][_0x4254aa(0x1fd)], void 0x0))
                    _0x2593f8[_0x4254aa(0x1fd)] = _0x23324d[_0x4254aa(0xb06)]['lockMode'];
                if (_0x3363f9[_0x4254aa(0x23e)](_0x23324d[_0x4254aa(0xb06)]['nameTag'], void 0x0))
                    _0x2593f8[_0x4254aa(0xac1)] = _0x23324d[_0x4254aa(0xb06)][_0x4254aa(0xac1)];
                if (_0x23324d[_0x4254aa(0x9dd)])
                    _0x2593f8['setLore'](_0x23324d[_0x4254aa(0x9dd)]);
                if (_0x23324d[_0x4254aa(0x99d)] && _0x23324d[_0x4254aa(0x99d)][_0x4254aa(0x7aa)]) {
                    const _0x47ba7d = _0x2593f8['getComponent'](_0x3363f9[_0x4254aa(0x5ee)]);
                    _0x47ba7d && _0x47ba7d[_0x4254aa(0x268)](_0x23324d[_0x4254aa(0x99d)][_0x4254aa(0x7aa)][_0x4254aa(0x2dc)](_0x4f2f11 => ({
                        'type': EnchantmentTypes[_0x4254aa(0x3c7)](_0x4f2f11[_0x4254aa(0xc08)]),
                        'level': _0x4f2f11[_0x4254aa(0x98d)]
                    })));
                }
                if (_0x23324d['components'] && _0x23324d['components'][_0x4254aa(0x3bd)]) {
                    const _0x53e1bd = _0x2593f8['getComponent'](_0x3363f9[_0x4254aa(0x7e8)]);
                    _0x53e1bd && (_0x53e1bd[_0x4254aa(0x91f)] = _0x23324d['components'][_0x4254aa(0x3bd)]);
                }
                _0x3e9b09['spawnItem'](_0x2593f8, _0x26878f);
            } catch (_0x1715e4) {
                console[_0x4254aa(0x73d)]('Failed\x20to\x20spawn\x20item:\x20' + _0x23324d[_0x4254aa(0x1b9)]);
            }
        }
        for (let _0x2544e6 = 0x0; _0x3363f9[_0x4254aa(0xa36)](_0x2544e6, _0x58b4ca[_0x4254aa(0x51f)]); _0x2544e6++) {
            const _0x32b259 = _0x58b4ca[_0x2544e6];
            if (!_0x32b259)
                continue;
            try {
                const _0x202711 = new ItemStack(_0x32b259[_0x4254aa(0x1b9)], _0x32b259['props'][_0x4254aa(0x5c5)]);
                if (_0x3363f9[_0x4254aa(0x658)](_0x32b259[_0x4254aa(0xb06)][_0x4254aa(0x4dc)], void 0x0))
                    _0x202711[_0x4254aa(0x4dc)] = _0x32b259[_0x4254aa(0xb06)][_0x4254aa(0x4dc)];
                if (_0x3363f9[_0x4254aa(0x1d1)](_0x32b259[_0x4254aa(0xb06)]['lockMode'], void 0x0))
                    _0x202711['lockMode'] = _0x32b259['props'][_0x4254aa(0x1fd)];
                if (_0x3363f9['ZWPaz'](_0x32b259[_0x4254aa(0xb06)]['nameTag'], void 0x0))
                    _0x202711[_0x4254aa(0xac1)] = _0x32b259[_0x4254aa(0xb06)][_0x4254aa(0xac1)];
                if (_0x32b259[_0x4254aa(0x9dd)])
                    _0x202711[_0x4254aa(0x870)](_0x32b259[_0x4254aa(0x9dd)]);
                if (_0x32b259[_0x4254aa(0x99d)] && _0x32b259['components']['enchantable']) {
                    const _0x147b91 = _0x202711[_0x4254aa(0x3cc)](_0x3363f9[_0x4254aa(0x5ee)]);
                    _0x147b91 && _0x147b91[_0x4254aa(0x268)](_0x32b259['components']['enchantable'][_0x4254aa(0x2dc)](_0x3b39b9 => ({
                        'type': EnchantmentTypes[_0x4254aa(0x3c7)](_0x3b39b9['type']),
                        'level': _0x3b39b9[_0x4254aa(0x98d)]
                    })));
                }
                if (_0x32b259[_0x4254aa(0x99d)] && _0x32b259[_0x4254aa(0x99d)][_0x4254aa(0x3bd)]) {
                    const _0x4c6ce5 = _0x202711[_0x4254aa(0x3cc)](_0x4254aa(0x3bd));
                    _0x4c6ce5 && (_0x4c6ce5[_0x4254aa(0x91f)] = _0x32b259[_0x4254aa(0x99d)][_0x4254aa(0x3bd)]);
                }
                _0x3e9b09[_0x4254aa(0x220)](_0x202711, _0x26878f);
            } catch (_0x5277f7) {
                console[_0x4254aa(0x73d)](_0x4254aa(0x74b) + _0x32b259['typeId']);
            }
        }
        _0x362f98[_0x4254aa(0x483)]('inventory:' + _0x16c63d, void 0x0), _0x362f98[_0x4254aa(0x483)](_0x4254aa(0x78f) + _0x16c63d, void 0x0);
    } catch (_0x1d5f2a) {
        console[_0x4254aa(0x73d)](_0x4254aa(0x27a) + _0x16c63d + ':\x20' + _0x1d5f2a);
    }
}
function _0x25e63f(_0x4ca570, _0x2e0482, _0x1521d7) {
    const _0xef507a = _0x21f734, _0x239b20 = {
            'foOyf': function (_0x59fa4f, _0x3ad58d) {
                return _0x59fa4f / _0x3ad58d;
            },
            'ZWYry': function (_0xe0db3e, _0x2b9471) {
                return _0xe0db3e - _0x2b9471;
            },
            'NubbC': function (_0x2a3997, _0xc977c5) {
                return _0x2a3997 + _0xc977c5;
            },
            'DfmmW': function (_0x4f4c14, _0x416c1f) {
                return _0x4f4c14 / _0x416c1f;
            },
            'heUav': function (_0x2f29fe, _0x336720) {
                return _0x2f29fe / _0x336720;
            },
            'elqJM': function (_0x352b1f, _0x5a9434) {
                return _0x352b1f * _0x5a9434;
            },
            'pFDjm': function (_0x2d6236, _0xecf471) {
                return _0x2d6236 - _0xecf471;
            },
            'gdJtP': _0xef507a(0x393)
        };
    try {
        const _0x272689 = _0x4ca570[_0xef507a(0x759)]({
                'location': _0x2e0482,
                'maxDistance': _0x1521d7['range'] || 0x1e,
                'type': _0x239b20[_0xef507a(0x37b)]
            }), _0x39ad16 = _0x1521d7[_0xef507a(0xa5d)] || 0x1e;
        _0x272689[_0xef507a(0x3e1)](_0x457d26 => {
            const _0x247a24 = _0xef507a, _0x1ef175 = _0x457d26['location'], _0x1910f2 = {
                    'x': _0x1ef175['x'] + _0x239b20[_0x247a24(0x624)](_0x239b20[_0x247a24(0x5d5)](_0x2e0482['x'], _0x1ef175['x']), _0x239b20[_0x247a24(0x624)](_0x39ad16, 0x14)),
                    'y': _0x239b20[_0x247a24(0x29a)](_0x1ef175['y'], _0x239b20[_0x247a24(0x1b1)](_0x2e0482['y'] - _0x1ef175['y'], _0x39ad16 / 0x14)),
                    'z': _0x239b20[_0x247a24(0x29a)](_0x1ef175['z'], _0x239b20[_0x247a24(0x5d5)](_0x2e0482['z'], _0x1ef175['z']) / _0x239b20[_0x247a24(0x2e1)](_0x39ad16, 0x14))
                }, _0x559de2 = _0x239b20['elqJM'](_0x590054[_0x247a24(0x801)](_0x1ef175, _0x2e0482), _0x39ad16 / _0x239b20[_0x247a24(0x9ce)](_0x39ad16, _0x239b20[_0x247a24(0x1b1)](_0x39ad16, 1.3)));
            _0x457d26[_0x247a24(0xa70)](_0x1521d7['id'], {
                'location': _0x1910f2,
                'volume': _0x239b20[_0x247a24(0x9ce)](_0x1521d7['volume'] ? _0x1521d7[_0x247a24(0x2b2)] : 0x1, _0x239b20[_0x247a24(0x429)](0x1, _0x559de2)),
                'pitch': _0x1521d7['pitch'] ? _0x1521d7['pitch'] : 0x1
            });
        });
    } catch {
    }
}
function _0x3ea9a1(_0x39dabd, _0x4a0e07) {
    const _0x1bf2b1 = _0x21f734, _0x4e961a = {
            'EhbIG': function (_0x357bcc, _0x25ebb5) {
                return _0x357bcc === _0x25ebb5;
            }
        };
    if (_0x39dabd[_0x1bf2b1(0x1b9)] === _0x4a0e07['id'])
        return !![];
    if (_0x4a0e07[_0x1bf2b1(0x1e6)] && _0x4a0e07[_0x1bf2b1(0x1e6)][_0x1bf2b1(0x620)](_0x39dabd[_0x1bf2b1(0x1b9)]))
        return ![];
    if (Array[_0x1bf2b1(0x2b1)](_0x4a0e07[_0x1bf2b1(0x951)]))
        for (const _0x2aeea9 of _0x4a0e07[_0x1bf2b1(0x951)]) {
            if (_0x39dabd[_0x1bf2b1(0x206)](_0x2aeea9))
                return !![];
        }
    else {
        if (_0x4e961a['EhbIG'](typeof _0x4a0e07[_0x1bf2b1(0x951)], _0x1bf2b1(0xc10))) {
            if (_0x39dabd['hasTag'](_0x4a0e07['tags']))
                return !![];
        }
    }
    const _0x57f8ea = _0x39dabd[_0x1bf2b1(0x3cc)](_0x1bf2b1(0x810));
    if (_0x57f8ea && _0x4a0e07[_0x1bf2b1(0x879)])
        for (const _0x3b22a2 of _0x4a0e07[_0x1bf2b1(0x879)]) {
            if (_0x57f8ea['hasEnchantment'](_0x3b22a2))
                return !![];
        }
    const _0x5749ba = _0x39dabd[_0x1bf2b1(0xbc0)]();
    if (_0x5749ba && _0x4a0e07['components'])
        for (const _0x4466d6 of _0x5749ba) {
            if (_0x4a0e07[_0x1bf2b1(0x99d)]['includes'](_0x4466d6))
                return !![];
        }
    return ![];
}
function _0x3faa9f(_0x593329) {
    const _0x2ac49b = _0x21f734, _0x1c696e = {
            'bBVhv': function (_0x5265ea, _0x73aa09) {
                return _0x5265ea === _0x73aa09;
            }
        }, _0xe5c07d = _0x593329['isSneaking'], _0x284948 = _0x593329[_0x2ac49b(0x1d0)]()['y'], _0xd46be0 = _0x1c696e[_0x2ac49b(0x6ef)](_0x593329[_0x2ac49b(0x271)](), GameMode[_0x2ac49b(0x805)]) && _0x593329['isFlying'];
    if (_0xd46be0 && _0x284948 < 0x0)
        return !![];
    return _0xe5c07d ? !![] : ![];
}
function _0x269639(_0x37f364, _0x43a436, _0x531d7a, _0x30a775) {
    const _0x228faf = _0x21f734, _0x14f802 = {
            'gJCoi': _0x228faf(0x22b),
            'ReCsH': function (_0x162f14, _0x37fd32) {
                return _0x162f14 === _0x37fd32;
            },
            'BEakL': _0x228faf(0xa23),
            'ZcPsR': function (_0xc39e6d, _0x46eb9f) {
                return _0xc39e6d < _0x46eb9f;
            },
            'xGWoj': function (_0x442e13, _0x580352) {
                return _0x442e13 - _0x580352;
            }
        };
    if (_0x14f802[_0x228faf(0x845)](_0x30a775, void 0x0) || _0x30a775)
        _0x37f364[_0x228faf(0xa70)](_0x14f802[_0x228faf(0x932)]);
    const _0x380273 = [_0x228faf(0x6bf) + _0x531d7a + (_0x14f802[_0x228faf(0x594)](_0x531d7a[_0x228faf(0x51f)], 0xc8) ? '$'['repeat'](_0x14f802[_0x228faf(0x8d5)](0xc8, _0x531d7a['length'])) : '')];
    for (const _0x5e1759 of _0x43a436)
        _0x380273[_0x228faf(0x28e)](_0x5e1759);
    _0x37f364[_0x228faf(0x7b1)](_0x380273);
    if (_0x14f802['ReCsH'](_0x30a775, void 0x0) || _0x30a775)
        system[_0x228faf(0x873)](() => {
            const _0x496499 = _0x228faf;
            if (_0x37f364 && _0x37f364[_0x496499(0x9ed)]())
                _0x37f364[_0x496499(0xa70)](_0x14f802[_0x496499(0x8f0)]);
        }, 0x6c);
}
function _0x45c2ab(_0x3965c1, _0x238fb6) {
    const _0x3f8684 = _0x21f734;
    _0x3965c1[_0x3f8684(0x32a)](_0x3f8684(0x7c7) + _0x238fb6['x'] + '\x20' + _0x238fb6['y'] + '\x20' + _0x238fb6['z'] + _0x3f8684(0x6a0));
}
var _0x1c49ea = class _0x4943c6 {
    constructor(_0x1bd09c) {
        const _0x1147ad = _0x21f734;
        this[_0x1147ad(0xa49)] = _0x1bd09c;
    }
    static [_0x21f734(0x760)](_0x4e624b) {
        const _0x49e401 = _0x21f734, _0x46ada1 = new _0x4943c6(_0x4e624b);
        _0x4943c6[_0x49e401(0x752)]['push'](_0x46ada1);
    }
    static [_0x21f734(0x48b)]() {
        _0x251fff['beforeEvents']['worldInitialize']['subscribe'](_0x5c797d => {
            const _0x4b4aa3 = _0x3124;
            _0x5c797d['blockComponentRegistry']['registerCustomComponent'](_0x207994 + ':seat', {
                'onPlayerInteract': _0x2ad5c1 => this[_0x4b4aa3(0x4ba)](_0x2ad5c1),
                'onPlayerDestroy': _0x53f376 => this[_0x4b4aa3(0x800)](_0x53f376)
            });
        });
    }
    static [_0x21f734(0x4ba)](_0x49fee9) {
        const _0x198dc8 = _0x21f734, _0xcb35bb = {
                'BrPOs': function (_0x5619aa, _0x2864d0) {
                    return _0x5619aa || _0x2864d0;
                },
                'TvpAh': function (_0x5d4649, _0x303b11, _0xb8847f) {
                    return _0x5d4649(_0x303b11, _0xb8847f);
                },
                'LOBua': function (_0x13a64f, _0x57e6ee) {
                    return _0x13a64f + _0x57e6ee;
                },
                'zHCTd': function (_0x5d0ccd, _0xedb90f) {
                    return _0x5d0ccd + _0xedb90f;
                }
            }, _0x534965 = _0x49fee9['block'], _0x55e68f = _0x49fee9['player'];
        if (_0xcb35bb['BrPOs'](!_0x534965, !_0x55e68f))
            return;
        const _0x5bd0c9 = _0xcb35bb[_0x198dc8(0x3e5)](_0x59bdcb, _0x55e68f, _0x50f8fd['Mainhand']);
        if (!_0x534965['above']()?.[_0x198dc8(0x206)](_0x207994 + ':cushion')) {
            if (_0x5bd0c9?.[_0x198dc8(0x1b9)][_0x198dc8(0x23a)](_0x198dc8(0x2eb)))
                return;
        }
        const _0x8b43f0 = _0x4943c6[_0x198dc8(0x752)][_0x198dc8(0x65e)](_0x23dde6 => _0x23dde6[_0x198dc8(0xa49)]['id'] === _0x534965[_0x198dc8(0x1b9)]);
        if (!_0x8b43f0)
            return;
        const _0x702d70 = {
                'x': _0xcb35bb[_0x198dc8(0x47b)](_0x534965[_0x198dc8(0x2c0)]['x'], _0x8b43f0['config'][_0x198dc8(0x7a9)]['x']),
                'y': _0x534965[_0x198dc8(0x2c0)]['y'] + _0x8b43f0[_0x198dc8(0xa49)][_0x198dc8(0x7a9)]['y'],
                'z': _0xcb35bb[_0x198dc8(0x72a)](_0x534965[_0x198dc8(0x2c0)]['z'], _0x8b43f0[_0x198dc8(0xa49)]['position']['z'])
            }, _0x53c546 = _0x534965[_0x198dc8(0x5fa)][_0x198dc8(0x30a)](_0x198dc8(0xba4)), _0x56b6a6 = this[_0x198dc8(0x863)](_0x53c546), _0x30aa8c = _0x534965['dimension']['spawnEntity'](_0x207994 + _0x198dc8(0x866), _0x702d70);
        _0x30aa8c[_0x198dc8(0x974)](_0x56b6a6), _0x30aa8c[_0x198dc8(0x27c)]('/ride\x20\x22' + _0x55e68f[_0x198dc8(0x497)] + _0x198dc8(0x819)), _0x4227d9[_0x198dc8(0x873)](() => {
            const _0x21ea78 = _0x198dc8;
            _0x30aa8c['triggerEvent'](_0x207994 + _0x21ea78(0x874));
        }, 0x1);
    }
    static [_0x21f734(0x800)](_0x4df7e6) {
        const _0x3cbffd = _0x21f734, _0x4b3b33 = _0x4df7e6['block']['dimension'][_0x3cbffd(0xa67)](_0x4df7e6[_0x3cbffd(0x87b)][_0x3cbffd(0x2c0)])[_0x3cbffd(0x65e)](_0xe31c0c => _0xe31c0c['typeId'] === _0x207994 + _0x3cbffd(0x866));
        if (_0x4b3b33)
            _0x4b3b33[_0x3cbffd(0x44b)]();
    }
    static [_0x21f734(0x863)](_0x303abf) {
        const _0x3891e5 = _0x21f734, _0x2ade5e = {
                'opdkY': _0x3891e5(0x571),
                'SIiYS': _0x3891e5(0x6a6),
                'pZMRx': _0x3891e5(0x7bd),
                'OFfyo': _0x3891e5(0x709)
            };
        switch (_0x303abf) {
        case _0x2ade5e[_0x3891e5(0x923)]:
            return {
                'x': 0x0,
                'y': 0x0
            };
        case _0x2ade5e['SIiYS']:
            return {
                'x': 0x0,
                'y': 0xb4
            };
        case _0x2ade5e[_0x3891e5(0x49c)]:
            return {
                'x': 0x0,
                'y': 0x5a
            };
        case _0x2ade5e[_0x3891e5(0xb5f)]:
            return {
                'x': 0x0,
                'y': 0x10e
            };
        default:
            return {
                'x': 0x0,
                'y': 0x0
            };
        }
    }
};
_0x25e7d0(_0x1c49ea, 'blocks', []);
var _0x4a07fe = _0x1c49ea;
import { world as _0x4c9dc2 } from '@minecraft/server';
var _0x28b227 = class {
    static ['initialize']() {
        const _0x20c65f = _0x21f734;
        _0x4c9dc2[_0x20c65f(0x959)]['worldInitialize'][_0x20c65f(0x725)](_0x43b922 => {
            const _0xc842d7 = _0x20c65f;
            _0x43b922[_0xc842d7(0x2ee)]['registerCustomComponent'](_0x207994 + ':fence_connect', {
                'beforeOnPlayerPlace': _0xf0bebe => this[_0xc842d7(0x3cf)](_0xf0bebe),
                'onPlace': _0x5876b8 => this[_0xc842d7(0x5ff)](_0x5876b8),
                'onPlayerDestroy': _0x3d7f4a => this[_0xc842d7(0xbfe)](_0x3d7f4a)
            });
        }), _0x4c9dc2['afterEvents'][_0x20c65f(0xb88)][_0x20c65f(0x725)](_0x39aacd => {
            this['handleOnDestroy'](_0x39aacd);
        }), _0x4c9dc2[_0x20c65f(0x327)]['playerBreakBlock'][_0x20c65f(0x725)](_0x3be322 => {
            const _0x4d64f0 = _0x20c65f;
            this[_0x4d64f0(0xbfe)](_0x3be322);
        }), _0x4c9dc2[_0x20c65f(0x327)][_0x20c65f(0xa3b)][_0x20c65f(0x725)](_0x12e313 => {
            const _0x95eb83 = _0x20c65f;
            this[_0x95eb83(0x5ff)](_0x12e313);
        });
    }
    static ['handleBeforePlacement'](_0x33f72c) {
        const _0x44b35f = _0x21f734, _0x3d0ef7 = {
                'jNWLL': _0x44b35f(0xc1f),
                'BIsXi': function (_0x496178, _0x321a48) {
                    return _0x496178 != _0x321a48;
                }
            }, _0x31aaa = _0x33f72c[_0x44b35f(0x87b)][_0x44b35f(0x571)](), _0x4a101c = _0x33f72c[_0x44b35f(0x87b)][_0x44b35f(0x6a6)](), _0x1e0236 = _0x33f72c[_0x44b35f(0x87b)][_0x44b35f(0x7bd)](), _0x2de689 = _0x33f72c[_0x44b35f(0x87b)]['west'](), _0x284cf8 = _0x33f72c[_0x44b35f(0x87b)][_0x44b35f(0x291)]();
        _0x284cf8 && !this[_0x44b35f(0x98c)]['includes'](_0x284cf8[_0x44b35f(0x1b9)]) && !_0x284cf8?.[_0x44b35f(0x206)](_0x3d0ef7['jNWLL']) && (_0x3d0ef7[_0x44b35f(0x273)](_0x33f72c['permutationToPlace'][_0x44b35f(0x30a)](_0x207994 + _0x44b35f(0x930)), void 0x0) && (_0x33f72c[_0x44b35f(0x2c1)] = _0x33f72c[_0x44b35f(0x2c1)]['withState'](_0x207994 + _0x44b35f(0x930), !![]))), _0x31aaa && !this[_0x44b35f(0x98c)][_0x44b35f(0x620)](_0x31aaa[_0x44b35f(0x1b9)]) && !_0x31aaa?.['hasTag'](_0x3d0ef7[_0x44b35f(0x1f9)]) && (_0x33f72c[_0x44b35f(0x2c1)] = _0x33f72c[_0x44b35f(0x2c1)][_0x44b35f(0x9d1)](_0x207994 + _0x44b35f(0x446), !![])), _0x4a101c && !this[_0x44b35f(0x98c)]['includes'](_0x4a101c[_0x44b35f(0x1b9)]) && !_0x4a101c?.[_0x44b35f(0x206)](_0x3d0ef7[_0x44b35f(0x1f9)]) && (_0x33f72c[_0x44b35f(0x2c1)] = _0x33f72c[_0x44b35f(0x2c1)][_0x44b35f(0x9d1)](_0x207994 + _0x44b35f(0x236), !![])), _0x1e0236 && !this[_0x44b35f(0x98c)]['includes'](_0x1e0236[_0x44b35f(0x1b9)]) && !_0x1e0236?.[_0x44b35f(0x206)](_0x3d0ef7['jNWLL']) && (_0x33f72c[_0x44b35f(0x2c1)] = _0x33f72c[_0x44b35f(0x2c1)][_0x44b35f(0x9d1)](_0x207994 + _0x44b35f(0x1ac), !![])), _0x2de689 && !this[_0x44b35f(0x98c)][_0x44b35f(0x620)](_0x2de689[_0x44b35f(0x1b9)]) && !_0x2de689?.[_0x44b35f(0x206)](_0x3d0ef7[_0x44b35f(0x1f9)]) && (_0x33f72c[_0x44b35f(0x2c1)] = _0x33f72c['permutationToPlace'][_0x44b35f(0x9d1)](_0x207994 + _0x44b35f(0xa41), !![]));
    }
    static [_0x21f734(0x5ff)](_0x10f84d) {
        const _0xf14713 = _0x21f734, _0x61e188 = { 'KErvp': _0xf14713(0xc1f) }, _0x1113e2 = _0x10f84d['block'];
        if (_0x1113e2['hasTag'](_0x61e188['KErvp']))
            return;
        if (this[_0xf14713(0x98c)][_0xf14713(0x620)](_0x1113e2['typeId']))
            return;
        try {
            const _0x381d8c = _0x1113e2['north'](), _0x8e4de5 = _0x1113e2[_0xf14713(0x6a6)](), _0x2ccf44 = _0x1113e2[_0xf14713(0x7bd)](), _0x8fecbe = _0x1113e2['west'](), _0x2db67b = _0x1113e2['below']();
            _0x2db67b && _0x2db67b[_0xf14713(0x206)](this[_0xf14713(0x82d)]) && (_0x2db67b['permutation'][_0xf14713(0x30a)](_0x207994 + _0xf14713(0x930)) != void 0x0 && _0x2db67b['setPermutation'](_0x2db67b['permutation']['withState'](_0x207994 + _0xf14713(0x930), !![]))), _0x381d8c && _0x381d8c['hasTag'](this[_0xf14713(0x82d)]) && _0x381d8c['setPermutation'](_0x381d8c[_0xf14713(0x5fa)][_0xf14713(0x9d1)](_0x207994 + _0xf14713(0x236), !![])), _0x8e4de5 && _0x8e4de5[_0xf14713(0x206)](this[_0xf14713(0x82d)]) && _0x8e4de5[_0xf14713(0x772)](_0x8e4de5[_0xf14713(0x5fa)][_0xf14713(0x9d1)](_0x207994 + _0xf14713(0x446), !![])), _0x2ccf44 && _0x2ccf44['hasTag'](this['tag']) && _0x2ccf44[_0xf14713(0x772)](_0x2ccf44[_0xf14713(0x5fa)][_0xf14713(0x9d1)](_0x207994 + _0xf14713(0xa41), !![])), _0x8fecbe && _0x8fecbe['hasTag'](this[_0xf14713(0x82d)]) && _0x8fecbe[_0xf14713(0x772)](_0x8fecbe[_0xf14713(0x5fa)][_0xf14713(0x9d1)](_0x207994 + ':connect_east', !![]));
        } catch (_0x3970f7) {
        }
    }
    static [_0x21f734(0xbfe)](_0x2a4e5f) {
        const _0x2da14a = _0x21f734, _0x538bab = {
                'TGGKY': function (_0x129b68, _0x46a1d6) {
                    return _0x129b68 && _0x46a1d6;
                },
                'iQbcX': function (_0x830db0, _0x5d0915) {
                    return _0x830db0 && _0x5d0915;
                },
                'MPEkD': function (_0x364d4b, _0x40d029) {
                    return _0x364d4b && _0x40d029;
                }
            }, _0xb26838 = _0x2a4e5f[_0x2da14a(0x87b)];
        try {
            const _0x114598 = _0xb26838[_0x2da14a(0x571)](), _0x3052d9 = _0xb26838[_0x2da14a(0x6a6)](), _0x30ea5f = _0xb26838[_0x2da14a(0x7bd)](), _0x203932 = _0xb26838['west'](), _0x41c953 = _0xb26838['below'](), _0x1c2f96 = _0x114598?.[_0x2da14a(0x5fa)][_0x2da14a(0x30a)](_0x207994 + _0x2da14a(0x236)), _0x1148a6 = _0x3052d9?.[_0x2da14a(0x5fa)][_0x2da14a(0x30a)](_0x207994 + ':connect_north'), _0x2023b4 = _0x30ea5f?.[_0x2da14a(0x5fa)][_0x2da14a(0x30a)](_0x207994 + ':connect_west'), _0x5e89db = _0x203932?.['permutation'][_0x2da14a(0x30a)](_0x207994 + _0x2da14a(0x1ac)), _0x31bb57 = _0x41c953?.['permutation'][_0x2da14a(0x30a)](_0x207994 + _0x2da14a(0x930));
            _0x538bab[_0x2da14a(0x405)](_0x41c953, _0x31bb57) && _0x41c953[_0x2da14a(0x772)](_0x41c953[_0x2da14a(0x5fa)][_0x2da14a(0x9d1)](_0x207994 + _0x2da14a(0x930), ![])), _0x538bab[_0x2da14a(0x1db)](_0x114598, _0x1c2f96) && _0x114598[_0x2da14a(0x772)](_0x114598[_0x2da14a(0x5fa)][_0x2da14a(0x9d1)](_0x207994 + ':connect_south', ![])), _0x538bab['TGGKY'](_0x3052d9, _0x1148a6) && _0x3052d9['setPermutation'](_0x3052d9['permutation'][_0x2da14a(0x9d1)](_0x207994 + ':connect_north', ![])), _0x538bab[_0x2da14a(0x6d9)](_0x30ea5f, _0x2023b4) && _0x30ea5f['setPermutation'](_0x30ea5f['permutation'][_0x2da14a(0x9d1)](_0x207994 + _0x2da14a(0xa41), ![])), _0x203932 && _0x5e89db && _0x203932[_0x2da14a(0x772)](_0x203932[_0x2da14a(0x5fa)][_0x2da14a(0x9d1)](_0x207994 + _0x2da14a(0x1ac), ![]));
        } catch (_0xd22a3a) {
        }
    }
};
_0x25e7d0(_0x28b227, _0x21f734(0x82d), _0x207994 + ':fence_connect'), _0x25e7d0(_0x28b227, 'nonSolidBlocks', _0x5d2db2);
import { world as _0x40e5a5 } from '@minecraft/server';
var _0x28def9 = class {
    static [_0x21f734(0x48b)]() {
        const _0x36723d = _0x21f734;
        _0x40e5a5[_0x36723d(0x327)][_0x36723d(0xa3b)][_0x36723d(0x725)](_0x181787 => {
            const _0x3b07eb = _0x36723d, _0x494ce6 = _0x181787['block'];
            _0x494ce6[_0x3b07eb(0x206)](this[_0x3b07eb(0x82d)]) && this[_0x3b07eb(0x561)](_0x494ce6), this['wallBlocks'][_0x3b07eb(0x620)](_0x494ce6['typeId']) && this[_0x3b07eb(0xaa8)](_0x494ce6);
        }), _0x40e5a5[_0x36723d(0x327)]['playerBreakBlock']['subscribe'](_0x238379 => {
            const _0x36bc9c = _0x36723d, _0x5985fb = _0x238379[_0x36bc9c(0x87b)], _0x266303 = _0x238379[_0x36bc9c(0x241)][_0x36bc9c(0xc08)]['id'];
            this[_0x36bc9c(0x8b9)][_0x36bc9c(0x620)](_0x266303) && this[_0x36bc9c(0x4eb)](_0x5985fb);
        });
    }
    static [_0x21f734(0x561)](_0x4b50fc) {
        const _0x27c922 = _0x21f734, _0xdcd672 = {
                'KSEGo': _0x27c922(0x571),
                'AyxmQ': function (_0x3a8e70, _0x20f19b) {
                    return _0x3a8e70 === _0x20f19b;
                },
                'SCLoL': _0x27c922(0x6a6),
                'Ttbrk': _0x27c922(0x7bd)
            }, _0x27a819 = _0x4b50fc['permutation'][_0x27c922(0x30a)](_0x27c922(0xba4));
        (_0x27a819 === _0xdcd672['KSEGo'] || _0xdcd672[_0x27c922(0x70e)](_0x27a819, _0xdcd672[_0x27c922(0x9a5)])) && ((this[_0x27c922(0x8c8)](_0x4b50fc['east']()) || this[_0x27c922(0x8c8)](_0x4b50fc[_0x27c922(0x709)]())) && this[_0x27c922(0x53b)](_0x4b50fc, !![])), (_0xdcd672[_0x27c922(0x70e)](_0x27a819, _0xdcd672[_0x27c922(0x2ea)]) || _0xdcd672[_0x27c922(0x70e)](_0x27a819, _0x27c922(0x709))) && ((this['isWall'](_0x4b50fc[_0x27c922(0x571)]()) || this[_0x27c922(0x8c8)](_0x4b50fc['south']())) && this[_0x27c922(0x53b)](_0x4b50fc, !![]));
    }
    static [_0x21f734(0xaa8)](_0x1068c1) {
        const _0x5cbdbe = _0x21f734, _0xbaf81b = {
                'KPmyE': 'west',
                'SjhtK': _0x5cbdbe(0x7bd),
                'mayET': _0x5cbdbe(0x571),
                'sMhtq': _0x5cbdbe(0x6a6)
            };
        this[_0x5cbdbe(0xb69)](_0x1068c1[_0x5cbdbe(0x571)](), 'east', _0xbaf81b[_0x5cbdbe(0x5d7)]), this[_0x5cbdbe(0xb69)](_0x1068c1['south'](), _0xbaf81b['SjhtK'], _0xbaf81b[_0x5cbdbe(0x5d7)]), this['updateNeighborLowState'](_0x1068c1[_0x5cbdbe(0x7bd)](), _0xbaf81b[_0x5cbdbe(0x232)], _0xbaf81b[_0x5cbdbe(0x41b)]), this[_0x5cbdbe(0xb69)](_0x1068c1[_0x5cbdbe(0x709)](), _0xbaf81b['mayET'], _0xbaf81b['sMhtq']);
    }
    static [_0x21f734(0x4eb)](_0x1aedc1) {
        const _0x5a64e4 = _0x21f734;
        this[_0x5a64e4(0xb1c)](_0x1aedc1[_0x5a64e4(0x571)](), _0x1aedc1[_0x5a64e4(0x571)]()?.[_0x5a64e4(0x571)]()), this[_0x5a64e4(0xb1c)](_0x1aedc1[_0x5a64e4(0x6a6)](), _0x1aedc1[_0x5a64e4(0x6a6)]()?.[_0x5a64e4(0x6a6)]()), this[_0x5a64e4(0xb1c)](_0x1aedc1[_0x5a64e4(0x7bd)](), _0x1aedc1[_0x5a64e4(0x7bd)]()?.['east']()), this[_0x5a64e4(0xb1c)](_0x1aedc1[_0x5a64e4(0x709)](), _0x1aedc1[_0x5a64e4(0x709)]()?.[_0x5a64e4(0x709)]());
    }
    static ['updateNeighborLowState'](_0x4277b9, _0x1e749b, _0x4629be) {
        const _0x6f99f2 = _0x21f734, _0xd71863 = {
                'WLfMV': function (_0x17562c, _0x311729) {
                    return _0x17562c === _0x311729;
                },
                'oMuBN': 'minecraft:cardinal_direction'
            };
        _0x4277b9?.['hasTag'](this[_0x6f99f2(0x82d)]) && (_0xd71863[_0x6f99f2(0xbad)](_0x4277b9['permutation'][_0x6f99f2(0x30a)](_0xd71863[_0x6f99f2(0xa82)]), _0x1e749b) || _0xd71863[_0x6f99f2(0xbad)](_0x4277b9[_0x6f99f2(0x5fa)][_0x6f99f2(0x30a)](_0xd71863[_0x6f99f2(0xa82)]), _0x4629be)) && this['setLowState'](_0x4277b9, !![]);
    }
    static [_0x21f734(0xb1c)](_0x51f23d, _0x2e342b) {
        const _0x1012a1 = _0x21f734;
        _0x51f23d?.[_0x1012a1(0x206)](this[_0x1012a1(0x82d)]) && !this[_0x1012a1(0x8c8)](_0x2e342b) && this[_0x1012a1(0x53b)](_0x51f23d, ![]);
    }
    static ['isWall'](_0x3b6e70) {
        const _0x173d0f = _0x21f734;
        return _0x3b6e70 && this['wallBlocks'][_0x173d0f(0x620)](_0x3b6e70[_0x173d0f(0x1b9)]);
    }
    static [_0x21f734(0x53b)](_0xc35acf, _0x35e03e) {
        const _0x3acb8b = _0x21f734;
        _0xc35acf['setPermutation'](_0xc35acf[_0x3acb8b(0x5fa)]['withState'](_0x207994 + _0x3acb8b(0x7fe), _0x35e03e));
    }
};
_0x25e7d0(_0x28def9, _0x21f734(0x82d), _0x207994 + _0x21f734(0x97d)), _0x25e7d0(_0x28def9, _0x21f734(0x8b9), _0x3d5897);
import {
    BlockComponentPlayerDestroyEvent as _0x1af060,
    system as _0x2763de,
    world as _0x359344
} from '@minecraft/server';
var _0x70c0aa = class {
    static ['initialize']() {
        const _0xf666c9 = _0x21f734;
        _0x359344['beforeEvents'][_0xf666c9(0x398)]['subscribe'](_0x2ae3b5 => {
            const _0x498dd5 = _0xf666c9;
            _0x2ae3b5['blockComponentRegistry'][_0x498dd5(0x565)](_0x207994 + ':connect_curtain', {
                'beforeOnPlayerPlace': _0x4d9aae => this['handleBeforePlacement'](_0x4d9aae),
                'onPlayerDestroy': _0x4ffbf7 => {
                    const _0x51867e = _0x498dd5;
                    this[_0x51867e(0xbf4)](_0x4ffbf7);
                },
                'onPlayerInteract': _0x4898fe => {
                    const _0x19a532 = _0x498dd5;
                    this[_0x19a532(0x254)](_0x4898fe);
                },
                'onPlace': _0x1a6dfc => {
                    this['handleBlockUpdate'](_0x1a6dfc);
                }
            });
        });
    }
    static [_0x21f734(0x254)](_0x5d332b) {
        const _0x1cb39a = _0x21f734, _0x143b61 = {
                'CheCw': function (_0x2fd85c, _0xfbd5e3, _0x236de3, _0x46d0ca) {
                    return _0x2fd85c(_0xfbd5e3, _0x236de3, _0x46d0ca);
                },
                'jePyL': function (_0x408552, _0x4f4fd6) {
                    return _0x408552 === _0x4f4fd6;
                },
                'CQQyy': _0x1cb39a(0xba4),
                'xPKQs': function (_0x1b9159, _0x55739e) {
                    return _0x1b9159 + _0x55739e;
                },
                'edjIb': _0x1cb39a(0xaf4),
                'AvGcK': _0x1cb39a(0x326),
                'FcFSA': function (_0x3ee11e, _0x232b59) {
                    return _0x3ee11e === _0x232b59;
                },
                'UinZa': _0x1cb39a(0x571),
                'RLpbl': function (_0x8741cd, _0x1f48e4) {
                    return _0x8741cd === _0x1f48e4;
                },
                'TsGxB': _0x1cb39a(0x6a6),
                'Vvnyx': function (_0x22e8b0, _0x5cb048, _0x2ccc85, _0xa34acb, _0x29192a) {
                    return _0x22e8b0(_0x5cb048, _0x2ccc85, _0xa34acb, _0x29192a);
                },
                'Kccsp': function (_0x12e6d8, _0x58bc55) {
                    return _0x12e6d8 - _0x58bc55;
                },
                'SpFpg': function (_0x21f5d3, _0x35a9b2) {
                    return _0x21f5d3 + _0x35a9b2;
                },
                'KnWct': function (_0x13bcd8, _0x521e19, _0x38ea85, _0x13ce6c, _0x3ac078) {
                    return _0x13bcd8(_0x521e19, _0x38ea85, _0x13ce6c, _0x3ac078);
                },
                'XGRuI': function (_0x4753b0, _0x257326) {
                    return _0x4753b0 - _0x257326;
                },
                'mBHqA': function (_0x105354, _0x55cf8a) {
                    return _0x105354 - _0x55cf8a;
                },
                'UclZb': function (_0x42097b, _0x4bb4af) {
                    return _0x42097b >= _0x4bb4af;
                }
            }, _0x22e978 = _0x5d332b[_0x1cb39a(0x87b)], _0x17abf5 = _0x22e978['permutation']['getState'](_0x143b61[_0x1cb39a(0x7b3)]), _0x155ff7 = _0x22e978[_0x1cb39a(0x5fa)][_0x1cb39a(0x30a)](_0x207994 + _0x1cb39a(0xa7e)), _0x3a5618 = !_0x155ff7;
        _0x155ff7 ? _0x22e978[_0x1cb39a(0xb28)][_0x1cb39a(0xa70)](_0x143b61['edjIb'], _0x22e978[_0x1cb39a(0x2c0)]) : _0x22e978[_0x1cb39a(0xb28)][_0x1cb39a(0xa70)](_0x143b61[_0x1cb39a(0x470)], _0x22e978[_0x1cb39a(0x2c0)]);
        const _0x335d9e = new Set(), _0x558f87 = [{
                    'x': _0x22e978[_0x1cb39a(0x2c0)]['x'],
                    'y': _0x22e978[_0x1cb39a(0x2c0)]['y'],
                    'z': _0x22e978['location']['z'],
                    'depth': 0x0
                }], _0x4e1a67 = 0x2710, _0x3b80ca = 0x3e8;
        let _0x823637 = 0x0;
        const _0x47b0a7 = (_0xd06dd, _0x1f33d9, _0x3348eb) => _0xd06dd + ',' + _0x1f33d9 + ',' + _0x3348eb, _0x1497e9 = (_0x2d3884, _0x234667, _0x48916a, _0x4f2a9f) => {
                const _0x479212 = _0x1cb39a, _0x5cd994 = _0x143b61[_0x479212(0x876)](_0x47b0a7, _0x2d3884, _0x234667, _0x48916a);
                if (_0x335d9e['has'](_0x5cd994) || _0x4f2a9f > _0x3b80ca)
                    return;
                try {
                    const _0x270ce9 = _0x22e978['dimension']['getBlock']({
                        'x': _0x2d3884,
                        'y': _0x234667,
                        'z': _0x48916a
                    });
                    if (!_0x270ce9)
                        return;
                    _0x270ce9[_0x479212(0x206)](_0x207994 + _0x479212(0x799)) && _0x143b61[_0x479212(0xb91)](_0x270ce9[_0x479212(0x5fa)]['getState'](_0x143b61[_0x479212(0x7b3)]), _0x17abf5) && (_0x335d9e[_0x479212(0x65f)](_0x5cd994), _0x558f87['push']({
                        'x': _0x2d3884,
                        'y': _0x234667,
                        'z': _0x48916a,
                        'depth': _0x143b61[_0x479212(0xbe8)](_0x4f2a9f, 0x1)
                    }));
                } catch {
                }
            };
        while (_0x558f87[_0x1cb39a(0x51f)] > 0x0 && _0x823637 < _0x4e1a67) {
            const {
                    x: _0x4ace90,
                    y: _0x3deb0d,
                    z: _0x324157,
                    depth: _0x318f12
                } = _0x558f87['shift'](), _0x40f72c = _0x22e978[_0x1cb39a(0xb28)][_0x1cb39a(0x3c0)]({
                    'x': _0x4ace90,
                    'y': _0x3deb0d,
                    'z': _0x324157
                });
            if (!_0x40f72c)
                continue;
            const _0xee4566 = Math[_0x1cb39a(0x789)](_0x318f12, 0x32);
            _0x2763de[_0x1cb39a(0x873)](() => {
                const _0x2b4cf0 = _0x1cb39a;
                try {
                    const _0x138109 = _0x22e978['dimension'][_0x2b4cf0(0x3c0)]({
                        'x': _0x4ace90,
                        'y': _0x3deb0d,
                        'z': _0x324157
                    });
                    _0x138109 && _0x138109['hasTag'](_0x207994 + _0x2b4cf0(0x799)) && _0x138109[_0x2b4cf0(0x772)](_0x138109[_0x2b4cf0(0x5fa)][_0x2b4cf0(0x9d1)](_0x207994 + _0x2b4cf0(0xa7e), _0x3a5618));
                } catch {
                }
            }, _0xee4566 * 0x1), _0x823637++, _0x143b61[_0x1cb39a(0x3e0)](_0x17abf5, _0x143b61[_0x1cb39a(0x299)]) || _0x143b61[_0x1cb39a(0xbed)](_0x17abf5, _0x143b61['TsGxB']) ? (_0x143b61[_0x1cb39a(0xa2c)](_0x1497e9, _0x4ace90 + 0x1, _0x3deb0d, _0x324157, _0x318f12), _0x143b61[_0x1cb39a(0xa2c)](_0x1497e9, _0x143b61[_0x1cb39a(0x585)](_0x4ace90, 0x1), _0x3deb0d, _0x324157, _0x318f12), _0x143b61[_0x1cb39a(0xa2c)](_0x1497e9, _0x4ace90, _0x3deb0d + 0x1, _0x324157, _0x318f12), _0x1497e9(_0x4ace90, _0x143b61[_0x1cb39a(0x585)](_0x3deb0d, 0x1), _0x324157, _0x318f12)) : (_0x143b61['Vvnyx'](_0x1497e9, _0x4ace90, _0x3deb0d, _0x143b61[_0x1cb39a(0x792)](_0x324157, 0x1), _0x318f12), _0x143b61['KnWct'](_0x1497e9, _0x4ace90, _0x3deb0d, _0x143b61[_0x1cb39a(0x8b0)](_0x324157, 0x1), _0x318f12), _0x1497e9(_0x4ace90, _0x3deb0d + 0x1, _0x324157, _0x318f12), _0x143b61['KnWct'](_0x1497e9, _0x4ace90, _0x143b61[_0x1cb39a(0x50f)](_0x3deb0d, 0x1), _0x324157, _0x318f12));
        }
        _0x143b61[_0x1cb39a(0x508)](_0x823637, _0x4e1a67) && console[_0x1cb39a(0x73d)](_0x1cb39a(0x411) + _0x823637 + _0x1cb39a(0xbf7));
    }
    static ['handleBeforePlacement'](_0x15b50a) {
        const _0x41dd0e = _0x21f734, _0x52ca0a = {
                'LegMS': function (_0x5463b8, _0x518abd) {
                    return _0x5463b8 || _0x518abd;
                },
                'DjsXz': 'minecraft:cardinal_direction',
                'fEmyP': 'left',
                'tSHvX': _0x41dd0e(0x1a4),
                'hpCwY': _0x41dd0e(0x291),
                'hPZgg': _0x41dd0e(0xbd3)
            }, _0x3158e8 = _0x15b50a[_0x41dd0e(0x87b)], _0x3edc4f = _0x15b50a['player'], _0x1699d0 = _0x15b50a['permutationToPlace'];
        if (_0x52ca0a[_0x41dd0e(0x3f9)](!_0x3158e8, !_0x3edc4f))
            return;
        const _0x2e2f82 = _0x15b50a[_0x41dd0e(0x2c1)][_0x41dd0e(0x30a)](_0x52ca0a['DjsXz']), _0x934996 = this['determineState'](_0x3158e8, _0x2e2f82), _0x33732c = this['validDirections'](_0x3158e8, _0x2e2f82, _0x52ca0a[_0x41dd0e(0x652)]), _0x2c8ab3 = this['validDirections'](_0x3158e8, _0x2e2f82, _0x52ca0a['tSHvX']), _0x538cee = this[_0x41dd0e(0x7b0)](_0x3158e8, _0x2e2f82, _0x52ca0a['hpCwY']), _0x2adee0 = this[_0x41dd0e(0x7b0)](_0x3158e8, _0x2e2f82, _0x52ca0a['hPZgg']), _0x363d70 = _0x33732c?.[_0x41dd0e(0x5fa)][_0x41dd0e(0x30a)](_0x207994 + ':open') || _0x2c8ab3?.[_0x41dd0e(0x5fa)][_0x41dd0e(0x30a)](_0x207994 + _0x41dd0e(0xa7e)) || _0x538cee?.[_0x41dd0e(0x5fa)][_0x41dd0e(0x30a)](_0x207994 + _0x41dd0e(0xa7e)) || _0x2adee0?.[_0x41dd0e(0x5fa)]['getState'](_0x207994 + ':open');
        _0x15b50a[_0x41dd0e(0x2c1)] = _0x15b50a[_0x41dd0e(0x2c1)][_0x41dd0e(0x9d1)](_0x207994 + _0x41dd0e(0x6f3), _0x934996)[_0x41dd0e(0x9d1)](_0x207994 + _0x41dd0e(0xa7e), _0x363d70 ? !![] : ![]);
    }
    static [_0x21f734(0xbf4)](_0x5c9202) {
        const _0x27228b = _0x21f734, _0xb6d551 = {
                'lgWvA': function (_0x3b8000, _0x199024) {
                    return _0x3b8000 instanceof _0x199024;
                },
                'EHjPV': _0x27228b(0xba4),
                'MfKqd': 'left',
                'SLvew': _0x27228b(0x291),
                'VrQmW': function (_0x5dd079, _0x4a317e) {
                    return _0x5dd079 == _0x4a317e;
                },
                'rxsMC': function (_0x31409f, _0x36148e) {
                    return _0x31409f == _0x36148e;
                },
                'vRvzt': function (_0xc050d0, _0x59a61c) {
                    return _0xc050d0 == _0x59a61c;
                },
                'VDcFZ': function (_0xacc4af, _0xcfcfbb) {
                    return _0xacc4af == _0xcfcfbb;
                }
            }, _0x4330e8 = _0x5c9202[_0x27228b(0x87b)];
        let _0x4dd502;
        _0xb6d551['lgWvA'](_0x5c9202, _0x1af060) ? _0x4dd502 = _0x5c9202[_0x27228b(0x2f4)][_0x27228b(0x30a)](_0xb6d551[_0x27228b(0x2a7)]) : _0x4dd502 = _0x4330e8[_0x27228b(0x5fa)][_0x27228b(0x30a)](_0x27228b(0xba4));
        const _0x4b8f9d = this[_0x27228b(0x7b0)](_0x4330e8, _0x4dd502, _0xb6d551[_0x27228b(0x528)]), _0x3af59c = this[_0x27228b(0x7b0)](_0x4330e8, _0x4dd502, _0x27228b(0x1a4)), _0x841e92 = this[_0x27228b(0x7b0)](_0x4330e8, _0x4dd502, _0xb6d551['SLvew']), _0x1e2f39 = this[_0x27228b(0x7b0)](_0x4330e8, _0x4dd502, _0x27228b(0xbd3)), _0x578282 = this[_0x27228b(0x71e)](_0x4b8f9d, _0x4dd502), _0x19706b = this[_0x27228b(0x71e)](_0x3af59c, _0x4dd502), _0x43bcd2 = this[_0x27228b(0x71e)](_0x841e92, _0x4dd502), _0x41061e = this[_0x27228b(0x71e)](_0x1e2f39, _0x4dd502);
        _0x4b8f9d && _0x4b8f9d[_0x27228b(0x206)](_0x207994 + ':curtain') && _0xb6d551[_0x27228b(0x88f)](_0x4b8f9d[_0x27228b(0x5fa)][_0x27228b(0x30a)](_0xb6d551[_0x27228b(0x2a7)]), _0x4dd502) && _0x4b8f9d['setPermutation'](_0x4b8f9d[_0x27228b(0x5fa)][_0x27228b(0x9d1)](_0x207994 + _0x27228b(0x6f3), _0x578282)), _0x3af59c && _0x3af59c[_0x27228b(0x206)](_0x207994 + _0x27228b(0x799)) && _0xb6d551[_0x27228b(0x4ac)](_0x3af59c[_0x27228b(0x5fa)][_0x27228b(0x30a)](_0xb6d551['EHjPV']), _0x4dd502) && _0x3af59c[_0x27228b(0x772)](_0x3af59c[_0x27228b(0x5fa)][_0x27228b(0x9d1)](_0x207994 + _0x27228b(0x6f3), _0x19706b)), _0x841e92 && _0x841e92[_0x27228b(0x206)](_0x207994 + _0x27228b(0x799)) && _0xb6d551[_0x27228b(0x296)](_0x841e92[_0x27228b(0x5fa)]['getState'](_0xb6d551[_0x27228b(0x2a7)]), _0x4dd502) && _0x841e92[_0x27228b(0x772)](_0x841e92[_0x27228b(0x5fa)][_0x27228b(0x9d1)](_0x207994 + _0x27228b(0x6f3), _0x43bcd2)), _0x1e2f39 && _0x1e2f39['hasTag'](_0x207994 + _0x27228b(0x799)) && _0xb6d551[_0x27228b(0x8e4)](_0x1e2f39[_0x27228b(0x5fa)][_0x27228b(0x30a)](_0xb6d551[_0x27228b(0x2a7)]), _0x4dd502) && _0x1e2f39['setPermutation'](_0x1e2f39['permutation'][_0x27228b(0x9d1)](_0x207994 + _0x27228b(0x6f3), _0x41061e));
    }
    static ['determineState'](_0x261387, _0x49ffee) {
        const _0xd2192b = _0x21f734, _0x1ccc28 = {
                'NYRxT': _0xd2192b(0x45f),
                'PiBlt': _0xd2192b(0x1a4),
                'HDvJe': _0xd2192b(0xbd3),
                'EyZfD': _0xd2192b(0xba4),
                'JqOSm': function (_0x142310, _0x16010e) {
                    return _0x142310 == _0x16010e;
                },
                'fjxWY': function (_0x5d79a6, _0x45967c) {
                    return _0x5d79a6 == _0x45967c;
                },
                'CQich': _0xd2192b(0x5d2),
                'jNWiH': function (_0x2cf325, _0xec4a58) {
                    return _0x2cf325 && _0xec4a58;
                },
                'qLLmL': 'single_top',
                'BTars': 'inner_top',
                'naDJi': function (_0x214e5e, _0x151de7) {
                    return _0x214e5e && _0x151de7;
                },
                'xwFPy': 'corner_right',
                'BCZre': function (_0x570bca, _0x3c8061) {
                    return _0x570bca && _0x3c8061;
                },
                'JgrxR': _0xd2192b(0x1a7),
                'mzSZH': function (_0x633380, _0x5023ba) {
                    return _0x633380 && _0x5023ba;
                },
                'VqJix': 'inner_right'
            }, _0x22abe9 = this[_0xd2192b(0x7b0)](_0x261387, _0x49ffee, _0x1ccc28[_0xd2192b(0x9f9)]), _0x2a6ee9 = this[_0xd2192b(0x7b0)](_0x261387, _0x49ffee, _0x1ccc28[_0xd2192b(0xb50)]), _0x52a314 = this[_0xd2192b(0x7b0)](_0x261387, _0x49ffee, _0xd2192b(0x291)), _0x300209 = this['validDirections'](_0x261387, _0x49ffee, _0x1ccc28[_0xd2192b(0x1c9)]);
        let _0x498f7d = ![], _0x4486f6 = ![], _0x232015 = ![], _0x3ed35f = ![];
        _0x22abe9 && _0x22abe9['hasTag'](_0x207994 + ':curtain') && _0x22abe9[_0xd2192b(0x5fa)]['getState'](_0x1ccc28[_0xd2192b(0x475)]) == _0x49ffee && (_0x498f7d = !![]);
        _0x2a6ee9 && _0x2a6ee9[_0xd2192b(0x206)](_0x207994 + ':curtain') && _0x2a6ee9[_0xd2192b(0x5fa)][_0xd2192b(0x30a)](_0xd2192b(0xba4)) == _0x49ffee && (_0x4486f6 = !![]);
        _0x52a314 && _0x52a314['hasTag'](_0x207994 + _0xd2192b(0x799)) && _0x1ccc28[_0xd2192b(0x669)](_0x52a314['permutation'][_0xd2192b(0x30a)](_0x1ccc28[_0xd2192b(0x475)]), _0x49ffee) && (_0x232015 = !![]);
        _0x300209 && _0x300209[_0xd2192b(0x206)](_0x207994 + _0xd2192b(0x799)) && _0x1ccc28[_0xd2192b(0x20a)](_0x300209[_0xd2192b(0x5fa)][_0xd2192b(0x30a)](_0x1ccc28[_0xd2192b(0x475)]), _0x49ffee) && (_0x3ed35f = !![]);
        let _0x16b6a7 = _0x1ccc28[_0xd2192b(0x355)];
        return _0x1ccc28[_0xd2192b(0x934)](_0x232015, _0x498f7d) && _0x4486f6 && (_0x16b6a7 = _0x1ccc28[_0xd2192b(0x355)]), _0x232015 && (!_0x498f7d || !_0x4486f6) && (_0x16b6a7 = _0xd2192b(0x2f7)), !_0x232015 && !_0x498f7d && !_0x4486f6 && (_0x16b6a7 = _0x1ccc28[_0xd2192b(0xbeb)]), _0x498f7d && _0x4486f6 && !_0x232015 && (_0x16b6a7 = _0x1ccc28[_0xd2192b(0x674)]), _0x1ccc28['naDJi'](_0x498f7d, !_0x4486f6) && (_0x16b6a7 = _0x1ccc28[_0xd2192b(0x9da)]), _0x1ccc28['BCZre'](!_0x498f7d, _0x4486f6) && (_0x16b6a7 = _0x1ccc28[_0xd2192b(0x4e2)]), _0x1ccc28[_0xd2192b(0xa8e)](_0x232015, _0x4486f6) && !_0x498f7d && (_0x16b6a7 = _0xd2192b(0x3dd)), _0x1ccc28[_0xd2192b(0x840)](_0x232015, _0x498f7d) && !_0x4486f6 && (_0x16b6a7 = _0x1ccc28[_0xd2192b(0xaea)]), _0x16b6a7;
    }
    static ['validDirections'](_0x30c11c, _0x54b7aa, _0x57bbe8) {
        const _0x5f4b9b = _0x21f734, _0x3bbfc4 = {
                'ufdAR': '3|0|2|1|5|4',
                'cZjzs': _0x5f4b9b(0xbd3),
                'OIGfB': function (_0xd37c3, _0x3be4a8) {
                    return _0xd37c3 === _0x3be4a8;
                },
                'DHtFZ': _0x5f4b9b(0x45f),
                'nqfRU': _0x5f4b9b(0x1a4),
                'ydckK': _0x5f4b9b(0x571),
                'lFjDH': function (_0x3f703b, _0x26cec8) {
                    return _0x3f703b === _0x26cec8;
                },
                'gxjLu': function (_0x8d092d, _0x15e7b4) {
                    return _0x8d092d === _0x15e7b4;
                },
                'IbKcc': function (_0x5a5ad0, _0x2158c3) {
                    return _0x5a5ad0 === _0x2158c3;
                },
                'dSLOb': function (_0x5b3d41, _0x55b242) {
                    return _0x5b3d41 === _0x55b242;
                },
                'QHXZi': _0x5f4b9b(0x709),
                'sQYiH': _0x5f4b9b(0x7bd)
            }, _0x539f = _0x3bbfc4['ufdAR'][_0x5f4b9b(0x1f5)]('|');
        let _0x3459b6 = 0x0;
        while (!![]) {
            switch (_0x539f[_0x3459b6++]) {
            case '0':
                if (_0x57bbe8 === _0x3bbfc4['cZjzs'])
                    return _0x30c11c[_0x5f4b9b(0xbd3)]();
                continue;
            case '1':
                if (_0x54b7aa === _0x5f4b9b(0x6a6)) {
                    if (_0x3bbfc4[_0x5f4b9b(0x80b)](_0x57bbe8, _0x3bbfc4['DHtFZ']))
                        return _0x30c11c[_0x5f4b9b(0x7bd)]();
                    if (_0x3bbfc4[_0x5f4b9b(0x80b)](_0x57bbe8, _0x3bbfc4[_0x5f4b9b(0x5f6)]))
                        return _0x30c11c[_0x5f4b9b(0x709)]();
                }
                continue;
            case '2':
                if (_0x3bbfc4[_0x5f4b9b(0x80b)](_0x54b7aa, _0x3bbfc4[_0x5f4b9b(0x357)])) {
                    if (_0x3bbfc4[_0x5f4b9b(0x97a)](_0x57bbe8, _0x3bbfc4['DHtFZ']))
                        return _0x30c11c[_0x5f4b9b(0x709)]();
                    if (_0x3bbfc4[_0x5f4b9b(0x41d)](_0x57bbe8, _0x3bbfc4[_0x5f4b9b(0x5f6)]))
                        return _0x30c11c[_0x5f4b9b(0x7bd)]();
                }
                continue;
            case '3':
                if (_0x3bbfc4[_0x5f4b9b(0x8fc)](_0x57bbe8, _0x5f4b9b(0x291)))
                    return _0x30c11c[_0x5f4b9b(0x291)]();
                continue;
            case '4':
                if (_0x3bbfc4[_0x5f4b9b(0x726)](_0x54b7aa, _0x3bbfc4[_0x5f4b9b(0x3ed)])) {
                    if (_0x57bbe8 === _0x3bbfc4[_0x5f4b9b(0x9db)])
                        return _0x30c11c[_0x5f4b9b(0x6a6)]();
                    if (_0x57bbe8 === _0x3bbfc4['nqfRU'])
                        return _0x30c11c['north']();
                }
                continue;
            case '5':
                if (_0x3bbfc4[_0x5f4b9b(0x97a)](_0x54b7aa, _0x3bbfc4['sQYiH'])) {
                    if (_0x57bbe8 === _0x3bbfc4[_0x5f4b9b(0x9db)])
                        return _0x30c11c[_0x5f4b9b(0x571)]();
                    if (_0x3bbfc4[_0x5f4b9b(0x8fc)](_0x57bbe8, _0x3bbfc4['nqfRU']))
                        return _0x30c11c[_0x5f4b9b(0x6a6)]();
                }
                continue;
            }
            break;
        }
    }
};
import {
    BlockComponentPlayerDestroyEvent as _0x407fdc,
    system as _0x38902d,
    world as _0x57a573
} from '@minecraft/server';
var _0x58d8f0 = class {
    static [_0x21f734(0x48b)]() {
        const _0x4fc7da = _0x21f734;
        _0x57a573[_0x4fc7da(0x959)][_0x4fc7da(0x398)][_0x4fc7da(0x725)](_0x4bb796 => {
            const _0x30baad = _0x4fc7da;
            _0x4bb796[_0x30baad(0x2ee)][_0x30baad(0x565)](_0x207994 + ':vertical_connect', {
                'beforeOnPlayerPlace': _0x1f73f4 => this[_0x30baad(0x3cf)](_0x1f73f4),
                'onPlayerDestroy': _0x2f5b10 => this['handleDestroy'](_0x2f5b10)
            });
        }), _0x57a573[_0x4fc7da(0x327)][_0x4fc7da(0xb88)][_0x4fc7da(0x725)](_0x1ce406 => {
            const _0x593640 = _0x4fc7da;
            _0x1ce406[_0x593640(0x70f)]['hasTag'](_0x207994 + _0x593640(0x9a0)) && this[_0x593640(0x800)](_0x1ce406);
        });
    }
    static ['applyMultipleStates'](_0xa368e9, _0xda8bfb) {
        const _0x47234c = _0x21f734;
        let _0x508aa4 = _0xa368e9;
        for (const [_0x22ea4b, _0x4327b2] of Object['entries'](_0xda8bfb)) {
            _0x508aa4 = _0x508aa4[_0x47234c(0x9d1)](_0x22ea4b, _0x4327b2);
        }
        return _0x508aa4;
    }
    static ['handleBeforePlacement'](_0x443b1e) {
        const _0x395e6e = _0x21f734, _0x2d144f = {
                'vYPuR': function (_0x179ab5, _0x572ca0) {
                    return _0x179ab5 === _0x572ca0;
                }
            }, _0x4ff198 = _0x443b1e['block'], _0x360fa8 = _0x4ff198[_0x395e6e(0x291)](), _0x442301 = _0x4ff198[_0x395e6e(0xbd3)](), _0x3c57a6 = _0x443b1e[_0x395e6e(0x2c1)]['type']['id'];
        if (_0x2d144f[_0x395e6e(0x679)](_0x442301?.[_0x395e6e(0x1b9)], _0x3c57a6)) {
            const _0x560563 = _0x442301['permutation'][_0x395e6e(0x833)]();
            _0x443b1e['permutationToPlace'] = this['applyMultipleStates'](_0x443b1e[_0x395e6e(0x2c1)], _0x560563), _0x443b1e[_0x395e6e(0x2c1)] = _0x443b1e[_0x395e6e(0x2c1)]['withState'](_0x207994 + _0x395e6e(0x51e), ![]), _0x38902d[_0x395e6e(0xb7e)](() => {
                const _0x37c93d = _0x395e6e;
                _0x442301[_0x37c93d(0x772)](_0x442301[_0x37c93d(0x5fa)][_0x37c93d(0x9d1)](_0x207994 + _0x37c93d(0x46c), ![]));
            });
        }
        if (_0x2d144f[_0x395e6e(0x679)](_0x360fa8?.['typeId'], _0x3c57a6)) {
            const _0x3948cb = _0x360fa8[_0x395e6e(0x5fa)]['getAllStates']();
            _0x443b1e['permutationToPlace'] = this[_0x395e6e(0x682)](_0x443b1e['permutationToPlace'], _0x3948cb), _0x443b1e[_0x395e6e(0x2c1)] = _0x443b1e[_0x395e6e(0x2c1)][_0x395e6e(0x9d1)](_0x207994 + _0x395e6e(0x46c), ![]), _0x38902d['run'](() => {
                const _0x53efbb = _0x395e6e;
                _0x360fa8[_0x53efbb(0x772)](_0x360fa8[_0x53efbb(0x5fa)]['withState'](_0x207994 + ':base', ![]));
            });
        }
    }
    static [_0x21f734(0x800)](_0x30b904) {
        const _0x10af43 = _0x21f734, _0x4b1dd1 = {
                'JhyhM': function (_0x47e8e1, _0x530354) {
                    return _0x47e8e1 instanceof _0x530354;
                },
                'bZxgY': function (_0x199ba7, _0x6099c1) {
                    return _0x199ba7 === _0x6099c1;
                },
                'SMLYE': function (_0x95d3d8, _0x5a1ebf) {
                    return _0x95d3d8 === _0x5a1ebf;
                }
            }, _0x57e90d = _0x30b904[_0x10af43(0x87b)];
        let _0x46971f;
        _0x4b1dd1[_0x10af43(0x3c2)](_0x30b904, _0x407fdc) ? _0x46971f = _0x30b904[_0x10af43(0x2f4)][_0x10af43(0xc08)]['id'] : _0x46971f = _0x30b904[_0x10af43(0x70f)][_0x10af43(0xc08)]['id'];
        const _0x57b5d3 = _0x57e90d[_0x10af43(0x291)](), _0x433f65 = _0x57e90d[_0x10af43(0xbd3)]();
        _0x4b1dd1[_0x10af43(0x396)](_0x433f65?.[_0x10af43(0x1b9)], _0x46971f) && _0x433f65[_0x10af43(0x772)](_0x433f65['permutation']['withState'](_0x207994 + _0x10af43(0x46c), !![])), _0x4b1dd1[_0x10af43(0xad8)](_0x57b5d3?.[_0x10af43(0x1b9)], _0x46971f) && _0x57b5d3['setPermutation'](_0x57b5d3['permutation'][_0x10af43(0x9d1)](_0x207994 + ':base', !![]));
    }
};
import { world as _0x9c6a8e } from '@minecraft/server';
var _0x3228e9 = class {
    static ['initialize']() {
        const _0x39ddfd = _0x21f734;
        _0x9c6a8e[_0x39ddfd(0x959)][_0x39ddfd(0x398)][_0x39ddfd(0x725)](_0x3ee01d => {
            const _0x467fa4 = _0x39ddfd;
            _0x3ee01d[_0x467fa4(0x2ee)]['registerCustomComponent'](_0x207994 + _0x467fa4(0x379), { 'beforeOnPlayerPlace': this['placeBlock'] });
        });
    }
    static ['placeBlock'](_0x1d9e76) {
        const _0x224a20 = _0x21f734, _0x27a76e = {
                'CXSyO': _0x224a20(0xba4),
                'slczd': function (_0x3c4e45, _0x70ac95) {
                    return _0x3c4e45(_0x70ac95);
                },
                'kAqpA': function (_0x1f4496, _0x50aa64) {
                    return _0x1f4496 === _0x50aa64;
                },
                'XrYGE': function (_0xc5d6bf, _0x3e7716) {
                    return _0xc5d6bf(_0x3e7716);
                },
                'EjhXJ': function (_0x335c9f, _0x52c6b3) {
                    return _0x335c9f === _0x52c6b3;
                },
                'CxpFZ': _0x224a20(0x571),
                'oneBi': function (_0x397f6e, _0x26951f) {
                    return _0x397f6e === _0x26951f;
                },
                'ElIkU': 'south',
                'iKVrs': 'west',
                'mTpoa': 'east'
            }, _0x1a15c1 = _0x29ec27, _0x52919c = _0x1d9e76[_0x224a20(0x87b)], _0x5974f4 = _0x1d9e76[_0x224a20(0x2c1)][_0x224a20(0x30a)](_0x27a76e[_0x224a20(0x51a)]), _0x4e1d8a = _0x486e18 => {
                const _0x45b175 = _0x224a20;
                return _0x1a15c1[_0x45b175(0x620)](_0x486e18[_0x45b175(0x1b9)]) || _0x486e18[_0x45b175(0x206)](_0x45b175(0xbdb));
            }, _0xa9de07 = _0x52919c[_0x224a20(0x709)]() && _0x27a76e[_0x224a20(0x600)](_0x4e1d8a, _0x52919c[_0x224a20(0x709)]()) && _0x27a76e['kAqpA'](_0x52919c[_0x224a20(0x709)]()[_0x224a20(0x5fa)][_0x224a20(0x30a)](_0x27a76e[_0x224a20(0x51a)]), _0x5974f4), _0xb75abb = _0x52919c[_0x224a20(0x7bd)]() && _0x27a76e['XrYGE'](_0x4e1d8a, _0x52919c[_0x224a20(0x7bd)]()) && _0x27a76e[_0x224a20(0xb5b)](_0x52919c[_0x224a20(0x7bd)]()[_0x224a20(0x5fa)][_0x224a20(0x30a)](_0x27a76e['CXSyO']), _0x5974f4), _0x1ea7ca = _0x52919c['north']() && _0x27a76e[_0x224a20(0x600)](_0x4e1d8a, _0x52919c[_0x224a20(0x571)]()) && _0x52919c[_0x224a20(0x571)]()['permutation'][_0x224a20(0x30a)](_0x27a76e[_0x224a20(0x51a)]) === _0x5974f4, _0x3490fd = _0x52919c[_0x224a20(0x6a6)]() && _0x4e1d8a(_0x52919c[_0x224a20(0x6a6)]()) && _0x52919c['south']()['permutation'][_0x224a20(0x30a)](_0x27a76e[_0x224a20(0x51a)]) === _0x5974f4, _0x4dc1c8 = _0x52919c[_0x224a20(0xbd3)]();
        if (_0x4dc1c8) {
            const _0x5488ee = _0x27a76e[_0x224a20(0xc16)](_0x4dc1c8[_0x224a20(0x5fa)][_0x224a20(0x30a)](_0x207994 + _0x224a20(0x490)), !![]);
            if (_0x5488ee) {
                _0x1d9e76[_0x224a20(0x2c1)] = _0x1d9e76['permutationToPlace'][_0x224a20(0x9d1)](_0x207994 + _0x224a20(0x490), !![]);
                return;
            }
        }
        _0x5974f4 === _0x27a76e[_0x224a20(0x670)] && _0xa9de07 && !_0xb75abb && (_0x1d9e76[_0x224a20(0x2c1)] = _0x1d9e76['permutationToPlace'][_0x224a20(0x9d1)](_0x207994 + _0x224a20(0x490), !![])), _0x27a76e[_0x224a20(0x52e)](_0x5974f4, _0x27a76e['ElIkU']) && _0xb75abb && !_0xa9de07 && (_0x1d9e76[_0x224a20(0x2c1)] = _0x1d9e76[_0x224a20(0x2c1)]['withState'](_0x207994 + _0x224a20(0x490), !![])), _0x27a76e[_0x224a20(0x52e)](_0x5974f4, _0x27a76e[_0x224a20(0x202)]) && !_0x1ea7ca && _0x3490fd && (_0x1d9e76[_0x224a20(0x2c1)] = _0x1d9e76[_0x224a20(0x2c1)][_0x224a20(0x9d1)](_0x207994 + ':door_mirror', !![])), _0x5974f4 === _0x27a76e[_0x224a20(0x3d4)] && !_0x3490fd && _0x1ea7ca && (_0x1d9e76[_0x224a20(0x2c1)] = _0x1d9e76[_0x224a20(0x2c1)][_0x224a20(0x9d1)](_0x207994 + _0x224a20(0x490), !![]));
    }
};
import { world as _0x5490c7 } from '@minecraft/server';
var _0x484f16 = class {
    static [_0x21f734(0x48b)]() {
        const _0x5437ba = _0x21f734;
        _0x5490c7[_0x5437ba(0x959)][_0x5437ba(0x398)][_0x5437ba(0x725)](_0x129c90 => {
            const _0x359c86 = _0x5437ba;
            _0x129c90[_0x359c86(0x2ee)]['registerCustomComponent'](_0x207994 + _0x359c86(0x604), { 'beforeOnPlayerPlace': this[_0x359c86(0x527)] });
        });
    }
    static [_0x21f734(0x527)](_0x299a5c) {
        const _0x481904 = _0x21f734, _0x1e866e = {
                'ggTax': _0x481904(0xba4),
                'rqyLW': function (_0x3960ea, _0x263ea5) {
                    return _0x3960ea === _0x263ea5;
                },
                'aHnIU': function (_0x17907f, _0x19041b) {
                    return _0x17907f === _0x19041b;
                },
                'zDucW': function (_0x45cf2e, _0x2e6023) {
                    return _0x45cf2e === _0x2e6023;
                },
                'HOJZn': _0x481904(0x571),
                'HncsO': function (_0x5d10aa, _0xc634c5) {
                    return _0x5d10aa === _0xc634c5;
                },
                'QBGjc': _0x481904(0x6a6),
                'BKkCL': 'west'
            }, _0x283c54 = _0x299a5c[_0x481904(0x87b)], _0x3a89ad = _0x299a5c[_0x481904(0x2c1)][_0x481904(0x30a)](_0x1e866e['ggTax']), _0x2ffd2e = _0x283c54[_0x481904(0x709)]()[_0x481904(0x5fa)]['getState'](_0x1e866e['ggTax']) === _0x3a89ad && _0x1e866e[_0x481904(0x950)](_0x283c54[_0x481904(0x709)]()[_0x481904(0x5fa)]['getState'](_0x207994 + _0x481904(0xa72)), ![]), _0x43c249 = _0x1e866e['rqyLW'](_0x283c54['east']()[_0x481904(0x5fa)]['getState'](_0x481904(0xba4)), _0x3a89ad) && _0x283c54[_0x481904(0x7bd)]()[_0x481904(0x5fa)][_0x481904(0x30a)](_0x207994 + _0x481904(0xa72)) === ![], _0x155bf7 = _0x283c54[_0x481904(0x571)]()[_0x481904(0x5fa)]['getState'](_0x1e866e['ggTax']) === _0x3a89ad && _0x1e866e[_0x481904(0x9f4)](_0x283c54[_0x481904(0x571)]()[_0x481904(0x5fa)][_0x481904(0x30a)](_0x207994 + _0x481904(0xa72)), ![]), _0x2ba49f = _0x1e866e[_0x481904(0x491)](_0x283c54[_0x481904(0x6a6)]()['permutation'][_0x481904(0x30a)](_0x481904(0xba4)), _0x3a89ad) && _0x1e866e[_0x481904(0x9f4)](_0x283c54[_0x481904(0x6a6)]()['permutation']['getState'](_0x207994 + _0x481904(0xa72)), ![]);
        _0x1e866e[_0x481904(0x9f4)](_0x3a89ad, _0x1e866e[_0x481904(0x1de)]) && !_0x2ffd2e && _0x43c249 && (_0x299a5c[_0x481904(0x2c1)] = _0x299a5c['permutationToPlace'][_0x481904(0x9d1)](_0x207994 + _0x481904(0xa72), !![])), _0x1e866e[_0x481904(0xbe2)](_0x3a89ad, _0x1e866e['QBGjc']) && !_0x43c249 && _0x2ffd2e && (_0x299a5c[_0x481904(0x2c1)] = _0x299a5c[_0x481904(0x2c1)][_0x481904(0x9d1)](_0x207994 + ':cabinet_mirror', !![])), _0x3a89ad === _0x1e866e[_0x481904(0x742)] && _0x155bf7 && !_0x2ba49f && (_0x299a5c[_0x481904(0x2c1)] = _0x299a5c[_0x481904(0x2c1)]['withState'](_0x207994 + _0x481904(0xa72), !![])), _0x1e866e[_0x481904(0x950)](_0x3a89ad, _0x481904(0x7bd)) && _0x2ba49f && !_0x155bf7 && (_0x299a5c[_0x481904(0x2c1)] = _0x299a5c['permutationToPlace'][_0x481904(0x9d1)](_0x207994 + _0x481904(0xa72), !![]));
    }
};
import {
    BlockComponentPlayerDestroyEvent as _0x9cd822,
    system as _0x3bdc3c,
    world as _0x2edfae
} from '@minecraft/server';
var _0x59694b = class {
        static [_0x21f734(0x48b)]() {
            const _0x57a804 = _0x21f734;
            _0x2edfae[_0x57a804(0x959)][_0x57a804(0x398)][_0x57a804(0x725)](_0x1fc324 => {
                const _0x8544f4 = _0x57a804;
                _0x1fc324[_0x8544f4(0x2ee)]['registerCustomComponent'](_0x207994 + _0x8544f4(0x4d7), {
                    'beforeOnPlayerPlace': _0x3f461d => this[_0x8544f4(0x3cf)](_0x3f461d),
                    'onPlayerDestroy': _0x4cfa3f => this['handleDestroy'](_0x4cfa3f)
                });
            }), _0x2edfae['afterEvents'][_0x57a804(0xb88)][_0x57a804(0x725)](_0x2bb98d => {
                const _0x501508 = _0x57a804;
                _0x2bb98d['explodedBlockPermutation'][_0x501508(0x206)](_0x207994 + ':cabinet_horizontal_connect') && this[_0x501508(0x800)](_0x2bb98d);
            });
        }
        static [_0x21f734(0x3cf)](_0xce0378) {
            const _0x27432a = _0x21f734, _0x16a93b = {
                    'GloIo': _0x27432a(0x45f),
                    'jICyA': _0x27432a(0x1a4),
                    'hakGl': function (_0x280e77, _0x295e4b) {
                        return _0x280e77 === _0x295e4b;
                    },
                    'LTiEp': _0x27432a(0xba4),
                    'MHfRL': function (_0x399d3b, _0x5b7383) {
                        return _0x399d3b === _0x5b7383;
                    },
                    'ZubME': _0x27432a(0x9e9),
                    'lCyis': function (_0x29672f, _0xfd9abf) {
                        return _0x29672f === _0xfd9abf;
                    }
                }, _0x330429 = _0xce0378[_0x27432a(0x87b)], _0x576971 = _0xce0378[_0x27432a(0x2c1)][_0x27432a(0x30a)](_0x27432a(0xba4)), _0x305a0c = this[_0x27432a(0x7b0)](_0x330429, _0x576971, _0x16a93b[_0x27432a(0x35e)]), _0x154312 = this[_0x27432a(0x7b0)](_0x330429, _0x576971, _0x16a93b[_0x27432a(0x7a8)]), _0x56f932 = _0xce0378['permutationToPlace'][_0x27432a(0xc08)]['id'];
            if (_0x16a93b[_0x27432a(0x7a2)](_0x305a0c?.[_0x27432a(0x1b9)], _0x56f932) && _0x16a93b[_0x27432a(0x7a2)](_0x305a0c[_0x27432a(0x5fa)]['getState'](_0x16a93b[_0x27432a(0xafd)]), _0x576971) && _0x16a93b[_0x27432a(0x622)](_0x305a0c[_0x27432a(0x5fa)][_0x27432a(0x30a)](_0x207994 + _0x27432a(0x6f3)), _0x16a93b[_0x27432a(0x67f)])) {
                _0xce0378[_0x27432a(0x2c1)] = _0xce0378[_0x27432a(0x2c1)][_0x27432a(0x9d1)](_0x207994 + _0x27432a(0x6f3), _0x27432a(0x1a4)), _0x3bdc3c[_0x27432a(0xb7e)](() => {
                    const _0x103667 = _0x27432a;
                    _0x305a0c['setPermutation'](_0x305a0c[_0x103667(0x5fa)][_0x103667(0x9d1)](_0x207994 + ':connect', _0x16a93b[_0x103667(0x35e)]));
                });
                return;
            }
            _0x16a93b[_0x27432a(0x9fe)](_0x154312?.[_0x27432a(0x1b9)], _0x56f932) && _0x154312[_0x27432a(0x5fa)][_0x27432a(0x30a)](_0x16a93b[_0x27432a(0xafd)]) === _0x576971 && _0x154312[_0x27432a(0x5fa)]['getState'](_0x207994 + _0x27432a(0x6f3)) === _0x16a93b['ZubME'] && (_0xce0378[_0x27432a(0x2c1)] = _0xce0378[_0x27432a(0x2c1)][_0x27432a(0x9d1)](_0x207994 + _0x27432a(0x6f3), _0x16a93b[_0x27432a(0x35e)]), _0x3bdc3c[_0x27432a(0xb7e)](() => {
                const _0x144526 = _0x27432a;
                _0x154312[_0x144526(0x772)](_0x154312[_0x144526(0x5fa)][_0x144526(0x9d1)](_0x207994 + _0x144526(0x6f3), _0x16a93b[_0x144526(0x7a8)]));
            }));
        }
        static [_0x21f734(0x800)](_0x41f8b8) {
            const _0x1cddc7 = _0x21f734, _0x125279 = {
                    'kYyys': function (_0x1e0ea8, _0x2c9158) {
                        return _0x1e0ea8 instanceof _0x2c9158;
                    },
                    'RfzaZ': _0x1cddc7(0xba4),
                    'llvEF': _0x1cddc7(0x45f),
                    'VcdlT': function (_0x256fac, _0x2e1c82) {
                        return _0x256fac === _0x2e1c82;
                    },
                    'PKeRv': function (_0x479dfe, _0x58f802) {
                        return _0x479dfe === _0x58f802;
                    },
                    'LwmRP': _0x1cddc7(0x9e9),
                    'ISPPG': function (_0x54d103, _0xd544ab) {
                        return _0x54d103 === _0xd544ab;
                    },
                    'HSIBF': function (_0x33e37b, _0x31911d) {
                        return _0x33e37b === _0x31911d;
                    }
                }, _0x309d7f = _0x41f8b8[_0x1cddc7(0x87b)];
            let _0x47aba0, _0xfd7506;
            _0x125279[_0x1cddc7(0x75b)](_0x41f8b8, _0x9cd822) ? (_0x47aba0 = _0x41f8b8[_0x1cddc7(0x2f4)][_0x1cddc7(0xc08)]['id'], _0xfd7506 = _0x41f8b8[_0x1cddc7(0x2f4)][_0x1cddc7(0x30a)](_0x125279['RfzaZ'])) : (_0x47aba0 = _0x41f8b8[_0x1cddc7(0x70f)]['type']['id'], _0xfd7506 = _0x41f8b8[_0x1cddc7(0x70f)]['getState'](_0x125279[_0x1cddc7(0x1ab)]));
            const _0x39726 = this['validDirections'](_0x309d7f, _0xfd7506, _0x125279[_0x1cddc7(0x6f1)]), _0x4c5829 = this[_0x1cddc7(0x7b0)](_0x309d7f, _0xfd7506, _0x1cddc7(0x1a4));
            _0x125279[_0x1cddc7(0x6d7)](_0x39726?.['typeId'], _0x47aba0) && _0x125279[_0x1cddc7(0xb6b)](_0x39726[_0x1cddc7(0x5fa)][_0x1cddc7(0x30a)](_0x207994 + _0x1cddc7(0x6f3)), _0x125279[_0x1cddc7(0x6f1)]) && _0x39726[_0x1cddc7(0x772)](_0x39726['permutation']['withState'](_0x207994 + _0x1cddc7(0x6f3), _0x125279['LwmRP'])), _0x125279[_0x1cddc7(0x693)](_0x4c5829?.[_0x1cddc7(0x1b9)], _0x47aba0) && _0x125279[_0x1cddc7(0x750)](_0x4c5829['permutation'][_0x1cddc7(0x30a)](_0x207994 + ':connect'), _0x1cddc7(0x1a4)) && _0x4c5829['setPermutation'](_0x4c5829[_0x1cddc7(0x5fa)][_0x1cddc7(0x9d1)](_0x207994 + _0x1cddc7(0x6f3), _0x125279[_0x1cddc7(0x3f5)]));
        }
        static [_0x21f734(0x7b0)](_0x414087, _0x343244, _0x226617) {
            const _0x43940c = _0x21f734, _0x51024b = {
                    'aKSqj': function (_0x49da71, _0xa7fc9) {
                        return _0x49da71 === _0xa7fc9;
                    },
                    'LazMv': _0x43940c(0x571),
                    'nQsrk': _0x43940c(0x45f),
                    'GeDjD': _0x43940c(0x6a6),
                    'Sahvx': function (_0x261d43, _0x5129d7) {
                        return _0x261d43 === _0x5129d7;
                    },
                    'uOsTt': _0x43940c(0x1a4),
                    'CdAmz': function (_0x42d705, _0x556d9c) {
                        return _0x42d705 === _0x556d9c;
                    },
                    'owQdZ': _0x43940c(0x709),
                    'ZPTbJ': function (_0x26ff87, _0x47b1a3) {
                        return _0x26ff87 === _0x47b1a3;
                    }
                };
            if (_0x51024b[_0x43940c(0x605)](_0x343244, _0x51024b[_0x43940c(0x655)])) {
                if (_0x51024b['aKSqj'](_0x226617, _0x51024b[_0x43940c(0x1d4)]))
                    return _0x414087[_0x43940c(0x7bd)]();
                if (_0x51024b[_0x43940c(0x605)](_0x226617, _0x43940c(0x1a4)))
                    return _0x414087['west']();
            }
            if (_0x343244 === _0x51024b[_0x43940c(0x813)]) {
                if (_0x226617 === _0x51024b[_0x43940c(0x1d4)])
                    return _0x414087['west']();
                if (_0x51024b[_0x43940c(0x698)](_0x226617, _0x51024b[_0x43940c(0xbdc)]))
                    return _0x414087['east']();
            }
            if (_0x51024b['aKSqj'](_0x343244, _0x43940c(0x7bd))) {
                if (_0x51024b['CdAmz'](_0x226617, _0x51024b[_0x43940c(0x1d4)]))
                    return _0x414087[_0x43940c(0x6a6)]();
                if (_0x51024b[_0x43940c(0x605)](_0x226617, _0x51024b[_0x43940c(0xbdc)]))
                    return _0x414087[_0x43940c(0x571)]();
            }
            if (_0x51024b[_0x43940c(0x698)](_0x343244, _0x51024b['owQdZ'])) {
                if (_0x51024b[_0x43940c(0xa75)](_0x226617, _0x51024b['nQsrk']))
                    return _0x414087[_0x43940c(0x571)]();
                if (_0x226617 === _0x51024b['uOsTt'])
                    return _0x414087[_0x43940c(0x6a6)]();
            }
        }
    }, _0x45dda2 = class {
        static [_0x21f734(0x48b)]() {
            const _0x357367 = _0x21f734;
            _0x2edfae[_0x357367(0x959)][_0x357367(0x398)][_0x357367(0x725)](_0x48dc5b => {
                const _0x57d2bf = _0x357367;
                _0x48dc5b[_0x57d2bf(0x2ee)][_0x57d2bf(0x565)](_0x207994 + _0x57d2bf(0x2d1), {
                    'beforeOnPlayerPlace': _0xfc0608 => this[_0x57d2bf(0x3cf)](_0xfc0608),
                    'onPlayerDestroy': _0x4aa7d7 => this['handleDestroy'](_0x4aa7d7)
                });
            }), _0x2edfae[_0x357367(0x327)][_0x357367(0xb88)][_0x357367(0x725)](_0x1e3932 => {
                const _0x3845a6 = _0x357367;
                _0x1e3932[_0x3845a6(0x70f)][_0x3845a6(0x206)](_0x207994 + _0x3845a6(0x2d1)) && this[_0x3845a6(0x800)](_0x1e3932);
            });
        }
        static [_0x21f734(0x682)](_0x212fdc, _0x129da1) {
            const _0x1f606d = _0x21f734;
            let _0x7544b1 = _0x212fdc;
            for (const [_0x1bb5af, _0x3b2a9d] of Object[_0x1f606d(0x5a8)](_0x129da1)) {
                _0x7544b1 = _0x7544b1[_0x1f606d(0x9d1)](_0x1bb5af, _0x3b2a9d);
            }
            return _0x7544b1;
        }
        static ['handleBeforePlacement'](_0x1645e7) {
            const _0x193364 = _0x21f734, _0x22170a = {
                    'xUlbx': _0x193364(0x731),
                    'rfHgM': 'top',
                    'IAxPr': function (_0x2584c7, _0x242805) {
                        return _0x2584c7 === _0x242805;
                    },
                    'MLESZ': function (_0x522306, _0x8ab34a) {
                        return _0x522306 === _0x8ab34a;
                    },
                    'rwomG': _0x193364(0x9e9),
                    'udKyn': function (_0x31e3f2, _0x35aaaf) {
                        return _0x31e3f2 === _0x35aaaf;
                    },
                    'DfzXa': function (_0x398cc8, _0x597ba4) {
                        return _0x398cc8 === _0x597ba4;
                    }
                }, _0x25eff3 = _0x1645e7[_0x193364(0x87b)], _0x261b09 = _0x25eff3[_0x193364(0x291)](), _0x4b008f = _0x25eff3[_0x193364(0xbd3)](), _0x391d19 = _0x1645e7[_0x193364(0x2c1)][_0x193364(0xc08)]['id'], _0x2210f0 = _0x1645e7['permutationToPlace'][_0x193364(0x30a)](_0x207994 + _0x193364(0xa72));
            if (_0x22170a[_0x193364(0x6b8)](_0x4b008f?.[_0x193364(0x1b9)], _0x391d19) && _0x22170a[_0x193364(0x6af)](_0x4b008f[_0x193364(0x5fa)][_0x193364(0x30a)](_0x207994 + ':connect'), _0x22170a[_0x193364(0xa64)]) && _0x22170a['IAxPr'](_0x4b008f['permutation'][_0x193364(0x30a)](_0x207994 + _0x193364(0xa72)), _0x2210f0)) {
                const _0x298cb7 = _0x4b008f[_0x193364(0x5fa)][_0x193364(0x833)]();
                _0x1645e7[_0x193364(0x2c1)] = this[_0x193364(0x682)](_0x1645e7[_0x193364(0x2c1)], _0x298cb7), _0x1645e7['permutationToPlace'] = _0x1645e7['permutationToPlace']['withState'](_0x207994 + _0x193364(0x6f3), 'top'), _0x3bdc3c[_0x193364(0xb7e)](() => {
                    const _0x583746 = _0x193364;
                    _0x4b008f['setPermutation'](_0x4b008f[_0x583746(0x5fa)][_0x583746(0x9d1)](_0x207994 + _0x583746(0x6f3), _0x22170a[_0x583746(0x86c)]));
                });
                return;
            }
            if (_0x22170a[_0x193364(0x9ea)](_0x261b09?.[_0x193364(0x1b9)], _0x391d19) && _0x22170a[_0x193364(0x77e)](_0x261b09[_0x193364(0x5fa)]['getState'](_0x207994 + _0x193364(0x6f3)), _0x22170a[_0x193364(0xa64)]) && _0x22170a['DfzXa'](_0x261b09[_0x193364(0x5fa)][_0x193364(0x30a)](_0x207994 + ':cabinet_mirror'), _0x2210f0)) {
                const _0x29dcd2 = _0x261b09[_0x193364(0x5fa)][_0x193364(0x833)]();
                _0x1645e7[_0x193364(0x2c1)] = this[_0x193364(0x682)](_0x1645e7[_0x193364(0x2c1)], _0x29dcd2), _0x1645e7[_0x193364(0x2c1)] = _0x1645e7['permutationToPlace']['withState'](_0x207994 + ':connect', _0x22170a[_0x193364(0x86c)]), _0x3bdc3c[_0x193364(0xb7e)](() => {
                    const _0x4e32ed = _0x193364;
                    _0x261b09['setPermutation'](_0x261b09[_0x4e32ed(0x5fa)][_0x4e32ed(0x9d1)](_0x207994 + _0x4e32ed(0x6f3), _0x22170a[_0x4e32ed(0x460)]));
                });
            }
        }
        static [_0x21f734(0x800)](_0x18b8e8) {
            const _0x13b135 = _0x21f734, _0x16ab11 = {
                    'QcPRY': function (_0x364930, _0x5e9e08) {
                        return _0x364930 instanceof _0x5e9e08;
                    },
                    'GbjjY': function (_0x4ed068, _0x5ad17c) {
                        return _0x4ed068 === _0x5ad17c;
                    },
                    'voZHM': 'top',
                    'uURlf': _0x13b135(0x9e9),
                    'KXOoJ': function (_0xd8f989, _0x5716d4) {
                        return _0xd8f989 === _0x5716d4;
                    },
                    'DtJIX': _0x13b135(0x731)
                }, _0x35223b = _0x18b8e8[_0x13b135(0x87b)];
            let _0x27cfb4;
            _0x16ab11[_0x13b135(0x2be)](_0x18b8e8, _0x9cd822) ? _0x27cfb4 = _0x18b8e8[_0x13b135(0x2f4)][_0x13b135(0xc08)]['id'] : _0x27cfb4 = _0x18b8e8['explodedBlockPermutation'][_0x13b135(0xc08)]['id'];
            const _0x33d2cb = _0x35223b[_0x13b135(0x291)](), _0x43dd98 = _0x35223b[_0x13b135(0xbd3)]();
            _0x33d2cb && _0x16ab11[_0x13b135(0x344)](_0x33d2cb?.['typeId'], _0x27cfb4) && _0x16ab11[_0x13b135(0x344)](_0x33d2cb[_0x13b135(0x5fa)][_0x13b135(0x30a)](_0x207994 + _0x13b135(0x6f3)), _0x16ab11[_0x13b135(0x233)]) && _0x33d2cb[_0x13b135(0x772)](_0x33d2cb[_0x13b135(0x5fa)][_0x13b135(0x9d1)](_0x207994 + _0x13b135(0x6f3), _0x16ab11[_0x13b135(0x58d)])), _0x43dd98 && _0x16ab11['GbjjY'](_0x43dd98?.[_0x13b135(0x1b9)], _0x27cfb4) && _0x16ab11[_0x13b135(0x349)](_0x43dd98[_0x13b135(0x5fa)][_0x13b135(0x30a)](_0x207994 + _0x13b135(0x6f3)), _0x16ab11[_0x13b135(0x38e)]) && _0x43dd98[_0x13b135(0x772)](_0x43dd98['permutation']['withState'](_0x207994 + _0x13b135(0x6f3), _0x13b135(0x9e9)));
        }
    };
import {
    StructureSaveMode,
    system as _0x4c84e2,
    world as _0x2c759f,
    MinecraftDimensionTypes as _0x4086da
} from '@minecraft/server';
var _0x2d5af9 = class _0x3c722c {
    static [_0x21f734(0x48b)]() {
        const _0x154d6c = _0x21f734, _0x2cb81a = {
                'auyFh': function (_0x43b01c, _0x42ef63) {
                    return _0x43b01c === _0x42ef63;
                },
                'jRTVh': function (_0x421908, _0x38d53c) {
                    return _0x421908 === _0x38d53c;
                },
                'WXrHK': 'sb_bf:save',
                'ngmjp': function (_0x53766e, _0x5050a6) {
                    return _0x53766e + _0x5050a6;
                },
                'yCMDe': function (_0x31d846, _0xf21f85, _0x1f6497) {
                    return _0x31d846(_0xf21f85, _0x1f6497);
                },
                'aVgSh': _0x154d6c(0xba4),
                'zbKvA': 'left',
                'iYlzU': _0x154d6c(0x1a4),
                'lwfLy': _0x154d6c(0x3de),
                'hPatX': function (_0x50aa35, _0x49b057) {
                    return _0x50aa35 === _0x49b057;
                },
                'jRSkH': function (_0xe6cbb3, _0x2e8782) {
                    return _0xe6cbb3 === _0x2e8782;
                },
                'kPMfa': _0x154d6c(0x857),
                'PUtaQ': function (_0x4a1be1, _0x3b212f) {
                    return _0x4a1be1 === _0x3b212f;
                }
            };
        _0x2c759f['beforeEvents'][_0x154d6c(0x398)][_0x154d6c(0x725)](_0x3ec751 => {
            const _0xee7d53 = _0x154d6c;
            _0x3ec751[_0xee7d53(0x2ee)]['registerCustomComponent'](_0x207994 + _0xee7d53(0x1f4), {
                'onPlayerInteract': _0x1dfa6d => _0x3c722c[_0xee7d53(0xc05)](_0x1dfa6d),
                'onPlayerDestroy': _0x443748 => _0x3c722c['onPlayerDestroy'](_0x443748)
            });
        }), _0x2c759f[_0x154d6c(0x327)][_0x154d6c(0x1ae)][_0x154d6c(0x725)](_0x7e2bb => {
            const _0x1eb11b = _0x154d6c;
            if (_0x2cb81a[_0x1eb11b(0x517)](_0x7e2bb[_0x1eb11b(0xa27)]['typeId'], _0x207994 + _0x1eb11b(0x1f4))) {
                _0x7e2bb[_0x1eb11b(0xa27)]['triggerEvent']('minecraft:entity_spawned');
                const _0xceda08 = {
                        'x': _0x7e2bb['entity'][_0x1eb11b(0x2c0)]['x'],
                        'y': _0x7e2bb[_0x1eb11b(0xa27)][_0x1eb11b(0x2c0)]['y'],
                        'z': _0x7e2bb[_0x1eb11b(0xa27)][_0x1eb11b(0x2c0)]['z']
                    }, _0x25d849 = _0x7e2bb[_0x1eb11b(0xa27)][_0x1eb11b(0xb28)];
                _0x4c84e2[_0x1eb11b(0x873)](() => {
                    try {
                        _0x3c722c['ensureSingleStorageEntityByDimension'](_0x25d849, _0xceda08);
                    } catch (_0x5197e2) {
                    }
                }, 0x1);
            }
        }), _0x4c84e2[_0x154d6c(0x327)][_0x154d6c(0x306)]['subscribe'](_0x31e4df => {
            const _0x3f8ac2 = _0x154d6c;
            if (_0x2cb81a[_0x3f8ac2(0x2b4)](_0x31e4df['id'], _0x2cb81a[_0x3f8ac2(0x221)])) {
                const _0x12ec29 = _0x31e4df[_0x3f8ac2(0xaf2)], _0x14d48b = _0x12ec29[_0x3f8ac2(0xb28)][_0x3f8ac2(0x3c0)](_0x12ec29[_0x3f8ac2(0x2c0)]);
                if (!_0x14d48b)
                    return;
                const _0x2da90a = {
                    'x': _0x2cb81a[_0x3f8ac2(0x9b8)](_0x14d48b[_0x3f8ac2(0x2c0)]['x'], 0.5),
                    'y': _0x14d48b[_0x3f8ac2(0x2c0)]['y'],
                    'z': _0x14d48b[_0x3f8ac2(0x2c0)]['z'] + 0.5
                };
                _0x12ec29['teleport'](_0x2da90a);
                const _0x40f0aa = _0x3c722c[_0x3f8ac2(0xa71)](_0x14d48b);
                _0x2cb81a[_0x3f8ac2(0xa4f)](_0x1451f2, _0x12ec29, _0x40f0aa);
                const _0x5ec8cf = _0x2c759f[_0x3f8ac2(0xa1e)][_0x3f8ac2(0x3c7)](_0x207994 + ':' + _0x40f0aa);
                _0x5ec8cf && _0x2c759f[_0x3f8ac2(0xa1e)]['delete'](_0x207994 + ':' + _0x40f0aa);
                _0x2c759f[_0x3f8ac2(0xa1e)]['createFromWorld'](_0x207994 + ':' + _0x40f0aa, _0x14d48b['dimension'], _0x14d48b[_0x3f8ac2(0x2c0)], _0x14d48b[_0x3f8ac2(0x2c0)], {
                    'includeBlocks': ![],
                    'includeEntities': !![],
                    'saveMode': StructureSaveMode[_0x3f8ac2(0x37c)]
                });
                const _0x29b1e6 = _0x14d48b[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x2cb81a['aVgSh']), _0x3c94a2 = _0x3c722c['validDirections'](_0x14d48b, _0x29b1e6, _0x2cb81a[_0x3f8ac2(0x55a)]), _0x537f8c = _0x3c722c[_0x3f8ac2(0x7b0)](_0x14d48b, _0x29b1e6, _0x2cb81a['iYlzU']), _0x7ec088 = _0x14d48b[_0x3f8ac2(0x291)](), _0x107299 = _0x14d48b[_0x3f8ac2(0xbd3)]();
                if (_0x14d48b) {
                    const _0x52f164 = _0x3f8ac2(0x395)[_0x3f8ac2(0x1f5)]('|');
                    let _0x79a4f2 = 0x0;
                    while (!![]) {
                        switch (_0x52f164[_0x79a4f2++]) {
                        case '0':
                            _0x2cb81a[_0x3f8ac2(0x2b4)](_0x14d48b[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x207994 + _0x3f8ac2(0x6f3)), _0x3f8ac2(0x731)) && (_0x7ec088[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x207994 + ':storage_open') === !![] && _0x7ec088[_0x3f8ac2(0x772)](_0x7ec088[_0x3f8ac2(0x5fa)]['withState'](_0x207994 + _0x3f8ac2(0x798), ![])));
                            continue;
                        case '1':
                            _0x14d48b[_0x3f8ac2(0xb28)][_0x3f8ac2(0xa70)](_0x2cb81a[_0x3f8ac2(0x820)], _0x14d48b[_0x3f8ac2(0x5a0)]());
                            continue;
                        case '2':
                            _0x14d48b[_0x3f8ac2(0x772)](_0x14d48b['permutation'][_0x3f8ac2(0x9d1)](_0x207994 + ':storage_open', ![]));
                            continue;
                        case '3':
                            _0x2cb81a[_0x3f8ac2(0x7fd)](_0x14d48b['permutation'][_0x3f8ac2(0x30a)](_0x207994 + _0x3f8ac2(0x6f3)), _0x2cb81a[_0x3f8ac2(0x55a)]) && (_0x2cb81a[_0x3f8ac2(0x2b4)](_0x537f8c['permutation']['getState'](_0x207994 + ':storage_open'), !![]) && _0x537f8c[_0x3f8ac2(0x772)](_0x537f8c[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x9d1)](_0x207994 + _0x3f8ac2(0x798), ![])));
                            continue;
                        case '4':
                            _0x2cb81a[_0x3f8ac2(0x2d2)](_0x14d48b[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x207994 + _0x3f8ac2(0x6f3)), _0x2cb81a[_0x3f8ac2(0x49e)]) && (_0x2cb81a[_0x3f8ac2(0x7fd)](_0x3c94a2[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x207994 + _0x3f8ac2(0x798)), !![]) && _0x3c94a2[_0x3f8ac2(0x772)](_0x3c94a2[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x9d1)](_0x207994 + _0x3f8ac2(0x798), ![])));
                            continue;
                        case '5':
                            _0x2cb81a[_0x3f8ac2(0x2b4)](_0x14d48b[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x207994 + _0x3f8ac2(0x6f3)), _0x2cb81a['kPMfa']) && (_0x2cb81a[_0x3f8ac2(0x7f8)](_0x107299[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x30a)](_0x207994 + ':storage_open'), !![]) && _0x107299[_0x3f8ac2(0x772)](_0x107299[_0x3f8ac2(0x5fa)][_0x3f8ac2(0x9d1)](_0x207994 + _0x3f8ac2(0x798), ![])));
                            continue;
                        }
                        break;
                    }
                }
            }
        });
    }
    static ['getInventoryId'](_0x464bf9) {
        const _0x4ed3d0 = _0x21f734, _0x5afc3d = {
                'wzgRY': function (_0x2f1024, _0x96423a) {
                    return _0x2f1024 + _0x96423a;
                },
                'EOXYl': function (_0x24d756, _0x186e21) {
                    return _0x24d756 + _0x186e21;
                },
                'LJAXs': _0x4ed3d0(0xb56),
                'ebwED': function (_0x17a945, _0xc69808) {
                    return _0x17a945 === _0xc69808;
                },
                'aHVif': _0x4ed3d0(0x1df),
                'lBCzM': function (_0x33c9ec, _0x58177a) {
                    return _0x33c9ec === _0x58177a;
                },
                'rJEZw': _0x4ed3d0(0x2fd),
                'HwbNF': _0x4ed3d0(0x777),
                'rhbWG': _0x4ed3d0(0x552)
            }, _0x1bf413 = {
                'x': _0x5afc3d['wzgRY'](_0x464bf9[_0x4ed3d0(0x2c0)]['x'], 0.5),
                'y': _0x464bf9[_0x4ed3d0(0x2c0)]['y'],
                'z': _0x5afc3d[_0x4ed3d0(0xbe4)](_0x464bf9[_0x4ed3d0(0x2c0)]['z'], 0.5)
            };
        let _0x177ed6 = _0x5afc3d['LJAXs'];
        if (_0x5afc3d['ebwED'](_0x464bf9[_0x4ed3d0(0xb28)]['id'], _0x4086da[_0x4ed3d0(0x1df)]))
            _0x177ed6 = _0x5afc3d[_0x4ed3d0(0x972)];
        else {
            if (_0x5afc3d['lBCzM'](_0x464bf9[_0x4ed3d0(0xb28)]['id'], _0x4086da['nether']))
                _0x177ed6 = _0x5afc3d[_0x4ed3d0(0x4af)];
            else
                _0x5afc3d['lBCzM'](_0x464bf9[_0x4ed3d0(0xb28)]['id'], _0x4086da[_0x4ed3d0(0xa61)]) ? _0x177ed6 = _0x5afc3d[_0x4ed3d0(0x543)] : _0x177ed6 = _0x5afc3d[_0x4ed3d0(0x448)] + this['hashDimensionId'](_0x464bf9[_0x4ed3d0(0xb28)]['id']);
        }
        return _0x177ed6 + '_' + _0x1bf413['x'] + '_' + _0x1bf413['y'] + '_' + _0x1bf413['z'];
    }
    static [_0x21f734(0xba1)](_0x1e6a73) {
        const _0x478852 = _0x21f734, _0x542f44 = {
                'mbMAC': function (_0x5d3b55, _0x2c3566) {
                    return _0x5d3b55 - _0x2c3566;
                },
                'wXlBV': function (_0x6d3a9d, _0x26a6c7) {
                    return _0x6d3a9d << _0x26a6c7;
                },
                'qxNLs': function (_0x1c4461, _0x231aa6) {
                    return _0x1c4461 & _0x231aa6;
                }
            };
        let _0x244498 = 0x0;
        for (let _0x102fbe = 0x0; _0x102fbe < _0x1e6a73[_0x478852(0x51f)]; _0x102fbe++) {
            const _0x2a9aec = _0x1e6a73[_0x478852(0x869)](_0x102fbe);
            _0x244498 = _0x542f44[_0x478852(0xace)](_0x542f44[_0x478852(0x920)](_0x244498, 0x5), _0x244498) + _0x2a9aec, _0x244498 = _0x542f44['qxNLs'](_0x244498, _0x244498);
        }
        return Math[_0x478852(0xa22)](_0x244498)[_0x478852(0x948)](0x24);
    }
    static [_0x21f734(0x968)](_0x413e8a) {
        const _0x5f059a = _0x21f734, _0x3f2188 = {
                'HXcli': _0x5f059a(0xb63),
                'laZwM': function (_0x3691a4, _0x1ed704) {
                    return _0x3691a4 < _0x1ed704;
                },
                'ttart': _0x5f059a(0x463),
                'zCaoH': function (_0x2a2de3, _0xbfab40) {
                    return _0x2a2de3 + _0xbfab40;
                },
                'PZDZv': function (_0x466b2d, _0x408034) {
                    return _0x466b2d + _0x408034;
                },
                'ooPzI': function (_0x471242, _0x171ea9, _0x5a363f, _0x22e3cd) {
                    return _0x471242(_0x171ea9, _0x5a363f, _0x22e3cd);
                }
            }, _0x1fa214 = _0x413e8a['block'], _0x33a7fe = {
                'x': _0x3f2188[_0x5f059a(0x913)](_0x1fa214['location']['x'], 0.5),
                'y': _0x1fa214['location']['y'],
                'z': _0x3f2188[_0x5f059a(0x499)](_0x1fa214[_0x5f059a(0x2c0)]['z'], 0.5)
            }, _0x133c65 = _0x1fa214['dimension'], _0x5e937f = this['getInventoryId'](_0x1fa214), _0x17c801 = _0x2c759f[_0x5f059a(0xa1e)][_0x5f059a(0x3c7)](_0x207994 + ':' + _0x5e937f);
        if (_0x17c801) {
            const _0x4bce16 = this['ensureSingleStorageEntity'](_0x1fa214, _0x33a7fe);
            !_0x4bce16 && _0x2c759f['structureManager'][_0x5f059a(0x3b1)](_0x207994 + ':' + _0x5e937f, _0x133c65, _0x1fa214[_0x5f059a(0x2c0)], { 'includeEntities': !![] }), _0x4c84e2[_0x5f059a(0x873)](() => {
                const _0x67af90 = _0x5f059a;
                try {
                    const _0x28af6c = this[_0x67af90(0x824)](_0x133c65, _0x33a7fe);
                    if (_0x28af6c) {
                        const _0x38f990 = _0x28af6c[_0x67af90(0x3cc)](_0x3f2188[_0x67af90(0x6fd)]);
                        let _0x35fac6 = _0x38f990[_0x67af90(0xa39)];
                        if (!_0x35fac6)
                            return;
                        let _0x31809f = _0x35fac6[_0x67af90(0x87e)];
                        for (let _0x372847 = 0x0; _0x3f2188[_0x67af90(0x831)](_0x372847, _0x31809f); _0x372847++) {
                            const _0x559c76 = _0x35fac6[_0x67af90(0x5cb)](_0x372847);
                            _0x559c76 && _0x493aa0[_0x67af90(0x620)](_0x559c76[_0x67af90(0x1b9)]) && _0x133c65['spawnItem'](_0x559c76, _0x33a7fe);
                        }
                        _0x28af6c[_0x67af90(0x44b)]();
                    }
                } catch (_0x5cc52f) {
                    console[_0x67af90(0x73d)](_0x3f2188[_0x67af90(0x9eb)], _0x5cc52f);
                }
                _0x2c759f[_0x67af90(0xa1e)][_0x67af90(0x305)](_0x207994 + ':' + _0x5e937f);
            }, 0x1);
        }
        _0x3f2188['ooPzI'](_0x4ffe09, _0x5e937f, _0x133c65, _0x33a7fe);
    }
    static [_0x21f734(0xc05)](_0x537c7f) {
        const _0x246aed = _0x21f734, _0x80b0bf = {
                'XPmfO': 'minecraft:cardinal_direction',
                'VpKQU': _0x246aed(0x1a4),
                'cZzaU': function (_0x1852f2, _0x5f010c) {
                    return _0x1852f2 === _0x5f010c;
                },
                'foerM': 'bottom',
                'OkJFt': function (_0x2ec0fb, _0x322ec1) {
                    return _0x2ec0fb + _0x322ec1;
                },
                'BimlN': 'top',
                'whzUG': function (_0x44bedf, _0x55242) {
                    return _0x44bedf + _0x55242;
                },
                'hQjEQ': function (_0x59d59f, _0x233adc) {
                    return _0x59d59f === _0x233adc;
                },
                'qOfii': 'left',
                'nBnmf': function (_0x264270, _0x4a68a2) {
                    return _0x264270 + _0x4a68a2;
                },
                'UMQIy': function (_0x19f183, _0x2fb249) {
                    return _0x19f183 === _0x2fb249;
                },
                'LOytt': function (_0x13ec7b, _0x28b3e1) {
                    return _0x13ec7b + _0x28b3e1;
                }
            }, _0xa9970c = _0x537c7f['block'], _0x15eae3 = {
                'x': _0xa9970c[_0x246aed(0x2c0)]['x'] + 0.5,
                'y': _0xa9970c['location']['y'],
                'z': _0xa9970c[_0x246aed(0x2c0)]['z'] + 0.5
            }, _0x2915ed = this[_0x246aed(0xa71)](_0xa9970c);
        _0xa9970c[_0x246aed(0xb28)][_0x246aed(0xa70)](_0x246aed(0xa8d), _0x15eae3), this['loadStructure'](_0x2915ed, _0xa9970c, _0x15eae3);
        const _0x10290f = _0xa9970c[_0x246aed(0x5fa)][_0x246aed(0x30a)](_0x80b0bf['XPmfO']), _0x4a1dcb = _0x3c722c[_0x246aed(0x7b0)](_0xa9970c, _0x10290f, _0x246aed(0x45f)), _0x5a6cb0 = _0x3c722c[_0x246aed(0x7b0)](_0xa9970c, _0x10290f, _0x80b0bf[_0x246aed(0x288)]), _0x573faf = _0xa9970c[_0x246aed(0x291)](), _0x43b9b8 = _0xa9970c[_0x246aed(0xbd3)]();
        if (_0xa9970c) {
            if (_0x80b0bf[_0x246aed(0xa50)](_0xa9970c[_0x246aed(0x5fa)][_0x246aed(0x30a)](_0x207994 + _0x246aed(0x6f3)), _0x80b0bf[_0x246aed(0x547)])) {
                const _0x268d85 = {
                        'x': _0x80b0bf[_0x246aed(0x43b)](_0x573faf[_0x246aed(0x2c0)]['x'], 0.5),
                        'y': _0x573faf[_0x246aed(0x2c0)]['y'],
                        'z': _0x80b0bf[_0x246aed(0x43b)](_0x573faf[_0x246aed(0x2c0)]['z'], 0.5)
                    }, _0x7e1745 = this[_0x246aed(0xa71)](_0x573faf);
                this[_0x246aed(0x69f)](_0x7e1745, _0x573faf, _0x268d85), _0x573faf[_0x246aed(0x772)](_0x573faf[_0x246aed(0x5fa)][_0x246aed(0x9d1)](_0x207994 + _0x246aed(0x798), !![]));
            }
            if (_0x80b0bf['cZzaU'](_0xa9970c[_0x246aed(0x5fa)][_0x246aed(0x30a)](_0x207994 + _0x246aed(0x6f3)), _0x80b0bf[_0x246aed(0x6f9)])) {
                const _0x447041 = {
                        'x': _0x80b0bf[_0x246aed(0x995)](_0x43b9b8[_0x246aed(0x2c0)]['x'], 0.5),
                        'y': _0x43b9b8['location']['y'],
                        'z': _0x80b0bf[_0x246aed(0x995)](_0x43b9b8[_0x246aed(0x2c0)]['z'], 0.5)
                    }, _0x13be66 = this[_0x246aed(0xa71)](_0x43b9b8);
                this['loadStructure'](_0x13be66, _0x43b9b8, _0x447041), _0x43b9b8[_0x246aed(0x772)](_0x43b9b8[_0x246aed(0x5fa)]['withState'](_0x207994 + _0x246aed(0x798), !![]));
            }
            if (_0x80b0bf[_0x246aed(0x68e)](_0xa9970c[_0x246aed(0x5fa)][_0x246aed(0x30a)](_0x207994 + _0x246aed(0x6f3)), _0x80b0bf[_0x246aed(0x76e)])) {
                const _0xb94d75 = {
                        'x': _0x5a6cb0[_0x246aed(0x2c0)]['x'] + 0.5,
                        'y': _0x5a6cb0[_0x246aed(0x2c0)]['y'],
                        'z': _0x80b0bf[_0x246aed(0xa06)](_0x5a6cb0[_0x246aed(0x2c0)]['z'], 0.5)
                    }, _0x1a0188 = this[_0x246aed(0xa71)](_0x5a6cb0);
                this['loadStructure'](_0x1a0188, _0x5a6cb0, _0xb94d75), _0x5a6cb0[_0x246aed(0x772)](_0x5a6cb0[_0x246aed(0x5fa)][_0x246aed(0x9d1)](_0x207994 + ':storage_open', !![]));
            }
            if (_0x80b0bf[_0x246aed(0x58f)](_0xa9970c[_0x246aed(0x5fa)]['getState'](_0x207994 + _0x246aed(0x6f3)), 'right')) {
                const _0x5b1e2b = {
                        'x': _0x80b0bf[_0x246aed(0x995)](_0x4a1dcb[_0x246aed(0x2c0)]['x'], 0.5),
                        'y': _0x4a1dcb[_0x246aed(0x2c0)]['y'],
                        'z': _0x80b0bf[_0x246aed(0xa8c)](_0x4a1dcb[_0x246aed(0x2c0)]['z'], 0.5)
                    }, _0xc2a034 = this[_0x246aed(0xa71)](_0x4a1dcb);
                this[_0x246aed(0x69f)](_0xc2a034, _0x4a1dcb, _0x5b1e2b), _0x4a1dcb[_0x246aed(0x772)](_0x4a1dcb[_0x246aed(0x5fa)][_0x246aed(0x9d1)](_0x207994 + ':storage_open', !![]));
            }
            _0xa9970c[_0x246aed(0x772)](_0xa9970c[_0x246aed(0x5fa)][_0x246aed(0x9d1)](_0x207994 + ':storage_open', !![]));
        }
    }
    static [_0x21f734(0x7b0)](_0x45b67e, _0x46b482, _0x18eca9) {
        const _0x48072b = _0x21f734, _0x4d57ef = {
                'efdAP': function (_0x707dd3, _0x33e062) {
                    return _0x707dd3 === _0x33e062;
                },
                'AtQLx': _0x48072b(0x1a4),
                'blhuF': function (_0x4d74a8, _0x5a0e21) {
                    return _0x4d74a8 === _0x5a0e21;
                },
                'VROGt': _0x48072b(0x6a6),
                'Zwdqy': _0x48072b(0x45f),
                'wzVpk': _0x48072b(0x7bd),
                'hlhVt': function (_0x431848, _0x3bbf28) {
                    return _0x431848 === _0x3bbf28;
                },
                'pjnRN': 'west',
                'LgqDy': function (_0x6e32a1, _0x388a42) {
                    return _0x6e32a1 === _0x388a42;
                },
                'CfiWC': function (_0x2a0c56, _0xc8a32f) {
                    return _0x2a0c56 === _0xc8a32f;
                }
            };
        if (_0x4d57ef[_0x48072b(0xa29)](_0x46b482, _0x48072b(0x571))) {
            if (_0x18eca9 === _0x48072b(0x45f))
                return _0x45b67e[_0x48072b(0x7bd)]();
            if (_0x4d57ef['efdAP'](_0x18eca9, _0x4d57ef[_0x48072b(0xb04)]))
                return _0x45b67e[_0x48072b(0x709)]();
        }
        if (_0x4d57ef[_0x48072b(0x596)](_0x46b482, _0x4d57ef[_0x48072b(0x1f0)])) {
            if (_0x4d57ef[_0x48072b(0x596)](_0x18eca9, _0x4d57ef[_0x48072b(0xad3)]))
                return _0x45b67e[_0x48072b(0x709)]();
            if (_0x4d57ef[_0x48072b(0x596)](_0x18eca9, _0x4d57ef[_0x48072b(0xb04)]))
                return _0x45b67e[_0x48072b(0x7bd)]();
        }
        if (_0x4d57ef[_0x48072b(0x596)](_0x46b482, _0x4d57ef[_0x48072b(0x28f)])) {
            if (_0x4d57ef['blhuF'](_0x18eca9, _0x4d57ef['Zwdqy']))
                return _0x45b67e[_0x48072b(0x6a6)]();
            if (_0x4d57ef[_0x48072b(0xbbb)](_0x18eca9, _0x4d57ef[_0x48072b(0xb04)]))
                return _0x45b67e[_0x48072b(0x571)]();
        }
        if (_0x4d57ef['blhuF'](_0x46b482, _0x4d57ef[_0x48072b(0xaa4)])) {
            if (_0x4d57ef['LgqDy'](_0x18eca9, _0x4d57ef[_0x48072b(0xad3)]))
                return _0x45b67e[_0x48072b(0x571)]();
            if (_0x4d57ef[_0x48072b(0x63f)](_0x18eca9, _0x4d57ef[_0x48072b(0xb04)]))
                return _0x45b67e['south']();
        }
    }
    static [_0x21f734(0x824)](_0x172e0c, _0xa5762e) {
        const _0x48874b = _0x21f734, _0x277a6a = {
                'OuZQL': function (_0x4eb06b, _0xa26cb) {
                    return _0x4eb06b === _0xa26cb;
                },
                'QqjUQ': function (_0xcaf6d7, _0x4436fd) {
                    return _0xcaf6d7 < _0x4436fd;
                }
            };
        try {
            const _0x3a1a2f = _0x172e0c[_0x48874b(0x759)]({
                'location': _0xa5762e,
                'type': _0x207994 + _0x48874b(0x1f4),
                'maxDistance': 0.1
            });
            if (_0x277a6a['OuZQL'](_0x3a1a2f[_0x48874b(0x51f)], 0x0))
                return void 0x0;
            if (_0x277a6a['OuZQL'](_0x3a1a2f[_0x48874b(0x51f)], 0x1))
                return _0x3a1a2f[0x0];
            const _0xccb2ae = _0x3a1a2f[0x0];
            for (let _0x17a1d7 = 0x1; _0x277a6a[_0x48874b(0x3e7)](_0x17a1d7, _0x3a1a2f[_0x48874b(0x51f)]); _0x17a1d7++) {
                try {
                    _0x3a1a2f[_0x17a1d7]['remove']();
                } catch (_0x17aa39) {
                }
            }
            return _0xccb2ae;
        } catch (_0x4ebb1d) {
            return void 0x0;
        }
    }
    static ['ensureSingleStorageEntity'](_0x145d95, _0x300aa2) {
        const _0x59d332 = _0x21f734, _0x5ca6f7 = {
                'zweVM': function (_0x532393, _0x6a6cec) {
                    return _0x532393 === _0x6a6cec;
                },
                'vyMsG': function (_0x2dd72e, _0xd1346) {
                    return _0x2dd72e === _0xd1346;
                }
            };
        if (!_0x145d95 || !_0x145d95[_0x59d332(0x9ed)]())
            return void 0x0;
        const _0x511968 = _0x145d95[_0x59d332(0xb28)][_0x59d332(0x759)]({
            'location': _0x300aa2,
            'type': _0x207994 + _0x59d332(0x1f4),
            'maxDistance': 0.1
        });
        if (_0x5ca6f7[_0x59d332(0xba9)](_0x511968['length'], 0x0))
            return void 0x0;
        if (_0x5ca6f7[_0x59d332(0x33c)](_0x511968[_0x59d332(0x51f)], 0x1))
            return _0x511968[0x0];
        const _0x569d19 = _0x511968[0x0];
        for (let _0x1f2745 = 0x1; _0x1f2745 < _0x511968['length']; _0x1f2745++) {
            try {
                _0x511968[_0x1f2745][_0x59d332(0x44b)]();
            } catch (_0x143aaa) {
            }
        }
        return _0x569d19;
    }
    static [_0x21f734(0x69f)](_0x3a95b3, _0x460d87, _0x8ecbfe, _0x26d3d3 = _0x21f734(0x5b5)) {
        const _0x28198f = _0x21f734, _0x316696 = this[_0x28198f(0x38a)](_0x460d87, _0x8ecbfe);
        if (_0x316696)
            return _0x316696;
        const _0x4ff684 = _0x2c759f['structureManager'][_0x28198f(0x3c7)](_0x207994 + ':' + _0x3a95b3);
        if (_0x4ff684)
            return _0x2c759f[_0x28198f(0xa1e)][_0x28198f(0x3b1)](_0x207994 + ':' + _0x3a95b3, _0x460d87['dimension'], _0x460d87['location'], { 'includeEntities': !![] }), void 0x0;
        else {
            const _0x581984 = _0x460d87[_0x28198f(0xb28)][_0x28198f(0x6dc)](_0x207994 + _0x28198f(0x1f4), _0x8ecbfe);
            return _0x581984['nameTag'] = _0x26d3d3, _0x581984;
        }
    }
};
import {
    BlockPermutation as _0x5dc0ff,
    EquipmentSlot as _0x489a56,
    ItemStack as _0x2114db,
    system as _0x2d6167,
    world as _0x2c812a
} from '@minecraft/server';
var _0x4011c3 = [
        _0x21f734(0xa00),
        _0x21f734(0x4f1),
        _0x21f734(0x737),
        _0x21f734(0xc09),
        'snowball',
        _0x21f734(0x1b4),
        _0x21f734(0x4d2),
        _0x21f734(0xb7d),
        _0x21f734(0x5f9),
        _0x21f734(0x6f7),
        _0x21f734(0x933),
        _0x21f734(0x431),
        _0x21f734(0xb9b),
        _0x21f734(0x991),
        _0x21f734(0x2f0),
        _0x21f734(0x278),
        _0x21f734(0x208),
        'area_effect_cloud'
    ], _0xd2c5e8 = class _0x121711 {
        constructor(_0x23e3c6) {
            this['config'] = _0x23e3c6;
        }
        static ['registerBehavior'](_0x5c13f2) {
            const _0x43a39a = _0x21f734, _0xed8cdf = new _0x121711(_0x5c13f2);
            this['blocks'][_0x43a39a(0x28e)](_0xed8cdf);
        }
        static ['initialize']() {
            const _0x5d498f = _0x21f734;
            _0x2c812a[_0x5d498f(0x959)][_0x5d498f(0x398)][_0x5d498f(0x725)](_0x3f16e1 => {
                const _0xb63922 = _0x5d498f;
                _0x3f16e1[_0xb63922(0x2ee)][_0xb63922(0x565)](_0x207994 + _0xb63922(0xb35), {
                    'onPlace': _0x2b0996 => {
                    }
                });
            }), _0x2c812a[_0x5d498f(0x959)][_0x5d498f(0x48a)][_0x5d498f(0x725)](_0x47c001 => {
                const _0x404928 = _0x5d498f;
                _0x47c001['isFirstEvent'] && _0x121711[_0x404928(0xba0)](_0x47c001);
            });
        }
        static [_0x21f734(0x688)](_0x23d032, _0x416c36, _0x42b7ff, _0x5a9422, _0x5e1c30, _0xa5c3d3 = ![]) {
            const _0x593d19 = _0x21f734, _0x3266f6 = {
                    'nLRLE': function (_0x427c70, _0x596b6d) {
                        return _0x427c70 + _0x596b6d;
                    },
                    'WulqN': function (_0x5278b2, _0x14f046) {
                        return _0x5278b2 === _0x14f046;
                    },
                    'marBO': _0x593d19(0xbf3),
                    'UzXGY': function (_0x49b12d, _0x3a7237, _0xd60057, _0x3da561) {
                        return _0x49b12d(_0x3a7237, _0xd60057, _0x3da561);
                    },
                    'oBWXk': function (_0x17ff0d, _0x17b432, _0x358bf2) {
                        return _0x17ff0d(_0x17b432, _0x358bf2);
                    },
                    'TByJZ': function (_0x30781a, _0x1c5bff, _0x29417d, _0x3dbdaf) {
                        return _0x30781a(_0x1c5bff, _0x29417d, _0x3dbdaf);
                    },
                    'ekSDO': function (_0x2880ff, _0x4e617d) {
                        return _0x2880ff == _0x4e617d;
                    },
                    'uXyRV': function (_0x5127fe, _0x5af2fd) {
                        return _0x5127fe > _0x5af2fd;
                    }
                };
            let _0x2b4ad1 = _0x5dc0ff[_0x593d19(0x8f4)](_0x23d032[_0x593d19(0xb80)]['id'] || _0x416c36[_0x593d19(0x1b9)]);
            if (_0x3266f6[_0x593d19(0x62f)](_0x23d032[_0x593d19(0xa10)], !![])) {
                const _0x205022 = _0x416c36[_0x593d19(0xb28)]['getEntitiesAtBlockLocation'](_0x416c36['location']);
                if (_0x3266f6['uXyRV'](_0x205022[_0x593d19(0x51f)], 0x0)) {
                    const _0x236d56 = _0x205022[_0x593d19(0x578)](_0x2d38d3 => !_0x4011c3[_0x593d19(0x620)](_0x2d38d3[_0x593d19(0x1b9)]));
                    if (_0x236d56['length'] > 0x0)
                        return;
                }
            }
            if (_0x23d032[_0x593d19(0xb80)]['id']) {
                const _0xcbd201 = _0x416c36['permutation']['getAllStates'](), _0x46bffa = Object['keys'](_0x2b4ad1[_0x593d19(0x833)]());
                for (const [_0x24035a, _0x26b60c] of Object['entries'](_0xcbd201)) {
                    if (_0x46bffa[_0x593d19(0x620)](_0x24035a))
                        try {
                            _0x2b4ad1 = _0x2b4ad1['withState'](_0x24035a, _0x26b60c);
                        } catch (_0x1b8f5d) {
                        }
                }
            } else
                for (const [_0x1db569, _0x42c284] of Object[_0x593d19(0x5a8)](_0x416c36[_0x593d19(0x5fa)][_0x593d19(0x833)]())) {
                    _0x2b4ad1 = _0x2b4ad1['withState'](_0x1db569, _0x42c284);
                }
            if (_0x23d032[_0x593d19(0xb80)][_0x593d19(0x30d)])
                for (const _0x3265a3 of _0x23d032[_0x593d19(0xb80)][_0x593d19(0x30d)]) {
                    _0x2b4ad1 = _0x2b4ad1['withState'](_0x3265a3[_0x593d19(0x5af)], _0x3265a3[_0x593d19(0x8c7)]);
                }
            _0x2d6167[_0x593d19(0x873)](() => {
                const _0x2ce5b0 = _0x593d19;
                _0x416c36[_0x2ce5b0(0x772)](_0x2b4ad1);
                const _0x1c3609 = {
                    'x': _0x3266f6['nLRLE'](_0x416c36[_0x2ce5b0(0x2c0)]['x'], 0.5),
                    'y': _0x3266f6['nLRLE'](_0x416c36[_0x2ce5b0(0x2c0)]['y'], 0.5),
                    'z': _0x416c36[_0x2ce5b0(0x2c0)]['z'] + 0.5
                };
                _0x23d032[_0x2ce5b0(0x758)] && (_0xa5c3d3 || _0x3266f6[_0x2ce5b0(0xb01)](_0x23d032[_0x2ce5b0(0x39d)], !![])) && _0x416c36[_0x2ce5b0(0xb28)][_0x2ce5b0(0xa70)](_0x23d032['sound'], _0x1c3609);
                _0x23d032[_0x2ce5b0(0x9b5)] && _0x416c36[_0x2ce5b0(0xb28)][_0x2ce5b0(0xb85)](_0x23d032[_0x2ce5b0(0x9b5)], _0x1c3609);
                _0x5a9422 && !_0x5e1c30[_0x2ce5b0(0x8c7)] && _0x23d032[_0x2ce5b0(0xa00)] && _0x23d032[_0x2ce5b0(0xa00)] !== _0x3266f6[_0x2ce5b0(0x7c9)] && _0x23d032[_0x2ce5b0(0xa69)] === !![] && (_0x3266f6[_0x2ce5b0(0xa51)](_0xed22af, _0x42b7ff, 0x1, !![]), _0x5e1c30[_0x2ce5b0(0x8c7)] = !![]);
                if (_0x23d032[_0x2ce5b0(0x308)]) {
                    const _0x32d724 = _0x3266f6['oBWXk'](_0x59bdcb, _0x42b7ff, _0x489a56[_0x2ce5b0(0xc15)]);
                    !_0x32d724 ? _0x3266f6[_0x2ce5b0(0xa9c)](_0x5c2500, _0x42b7ff, _0x489a56['Mainhand'], new _0x2114db(_0x23d032[_0x2ce5b0(0x308)])) : _0x3266f6[_0x2ce5b0(0x548)](_0x467466, _0x42b7ff, new _0x2114db(_0x23d032['transformItem']));
                }
                if (_0x23d032[_0x2ce5b0(0x64b)]) {
                    const _0x455996 = new _0x2114db(_0x23d032[_0x2ce5b0(0x64b)], 0x1);
                    _0x3266f6['oBWXk'](_0x467466, _0x42b7ff, _0x455996);
                }
            });
        }
        static ['isItemValid'](_0xef1c41, _0x5010e8, _0x2eaa5a) {
            const _0x144984 = _0x21f734, _0x273dc0 = {
                    'hcSKU': function (_0x56dfc9, _0x385395) {
                        return _0x56dfc9 === _0x385395;
                    },
                    'WogUz': function (_0x2f0220, _0x5932f6) {
                        return _0x2f0220(_0x5932f6);
                    },
                    'QqhtT': function (_0x3d56a6, _0x420268) {
                        return _0x3d56a6 !== _0x420268;
                    },
                    'ehNFi': 'hand',
                    'vqoCF': function (_0x4c73c6, _0x1bee08) {
                        return _0x4c73c6 === _0x1bee08;
                    },
                    'irubt': _0x144984(0x69d),
                    'VhzcZ': 'object',
                    'GfCrQ': function (_0x143256, _0x1d5385, _0x1dc866) {
                        return _0x143256(_0x1d5385, _0x1dc866);
                    },
                    'zGftT': function (_0x43b1ab, _0x1008aa, _0x470201) {
                        return _0x43b1ab(_0x1008aa, _0x470201);
                    },
                    'vYZfy': function (_0x7cf364, _0xa779aa) {
                        return _0x7cf364 === _0xa779aa;
                    }
                };
            if (_0x273dc0[_0x144984(0xb61)](_0xef1c41[_0x144984(0x352)], !![]) && _0x273dc0[_0x144984(0x31e)](_0x3faa9f, _0x2eaa5a) && _0x273dc0[_0x144984(0x434)](_0x5010e8, void 0x0))
                return ![];
            if (_0xef1c41[_0x144984(0xa00)] === void 0x0)
                return !![];
            if (_0xef1c41['item'] === _0x273dc0[_0x144984(0x637)])
                return _0x273dc0[_0x144984(0xae5)](_0x5010e8, void 0x0);
            if (_0xef1c41[_0x144984(0xa00)] === _0x273dc0['irubt'])
                return !![];
            if (_0x273dc0['vqoCF'](typeof _0xef1c41[_0x144984(0xa00)], _0x273dc0['VhzcZ']) && !Array[_0x144984(0x2b1)](_0xef1c41[_0x144984(0xa00)])) {
                if (!_0x2eaa5a)
                    return ![];
                const _0x5ef36d = _0x273dc0[_0x144984(0x95f)](_0x59bdcb, _0x2eaa5a, _0x489a56[_0x144984(0xc15)]);
                if (!_0x5ef36d)
                    return ![];
                return _0x273dc0[_0x144984(0x36f)](_0x3ea9a1, _0x5ef36d, _0xef1c41[_0x144984(0xa00)]);
            }
            if (Array[_0x144984(0x2b1)](_0xef1c41[_0x144984(0xa00)])) {
                if (_0x273dc0[_0x144984(0x2b0)](_0x5010e8, void 0x0))
                    return _0xef1c41[_0x144984(0xa00)]['includes'](_0x144984(0xbf3));
                return _0xef1c41[_0x144984(0xa00)][_0x144984(0x88d)](_0x1ef10d => _0x1ef10d === _0x5010e8);
            }
            if (_0x273dc0[_0x144984(0x2b0)](_0x5010e8, void 0x0))
                return ![];
            return _0x273dc0[_0x144984(0xae5)](_0xef1c41[_0x144984(0xa00)], _0x5010e8);
        }
        static ['areStatesValid'](_0x1ebc6b, _0xc6a3eb) {
            const _0x289716 = {
                'oMhhu': function (_0x1861be, _0x23f2d6) {
                    return _0x1861be !== _0x23f2d6;
                }
            };
            if (!_0x1ebc6b['states'])
                return !![];
            return !_0x1ebc6b['states']['some'](_0x3c6216 => {
                const _0x585b24 = _0x3124, _0x44b81b = _0xc6a3eb['permutation'][_0x585b24(0x30a)](_0x3c6216[_0x585b24(0x5af)]);
                if (_0x44b81b === void 0x0)
                    return !![];
                if (Array[_0x585b24(0x2b1)](_0x3c6216[_0x585b24(0x8c7)]))
                    return !_0x3c6216[_0x585b24(0x8c7)][_0x585b24(0x578)](_0x5576e3 => typeof _0x5576e3 === 'string' || typeof _0x5576e3 === 'number')[_0x585b24(0x620)](_0x44b81b);
                return _0x289716[_0x585b24(0x965)](_0x44b81b, _0x3c6216[_0x585b24(0x8c7)]);
            });
        }
        static [_0x21f734(0x4a9)](_0x431a9e, _0x29bfbd, _0x5afb0e, _0x4e1fd2) {
            const _0x4f39fb = _0x21f734, _0x33b602 = {
                    'lzIKJ': function (_0x301fdd, _0x144ac7, _0x2c6204) {
                        return _0x301fdd(_0x144ac7, _0x2c6204);
                    },
                    'pVitE': function (_0x51b696, _0x3ffaa1) {
                        return _0x51b696 === _0x3ffaa1;
                    },
                    'XUaOP': 'above',
                    'bdovl': _0x4f39fb(0xbd3),
                    'pNwbb': function (_0x21f505, _0x4d79c3) {
                        return _0x21f505 === _0x4d79c3;
                    }
                }, _0x42ceb0 = {
                    'north': () => _0x431a9e[_0x4f39fb(0x571)](),
                    'south': () => _0x431a9e[_0x4f39fb(0x6a6)](),
                    'east': () => _0x431a9e[_0x4f39fb(0x7bd)](),
                    'west': () => _0x431a9e[_0x4f39fb(0x709)](),
                    'up': () => _0x431a9e['above'](),
                    'down': () => _0x431a9e[_0x4f39fb(0xbd3)]()
                }, _0x4dc109 = _0x42ceb0[_0x29bfbd['toLocaleLowerCase']()]?.[_0x4f39fb(0x44a)](_0x431a9e);
            if (!_0x4dc109)
                return ![];
            const _0x58c89f = _0x4dc109, _0x4a8f27 = _0x121711['getBlockByIdentifier'](_0x58c89f[_0x4f39fb(0x1b9)]);
            if (!_0x4a8f27)
                return ![];
            const _0x2b8b2b = _0x33b602['lzIKJ'](_0x59bdcb, _0x5afb0e, _0x489a56[_0x4f39fb(0xc15)])?.[_0x4f39fb(0x1b9)];
            let _0x27043f = ![];
            for (const _0x77f2c4 of _0x4a8f27[_0x4f39fb(0xa49)][_0x4f39fb(0xb68)]) {
                if (!_0x121711[_0x4f39fb(0xae1)](_0x77f2c4, _0x2b8b2b, _0x5afb0e))
                    continue;
                if (!_0x121711[_0x4f39fb(0x375)](_0x77f2c4, _0x58c89f))
                    continue;
                _0x77f2c4[_0x4f39fb(0xa7a)] && (_0x121711[_0x4f39fb(0x688)](_0x77f2c4, _0x58c89f, _0x5afb0e, !![], _0x4e1fd2, ![]), _0x27043f = !![]);
                if (_0x33b602['pVitE'](_0x77f2c4[_0x4f39fb(0x4cc)], _0x33b602['XUaOP']) || _0x33b602['pVitE'](_0x77f2c4['adjecentUpdate'], _0x33b602[_0x4f39fb(0x576)])) {
                    const _0x4d7d0e = _0x33b602[_0x4f39fb(0x382)](_0x77f2c4[_0x4f39fb(0x4cc)], _0x33b602['XUaOP']) ? _0x431a9e[_0x4f39fb(0x291)]() : _0x431a9e[_0x4f39fb(0xbd3)]();
                    _0x4d7d0e && _0x33b602[_0x4f39fb(0x461)](_0x4d7d0e[_0x4f39fb(0x1b9)], _0x58c89f[_0x4f39fb(0x1b9)]) && (_0x121711[_0x4f39fb(0x688)](_0x77f2c4, _0x4d7d0e, _0x5afb0e, !![], _0x4e1fd2, ![]), _0x27043f = !![]);
                }
                _0x33b602[_0x4f39fb(0x461)](_0x77f2c4[_0x4f39fb(0x4cc)], _0x4f39fb(0x9cf)) && (_0x27043f = _0x121711['updateVerticalBlocks'](_0x58c89f, _0x77f2c4, _0x5afb0e, _0x4e1fd2) || _0x27043f);
            }
            return _0x27043f;
        }
        static [_0x21f734(0x29f)](_0x203189, _0x10ebff, _0x476c9d, _0x65b055) {
            const _0x466da4 = _0x21f734, _0x7dd887 = {
                    'SgLYO': function (_0x8601ee, _0xf94c1) {
                        return _0x8601ee !== _0xf94c1;
                    }
                }, _0x4cfda5 = _0x203189['typeId'], _0x4413ab = _0x203189['permutation'][_0x466da4(0x833)](), _0x5b8c35 = _0x38a262 => _0x38a262[_0x466da4(0x2c0)]['x'] + ',' + _0x38a262[_0x466da4(0x2c0)]['y'] + ',' + _0x38a262[_0x466da4(0x2c0)]['z'], _0xa0ba6 = _0x39500e => {
                    const _0x415004 = _0x466da4;
                    if (_0x10ebff[_0x415004(0x30d)] && _0x10ebff['states']['length'] > 0x0) {
                        for (const _0x456e92 of _0x10ebff[_0x415004(0x30d)]) {
                            const _0x45d607 = _0x4413ab[_0x456e92[_0x415004(0x5af)]], _0x483c4f = _0x39500e[_0x415004(0x5fa)]['getState'](_0x456e92[_0x415004(0x5af)]);
                            if (_0x7dd887[_0x415004(0xa17)](_0x45d607, _0x483c4f))
                                return ![];
                        }
                        return !![];
                    }
                    return !![];
                };
            return this[_0x466da4(0x2b9)](_0x203189, _0x10ebff, _0x476c9d, _0x65b055, _0x4cfda5, _0x4413ab, _0xa0ba6), !![];
        }
        static [_0x21f734(0x2b9)](_0x3395fa, _0x4d9242, _0x5daf1e, _0x295a5e, _0x43c6f8, _0xa69026, _0x372329) {
            const _0x4971e1 = _0x21f734, _0x54feef = {
                    'LIzCD': function (_0x23b1e0, _0x477639) {
                        return _0x23b1e0 === _0x477639;
                    },
                    'vZTkV': function (_0x802b77, _0xa4afd) {
                        return _0x802b77 >= _0xa4afd;
                    },
                    'Bmlun': function (_0x51119b, _0x3c36cf) {
                        return _0x51119b - _0x3c36cf;
                    },
                    'xgVNM': function (_0x340a0c, _0xe4ee74) {
                        return _0x340a0c !== _0xe4ee74;
                    },
                    'rvlSB': function (_0x30369a, _0x47fa55) {
                        return _0x30369a(_0x47fa55);
                    },
                    'MUGSR': function (_0x532526, _0x98e028) {
                        return _0x532526(_0x98e028);
                    },
                    'fLkLT': function (_0x15bf4f, _0x14dcfa) {
                        return _0x15bf4f(_0x14dcfa);
                    },
                    'zlwKH': function (_0x5e7ed1, _0x48b2de) {
                        return _0x5e7ed1 === _0x48b2de;
                    },
                    'uYCxX': function (_0x25903e, _0x19102e) {
                        return _0x25903e(_0x19102e);
                    },
                    'Nerog': function (_0x5d5894, _0xf109b9) {
                        return _0x5d5894 > _0xf109b9;
                    },
                    'EPxWf': function (_0x377fe5, _0x3ff2d4) {
                        return _0x377fe5 < _0x3ff2d4;
                    },
                    'ONXDI': function (_0x5e7e5b) {
                        return _0x5e7e5b();
                    }
                }, _0xad5162 = 0x64, _0x4d9d51 = 0x5, _0x59fda0 = _0x3395fa['dimension'], _0x184344 = new Set(), _0x3df6cc = _0x280f0d => _0x280f0d['location']['x'] + ',' + _0x280f0d[_0x4971e1(0x2c0)]['y'] + ',' + _0x280f0d[_0x4971e1(0x2c0)]['z'];
            _0x184344[_0x4971e1(0x65f)](_0x54feef[_0x4971e1(0x94e)](_0x3df6cc, _0x3395fa));
            const _0x1cac22 = [{
                    'x': _0x3395fa[_0x4971e1(0x2c0)]['x'],
                    'y': _0x3395fa[_0x4971e1(0x2c0)]['y'],
                    'z': _0x3395fa['location']['z']
                }];
            let _0x1c299f = 0x0;
            const _0x44ffe0 = () => {
                const _0x35abfe = _0x4971e1;
                if (_0x54feef[_0x35abfe(0xa48)](_0x1cac22[_0x35abfe(0x51f)], 0x0) || _0x54feef[_0x35abfe(0x4d6)](_0x1c299f, _0xad5162))
                    return;
                const _0x57f547 = Math['min'](_0x4d9d51, _0x1cac22[_0x35abfe(0x51f)], _0x54feef[_0x35abfe(0x418)](_0xad5162, _0x1c299f)), _0x34b76c = _0x1cac22[_0x35abfe(0xa43)](0x0, _0x57f547);
                for (const _0x37f1c0 of _0x34b76c) {
                    try {
                        const _0x5b2e63 = _0x59fda0['getBlock'](_0x37f1c0);
                        if (!_0x5b2e63 || _0x54feef[_0x35abfe(0x4d3)](_0x5b2e63['typeId'], _0x43c6f8) || !_0x54feef[_0x35abfe(0x66b)](_0x372329, _0x5b2e63))
                            continue;
                        _0x121711[_0x35abfe(0x688)](_0x4d9242, _0x5b2e63, _0x5daf1e, !![], _0x295a5e, ![]), _0x1c299f++;
                        try {
                            const _0x540849 = _0x5b2e63[_0x35abfe(0x291)]();
                            if (_0x540849) {
                                const _0x1119ce = _0x54feef[_0x35abfe(0x312)](_0x3df6cc, _0x540849);
                                !_0x184344[_0x35abfe(0x1b2)](_0x1119ce) && _0x54feef[_0x35abfe(0xa48)](_0x540849[_0x35abfe(0x1b9)], _0x43c6f8) && _0x372329(_0x540849) && (_0x184344[_0x35abfe(0x65f)](_0x1119ce), _0x1cac22[_0x35abfe(0x28e)]({
                                    'x': _0x540849[_0x35abfe(0x2c0)]['x'],
                                    'y': _0x540849[_0x35abfe(0x2c0)]['y'],
                                    'z': _0x540849[_0x35abfe(0x2c0)]['z']
                                }));
                            }
                        } catch {
                        }
                        try {
                            const _0x2a5913 = _0x5b2e63[_0x35abfe(0xbd3)]();
                            if (_0x2a5913) {
                                const _0x4fb24d = _0x54feef[_0x35abfe(0xbf2)](_0x3df6cc, _0x2a5913);
                                !_0x184344[_0x35abfe(0x1b2)](_0x4fb24d) && _0x54feef['zlwKH'](_0x2a5913[_0x35abfe(0x1b9)], _0x43c6f8) && _0x54feef[_0x35abfe(0x94e)](_0x372329, _0x2a5913) && (_0x184344[_0x35abfe(0x65f)](_0x4fb24d), _0x1cac22['push']({
                                    'x': _0x2a5913[_0x35abfe(0x2c0)]['x'],
                                    'y': _0x2a5913[_0x35abfe(0x2c0)]['y'],
                                    'z': _0x2a5913[_0x35abfe(0x2c0)]['z']
                                }));
                            }
                        } catch {
                        }
                    } catch (_0x567b41) {
                    }
                }
                _0x54feef[_0x35abfe(0xa04)](_0x1cac22['length'], 0x0) && _0x54feef[_0x35abfe(0x809)](_0x1c299f, _0xad5162) && _0x2d6167['runTimeout'](_0x44ffe0, 0x1);
            };
            _0x54feef[_0x4971e1(0x9ec)](_0x44ffe0);
        }
        static [_0x21f734(0xba0)](_0x5dc3a6) {
            const _0x5bff5d = _0x21f734, _0x860dd8 = {
                    'oPOhE': function (_0x18ea4e, _0x26931b) {
                        return _0x18ea4e !== _0x26931b;
                    },
                    'Jqued': function (_0x50b171, _0x1ba960) {
                        return _0x50b171 + _0x1ba960;
                    },
                    'LPcmd': function (_0xc948f7, _0x308bc6) {
                        return _0xc948f7 + _0x308bc6;
                    },
                    'zUExR': function (_0x391fae, _0x4cc358) {
                        return _0x391fae + _0x4cc358;
                    },
                    'zBMAV': function (_0x12d7fd, _0xa481ab) {
                        return _0x12d7fd || _0xa481ab;
                    },
                    'oKADU': function (_0x2b4848, _0x58261e, _0x313b64) {
                        return _0x2b4848(_0x58261e, _0x313b64);
                    },
                    'uNAgO': function (_0x1bbc05, _0x15f0a3) {
                        return _0x1bbc05 === _0x15f0a3;
                    },
                    'oWFDZ': _0x5bff5d(0x9cf),
                    'wajTv': _0x5bff5d(0x291),
                    'MouUz': function (_0x47cacc, _0x53ab20) {
                        return _0x47cacc === _0x53ab20;
                    },
                    'cGLWX': 'below'
                }, {
                    block: _0x3d0968,
                    player: _0x322ec4
                } = _0x5dc3a6;
            if (_0x860dd8['zBMAV'](!_0x3d0968, !_0x322ec4))
                return;
            const _0x5d06ee = { 'value': ![] }, _0x82da4d = _0x5dc3a6[_0x5bff5d(0x9e3)]?.[_0x5bff5d(0x57d)](), _0x32e3d8 = _0x121711['getBlockByIdentifier'](_0x3d0968[_0x5bff5d(0x1b9)]);
            if (!_0x32e3d8)
                return;
            const _0x2feca6 = _0x32e3d8[_0x5bff5d(0xa49)][_0x5bff5d(0xb68)][_0x5bff5d(0x88d)](_0xdee845 => _0xdee845[_0x5bff5d(0xa7a)] === !![]), _0x5ee5b4 = _0x2feca6 ? _0x121711[_0x5bff5d(0x4a9)](_0x3d0968, _0x5dc3a6[_0x5bff5d(0x9e3)], _0x322ec4, _0x5d06ee) : ![], _0x52d2a = _0x860dd8[_0x5bff5d(0x6db)](_0x59bdcb, _0x322ec4, _0x489a56[_0x5bff5d(0xc15)])?.['typeId'];
            let _0x328c57 = ![];
            for (const _0x4286bd of _0x32e3d8[_0x5bff5d(0xa49)][_0x5bff5d(0xb68)]) {
                if (!_0x121711[_0x5bff5d(0xae1)](_0x4286bd, _0x52d2a, _0x322ec4))
                    continue;
                if (!_0x121711['areStatesValid'](_0x4286bd, _0x3d0968))
                    continue;
                if (_0x4286bd[_0x5bff5d(0xa53)]) {
                    const _0x3800f0 = Array['isArray'](_0x4286bd[_0x5bff5d(0xa53)]) ? _0x4286bd[_0x5bff5d(0xa53)][_0x5bff5d(0x2dc)](_0x1662ea => _0x1662ea[_0x5bff5d(0x57d)]()) : [_0x4286bd[_0x5bff5d(0xa53)]['toLowerCase']()];
                    if (!_0x3800f0[_0x5bff5d(0x620)](_0x82da4d))
                        continue;
                }
                _0x328c57 = !![], _0x2d6167['runTimeout'](() => {
                    const _0x3f6eb5 = _0x5bff5d;
                    _0x4286bd[_0x3f6eb5(0x228)] && _0x4286bd[_0x3f6eb5(0x228)](_0x322ec4, _0x3d0968);
                }, 0x1);
                if (_0x860dd8[_0x5bff5d(0x3bf)](_0x4286bd[_0x5bff5d(0x4cc)], _0x860dd8[_0x5bff5d(0x1cc)])) {
                    _0x2d6167[_0x5bff5d(0x873)](() => {
                        const _0x4ae8fc = _0x5bff5d;
                        if (_0x4286bd[_0x4ae8fc(0x758)] && _0x860dd8[_0x4ae8fc(0x2df)](_0x4286bd[_0x4ae8fc(0x39d)], !![])) {
                            const _0x347c7f = {
                                'x': _0x860dd8[_0x4ae8fc(0x586)](_0x3d0968[_0x4ae8fc(0x2c0)]['x'], 0.5),
                                'y': _0x860dd8[_0x4ae8fc(0x541)](_0x3d0968[_0x4ae8fc(0x2c0)]['y'], 0.5),
                                'z': _0x860dd8['zUExR'](_0x3d0968[_0x4ae8fc(0x2c0)]['z'], 0.5)
                            };
                            _0x3d0968[_0x4ae8fc(0xb28)]['playSound'](_0x4286bd[_0x4ae8fc(0x758)], _0x347c7f);
                        }
                    }, 0x1), _0x121711[_0x5bff5d(0x29f)](_0x3d0968, _0x4286bd, _0x322ec4, _0x5d06ee);
                    continue;
                }
                if (_0x860dd8[_0x5bff5d(0x3bf)](_0x4286bd[_0x5bff5d(0x4cc)], _0x860dd8[_0x5bff5d(0x996)]) || _0x860dd8['MouUz'](_0x4286bd[_0x5bff5d(0x4cc)], _0x860dd8[_0x5bff5d(0x6f0)])) {
                    const _0x4a2943 = _0x4286bd['adjecentUpdate'] === _0x860dd8[_0x5bff5d(0x996)] ? _0x3d0968[_0x5bff5d(0x291)]() : _0x3d0968[_0x5bff5d(0xbd3)]();
                    _0x4a2943 && _0x4a2943[_0x5bff5d(0x1b9)] === _0x3d0968[_0x5bff5d(0x1b9)] && (_0x121711['applyTransform'](_0x4286bd, _0x4a2943, _0x322ec4, !![], _0x5d06ee, ![]), _0x328c57 = !![]);
                }
                _0x121711[_0x5bff5d(0x688)](_0x4286bd, _0x3d0968, _0x322ec4, !_0x5ee5b4, _0x5d06ee, !![]);
            }
            _0x328c57 && (_0x5dc3a6['cancel'] = !![]);
        }
        static ['getBlockByIdentifier'](_0x5092e9) {
            const _0x3b14b1 = _0x21f734;
            return _0x121711[_0x3b14b1(0x752)][_0x3b14b1(0x65e)](_0x45a4ed => _0x45a4ed[_0x3b14b1(0xa49)]['id'] === _0x5092e9);
        }
    };
_0x25e7d0(_0xd2c5e8, _0x21f734(0x752), []);
var _0x398ddd = _0xd2c5e8;
import {
    system as _0x3281ba,
    world as _0x5bac9d
} from '@minecraft/server';
var _0x35613d = class _0x4eea79 {
    constructor(_0xd6d955) {
        const _0x884d9f = _0x21f734;
        this[_0x884d9f(0xa49)] = _0xd6d955;
    }
    static [_0x21f734(0x760)](_0x255538) {
        const _0x19abc8 = _0x21f734, _0x330c68 = new _0x4eea79(_0x255538);
        _0x4eea79[_0x19abc8(0x752)]['push'](_0x330c68);
    }
    static [_0x21f734(0x48b)]() {
        const _0x301d0f = _0x21f734;
        _0x5bac9d[_0x301d0f(0x959)][_0x301d0f(0x398)][_0x301d0f(0x725)](_0x1745a7 => {
            const _0x243da8 = _0x301d0f;
            _0x1745a7[_0x243da8(0x2ee)][_0x243da8(0x565)](_0x207994 + _0x243da8(0xaaa), { 'onTick': _0x5a22f2 => this[_0x243da8(0x5df)](_0x5a22f2) });
        }), _0x5bac9d[_0x301d0f(0x327)][_0x301d0f(0x8ee)][_0x301d0f(0x725)](_0x13268f => {
            const _0x280d90 = _0x301d0f;
            this[_0x280d90(0x632)](_0x13268f[_0x280d90(0x87b)]);
        });
    }
    static [_0x21f734(0x5df)](_0x5dc7b6) {
        const _0x3a7a8c = _0x21f734, _0x16c53c = _0x5dc7b6[_0x3a7a8c(0x87b)];
        if (!_0x16c53c)
            return;
        const _0x56f70b = this[_0x3a7a8c(0x5ea)](_0x16c53c[_0x3a7a8c(0x1b9)]);
        if (!_0x56f70b)
            return;
        if (_0x56f70b['config'][_0x3a7a8c(0x645)] && !_0x56f70b[_0x3a7a8c(0xa49)]['conditions'](_0x16c53c))
            return;
        this['applyEffects'](_0x16c53c, _0x56f70b);
    }
    static [_0x21f734(0x5ea)](_0xd6479b) {
        const _0x3d7a9b = _0x21f734;
        return _0x4eea79[_0x3d7a9b(0x752)][_0x3d7a9b(0x65e)](_0x5ae0dd => _0x5ae0dd['config']['id'] === _0xd6479b);
    }
    static ['applyEffects'](_0x4c2055, _0x2005f4) {
        const _0x50e62f = _0x21f734, _0x5a3552 = {
                'UqnJv': function (_0x2964f1, _0x462cf6) {
                    return _0x2964f1 === _0x462cf6;
                },
                'PlrtE': function (_0x357f48, _0x98a5e1) {
                    return _0x357f48 * _0x98a5e1;
                },
                'FKICy': function (_0x568f2e, _0x5a8736) {
                    return _0x568f2e < _0x5a8736;
                },
                'FRJiO': function (_0x54af7c, _0x293ae8, _0x42308c, _0x3da645) {
                    return _0x54af7c(_0x293ae8, _0x42308c, _0x3da645);
                },
                'IZTRr': function (_0x354b16, _0x136cf3) {
                    return _0x354b16 - _0x136cf3;
                },
                'EhNqb': function (_0x5d47cd, _0x2e349d) {
                    return _0x5d47cd < _0x2e349d;
                },
                'SBFRq': function (_0x3bbb41, _0x51d780) {
                    return _0x3bbb41 + _0x51d780;
                },
                'ABhGG': function (_0x15ed7b, _0x49ba8a) {
                    return _0x15ed7b + _0x49ba8a;
                }
            }, _0x7081cf = _0x3281ba['currentTick'], _0x40895c = _0x4c2055[_0x50e62f(0x2c0)]['x'] + ',' + _0x4c2055[_0x50e62f(0x2c0)]['y'] + ',' + _0x4c2055['location']['z'];
        _0x2005f4[_0x50e62f(0xa49)]['sound'] && _0x2005f4[_0x50e62f(0xa49)][_0x50e62f(0x758)][_0x50e62f(0x3e1)](_0x2e428c => {
            const _0x38bcc9 = _0x50e62f, _0x594ba5 = _0x40895c + _0x38bcc9(0xad1) + _0x2e428c['id'], _0x1f456e = this['lastEffectTick'][_0x38bcc9(0x3c7)](_0x594ba5) || 0x0;
            (_0x5a3552[_0x38bcc9(0x2d3)](_0x1f456e, 0x0) || _0x7081cf - _0x1f456e >= _0x5a3552[_0x38bcc9(0x89c)](_0x2e428c[_0x38bcc9(0x9b3)], 0x14)) && (_0x5a3552[_0x38bcc9(0x649)](Math[_0x38bcc9(0xaab)](), _0x2e428c['chance']) && ((!_0x2e428c[_0x38bcc9(0x645)] || _0x2e428c['conditions'](_0x4c2055)) && (_0x5a3552['FRJiO'](_0x25e63f, _0x4c2055['dimension'], _0x4c2055[_0x38bcc9(0x2c0)], {
                'id': _0x2e428c['id'],
                'pitch': 0x1,
                'volume': 0x1,
                'range': _0x2e428c[_0x38bcc9(0xa5d)]
            }), this[_0x38bcc9(0x5e3)][_0x38bcc9(0x54f)](_0x594ba5, _0x7081cf))));
        }), _0x2005f4['config'][_0x50e62f(0x8b5)] && _0x2005f4[_0x50e62f(0xa49)][_0x50e62f(0x8b5)][_0x50e62f(0x3e1)](_0x4c3c0b => {
            const _0x3c69c4 = _0x50e62f, _0x3d2192 = _0x40895c + ':particle:' + _0x4c3c0b['id'] + ':' + (_0x4c3c0b[_0x3c69c4(0x2c0)]?.['x'] ?? 0x0) + ':' + (_0x4c3c0b[_0x3c69c4(0x2c0)]?.['y'] ?? 0x0) + ':' + (_0x4c3c0b[_0x3c69c4(0x2c0)]?.['z'] ?? 0x0), _0x4a9660 = this[_0x3c69c4(0x5e3)][_0x3c69c4(0x3c7)](_0x3d2192) || 0x0;
            if (_0x4a9660 === 0x0 || _0x5a3552['IZTRr'](_0x7081cf, _0x4a9660) >= _0x4c3c0b['interval'] * 0x14) {
                if (_0x5a3552[_0x3c69c4(0x6ec)](Math[_0x3c69c4(0xaab)](), _0x4c3c0b['chance'])) {
                    if (!_0x4c3c0b[_0x3c69c4(0x645)] || _0x4c3c0b[_0x3c69c4(0x645)](_0x4c2055)) {
                        const _0x526c39 = _0x4c2055[_0x3c69c4(0x5fa)];
                        let _0x1ec978 = _0x4c2055[_0x3c69c4(0x5a0)]();
                        if (_0x4c3c0b[_0x3c69c4(0x2c0)]) {
                            const _0x54a277 = this[_0x3c69c4(0x675)](_0x4c3c0b[_0x3c69c4(0x2c0)], _0x526c39);
                            _0x1ec978 = {
                                'x': _0x5a3552['SBFRq'](_0x4c2055[_0x3c69c4(0x5a0)]()['x'], _0x54a277['x']),
                                'y': _0x5a3552['ABhGG'](_0x4c2055[_0x3c69c4(0x5a0)]()['y'], _0x54a277['y']),
                                'z': _0x4c2055[_0x3c69c4(0x5a0)]()['z'] + _0x54a277['z']
                            };
                        }
                        _0x4c2055['dimension'][_0x3c69c4(0xb85)](_0x4c3c0b['id'], _0x1ec978), this[_0x3c69c4(0x5e3)][_0x3c69c4(0x54f)](_0x3d2192, _0x7081cf);
                    }
                }
            }
        });
    }
    static [_0x21f734(0x675)](_0x464e4e, _0x1e1889) {
        const _0x2eb2ee = _0x21f734, _0xddf990 = {
                'gPPfe': 'direction',
                'qxGsk': _0x2eb2ee(0x571),
                'iLjnn': _0x2eb2ee(0x7bd),
                'qCzda': _0x2eb2ee(0x6a6),
                'rkLer': 'west'
            };
        if (!_0x1e1889 || !_0x1e1889[_0x2eb2ee(0x30a)])
            return _0x464e4e;
        try {
            const _0x19bc61 = _0x1e1889[_0x2eb2ee(0x30a)](_0x2eb2ee(0xba4)) || _0x1e1889[_0x2eb2ee(0x30a)](_0x2eb2ee(0xacd)) || _0x1e1889['getState'](_0xddf990['gPPfe']);
            if (!_0x19bc61)
                return _0x464e4e;
            switch (_0x19bc61) {
            case _0xddf990['qxGsk']:
                return _0x464e4e;
            case _0xddf990[_0x2eb2ee(0x580)]:
                return {
                    'x': -_0x464e4e['z'],
                    'y': _0x464e4e['y'],
                    'z': _0x464e4e['x']
                };
            case _0xddf990[_0x2eb2ee(0x78c)]:
                return {
                    'x': -_0x464e4e['x'],
                    'y': _0x464e4e['y'],
                    'z': -_0x464e4e['z']
                };
            case _0xddf990['rkLer']:
                return {
                    'x': _0x464e4e['z'],
                    'y': _0x464e4e['y'],
                    'z': -_0x464e4e['x']
                };
            default:
                return _0x464e4e;
            }
        } catch (_0x5a2a26) {
            return _0x464e4e;
        }
    }
    static [_0x21f734(0x9f6)](_0x1e1036, _0x1eb824) {
        const _0x10ab01 = _0x21f734;
        !this['timeoutIds'][_0x10ab01(0x1b2)](_0x1e1036) && this[_0x10ab01(0xb30)][_0x10ab01(0x54f)](_0x1e1036, []), this[_0x10ab01(0xb30)][_0x10ab01(0x3c7)](_0x1e1036)[_0x10ab01(0x28e)](_0x1eb824);
    }
    static [_0x21f734(0x632)](_0x11c858) {
        const _0x41af89 = _0x21f734, _0x4f331c = _0x11c858[_0x41af89(0x2c0)]['x'] + ',' + _0x11c858[_0x41af89(0x2c0)]['y'] + ',' + _0x11c858['location']['z'], _0x43b518 = this[_0x41af89(0xb30)][_0x41af89(0x3c7)](_0x4f331c);
        _0x43b518 && (_0x43b518[_0x41af89(0x3e1)](_0x29a14e => {
            _0x3281ba['clearRun'](_0x29a14e);
        }), this[_0x41af89(0xb30)][_0x41af89(0x305)](_0x4f331c));
    }
    static [_0x21f734(0x37e)](_0x4d0cb5) {
        const _0x20d873 = _0x21f734, _0x21d5b3 = {
                'ktNBR': function (_0x116657, _0x5ced00) {
                    return _0x116657 === _0x5ced00;
                }
            };
        try {
            const _0x598164 = _0x4d0cb5[_0x20d873(0xb28)][_0x20d873(0x3c0)](_0x4d0cb5[_0x20d873(0x2c0)]);
            return _0x21d5b3[_0x20d873(0x9e8)](_0x598164?.[_0x20d873(0x1b9)], _0x4d0cb5['typeId']);
        } catch (_0x5dae1d) {
            return ![];
        }
    }
};
_0x25e7d0(_0x35613d, _0x21f734(0x752), []), _0x25e7d0(_0x35613d, _0x21f734(0x5e3), new Map()), _0x25e7d0(_0x35613d, _0x21f734(0xb30), new Map());
var _0x330c84 = _0x35613d;
import {
    system as _0x1d4e6b,
    world as _0x4d6244
} from '@minecraft/server';
var _0x4537ac = class {
    static [_0x21f734(0x48b)]() {
        const _0x33e203 = _0x21f734;
        _0x4d6244[_0x33e203(0x959)][_0x33e203(0x398)]['subscribe'](_0x52d793 => {
            const _0x327b6 = _0x33e203;
            _0x52d793[_0x327b6(0x2ee)][_0x327b6(0x565)](_0x207994 + _0x327b6(0x257), {
                'beforeOnPlayerPlace': _0x43359 => this['handleBeforePlacement'](_0x43359),
                'onPlace': _0x23edae => this[_0x327b6(0x5ff)](_0x23edae),
                'onPlayerDestroy': _0x136720 => this[_0x327b6(0xbfe)](_0x136720)
            });
        }), _0x4d6244['afterEvents']['blockExplode'][_0x33e203(0x725)](_0x587c8e => {
            this['handleOnDestroy'](_0x587c8e);
        }), _0x4d6244['afterEvents'][_0x33e203(0x8ee)][_0x33e203(0x725)](_0x308194 => {
            const _0x52665e = _0x33e203;
            this[_0x52665e(0xbfe)](_0x308194);
        }), _0x4d6244[_0x33e203(0x327)]['playerPlaceBlock']['subscribe'](_0x293601 => {
            const _0x32d810 = _0x33e203;
            this[_0x32d810(0x5ff)](_0x293601);
        });
    }
    static [_0x21f734(0x3cf)](_0xd58936) {
        const _0x8d37c1 = _0x21f734, _0x57388f = {
                'wMXxH': 'nonsolid',
                'ptRAL': function (_0x487ce5, _0x46af4c) {
                    return _0x487ce5 !== _0x46af4c;
                },
                'dlRli': function (_0x116ef5, _0x45bee5) {
                    return _0x116ef5 + _0x45bee5;
                },
                'jqJTp': function (_0x3de725, _0x3c4af5) {
                    return _0x3de725 && _0x3c4af5;
                },
                'bJUaY': function (_0x15d224, _0x2f6576) {
                    return _0x15d224 === _0x2f6576;
                },
                'YkdiF': function (_0x42a8a5, _0x4b875d) {
                    return _0x42a8a5 >= _0x4b875d;
                }
            }, _0x1784e3 = _0xd58936[_0x8d37c1(0x87b)][_0x8d37c1(0x571)](), _0x366fb8 = _0xd58936[_0x8d37c1(0x87b)][_0x8d37c1(0x6a6)](), _0x3c659c = _0xd58936[_0x8d37c1(0x87b)][_0x8d37c1(0x7bd)](), _0x225826 = _0xd58936['block']['west'](), _0xaa1ad4 = _0xd58936[_0x8d37c1(0x87b)][_0x8d37c1(0x291)]();
        let _0x17cee7 = ![], _0xaa5e56 = ![], _0x52388c = ![], _0x4ac0c3 = ![], _0x4bd4b0 = ![];
        _0xaa1ad4 && _0xaa1ad4[_0x8d37c1(0x206)](this['tag']) && (_0x4bd4b0 = !![], _0xd58936[_0x8d37c1(0x2c1)][_0x8d37c1(0x30a)](_0x207994 + _0x8d37c1(0x930)) != void 0x0 && (_0xd58936[_0x8d37c1(0x2c1)] = _0xd58936[_0x8d37c1(0x2c1)]['withState'](_0x207994 + _0x8d37c1(0x930), !![])));
        _0x1784e3 && !this[_0x8d37c1(0x98c)][_0x8d37c1(0x620)](_0x1784e3[_0x8d37c1(0x1b9)]) && !_0x1784e3?.[_0x8d37c1(0x206)](_0x57388f[_0x8d37c1(0x6e7)]) && (_0x17cee7 = !![], _0xd58936[_0x8d37c1(0x2c1)] = _0xd58936[_0x8d37c1(0x2c1)][_0x8d37c1(0x9d1)](_0x207994 + ':connect_north', !![]));
        _0x366fb8 && !this[_0x8d37c1(0x98c)][_0x8d37c1(0x620)](_0x366fb8[_0x8d37c1(0x1b9)]) && !_0x366fb8?.['hasTag'](_0x57388f[_0x8d37c1(0x6e7)]) && (_0xaa5e56 = !![], _0xd58936[_0x8d37c1(0x2c1)] = _0xd58936[_0x8d37c1(0x2c1)][_0x8d37c1(0x9d1)](_0x207994 + _0x8d37c1(0x236), !![]));
        _0x3c659c && !this[_0x8d37c1(0x98c)][_0x8d37c1(0x620)](_0x3c659c[_0x8d37c1(0x1b9)]) && !_0x3c659c?.['hasTag'](_0x57388f['wMXxH']) && (_0x52388c = !![], _0xd58936[_0x8d37c1(0x2c1)] = _0xd58936[_0x8d37c1(0x2c1)]['withState'](_0x207994 + _0x8d37c1(0x1ac), !![]));
        _0x225826 && !this[_0x8d37c1(0x98c)]['includes'](_0x225826[_0x8d37c1(0x1b9)]) && !_0x225826?.[_0x8d37c1(0x206)](_0x57388f[_0x8d37c1(0x6e7)]) && (_0x4ac0c3 = !![], _0xd58936['permutationToPlace'] = _0xd58936[_0x8d37c1(0x2c1)][_0x8d37c1(0x9d1)](_0x207994 + _0x8d37c1(0xa41), !![]));
        if (_0x57388f[_0x8d37c1(0x35c)](_0xd58936[_0x8d37c1(0x2c1)][_0x8d37c1(0x30a)](_0x207994 + _0x8d37c1(0x678)), void 0x0)) {
            const _0x2674a2 = _0x57388f[_0x8d37c1(0x4c5)](_0x57388f[_0x8d37c1(0x4c5)](_0x17cee7 ? 0x1 : 0x0, _0xaa5e56 ? 0x1 : 0x0), _0x52388c ? 0x1 : 0x0) + (_0x4ac0c3 ? 0x1 : 0x0), _0x43f384 = _0x57388f[_0x8d37c1(0x82b)](_0x17cee7, _0xaa5e56) && !_0x52388c && !_0x4ac0c3 || _0x57388f[_0x8d37c1(0x82b)](!_0x17cee7, !_0xaa5e56) && _0x52388c && _0x4ac0c3;
            let _0x2f950d = ![];
            try {
                _0xaa1ad4 && _0xaa1ad4[_0x8d37c1(0x206)](this['tag']) && (_0x2f950d = _0xaa1ad4['permutation'][_0x8d37c1(0x30a)](_0x207994 + _0x8d37c1(0x678)) === !![]);
            } catch (_0x5cd4e6) {
            }
            const _0x2d5031 = _0x2f950d || _0x57388f[_0x8d37c1(0x8aa)](_0x2674a2, 0x0) || _0x57388f[_0x8d37c1(0x8aa)](_0x2674a2, 0x1) || _0x57388f['YkdiF'](_0x2674a2, 0x3) || _0x57388f[_0x8d37c1(0x8aa)](_0x2674a2, 0x2) && !_0x43f384;
            _0xd58936[_0x8d37c1(0x2c1)] = _0xd58936[_0x8d37c1(0x2c1)]['withState'](_0x207994 + _0x8d37c1(0x678), _0x2d5031);
        }
    }
    static [_0x21f734(0x5ff)](_0x110050) {
        const _0x2756ea = _0x21f734, _0x35cc0e = {
                'ygxqP': _0x2756ea(0xc1f),
                'MnKFW': function (_0x2864ed, _0x11c53a) {
                    return _0x2864ed === _0x11c53a;
                },
                'TUknb': function (_0x489172, _0x5dab49) {
                    return _0x489172 === _0x5dab49;
                },
                'JcNcr': function (_0x576ee4, _0x16f4e7) {
                    return _0x576ee4 + _0x16f4e7;
                },
                'dKVat': function (_0x2a119b, _0x38aa21) {
                    return _0x2a119b && _0x38aa21;
                },
                'WLImI': function (_0xb4e8c7, _0x5e9cfa) {
                    return _0xb4e8c7 && _0x5e9cfa;
                },
                'CVGoa': function (_0x5a33b8, _0x1ab5dd) {
                    return _0x5a33b8 !== _0x1ab5dd;
                }
            }, _0x42e5d8 = _0x110050[_0x2756ea(0x87b)];
        if (_0x42e5d8[_0x2756ea(0x206)](_0x35cc0e['ygxqP']))
            return;
        if (this[_0x2756ea(0x98c)][_0x2756ea(0x620)](_0x42e5d8['typeId']))
            return;
        try {
            const _0x4f4694 = _0x42e5d8[_0x2756ea(0x571)](), _0x31798c = _0x42e5d8['south'](), _0x169121 = _0x42e5d8['east'](), _0x121e29 = _0x42e5d8[_0x2756ea(0x709)](), _0x369637 = _0x42e5d8[_0x2756ea(0xbd3)](), _0x385c1c = _0x42e5d8['above']();
            let _0x3b82e5 = ![];
            const _0x37c42e = _0x35cc0e['MnKFW'](_0x42e5d8[_0x2756ea(0x5fa)]['getState'](_0x207994 + _0x2756ea(0x446)), !![]), _0x1503b2 = _0x42e5d8[_0x2756ea(0x5fa)][_0x2756ea(0x30a)](_0x207994 + ':connect_south') === !![], _0x30b7a9 = _0x35cc0e['MnKFW'](_0x42e5d8[_0x2756ea(0x5fa)]['getState'](_0x207994 + _0x2756ea(0x1ac)), !![]), _0x4ca937 = _0x35cc0e[_0x2756ea(0xbd1)](_0x42e5d8[_0x2756ea(0x5fa)][_0x2756ea(0x30a)](_0x207994 + _0x2756ea(0xa41)), !![]), _0x406600 = _0x35cc0e[_0x2756ea(0x76f)](_0x42e5d8[_0x2756ea(0x5fa)][_0x2756ea(0x30a)](_0x207994 + _0x2756ea(0x678)), !![]), _0xbd0b48 = _0x35cc0e[_0x2756ea(0x89f)]((_0x37c42e ? 0x1 : 0x0) + (_0x1503b2 ? 0x1 : 0x0), _0x30b7a9 ? 0x1 : 0x0) + (_0x4ca937 ? 0x1 : 0x0);
            _0x3b82e5 = _0x35cc0e['dKVat'](_0x37c42e, _0x1503b2) && !_0x30b7a9 && !_0x4ca937 || _0x35cc0e['WLImI'](!_0x37c42e, !_0x1503b2) && _0x30b7a9 && _0x4ca937;
            const _0x1a4408 = !(_0xbd0b48 === 0x2 && _0x3b82e5 && !_0x406600);
            _0x369637 && _0x369637['hasTag'](this['tag']) && (_0x369637[_0x2756ea(0x5fa)][_0x2756ea(0x30a)](_0x207994 + _0x2756ea(0x930)) != void 0x0 && _0x369637[_0x2756ea(0x772)](_0x369637[_0x2756ea(0x5fa)][_0x2756ea(0x9d1)](_0x207994 + _0x2756ea(0x930), !![])), _0x1a4408 && this[_0x2756ea(0x26a)](_0x369637, _0x406600));
            if (_0x385c1c) {
                if (_0x35cc0e['CVGoa'](_0x42e5d8[_0x2756ea(0x5fa)][_0x2756ea(0x30a)](_0x207994 + _0x2756ea(0x930)), void 0x0)) {
                    const _0x122251 = _0x385c1c[_0x2756ea(0x206)](this[_0x2756ea(0x82d)]);
                    _0x42e5d8[_0x2756ea(0x772)](_0x42e5d8[_0x2756ea(0x5fa)][_0x2756ea(0x9d1)](_0x207994 + ':connect_up', _0x122251));
                }
            }
            _0x385c1c && _0x385c1c[_0x2756ea(0x206)](this['tag']) && this['updateUpwardConnection'](_0x42e5d8), _0x4f4694 && _0x4f4694[_0x2756ea(0x206)](this['tag']) && (_0x4f4694['setPermutation'](_0x4f4694[_0x2756ea(0x5fa)][_0x2756ea(0x9d1)](_0x207994 + ':connect_south', !![])), this[_0x2756ea(0xb17)](_0x4f4694)), _0x31798c && _0x31798c[_0x2756ea(0x206)](this['tag']) && (_0x31798c[_0x2756ea(0x772)](_0x31798c[_0x2756ea(0x5fa)]['withState'](_0x207994 + _0x2756ea(0x446), !![])), this[_0x2756ea(0xb17)](_0x31798c)), _0x169121 && _0x169121[_0x2756ea(0x206)](this['tag']) && (_0x169121[_0x2756ea(0x772)](_0x169121[_0x2756ea(0x5fa)][_0x2756ea(0x9d1)](_0x207994 + ':connect_west', !![])), this['updatePoleVisibility'](_0x169121)), _0x121e29 && _0x121e29[_0x2756ea(0x206)](this[_0x2756ea(0x82d)]) && (_0x121e29[_0x2756ea(0x772)](_0x121e29[_0x2756ea(0x5fa)][_0x2756ea(0x9d1)](_0x207994 + _0x2756ea(0x1ac), !![])), this['updatePoleVisibility'](_0x121e29));
        } catch (_0xd57f02) {
        }
    }
    static [_0x21f734(0xbfe)](_0x53e6fe) {
        const _0x4b0624 = _0x21f734, _0x3f31d5 = {
                'uSYIZ': _0x4b0624(0x8b6),
                'URJgJ': function (_0x3c4552, _0x3c922a) {
                    return _0x3c4552 !== _0x3c922a;
                }
            }, _0x2fb4eb = _0x53e6fe['block'];
        try {
            const _0x4fb665 = _0x2fb4eb[_0x4b0624(0x571)](), _0x574dff = _0x2fb4eb[_0x4b0624(0x6a6)](), _0x2ca868 = _0x2fb4eb[_0x4b0624(0x7bd)](), _0x1fe297 = _0x2fb4eb['west'](), _0xe78846 = _0x2fb4eb[_0x4b0624(0xbd3)](), _0x346c9c = _0x2fb4eb[_0x4b0624(0x291)]();
            _0xe78846 && _0xe78846[_0x4b0624(0x206)](this['tag']) && (_0x3f31d5[_0x4b0624(0x680)](_0xe78846[_0x4b0624(0x5fa)]['getState'](_0x207994 + _0x4b0624(0x930)), void 0x0) && _0xe78846[_0x4b0624(0x772)](_0xe78846[_0x4b0624(0x5fa)][_0x4b0624(0x9d1)](_0x207994 + _0x4b0624(0x930), ![])), this[_0x4b0624(0xb17)](_0xe78846)), _0x4fb665 && _0x4fb665[_0x4b0624(0x206)](this[_0x4b0624(0x82d)]) && (_0x4fb665['setPermutation'](_0x4fb665['permutation'][_0x4b0624(0x9d1)](_0x207994 + ':connect_south', ![])), this[_0x4b0624(0xb17)](_0x4fb665)), _0x574dff && _0x574dff['hasTag'](this[_0x4b0624(0x82d)]) && (_0x574dff['setPermutation'](_0x574dff[_0x4b0624(0x5fa)][_0x4b0624(0x9d1)](_0x207994 + ':connect_north', ![])), this[_0x4b0624(0xb17)](_0x574dff)), _0x2ca868 && _0x2ca868[_0x4b0624(0x206)](this[_0x4b0624(0x82d)]) && (_0x2ca868['setPermutation'](_0x2ca868[_0x4b0624(0x5fa)][_0x4b0624(0x9d1)](_0x207994 + ':connect_west', ![])), this[_0x4b0624(0xb17)](_0x2ca868)), _0x1fe297 && _0x1fe297[_0x4b0624(0x206)](this[_0x4b0624(0x82d)]) && (_0x1fe297[_0x4b0624(0x772)](_0x1fe297[_0x4b0624(0x5fa)]['withState'](_0x207994 + _0x4b0624(0x1ac), ![])), this[_0x4b0624(0xb17)](_0x1fe297)), _0x346c9c && _0x346c9c[_0x4b0624(0x206)](this[_0x4b0624(0x82d)]) && this[_0x4b0624(0xb67)](null, _0x346c9c), _0xe78846 && _0xe78846[_0x4b0624(0x206)](this[_0x4b0624(0x82d)]) && this[_0x4b0624(0xb17)](_0xe78846), _0x1d4e6b[_0x4b0624(0x873)](() => {
                const _0x3eafb5 = _0x4b0624;
                try {
                    _0x2fb4eb && _0x2fb4eb[_0x3eafb5(0xb28)] && this[_0x3eafb5(0x214)](_0x2fb4eb[_0x3eafb5(0x2c0)], _0x2fb4eb[_0x3eafb5(0xb28)]);
                } catch (_0x467cf6) {
                    console[_0x3eafb5(0x73d)](_0x3f31d5[_0x3eafb5(0xa87)], _0x467cf6);
                }
            }, 0x1);
        } catch (_0x3b4ce5) {
            console['warn']('Error\x20in\x20handleOnDestroy:\x20' + _0x3b4ce5);
        }
    }
    static ['updateNeighborConnections'](_0x2e3a49, _0x4238d2) {
        const _0x2830f1 = _0x21f734, _0x22a882 = {
                'WhnEK': function (_0x12a010, _0x4bb10a) {
                    return _0x12a010 + _0x4bb10a;
                },
                'DnqIz': function (_0x4f1678, _0x492795) {
                    return _0x4f1678 + _0x492795;
                }
            };
        try {
            const _0x3c08fa = [
                {
                    'x': 0x0,
                    'y': 0x1,
                    'z': 0x0
                },
                {
                    'x': 0x0,
                    'y': -0x1,
                    'z': 0x0
                },
                {
                    'x': 0x1,
                    'y': 0x0,
                    'z': 0x0
                },
                {
                    'x': -0x1,
                    'y': 0x0,
                    'z': 0x0
                },
                {
                    'x': 0x0,
                    'y': 0x0,
                    'z': 0x1
                },
                {
                    'x': 0x0,
                    'y': 0x0,
                    'z': -0x1
                }
            ];
            for (const _0x2971c9 of _0x3c08fa) {
                const _0x6377d6 = {
                        'x': _0x22a882['WhnEK'](_0x2e3a49['x'], _0x2971c9['x']),
                        'y': _0x2e3a49['y'] + _0x2971c9['y'],
                        'z': _0x22a882[_0x2830f1(0x512)](_0x2e3a49['z'], _0x2971c9['z'])
                    }, _0x56d9d8 = _0x4238d2[_0x2830f1(0x3c0)](_0x6377d6);
                _0x56d9d8 && _0x56d9d8[_0x2830f1(0x206)](this[_0x2830f1(0x82d)]) && this[_0x2830f1(0x4d5)](_0x56d9d8);
            }
        } catch (_0x3e0f79) {
            console[_0x2830f1(0x73d)]('Error\x20updating\x20neighbor\x20connections:\x20' + _0x3e0f79);
        }
    }
    static [_0x21f734(0x4d5)](_0x5dc965) {
        const _0x502a27 = _0x21f734, _0x44914f = {
                'jaeiX': function (_0x359289, _0x5d9903) {
                    return _0x359289 !== _0x5d9903;
                },
                'IZKnU': _0x502a27(0xc1f),
                'MveTe': function (_0x348338, _0xab46c8) {
                    return _0x348338 !== _0xab46c8;
                }
            };
        try {
            if (!_0x5dc965 || !_0x5dc965['hasTag'](this[_0x502a27(0x82d)]))
                return;
            const _0x517550 = _0x5dc965[_0x502a27(0x571)](), _0x37debe = _0x5dc965['south'](), _0x3fb7ab = _0x5dc965[_0x502a27(0x7bd)](), _0x2244ed = _0x5dc965[_0x502a27(0x709)](), _0x4583dc = _0x5dc965[_0x502a27(0x291)](), _0x32735f = _0x5dc965['below']();
            let _0x190634 = _0x5dc965[_0x502a27(0x5fa)];
            if (_0x44914f['jaeiX'](_0x190634[_0x502a27(0x30a)](_0x207994 + _0x502a27(0x446)), void 0x0)) {
                const _0x45867a = !!(_0x517550 && !this[_0x502a27(0x98c)]['includes'](_0x517550['typeId']) && !_0x517550[_0x502a27(0x206)](_0x502a27(0xc1f)));
                _0x190634 = _0x190634['withState'](_0x207994 + _0x502a27(0x446), _0x45867a);
            }
            if (_0x190634[_0x502a27(0x30a)](_0x207994 + ':connect_south') !== void 0x0) {
                const _0xae9c69 = !!(_0x37debe && !this[_0x502a27(0x98c)]['includes'](_0x37debe[_0x502a27(0x1b9)]) && !_0x37debe['hasTag'](_0x44914f['IZKnU']));
                _0x190634 = _0x190634[_0x502a27(0x9d1)](_0x207994 + _0x502a27(0x236), _0xae9c69);
            }
            if (_0x190634['getState'](_0x207994 + _0x502a27(0x1ac)) !== void 0x0) {
                const _0x296853 = !!(_0x3fb7ab && !this[_0x502a27(0x98c)][_0x502a27(0x620)](_0x3fb7ab[_0x502a27(0x1b9)]) && !_0x3fb7ab['hasTag'](_0x44914f[_0x502a27(0x59b)]));
                _0x190634 = _0x190634[_0x502a27(0x9d1)](_0x207994 + _0x502a27(0x1ac), _0x296853);
            }
            if (_0x44914f[_0x502a27(0x24b)](_0x190634[_0x502a27(0x30a)](_0x207994 + _0x502a27(0xa41)), void 0x0)) {
                const _0x4b4bd7 = !!(_0x2244ed && !this[_0x502a27(0x98c)][_0x502a27(0x620)](_0x2244ed[_0x502a27(0x1b9)]) && !_0x2244ed[_0x502a27(0x206)](_0x44914f[_0x502a27(0x59b)]));
                _0x190634 = _0x190634[_0x502a27(0x9d1)](_0x207994 + _0x502a27(0xa41), _0x4b4bd7);
            }
            if (_0x44914f[_0x502a27(0x24b)](_0x190634['getState'](_0x207994 + _0x502a27(0x930)), void 0x0)) {
                const _0x536ffc = !!(_0x4583dc && _0x4583dc[_0x502a27(0x206)](this[_0x502a27(0x82d)]));
                _0x190634 = _0x190634['withState'](_0x207994 + _0x502a27(0x930), _0x536ffc);
            }
            _0x5dc965[_0x502a27(0x772)](_0x190634), this[_0x502a27(0xb17)](_0x5dc965);
        } catch (_0x1b80a3) {
            console['warn'](_0x502a27(0xa9f) + _0x1b80a3);
        }
    }
    static [_0x21f734(0xb67)](_0x446a9d, _0x4123ce) {
        const _0x4ae2c4 = _0x21f734, _0x122125 = {
                'OsKDZ': function (_0x2b6ba7, _0x27a8b8) {
                    return _0x2b6ba7 === _0x27a8b8;
                },
                'CXcPh': function (_0x1ac0b8, _0x5c75eb) {
                    return _0x1ac0b8 !== _0x5c75eb;
                }
            };
        try {
            const _0x4a7798 = _0x4123ce || (_0x446a9d ? _0x446a9d[_0x4ae2c4(0x291)]() : null);
            if (!_0x4a7798 || !_0x4a7798[_0x4ae2c4(0x206)](this[_0x4ae2c4(0x82d)]))
                return;
            if (_0x122125[_0x4ae2c4(0x2ae)](_0x4a7798['permutation'][_0x4ae2c4(0x30a)](_0x207994 + _0x4ae2c4(0x930)), void 0x0))
                return;
            let _0x356140 = ![];
            const _0x415bcd = _0x4a7798[_0x4ae2c4(0x291)]();
            _0x415bcd && (_0x356140 = _0x415bcd[_0x4ae2c4(0x206)](this[_0x4ae2c4(0x82d)]));
            const _0x30dce3 = _0x122125[_0x4ae2c4(0x2ae)](_0x4a7798[_0x4ae2c4(0x5fa)][_0x4ae2c4(0x30a)](_0x207994 + _0x4ae2c4(0x930)), !![]);
            _0x122125[_0x4ae2c4(0x619)](_0x30dce3, _0x356140) && _0x4a7798[_0x4ae2c4(0x772)](_0x4a7798[_0x4ae2c4(0x5fa)]['withState'](_0x207994 + _0x4ae2c4(0x930), _0x356140));
        } catch (_0x3018b2) {
            console[_0x4ae2c4(0x73d)](_0x4ae2c4(0x442) + _0x3018b2);
        }
    }
    static ['hasPoleAbove'](_0x306051) {
        const _0x19279c = _0x21f734, _0x5d5881 = {
                'NYjiZ': function (_0x4a526d, _0x492f82) {
                    return _0x4a526d === _0x492f82;
                }
            };
        try {
            const _0x39cbcd = _0x306051['above']();
            if (!_0x39cbcd || !_0x39cbcd[_0x19279c(0x206)](this[_0x19279c(0x82d)]))
                return ![];
            return _0x5d5881['NYjiZ'](_0x39cbcd['permutation'][_0x19279c(0x30a)](_0x207994 + ':pole'), !![]);
        } catch (_0xb588fa) {
            return ![];
        }
    }
    static [_0x21f734(0xb17)](_0x1f878c) {
        const _0x252767 = _0x21f734, _0x29502a = {
                'IskQu': function (_0x509c59, _0x5afc46) {
                    return _0x509c59 === _0x5afc46;
                },
                'ggmxB': function (_0x5a9fd0, _0x34866e) {
                    return _0x5a9fd0 === _0x34866e;
                },
                'JZLDy': function (_0xe98525, _0x360c40) {
                    return _0xe98525 === _0x360c40;
                },
                'EiBHv': function (_0x4d645c, _0x5a137a) {
                    return _0x4d645c === _0x5a137a;
                },
                'aqxzc': function (_0x30e85a, _0x4ccb64) {
                    return _0x30e85a === _0x4ccb64;
                },
                'Eqqet': function (_0x42aca0, _0x534c4e) {
                    return _0x42aca0 + _0x534c4e;
                },
                'gsThx': function (_0x39ec91, _0x19a597) {
                    return _0x39ec91 + _0x19a597;
                },
                'ykVlT': function (_0x29496b, _0x44a650) {
                    return _0x29496b && _0x44a650;
                },
                'Enlgh': function (_0x4e2941, _0x33b4b0) {
                    return _0x4e2941 && _0x33b4b0;
                },
                'yoeVG': function (_0x43a246, _0x455935) {
                    return _0x43a246 === _0x455935;
                },
                'synYC': function (_0x272dbf, _0x518d3d) {
                    return _0x272dbf === _0x518d3d;
                },
                'KJAvA': function (_0x27eb6c, _0x4153a7) {
                    return _0x27eb6c !== _0x4153a7;
                }
            };
        try {
            if (!_0x1f878c || !_0x1f878c['hasTag'](this[_0x252767(0x82d)]))
                return;
            if (_0x29502a[_0x252767(0x5e7)](_0x1f878c[_0x252767(0x5fa)][_0x252767(0x30a)](_0x207994 + _0x252767(0x678)), void 0x0))
                return;
            const _0x4634f9 = _0x29502a['ggmxB'](_0x1f878c[_0x252767(0x5fa)][_0x252767(0x30a)](_0x207994 + _0x252767(0x446)), !![]), _0x1dd661 = _0x29502a[_0x252767(0x943)](_0x1f878c[_0x252767(0x5fa)][_0x252767(0x30a)](_0x207994 + _0x252767(0x236)), !![]), _0xd20844 = _0x29502a['EiBHv'](_0x1f878c[_0x252767(0x5fa)][_0x252767(0x30a)](_0x207994 + _0x252767(0x1ac)), !![]), _0x3e43da = _0x29502a[_0x252767(0x9f8)](_0x1f878c['permutation'][_0x252767(0x30a)](_0x207994 + _0x252767(0xa41)), !![]), _0x3ecac1 = this[_0x252767(0x768)](_0x1f878c), _0x6d485d = _0x29502a[_0x252767(0x7e1)](_0x29502a['gsThx'](_0x4634f9 ? 0x1 : 0x0, _0x1dd661 ? 0x1 : 0x0) + (_0xd20844 ? 0x1 : 0x0), _0x3e43da ? 0x1 : 0x0), _0x18dc7c = _0x29502a[_0x252767(0xa2f)](_0x4634f9, _0x1dd661) && !_0xd20844 && !_0x3e43da || _0x29502a['Enlgh'](!_0x4634f9, !_0x1dd661) && _0xd20844 && _0x3e43da, _0x2cc611 = _0x3ecac1 || _0x29502a[_0x252767(0x292)](_0x6d485d, 0x0) || _0x29502a[_0x252767(0x292)](_0x6d485d, 0x1) || _0x29502a[_0x252767(0x476)](_0x6d485d, 0x2) && !_0x18dc7c || _0x6d485d >= 0x3, _0xd3fd61 = _0x1f878c['permutation'], _0x376684 = _0x29502a['synYC'](_0xd3fd61['getState'](_0x207994 + _0x252767(0x678)), !![]);
            _0x29502a[_0x252767(0x60c)](_0x376684, _0x2cc611) && _0x1f878c[_0x252767(0x772)](_0xd3fd61['withState'](_0x207994 + _0x252767(0x678), _0x2cc611)), this[_0x252767(0x1bc)](_0x1f878c, _0x2cc611);
        } catch (_0xf7a9cc) {
            console[_0x252767(0x73d)](_0x252767(0x6aa) + _0xf7a9cc);
        }
    }
    static ['updatePoleStateDownwards'](_0x5a8a37, _0x5aca67, _0x452963 = 0x0) {
        const _0x43e871 = _0x21f734, _0x4dc068 = {
                'TskLE': function (_0x535712, _0x5f3597) {
                    return _0x535712 === _0x5f3597;
                },
                'xQjlf': function (_0x1fa275, _0x4a45a0) {
                    return _0x1fa275 === _0x4a45a0;
                },
                'gtoGG': function (_0x1ec9cb, _0x529834) {
                    return _0x1ec9cb !== _0x529834;
                }
            };
        try {
            if (_0x452963 === 0x0)
                this[_0x43e871(0x26a)](_0x5a8a37, _0x5aca67);
            else {
                const _0x4ec3c1 = _0x5a8a37[_0x43e871(0xbd3)]();
                if (!_0x4ec3c1 || !_0x4ec3c1[_0x43e871(0x206)](this[_0x43e871(0x82d)]))
                    return;
                if (_0x4dc068[_0x43e871(0x2ba)](_0x4ec3c1[_0x43e871(0x5fa)][_0x43e871(0x30a)](_0x207994 + _0x43e871(0x678)), void 0x0))
                    return;
                if (_0x5aca67) {
                    const _0x43cd18 = _0x4dc068[_0x43e871(0x875)](_0x4ec3c1[_0x43e871(0x5fa)][_0x43e871(0x30a)](_0x207994 + _0x43e871(0x678)), !![]);
                    _0x4dc068['gtoGG'](_0x43cd18, !![]) && _0x4ec3c1[_0x43e871(0x772)](_0x4ec3c1[_0x43e871(0x5fa)][_0x43e871(0x9d1)](_0x207994 + _0x43e871(0x678), !![]));
                }
            }
        } catch (_0x3b5109) {
            console[_0x43e871(0x73d)](_0x43e871(0x432) + _0x3b5109);
        }
    }
    static [_0x21f734(0x26a)](_0x130f71, _0x485d5f) {
        const _0x180f7f = _0x21f734, _0x56e57f = {
                'fUIBr': function (_0x3230b1, _0x509b49) {
                    return _0x3230b1 === _0x509b49;
                },
                'dNaOh': function (_0x4b7c95, _0x2cbed6) {
                    return _0x4b7c95 === _0x2cbed6;
                },
                'LDYzY': function (_0x58fa92, _0x47e85e) {
                    return _0x58fa92 === _0x47e85e;
                },
                'mfgyr': function (_0x4eb432, _0x581fb7) {
                    return _0x4eb432 === _0x581fb7;
                },
                'TPVfg': function (_0x1b8445, _0x16d28f) {
                    return _0x1b8445 + _0x16d28f;
                },
                'HFwwG': function (_0x79ef52, _0x41a766) {
                    return _0x79ef52 && _0x41a766;
                },
                'lnxUH': function (_0x123c90, _0x59c1da) {
                    return _0x123c90 === _0x59c1da;
                },
                'JZFRg': function (_0xfef372, _0xe9322b) {
                    return _0xfef372 >= _0xe9322b;
                },
                'LnSDU': function (_0x35d03c, _0x5a12c2) {
                    return _0x35d03c === _0x5a12c2;
                },
                'DzMAq': function (_0x268218, _0x1b766a) {
                    return _0x268218 < _0x1b766a;
                },
                'hGjvi': function (_0x7b9c5f, _0x4435ac) {
                    return _0x7b9c5f - _0x4435ac;
                },
                'oqfOu': function (_0xd1ab32) {
                    return _0xd1ab32();
                }
            }, _0x25db79 = 0x64, _0x367572 = _0x130f71['dimension'], _0x5cede3 = {
                'x': _0x130f71[_0x180f7f(0x2c0)]['x'],
                'y': _0x130f71['location']['y'],
                'z': _0x130f71[_0x180f7f(0x2c0)]['z']
            }, _0x41c09b = [{
                    ..._0x5cede3,
                    'hasPole': _0x485d5f,
                    'depth': 0x0
                }], _0x34fa93 = () => {
                const _0x2fb883 = _0x180f7f;
                if (_0x56e57f[_0x2fb883(0x86e)](_0x41c09b[_0x2fb883(0x51f)], 0x0))
                    return;
                const _0xab9c63 = Math[_0x2fb883(0x789)](0x5, _0x41c09b[_0x2fb883(0x51f)]), _0x59e837 = _0x41c09b[_0x2fb883(0xa43)](0x0, _0xab9c63);
                for (const _0x5d483c of _0x59e837) {
                    try {
                        const {
                                x: _0x1b285a,
                                y: _0x12b569,
                                z: _0x32ec58,
                                hasPole: _0x41be83,
                                depth: _0x269873
                            } = _0x5d483c, _0x503151 = _0x367572[_0x2fb883(0x3c0)]({
                                'x': _0x1b285a,
                                'y': _0x12b569,
                                'z': _0x32ec58
                            });
                        if (!_0x503151)
                            continue;
                        if (!_0x503151[_0x2fb883(0x206)](this['tag']))
                            continue;
                        if (_0x56e57f[_0x2fb883(0x564)](_0x503151[_0x2fb883(0x5fa)][_0x2fb883(0x30a)](_0x207994 + _0x2fb883(0x678)), void 0x0))
                            continue;
                        let _0x211d16;
                        if (_0x41be83)
                            _0x211d16 = !![];
                        else {
                            const _0x2c78c1 = _0x56e57f[_0x2fb883(0x564)](_0x503151[_0x2fb883(0x5fa)]['getState'](_0x207994 + _0x2fb883(0x446)), !![]), _0x33fe99 = _0x503151[_0x2fb883(0x5fa)][_0x2fb883(0x30a)](_0x207994 + _0x2fb883(0x236)) === !![], _0x558356 = _0x56e57f['LDYzY'](_0x503151[_0x2fb883(0x5fa)]['getState'](_0x207994 + _0x2fb883(0x1ac)), !![]), _0x96fb9a = _0x56e57f['mfgyr'](_0x503151[_0x2fb883(0x5fa)][_0x2fb883(0x30a)](_0x207994 + _0x2fb883(0xa41)), !![]), _0x2ed860 = _0x56e57f['TPVfg'](_0x2c78c1 ? 0x1 : 0x0, _0x33fe99 ? 0x1 : 0x0) + (_0x558356 ? 0x1 : 0x0) + (_0x96fb9a ? 0x1 : 0x0), _0x52270c = _0x2c78c1 && _0x33fe99 && !_0x558356 && !_0x96fb9a || _0x56e57f['HFwwG'](!_0x2c78c1, !_0x33fe99) && _0x558356 && _0x96fb9a;
                            _0x211d16 = _0x56e57f[_0x2fb883(0x23d)](_0x2ed860, 0x0) || _0x2ed860 === 0x1 || _0x56e57f['fUIBr'](_0x2ed860, 0x2) && !_0x52270c || _0x56e57f[_0x2fb883(0x3aa)](_0x2ed860, 0x3);
                        }
                        this[_0x2fb883(0xb67)](_0x503151);
                        const _0x487b0e = _0x56e57f[_0x2fb883(0x92c)](_0x503151[_0x2fb883(0x5fa)][_0x2fb883(0x30a)](_0x207994 + _0x2fb883(0x678)), !![]);
                        _0x487b0e !== _0x211d16 && _0x503151['setPermutation'](_0x503151[_0x2fb883(0x5fa)][_0x2fb883(0x9d1)](_0x207994 + ':pole', _0x211d16)), _0x56e57f['DzMAq'](_0x269873, _0x25db79) && _0x41c09b[_0x2fb883(0x28e)]({
                            'x': _0x1b285a,
                            'y': _0x56e57f[_0x2fb883(0x8fd)](_0x12b569, 0x1),
                            'z': _0x32ec58,
                            'hasPole': _0x211d16,
                            'depth': _0x56e57f['TPVfg'](_0x269873, 0x1)
                        });
                    } catch (_0x4429e9) {
                        console[_0x2fb883(0x73d)](_0x2fb883(0x4a5) + _0x4429e9);
                    }
                }
                _0x41c09b['length'] > 0x0 && _0x1d4e6b['runTimeout'](_0x34fa93, 0x1);
            };
        _0x56e57f['oqfOu'](_0x34fa93);
    }
};
_0x25e7d0(_0x4537ac, _0x21f734(0x82d), _0x207994 + ':wall_connect'), _0x25e7d0(_0x4537ac, 'nonSolidBlocks', _0x5d2db2);
import { world as _0x4b3cfe } from '@minecraft/server';
var _0x391b73 = class _0x3ef1ea {
    constructor(_0x42fd11) {
        const _0x2ed861 = _0x21f734;
        this[_0x2ed861(0xa49)] = _0x42fd11;
    }
    static ['registerBehavior'](_0x6b8ddb) {
        const _0x4f9431 = _0x21f734, _0x391d03 = new _0x3ef1ea(_0x6b8ddb);
        this[_0x4f9431(0x752)]['push'](_0x391d03);
    }
    static [_0x21f734(0x3c0)](_0x4be839) {
        const _0x5cd8d7 = _0x21f734;
        return this[_0x5cd8d7(0x752)]['find'](_0xb028bd => _0xb028bd['config']['id'] === _0x4be839);
    }
    static ['initialize']() {
        const _0x833127 = _0x21f734;
        _0x4b3cfe[_0x833127(0x327)][_0x833127(0x8ee)]['subscribe'](_0x55ff0a => {
            const _0xd2a240 = _0x833127, _0x3b237c = _0x3ef1ea[_0xd2a240(0x3c0)](_0x55ff0a['brokenBlockPermutation']['type']['id']);
            if (!_0x3b237c)
                return;
            _0x3b237c[_0xd2a240(0xa49)]['onDestroy'] && _0x3b237c[_0xd2a240(0xa49)]['onDestroy'](_0x55ff0a);
        }), _0x4b3cfe[_0x833127(0x327)][_0x833127(0xa3b)][_0x833127(0x725)](_0x543c5a => {
            const _0x293746 = _0x833127, _0x300fab = _0x3ef1ea[_0x293746(0x3c0)](_0x543c5a[_0x293746(0x87b)][_0x293746(0xc08)]['id']);
            if (!_0x300fab)
                return;
            _0x300fab[_0x293746(0xa49)][_0x293746(0x378)] && _0x300fab[_0x293746(0xa49)][_0x293746(0x378)](_0x543c5a);
        }), _0x4b3cfe[_0x833127(0x327)][_0x833127(0xb88)][_0x833127(0x725)](_0x838a2c => {
            const _0x44a9b4 = _0x833127, _0x377204 = _0x3ef1ea[_0x44a9b4(0x3c0)](_0x838a2c[_0x44a9b4(0x70f)][_0x44a9b4(0xc08)]['id']);
            if (!_0x377204)
                return;
            _0x377204[_0x44a9b4(0xa49)][_0x44a9b4(0x668)] && _0x377204[_0x44a9b4(0xa49)]['onDestroy'](_0x838a2c);
        });
    }
};
_0x25e7d0(_0x391b73, _0x21f734(0x752), []);
var _0x425a4d = _0x391b73;
import {
    Block as _0x5a2984,
    BlockPermutation as _0x4ba73c,
    system as _0x4473e3,
    world as _0x425220
} from '@minecraft/server';
var _0x2b1988 = class {
    static [_0x21f734(0x48b)]() {
        const _0x1ba7d1 = _0x21f734, _0x5c4b79 = {
                'InUGg': _0x1ba7d1(0xacd),
                'swvIN': 'bottom',
                'tYSxJ': function (_0x4ffac3, _0x3973f8) {
                    return _0x4ffac3 == _0x3973f8;
                },
                'Iiezt': 'top',
                'xlsrz': function (_0x87f340, _0x2b4f3c) {
                    return _0x87f340 == _0x2b4f3c;
                },
                'GMiLP': function (_0xb27713, _0x796cd7) {
                    return _0xb27713 == _0x796cd7;
                },
                'xOreV': function (_0x39b17a, _0x3d77cf) {
                    return _0x39b17a == _0x3d77cf;
                }
            };
        _0x425220[_0x1ba7d1(0x959)][_0x1ba7d1(0x398)][_0x1ba7d1(0x725)](_0x2af046 => {
            const _0xc964f0 = _0x1ba7d1;
            _0x2af046[_0xc964f0(0x2ee)]['registerCustomComponent'](_0x207994 + _0xc964f0(0xb13), {
                'beforeOnPlayerPlace': this['placeBlock'],
                'onTick': this['generateBlock']
            });
        }), _0x425220[_0x1ba7d1(0x959)][_0x1ba7d1(0x8ee)][_0x1ba7d1(0x725)](this[_0x1ba7d1(0x85d)]), _0x425220[_0x1ba7d1(0x327)][_0x1ba7d1(0xb88)][_0x1ba7d1(0x725)](this[_0x1ba7d1(0x85d)]), _0x425220[_0x1ba7d1(0x327)][_0x1ba7d1(0xb6f)][_0x1ba7d1(0x725)](_0xeab828 => {
            const _0x1fb9e1 = _0x1ba7d1, _0x22664a = _0xeab828['block']['permutation']['getState'](_0x5c4b79[_0x1fb9e1(0x1cd)]);
            let _0x2960dc, _0x3527d7, _0x3fb2e4 = 0x0, _0x274e4f = _0x5c4b79['swvIN'];
            _0x5c4b79[_0x1fb9e1(0x81b)](_0x22664a, 0x0) && (_0x3fb2e4 = 0x5, _0x274e4f = _0x5c4b79['Iiezt'], _0x4473e3[_0x1fb9e1(0x873)](() => {
                const _0x4077f6 = _0x1fb9e1;
                _0x3527d7 = _0xeab828[_0x4077f6(0x87b)]['below']()[_0x4077f6(0xbd3)](), _0x2960dc = _0xeab828['block'][_0x4077f6(0xbd3)]()['below']()[_0x4077f6(0xbd3)]();
            }, 0x5)), _0x5c4b79['tYSxJ'](_0x22664a, 0x1) && (_0x3fb2e4 = 0x5, _0x4473e3[_0x1fb9e1(0x873)](() => {
                const _0x22575b = _0x1fb9e1;
                _0x3527d7 = _0xeab828[_0x22575b(0x87b)][_0x22575b(0x291)]()[_0x22575b(0x291)](), _0x2960dc = _0xeab828[_0x22575b(0x87b)][_0x22575b(0x291)]()[_0x22575b(0x291)]()['above']();
            }, 0x5)), _0x5c4b79[_0x1fb9e1(0x5d3)](_0x22664a, 0x2) && (_0x3527d7 = _0xeab828['block'][_0x1fb9e1(0x6a6)]()[_0x1fb9e1(0xbd3)](), _0x2960dc = _0xeab828[_0x1fb9e1(0x87b)][_0x1fb9e1(0x6a6)]()[_0x1fb9e1(0x6a6)]()), _0x5c4b79['GMiLP'](_0x22664a, 0x3) && (_0x3527d7 = _0xeab828[_0x1fb9e1(0x87b)][_0x1fb9e1(0x571)]()[_0x1fb9e1(0xbd3)](), _0x2960dc = _0xeab828[_0x1fb9e1(0x87b)][_0x1fb9e1(0x571)]()[_0x1fb9e1(0x571)]()), _0x5c4b79[_0x1fb9e1(0x1c5)](_0x22664a, 0x4) && (_0x3527d7 = _0xeab828[_0x1fb9e1(0x87b)][_0x1fb9e1(0x7bd)]()[_0x1fb9e1(0xbd3)](), _0x2960dc = _0xeab828[_0x1fb9e1(0x87b)][_0x1fb9e1(0x7bd)]()[_0x1fb9e1(0x7bd)]()), _0x22664a == 0x5 && (_0x3527d7 = _0xeab828['block'][_0x1fb9e1(0x709)]()['below'](), _0x2960dc = _0xeab828[_0x1fb9e1(0x87b)][_0x1fb9e1(0x709)]()[_0x1fb9e1(0x709)]()), _0x4473e3['runTimeout'](() => {
                const _0x5ef599 = _0x1fb9e1;
                _0x3527d7?.[_0x5ef599(0x5fa)]['getState'](_0x207994 + _0x5ef599(0xbd6)) === _0x274e4f && this[_0x5ef599(0x85d)](_0x3527d7), _0x2960dc?.[_0x5ef599(0x5fa)][_0x5ef599(0x30a)](_0x207994 + _0x5ef599(0xbd6)) !== void 0x0 && _0x2960dc[_0x5ef599(0xb28)]['runCommandAsync'](_0x5ef599(0x249) + _0x2960dc[_0x5ef599(0x2c0)]['x'] + '\x20' + _0x2960dc[_0x5ef599(0x2c0)]['y'] + '\x20' + _0x2960dc[_0x5ef599(0x2c0)]['z'] + _0x5ef599(0x6a0));
            }, _0x3fb2e4);
        });
    }
    static [_0x21f734(0x527)](_0x744df5) {
        const _0x239ea3 = _0x21f734, _0x4c76cc = {
                'CzjlW': 'top',
                'YsBsE': _0x239ea3(0xba4),
                'wPZjS': _0x239ea3(0x9d5),
                'RdnjZ': function (_0x8031e2, _0x95177d) {
                    return _0x8031e2 !== _0x95177d;
                },
                'GRoDV': _0x239ea3(0x6d4),
                'eEdVo': function (_0x40f71c, _0x5e32f0) {
                    return _0x40f71c !== _0x5e32f0;
                },
                'RLNRI': 'minecraft:air',
                'VmTpX': function (_0x1b5ace, _0x3e2dd0) {
                    return _0x1b5ace === _0x3e2dd0;
                }
            }, _0x10c213 = _0x744df5['permutationToPlace']['type']['id'], _0x1e9fa3 = _0x744df5[_0x239ea3(0x2c1)][_0x239ea3(0x833)](), _0x5e468b = _0x744df5[_0x239ea3(0xa53)], _0xa373dd = _0x744df5[_0x239ea3(0x2c1)][_0x239ea3(0x30a)](_0x4c76cc[_0x239ea3(0x334)]), _0x18b69e = _0x744df5[_0x239ea3(0x2c1)][_0x239ea3(0x30a)](_0x4c76cc[_0x239ea3(0x749)]);
        if (_0x4c76cc[_0x239ea3(0x20d)](_0x5e468b, _0x4c76cc[_0x239ea3(0x2ab)])) {
            if (_0x4c76cc[_0x239ea3(0x2b8)](_0x744df5[_0x239ea3(0x87b)][_0x239ea3(0x291)]()?.[_0x239ea3(0x1b9)], _0x4c76cc['RLNRI'])) {
                _0x744df5[_0x239ea3(0xaa9)] = !![];
                return;
            }
            _0x4473e3[_0x239ea3(0xb7e)](() => {
                const _0x16bb73 = _0x239ea3;
                _0x744df5[_0x16bb73(0x87b)]['above']()?.[_0x16bb73(0x772)](_0x4ba73c[_0x16bb73(0x8f4)]('' + _0x10c213, _0x1e9fa3)[_0x16bb73(0x9d1)](_0x207994 + _0x16bb73(0xbd6), _0x4c76cc[_0x16bb73(0x52b)]));
            });
            return;
        }
        if (_0x4c76cc[_0x239ea3(0x7da)](_0x5e468b, _0x4c76cc['GRoDV'])) {
            if (_0x744df5[_0x239ea3(0x87b)][_0x239ea3(0xbd3)]()?.[_0x239ea3(0x1b9)] !== _0x4c76cc[_0x239ea3(0x687)]) {
                _0x744df5[_0x239ea3(0xaa9)] = !![];
                return;
            }
            _0x744df5[_0x239ea3(0x2c1)] = _0x744df5[_0x239ea3(0x2c1)][_0x239ea3(0x9d1)](_0x207994 + _0x239ea3(0xbd6), _0x4c76cc['CzjlW']), _0x4473e3[_0x239ea3(0xb7e)](() => {
                const _0x3efffa = _0x239ea3;
                _0x744df5['block'][_0x3efffa(0xbd3)]()?.['setPermutation'](_0x4ba73c['resolve']('' + _0x10c213, _0x1e9fa3)[_0x3efffa(0x9d1)](_0x207994 + _0x3efffa(0xbd6), 'bottom'));
            });
        }
    }
    static [_0x21f734(0x635)](_0x6a1a4a) {
        const _0x147673 = _0x21f734, _0x1d3467 = {
                'MuFqJ': function (_0x4a06ec, _0x4516c0) {
                    return _0x4a06ec === _0x4516c0;
                },
                'RJRrt': _0x147673(0x731),
                'dqMfn': function (_0x2e2228, _0x22ce4f) {
                    return _0x2e2228 !== _0x22ce4f;
                },
                'wwvPA': 'minecraft:air',
                'YvOxe': 'top',
                'uoMWY': function (_0x410b23, _0x150ca5) {
                    return _0x410b23 === _0x150ca5;
                },
                'wcziw': function (_0x31785e, _0x411a61) {
                    return _0x31785e !== _0x411a61;
                }
            }, _0x246f5b = _0x6a1a4a[_0x147673(0x87b)][_0x147673(0x1b9)], _0x3e4229 = _0x6a1a4a[_0x147673(0x87b)][_0x147673(0x5fa)]['getAllStates'](), _0x37f51f = _0x6a1a4a[_0x147673(0x87b)][_0x147673(0x291)](), _0x1800f9 = _0x6a1a4a[_0x147673(0x87b)][_0x147673(0xbd3)]();
        if (_0x1d3467[_0x147673(0x47e)](_0x6a1a4a[_0x147673(0x87b)][_0x147673(0x5fa)][_0x147673(0x30a)](_0x207994 + ':half'), _0x1d3467[_0x147673(0x5fd)])) {
            if (_0x1d3467[_0x147673(0x6d6)](_0x37f51f?.[_0x147673(0x1b9)], _0x1d3467[_0x147673(0x4b9)]) && _0x1d3467[_0x147673(0x6d6)](_0x37f51f?.[_0x147673(0x1b9)], _0x246f5b))
                return;
            _0x37f51f?.[_0x147673(0x772)](_0x4ba73c[_0x147673(0x8f4)]('' + _0x246f5b, _0x3e4229)[_0x147673(0x9d1)](_0x207994 + ':half', _0x1d3467['YvOxe']));
        }
        if (_0x1d3467[_0x147673(0xb38)](_0x6a1a4a[_0x147673(0x87b)][_0x147673(0x5fa)][_0x147673(0x30a)](_0x207994 + _0x147673(0xbd6)), _0x1d3467[_0x147673(0x7c5)])) {
            if (_0x1d3467[_0x147673(0x621)](_0x1800f9?.[_0x147673(0x1b9)], _0x147673(0x1a5)) && _0x1d3467[_0x147673(0x6d6)](_0x1800f9?.[_0x147673(0x1b9)], _0x246f5b))
                return;
            _0x1800f9?.[_0x147673(0x772)](_0x4ba73c[_0x147673(0x8f4)]('' + _0x246f5b, _0x3e4229)[_0x147673(0x9d1)](_0x207994 + ':half', _0x1d3467[_0x147673(0x5fd)]));
        }
    }
    static [_0x21f734(0x85d)](_0x1ad89f) {
        const _0x3e9b90 = _0x21f734, _0x1c1f3c = {
                'btiTa': function (_0x823e79, _0x19d5e1) {
                    return _0x823e79 instanceof _0x19d5e1;
                },
                'UVDDV': function (_0x6e5a00, _0x466be6) {
                    return _0x6e5a00 === _0x466be6;
                },
                'dFFyc': _0x3e9b90(0x857)
            };
        let _0x612993;
        _0x1c1f3c[_0x3e9b90(0xb27)](_0x1ad89f, _0x5a2984) ? _0x612993 = _0x1ad89f : _0x612993 = _0x1ad89f[_0x3e9b90(0x87b)];
        const _0x363ad6 = _0x612993[_0x3e9b90(0x5fa)]['getState'](_0x207994 + _0x3e9b90(0xbd6));
        if (!_0x363ad6)
            return;
        const _0x290688 = _0x612993[_0x3e9b90(0x1b9)], _0x221c3f = _0x1c1f3c[_0x3e9b90(0x1cf)](_0x363ad6, _0x1c1f3c[_0x3e9b90(0x83e)]) ? _0x612993[_0x3e9b90(0xbd3)]() : _0x612993['above']();
        _0x1c1f3c[_0x3e9b90(0x1cf)](_0x221c3f?.[_0x3e9b90(0x1b9)], _0x290688) && (_0x221c3f['isWaterlogged'] ? _0x221c3f[_0x3e9b90(0xb28)][_0x3e9b90(0x27c)](_0x3e9b90(0x249) + _0x221c3f['x'] + '\x20' + _0x221c3f['y'] + '\x20' + _0x221c3f['z'] + _0x3e9b90(0x606)) : _0x221c3f[_0x3e9b90(0xb28)][_0x3e9b90(0x27c)]('/setblock\x20' + _0x221c3f['x'] + '\x20' + _0x221c3f['y'] + '\x20' + _0x221c3f['z'] + _0x3e9b90(0x6a0))), _0x612993['isWaterlogged'] ? _0x612993['dimension'][_0x3e9b90(0x27c)](_0x3e9b90(0x249) + _0x612993['x'] + '\x20' + _0x612993['y'] + '\x20' + _0x612993['z'] + _0x3e9b90(0x606)) : _0x612993[_0x3e9b90(0xb28)][_0x3e9b90(0x27c)](_0x3e9b90(0x249) + _0x612993['x'] + '\x20' + _0x612993['y'] + '\x20' + _0x612993['z'] + _0x3e9b90(0x6a0));
    }
};
import { world as _0x56ca14 } from '@minecraft/server';
var _0x271665 = class _0x114674 {
    constructor(_0x46f9af) {
        this['config'] = _0x46f9af;
    }
    static ['registerBehavior'](_0x56fc9d) {
        const _0x36a416 = _0x21f734, _0x132ee6 = new _0x114674(_0x56fc9d);
        this[_0x36a416(0x752)][_0x36a416(0x28e)](_0x132ee6);
    }
    static [_0x21f734(0x48b)]() {
        const _0x106bf1 = _0x21f734;
        _0x56ca14[_0x106bf1(0x959)][_0x106bf1(0x398)]['subscribe'](_0x1ef7e0 => {
            const _0x1878d3 = _0x106bf1;
            _0x1ef7e0[_0x1878d3(0x2ee)][_0x1878d3(0x565)](_0x207994 + _0x1878d3(0x48f), {
                'onTick': _0x3096e5 => {
                    const _0x998f3a = _0x1878d3;
                    this[_0x998f3a(0x9ba)](_0x3096e5);
                }
            });
        });
    }
    static [_0x21f734(0x9ba)](_0x422e49) {
        const _0x5f2b4d = _0x21f734, _0xbc0fc4 = {
                'hKMAw': function (_0x397a6c, _0xf359d5) {
                    return _0x397a6c !== _0xf359d5;
                }
            }, _0x42809a = _0x422e49[_0x5f2b4d(0x87b)], _0xa7663e = _0x114674[_0x5f2b4d(0x752)][_0x5f2b4d(0x65e)](_0x1b5834 => _0x1b5834[_0x5f2b4d(0xa49)]['id'] === _0x422e49[_0x5f2b4d(0x87b)]['typeId']);
        _0xa7663e && _0xa7663e['config'][_0x5f2b4d(0xa2a)][_0x5f2b4d(0x3e1)](_0x5b3ab9 => {
            const _0x137c0a = _0x5f2b4d;
            if (_0x5b3ab9[_0x137c0a(0x5af)] && _0xbc0fc4[_0x137c0a(0x5c1)](_0x42809a[_0x137c0a(0x5fa)][_0x137c0a(0x30a)](_0x5b3ab9[_0x137c0a(0x5af)][_0x137c0a(0x5af)]), _0x5b3ab9[_0x137c0a(0x5af)][_0x137c0a(0x8c7)]))
                return;
            else
                _0x5b3ab9['condition'](_0x42809a) && _0x5b3ab9[_0x137c0a(0x5c9)](_0x42809a);
        });
    }
};
_0x25e7d0(_0x271665, 'blocks', []);
var _0x4a8742 = _0x271665;
import {
    ItemStack as _0x53693f,
    world as _0x568ad
} from '@minecraft/server';
function _0x2d869c() {
    const _0x238a82 = _0x21f734, _0x1e262c = {
            'ijBCz': 'sb_bf.disc.nowPlaying',
            'zIpfN': _0x238a82(0x3a0),
            'daMrm': _0x238a82(0x8f1),
            'yxuLr': function (_0x477512, _0x43105c) {
                return _0x477512 === _0x43105c;
            },
            'cTwto': _0x238a82(0x21e),
            'rMGLb': 'record_5',
            'MQCPT': _0x238a82(0x640),
            'sdtfR': _0x238a82(0x6f8),
            'cUUDH': _0x238a82(0x2a5),
            'ZSQjU': 'minecraft:music_disc_13',
            'kXWVI': 'record_13',
            'FBwIg': 'record.blocks',
            'cpAFy': _0x238a82(0x743),
            'lcTJS': _0x238a82(0x4b3),
            'ZxjYv': 'minecraft:music_disc_cat',
            'PtjxN': 'record.chirp',
            'ReSUq': 'minecraft:music_disc_chirp',
            'pCSnS': _0x238a82(0x1e2),
            'HqcEk': _0x238a82(0x1b5),
            'Evshw': _0x238a82(0x96b),
            'Ruiso': _0x238a82(0x3c3),
            'Ivynn': 'record.far',
            'ilDNf': _0x238a82(0x9ae),
            'iUISG': _0x238a82(0x667),
            'pqTFv': _0x238a82(0x433),
            'rJxYI': _0x238a82(0x213),
            'QbNnt': _0x238a82(0x33f),
            'cDLei': _0x238a82(0x43d),
            'ZGdZG': _0x238a82(0x216),
            'yWTAQ': _0x238a82(0xab3),
            'ZqRtV': _0x238a82(0x354),
            'RGWEr': _0x238a82(0x806),
            'xjHNW': _0x238a82(0xbab),
            'FhZhf': _0x238a82(0x4a7),
            'EXpGH': _0x238a82(0x7fc),
            'Ftcji': _0x238a82(0x63a),
            'ShGIh': 'record_relic',
            'piINR': 'record.stal',
            'dPqud': _0x238a82(0xbb0),
            'EAvgC': _0x238a82(0x803),
            'NNJVJ': _0x238a82(0xa5c),
            'OENQB': _0x238a82(0x5bb),
            'lasCj': _0x238a82(0xa1f),
            'rXnOj': _0x238a82(0x590),
            'nAaIU': _0x238a82(0x4d0),
            'yxcel': _0x238a82(0x7d5),
            'uPwEy': 'minecraft:music_disc_lava_chicken',
            'vrFLe': 'record_lava_chicken',
            'ZnlcH': _0x238a82(0xafb),
            'SDeee': _0x238a82(0x5f5),
            'wGOJh': 'record_tears',
            'NjjAu': _0x238a82(0x1c0)
        }, _0x1f4857 = [
            {
                'id': _0x238a82(0x415),
                'item': _0x1e262c[_0x238a82(0x472)],
                'lang': _0x1e262c['rMGLb']
            },
            {
                'id': _0x1e262c[_0x238a82(0x681)],
                'item': _0x238a82(0x998),
                'lang': _0x1e262c['sdtfR']
            },
            {
                'id': _0x1e262c[_0x238a82(0xbc5)],
                'item': _0x1e262c['ZSQjU'],
                'lang': _0x1e262c[_0x238a82(0x2f5)]
            },
            {
                'id': _0x1e262c[_0x238a82(0x88b)],
                'item': _0x238a82(0x969),
                'lang': _0x1e262c[_0x238a82(0x87a)]
            },
            {
                'id': _0x1e262c[_0x238a82(0xa33)],
                'item': _0x1e262c['ZxjYv'],
                'lang': _0x238a82(0x2fc)
            },
            {
                'id': _0x1e262c[_0x238a82(0x8d2)],
                'item': _0x1e262c[_0x238a82(0x56a)],
                'lang': _0x1e262c[_0x238a82(0x4f6)]
            },
            {
                'id': _0x1e262c[_0x238a82(0x741)],
                'item': _0x238a82(0x881),
                'lang': _0x238a82(0x99a)
            },
            {
                'id': _0x1e262c[_0x238a82(0x2c6)],
                'item': _0x1e262c['Ruiso'],
                'lang': 'record_creator_music_box'
            },
            {
                'id': _0x1e262c[_0x238a82(0x1f7)],
                'item': _0x1e262c[_0x238a82(0x34a)],
                'lang': _0x1e262c[_0x238a82(0x5c7)]
            },
            {
                'id': _0x238a82(0x61a),
                'item': _0x1e262c[_0x238a82(0x84e)],
                'lang': _0x1e262c['rJxYI']
            },
            {
                'id': _0x1e262c[_0x238a82(0x1e8)],
                'item': _0x1e262c['cDLei'],
                'lang': _0x1e262c['ZGdZG']
            },
            {
                'id': _0x1e262c[_0x238a82(0xaee)],
                'item': _0x1e262c[_0x238a82(0x24a)],
                'lang': _0x1e262c['RGWEr']
            },
            {
                'id': _0x1e262c[_0x238a82(0x859)],
                'item': _0x238a82(0x301),
                'lang': _0x1e262c['FhZhf']
            },
            {
                'id': _0x1e262c[_0x238a82(0x95b)],
                'item': _0x238a82(0x9c5),
                'lang': _0x238a82(0x67a)
            },
            {
                'id': _0x238a82(0xb84),
                'item': _0x1e262c[_0x238a82(0x3e3)],
                'lang': _0x1e262c[_0x238a82(0x372)]
            },
            {
                'id': _0x1e262c[_0x238a82(0x8a3)],
                'item': _0x238a82(0x8cc),
                'lang': _0x238a82(0x97f)
            },
            {
                'id': _0x1e262c[_0x238a82(0x78d)],
                'item': _0x238a82(0x28b),
                'lang': _0x1e262c['EAvgC']
            },
            {
                'id': _0x1e262c[_0x238a82(0xaff)],
                'item': _0x1e262c['OENQB'],
                'lang': _0x1e262c[_0x238a82(0x832)]
            },
            {
                'id': _0x238a82(0x7f2),
                'item': _0x1e262c[_0x238a82(0x28c)],
                'lang': _0x1e262c[_0x238a82(0x727)]
            },
            {
                'id': _0x1e262c['yxcel'],
                'item': _0x1e262c[_0x238a82(0x64d)],
                'lang': _0x1e262c[_0x238a82(0x7c0)]
            },
            {
                'id': _0x1e262c[_0x238a82(0x54b)],
                'item': _0x1e262c[_0x238a82(0x4fa)],
                'lang': _0x1e262c[_0x238a82(0x6d5)]
            }
        ], _0x86679b = _0x1f4857[_0x238a82(0x2dc)](_0x2c90a1 => {
            const _0x48bcff = _0x238a82, _0x1091b4 = {
                    'states': [{
                            'state': _0x1e262c[_0x48bcff(0x506)],
                            'value': ![]
                        }],
                    'sound': _0x1e262c[_0x48bcff(0x518)],
                    'item': _0x2c90a1[_0x48bcff(0xa00)],
                    'takeItem': !![],
                    'transformTo': {
                        'states': [{
                                'state': _0x1e262c[_0x48bcff(0x506)],
                                'value': !![]
                            }]
                    },
                    'function'(_0x3da118, _0x59215a) {
                        const _0x2b128c = _0x48bcff, _0x3758b2 = _0x59215a['location'];
                        _0x568ad[_0x2b128c(0x483)](_0x2b128c(0x287) + _0x3758b2['x'] + '_' + _0x3758b2['y'] + '_' + _0x3758b2['z'], _0x2c90a1['item']), _0x3da118[_0x2b128c(0x3a7)][_0x2b128c(0xa63)]({
                            'rawtext': [
                                { 'translate': _0x1e262c[_0x2b128c(0x2e3)] },
                                { 'translate': _0x2b128c(0x29e) + _0x2c90a1[_0x2b128c(0x676)] + _0x2b128c(0x203) }
                            ]
                        }), _0x59215a[_0x2b128c(0xb28)][_0x2b128c(0xa70)](_0x2c90a1['id'], _0x59215a[_0x2b128c(0x2c0)]);
                    }
                };
            return _0x1091b4;
        });
    _0xb54d87['register']({
        'id': _0x238a82(0x4fc),
        'transform': {
            'transforms': [
                ..._0x86679b,
                {
                    'states': [{
                            'state': 'sb_bf:playing',
                            'value': !![]
                        }],
                    'sound': _0x1e262c[_0x238a82(0x518)],
                    'item': 'all',
                    'takeItem': ![],
                    'transformTo': {
                        'states': [{
                                'state': _0x1e262c[_0x238a82(0x506)],
                                'value': ![]
                            }]
                    },
                    'function'(_0x2d5fdf, _0x42e1df) {
                        const _0x3919ce = _0x238a82, _0x147b56 = _0x42e1df['location'], _0x22b278 = _0x568ad[_0x3919ce(0xb95)](_0x3919ce(0x287) + _0x147b56['x'] + '_' + _0x147b56['y'] + '_' + _0x147b56['z']), _0x5ab5aa = _0x1f4857['find'](_0x4d94b4 => _0x4d94b4[_0x3919ce(0xa00)] === _0x22b278);
                        _0x5ab5aa && (_0x42e1df[_0x3919ce(0xb28)]['playSound'](_0x5ab5aa['id'], _0x42e1df[_0x3919ce(0x2c0)], { 'volume': 1e-7 }), _0x42e1df[_0x3919ce(0xb28)][_0x3919ce(0x220)](new _0x53693f(_0x22b278), _0x42e1df[_0x3919ce(0x5a0)]()), _0x568ad['setDynamicProperty']('disc_player:' + _0x147b56['x'] + '_' + _0x147b56['y'] + '_' + _0x147b56['z'], void 0x0));
                    }
                }
            ]
        },
        'events': {
            'onDestroy': _0x10523a => {
                const _0x3e2131 = _0x238a82, _0x2a2f94 = _0x10523a[_0x3e2131(0x87b)][_0x3e2131(0x2c0)], _0x2078fd = _0x568ad['getDynamicProperty'](_0x3e2131(0x287) + _0x2a2f94['x'] + '_' + _0x2a2f94['y'] + '_' + _0x2a2f94['z']), _0x16cfcb = _0x1f4857[_0x3e2131(0x65e)](_0xf7bc12 => _0xf7bc12['item'] === _0x2078fd);
                _0x16cfcb && (_0x10523a[_0x3e2131(0xb28)][_0x3e2131(0xa70)](_0x16cfcb['id'], _0x10523a[_0x3e2131(0x87b)][_0x3e2131(0x2c0)], { 'volume': 1e-7 }), _0x10523a[_0x3e2131(0xb28)]['spawnItem'](new _0x53693f(_0x2078fd), _0x10523a[_0x3e2131(0x87b)][_0x3e2131(0x5a0)]()), _0x568ad[_0x3e2131(0x483)](_0x3e2131(0x287) + _0x2a2f94['x'] + '_' + _0x2a2f94['y'] + '_' + _0x2a2f94['z'], void 0x0));
            }
        },
        'visualEffects': {
            'particles': [{
                    'id': _0x1e262c['NjjAu'],
                    'chance': 0x1,
                    'interval': 0x1,
                    'location': {
                        'x': -0.3,
                        'y': 0.3,
                        'z': 0.3
                    }
                }]
        },
        'conditionCheck': {
            'events': [{
                    'condition': _0x18be55 => {
                        const _0x2753ae = _0x238a82;
                        return _0x18be55[_0x2753ae(0x5fa)][_0x2753ae(0x30a)](_0x2753ae(0x3a0)) === !![];
                    },
                    'event': _0x374b9c => {
                        const _0x113db8 = _0x238a82, _0x2ad455 = _0x568ad[_0x113db8(0xb95)]('disc_player:' + _0x374b9c[_0x113db8(0x2c0)]['x'] + '_' + _0x374b9c[_0x113db8(0x2c0)]['y'] + '_' + _0x374b9c[_0x113db8(0x2c0)]['z']);
                        if (_0x1e262c[_0x113db8(0x413)](_0x2ad455, void 0x0)) {
                            const _0x46939b = _0x1f4857['find'](_0x2ed779 => _0x2ed779[_0x113db8(0xa00)] === _0x2ad455);
                            _0x46939b && _0x374b9c[_0x113db8(0xb28)]['playSound'](_0x46939b['id'], _0x374b9c[_0x113db8(0x2c0)], { 'volume': 1e-7 }), _0x374b9c[_0x113db8(0x772)](_0x374b9c[_0x113db8(0x5fa)][_0x113db8(0x9d1)](_0x113db8(0x3a0), ![]));
                        }
                    }
                }]
        }
    });
}
import {
    BlockPermutation as _0xb14064,
    EquipmentSlot as _0x133814,
    GameMode as _0x48778a,
    ItemStack as _0x2cbd0b,
    system as _0x1b2fe6,
    world as _0x35607f
} from '@minecraft/server';
var _0x293995 = class _0x39113c {
    constructor(_0x2911a2) {
        this['config'] = _0x2911a2;
    }
    static [_0x21f734(0x760)](_0x49ef41) {
        const _0x103208 = _0x21f734, _0x5cc0d7 = new _0x39113c(_0x49ef41);
        _0x39113c[_0x103208(0x752)][_0x103208(0x28e)](_0x5cc0d7);
    }
    static ['initialize']() {
        const _0xafda34 = _0x21f734;
        _0x35607f[_0xafda34(0x959)][_0xafda34(0x398)][_0xafda34(0x725)](_0x4644f1 => {
            const _0x3259c1 = _0xafda34;
            _0x4644f1[_0x3259c1(0x2ee)][_0x3259c1(0x565)](_0x207994 + ':multi_block', {
                'onPlace': _0x3356c3 => {
                }
            });
        }), _0x35607f['beforeEvents'][_0xafda34(0x48a)][_0xafda34(0x725)](_0x204cc2 => {
            const _0x62458c = _0xafda34;
            _0x204cc2[_0x62458c(0x212)] && this[_0x62458c(0x527)](_0x204cc2);
        });
    }
    static [_0x21f734(0x527)](_0x244242) {
        const _0x1e5a5e = _0x21f734, _0x2251c7 = {
                'lbxTQ': function (_0x8af5a, _0x4ab0e5) {
                    return _0x8af5a !== _0x4ab0e5;
                },
                'zoYrR': function (_0x569e33, _0x5df1b0, _0x163948) {
                    return _0x569e33(_0x5df1b0, _0x163948);
                },
                'ceVMd': function (_0x5d1d85, _0x55ef1c) {
                    return _0x5d1d85(_0x55ef1c);
                },
                'jjDaH': function (_0x5063fb, _0x2825ff) {
                    return _0x5063fb + _0x2825ff;
                },
                'ANbTd': 'minecraft:cardinal_direction',
                'xqzNl': function (_0x3dddf7, _0x1376a6) {
                    return _0x3dddf7 && _0x1376a6;
                }
            }, _0x55d01e = _0x244242['block'];
        let _0x4c94da = _0x59bdcb(_0x244242['player'], _0x133814['Mainhand']);
        if (!_0x244242[_0x1e5a5e(0x848)] || !_0x55d01e || !_0x4c94da)
            return;
        _0x4c94da = new _0x2cbd0b(_0x4c94da?.['typeId'][_0x1e5a5e(0x1f5)](_0x1e5a5e(0x556))[0x0]);
        if (_0x55d01e[_0x1e5a5e(0x1b9)] === _0x4c94da[_0x1e5a5e(0x1b9)]) {
            const _0x1e2b4b = _0x39113c[_0x1e5a5e(0xa77)](_0x4c94da[_0x1e5a5e(0x1b9)]);
            if (!_0x1e2b4b)
                return;
            const _0x21c637 = _0x2251c7[_0x1e5a5e(0x614)](parseInt, _0x55d01e[_0x1e5a5e(0x5fa)][_0x1e5a5e(0x30a)](_0x207994 + ':count')), _0x50dc8f = _0x1e2b4b[_0x1e5a5e(0xa49)][_0x1e5a5e(0x30d)];
            let _0x2de0d1 = _0x2251c7['jjDaH'](_0x21c637, 0x1);
            if (_0x2de0d1 > _0x50dc8f)
                return;
            _0x244242[_0x1e5a5e(0xaa9)] = !![];
            const _0x100784 = _0x55d01e[_0x1e5a5e(0x5fa)][_0x1e5a5e(0x833)](), _0x5f1bfd = _0x55d01e['permutation']['getState'](_0x2251c7['ANbTd']), _0x1e5a1e = {
                    ..._0x100784,
                    [_0x207994 + ':count']: _0x2de0d1,
                    ..._0x2251c7[_0x1e5a5e(0xb49)](_0x5f1bfd, { [_0x1e5a5e(0xba4)]: _0x5f1bfd })
                };
            _0x1b2fe6[_0x1e5a5e(0x873)](() => {
                const _0x40e9d2 = _0x1e5a5e;
                _0x4c94da && (_0x55d01e[_0x40e9d2(0x772)](_0xb14064[_0x40e9d2(0x8f4)]('' + _0x4c94da[_0x40e9d2(0xc08)]['id'], _0x1e5a1e)), _0x1e2b4b[_0x40e9d2(0xa49)]['sound'] && _0x35607f[_0x40e9d2(0xa70)](_0x1e2b4b[_0x40e9d2(0xa49)][_0x40e9d2(0x758)], _0x244242[_0x40e9d2(0x848)][_0x40e9d2(0x2c0)]), _0x2251c7[_0x40e9d2(0x67d)](_0x244242[_0x40e9d2(0x848)][_0x40e9d2(0x271)](), _0x48778a[_0x40e9d2(0x805)]) && _0x2251c7[_0x40e9d2(0x7b6)](_0x2c8ecf, _0x244242[_0x40e9d2(0x848)], _0x4c94da[_0x40e9d2(0x1b9)]));
            }, 0x1);
        }
    }
    static [_0x21f734(0xa77)](_0x52b3c4) {
        const _0x4e45a5 = _0x21f734;
        return _0x39113c['blocks'][_0x4e45a5(0x65e)](_0x20ca76 => _0x20ca76[_0x4e45a5(0xa49)]['id'] === _0x52b3c4);
    }
};
_0x25e7d0(_0x293995, _0x21f734(0x752), []);
var _0x2234ce = _0x293995;
import {
    ItemEnchantableComponent as _0x2ca2d9,
    system as _0x26de46,
    world as _0x36850e
} from '@minecraft/server';
function _0x4213() {
    const _0x21cb8a = [
        '_picture',
        'pBfjy',
        'NmRev',
        'sb_bf:light_blue_glazed_terracotta_vase',
        'cos',
        'minecraft:pink_tulip',
        'IjZGm',
        '§r.',
        'minecraft:dandelion',
        'cUmey',
        'TByJZ',
        'chandelier',
        'JUtxu',
        'Error\x20updating\x20block\x20connection\x20states:\x20',
        'entityAnimation',
        'shelf',
        '9273mTkuEI',
        'triggerEffects',
        'pjnRN',
        'scale',
        'open',
        'framed_glass_pane',
        'handleWallPlacement',
        'cancel',
        ':effect_emitter',
        'random',
        'South',
        'PpdAZ',
        'jgrGT',
        'sb_bf:bamboo_glass_door',
        '°\x0aFOV:\x20',
        'noYbT',
        'tcamY',
        'record.otherside',
        'sb_bf.form.tiled_glass.title',
        'multipleBlocks',
        'getImpactedBlocks',
        'showErrorMessage',
        'checkFormUnlock',
        'lQzCZ',
        'dcxEs',
        'sb_bf:oak_glass_trapdoor',
        'sb_bf.form.slime_jar.description.1',
        'eDSvO',
        'glass',
        'czmJH',
        'GnSJL',
        'nameTag',
        'dropdown',
        'HyeIs',
        'NsxhS',
        'scarecrow',
        'Failed\x20to\x20play\x20sound\x20',
        'XutYr',
        'sb_bf:jungle_glass_trapdoor',
        'sb_bf.form.villager_plushie.description',
        'minecraft:honey_block',
        'blue_orchid',
        ':leg_ne',
        'facing_direction',
        'mbMAC',
        'JIiQL',
        'isShearable',
        ':sound:',
        'minecraft:beetroot',
        'Zwdqy',
        'UgUJo',
        'TdgQS',
        'minecraft:birch_leaves',
        'LtIeb',
        'SMLYE',
        'minecraft:cobbled_deepslate_slab',
        'minecraft:stone_brick_stairs',
        'interactSound',
        'sb_bf.form.door_cabinets.description.1',
        'kgAzl',
        '_isMainForm',
        'sb_bf.photobook.statue.info.1x3',
        'oHvEp',
        'isItemValid',
        'qXVpT',
        'mkHwF',
        'trigger',
        'vqoCF',
        '95YoiXDC',
        'uqEAp',
        'textures/sb/bf/form/plushie_piglin',
        'minecraft:orange_stained_glass',
        'VqJix',
        'IQfqf',
        'getDimension',
        'crafting_furniture_table',
        'yWTAQ',
        'itemReleaseUse',
        'yfsei',
        'red',
        'sourceEntity',
        'QAcHn',
        'sb_bf:curtain.open',
        'PXzMw',
        'iaJPr',
        'triggerMessages',
        'sb_bf:special_wither_painting',
        'UGOqe',
        'gYBrI',
        'record.tears',
        'creaking_painting',
        'LTiEp',
        'BYUOE',
        'NNJVJ',
        'sb_bf:jungle_shutter',
        'WulqN',
        'QqCti',
        'onStart',
        'AtQLx',
        'determineLegsBeforePlacement',
        'props',
        'minecraft:silk_touch',
        'aNaXo',
        'SwTOP',
        'minecraft:wither_rose',
        'food',
        'minecraft:peony',
        'angleDegrees',
        'abaPW',
        'createCylinder',
        'qnWDy',
        'minecraft:end_stone_brick_slab',
        'minecraft:totem_particle',
        ':tall_block',
        'sb_bf.form.mushroom_stew.title',
        'rose_bush',
        'pNJvX',
        'updatePoleVisibility',
        'entityInteract',
        'cPzep',
        ',\x20Has\x20LOS:\x20',
        'Cat',
        'resetNeighborLowState',
        'createSphere',
        'flower_pot',
        'minecraft:pink_stained_glass',
        'actionForms',
        'Ljatk',
        'Dog',
        'open.nether_wood_door',
        'corner_sw',
        'hjpmS',
        'textures/sb/bf/form/slime_jar',
        'btiTa',
        'dimension',
        'qYCxL',
        'CFjNS',
        'minecraft:jungle_stairs',
        'minecraft:saturation',
        'minecraft:stone_brick_slab',
        'title\x20@s\x20actionbar\x20',
        'textures/sb/bf/form/trophy_gold',
        'timeoutIds',
        'LKioC',
        '4|5|2|8|0|9|1|7|3|6',
        'sb_bf:horse_picture',
        'sb_bf.form.books.description.1',
        ':transform_block',
        'pGCLR',
        'biomes',
        'uoMWY',
        'hZOey',
        'sb_bf:pale_oak_special_fence_gate',
        'textures/sb/bf/ui/locked',
        'afZrK',
        'xXiCP',
        'sb_bf:birch_special_fence',
        'sb_bf:jar_slime',
        'thyWm',
        'tHToh',
        'orange_candle_holder',
        'BMZkz',
        'minecraft:xp_orb',
        'tiBDY',
        'Ender\x20Dragon',
        'onEnd',
        'VnZAE',
        'xqzNl',
        'eoQhV',
        'sb_bf:dark_oak_glass_door',
        'sb_bf:hay_dust',
        'sb_bf:filled',
        'PfULg',
        '.form.no_recipe',
        'PiBlt',
        'textures/sb/bf/form/decorated_planks.category',
        'textures/sb/bf/form/statue_dolphin',
        'minecraft:mossy_stone_brick_stairs',
        'minecraft:pink_petals',
        'sb_bf.locked.description.frog',
        'unknown',
        'fpwbq',
        'HBCRg',
        'tOOQv',
        'lXIZS',
        'EjhXJ',
        'jsaDu',
        'minecraft:green_bundle',
        'copper_ingot',
        'OFfyo',
        'kidZU',
        'hcSKU',
        'lPpsI',
        'inventory',
        'dzfFt',
        'textures/sb/bf/form/special_glass_pane',
        'uuRFo',
        'updateUpwardConnection',
        'transforms',
        'updateNeighborLowState',
        'getHeadLocation',
        'PKeRv',
        'bKifT',
        'minecraft:potatoes',
        'ZjMxP',
        'pistonActivate',
        'red_candle_holder',
        'xydue',
        'triggerFormFromInventory',
        'blockBreakForms',
        'RRzfU',
        'show',
        'identifier',
        'randomWithinRadius',
        'DOjzL',
        ',\x20Distance:\x20',
        'sb_bf:furniture_guide',
        'minecraft:blackstone_slab',
        'minecraft:birch_fence',
        'boat',
        'run',
        'getCurrentState',
        'transformTo',
        'wRIhq',
        'sb_bf.form.modular_blocks.description.1',
        'minecraft:brown_stained_glass_pane',
        'record.relic',
        'spawnParticle',
        'rqWgQ',
        'DwHSz',
        'blockExplode',
        'minecraft:polished_blackstone_stairs',
        'azrJt',
        'minecraft:red_stained_glass_pane',
        'onBlockBreak',
        'setBlockType',
        'qJGnJ',
        'Evijc',
        'bucket.empty_water',
        'jePyL',
        '§r!',
        'onEntityHit',
        'vOhpg',
        'getDynamicProperty',
        'Frog',
        'adjog',
        'sb_bf:orange_glazed_terracotta_vase',
        'Chicken\x20Jockey\x20Statue',
        'cyan',
        'command_block_minecart',
        'nNJfZ',
        'purple_candle_holder',
        'xwmTS',
        'sb_bf.form.herringbone_planks.description.1',
        'transformBlock',
        'hashDimensionId',
        'onInterval',
        'entityKill',
        'minecraft:cardinal_direction',
        'RJeRa',
        'QjcQP',
        '147848AZAMiQ',
        'sb_bf.form.stew.title',
        'zweVM',
        'GShWg',
        'record.pigstep',
        'minecraft:spruce_sapling',
        'WLfMV',
        'fZHxM',
        'tutorial',
        'record.strad',
        'textures/sb/bf/form/decorated_glass.category',
        'mLHPH',
        'sb_bf.wood_variants',
        'sb_bf.form.shutter.description.1',
        'minecraft:wheat',
        'minecraft:jungle_fence',
        'sb_bf.photobook.description.creeper',
        'yellow_candle_holder',
        'FZTgh',
        'XyMLN',
        'hlhVt',
        'kLlYV',
        'sb_bf:birch_shutter',
        'TWhuW',
        'fSuCr',
        'getComponents',
        'xvKPJ',
        'bJhmf',
        'cyan_chandelier',
        'Zombie',
        'cUUDH',
        'pink_candle_holder',
        'minecraft:thrown_trident',
        'pGmjQ',
        'VGoZH',
        'eekAy',
        'minecraft:blue_stained_glass_pane',
        'sb_bf.photobook.description.warden',
        'aNFNa',
        'KKhyD',
        'jSmsH',
        'open.wooden_door',
        'MnKFW',
        '.form.compostable',
        'below',
        'sb_bf:birch_special_fence_gate',
        'sb_bf:animation',
        ':half',
        ':cooking_pot',
        'iLvcQ',
        'sb_bf:painting',
        'iBYIT',
        'door_mirror',
        'uOsTt',
        'sb_bf.form.curtains.title',
        'minecraft:sweet_berry_bush',
        'minecraft:magenta_stained_glass_pane',
        'ZORxK',
        'stateOnComplete',
        'HncsO',
        'fortuneMultiplier',
        'EOXYl',
        'dig.honey_block',
        'kKSWQ',
        'WuiHD',
        'xPKQs',
        'MloSu',
        'Unknown\x20form\x20type\x20for\x20form\x20with\x20id:\x20',
        'qLLmL',
        'sb_bf.form.wither_painting.description',
        'RLpbl',
        'sb_bf:spruce_special_fence_gate',
        'addItem',
        'removeItem',
        'startsWith',
        'fLkLT',
        'hand',
        'handleBlockUpdate',
        'gray',
        'zfmAh',
        '\x20blocks\x20processed',
        'close.fence_gate',
        'dhrfP',
        'sb_bf.form.lamps.description.1',
        'minecraft:glass_pane',
        'sb_bf.photobook.description.ender_dragon',
        'sb_bf.form.sink.title',
        'handleOnDestroy',
        'ZMjxD',
        'FThxd',
        'sb_bf.form.special_fence_gate.title',
        'ptTsp',
        'ruQjq',
        'piglin',
        'onPlayerInteract',
        'lockedDescription',
        'wither_painting',
        'type',
        'painting',
        'scriptEvent',
        '§cYou\x20need\x20at\x20least\x202\x20blocks\x20of\x20andesite\x20to\x20carve\x20this\x20statue.',
        'light_blue',
        'gTtaW',
        'currentFormOpenedViaInteraction',
        'textures/sb/bf/items/picture/creaking',
        'string',
        'ZtNmv',
        'creaking',
        'iCqdQ',
        'KROVD',
        'Mainhand',
        'kAqpA',
        'DOfdk',
        'YUckr',
        'vloKD',
        'YAqWP',
        'QtVni',
        'sb_bf:horse_statue',
        'itemStack',
        'DRyBI',
        'nonsolid',
        'PSePI',
        'right',
        'minecraft:air',
        'rabbit_stew',
        'corner_left',
        'PrmTr',
        'YlbCe',
        'sb_bf:special_creaking_painting',
        'RfzaZ',
        ':connect_east',
        'useItemForms',
        'entityLoad',
        'vnxrx',
        'wide_planks',
        'DfmmW',
        'has',
        'ink_and_quill',
        'egg',
        'record.creator',
        'sb_bf:jar_cookie',
        'yhYAG',
        'iqZvb',
        'typeId',
        'xTkkT',
        'sEsAA',
        'updatePoleStateDownwards',
        'zombie',
        'sb_bf.locked.description.piglin',
        'VoZBU',
        'sb_bf:note',
        'sb_bf.form.shelf.title',
        'deadEntity',
        'crimson',
        'special_glass',
        'xOreV',
        'LgthJ',
        'minecraft:slime_ball',
        ':fill_state',
        'HDvJe',
        '.form.drops',
        'textField',
        'oWFDZ',
        'InUGg',
        'ItemModule',
        'UVDDV',
        'getVelocity',
        'JdiKX',
        'tile.sb_bf:warden_painting.name',
        'sb_bf.photobook.description.golem',
        'nQsrk',
        'zILEM',
        'hoverParticleOffset',
        'jFtle',
        'carbv',
        'enderman',
        'stsDT',
        'iQbcX',
        'tile.sb_bf:piglin_plushie.name',
        'Tanfg',
        'HOJZn',
        'overworld',
        'sb_bf:lime_glazed_terracotta_vase',
        '.form.not_tameable',
        'record_chirp',
        'minecraft:flowering_azalea_leaves',
        'minecraft:melon_stem',
        'tGcyG',
        'exclude',
        'sb_bf:chicken_jockey_statue',
        'QbNnt',
        'property',
        'AamXw',
        'bDxhf',
        'IIRZV',
        'checkSurroundingBlocks',
        'recipe',
        'QkNKx',
        'VROGt',
        'sb_bf:pig_picture',
        ':leg_se',
        'UNpot',
        ':storage',
        'split',
        'ACAmC',
        'Ivynn',
        'ouAIF',
        'jNWLL',
        'UcjcO',
        'minecraft:red_stained_glass',
        'qQVNb',
        'lockMode',
        'NoAZk',
        'kgEhl',
        'sb_bf.form.ingots.description.1',
        'villager_plushie',
        'iKVrs',
        '.desc',
        'equippable',
        'GAqTr',
        'hasTag',
        'blockDestroy',
        'splash_potion',
        'iyuvW',
        'fjxWY',
        'minecraft:red_bundle',
        'vbPvw',
        'RdnjZ',
        'maxDurability',
        'sb_bf.form.glass_door.title',
        'FCGtQ',
        'hasComponent',
        'isFirstEvent',
        'record_mall',
        'updateNeighborConnections',
        'zWToC',
        'record_mellohi',
        'Choose\x20a\x20guide\x20to\x20view:',
        ',\x20In\x20FOV:\x20',
        'sb_bf.form.door_cabinets.title',
        'apEQl',
        'vcvEv',
        'IzQPz',
        'UDCnM',
        'minecraft:music_disc_5',
        'MFboo',
        'spawnItem',
        'WXrHK',
        'minecraft:orange_tulip',
        'UkJoU',
        'minecraft:polished_blackstone_slab',
        'PDqjq',
        'WHAQA',
        'mqlGK',
        'function',
        'aFMQN',
        'conditionCheck',
        'random.toast_recipe_unlocking_out',
        'chicken_jockey',
        'sb_bf:spruce_glass_trapdoor',
        'sounds',
        'jACko',
        'gHxzh',
        'QExwE',
        'mayET',
        'voZHM',
        'sneaked',
        'sb_bf.photobook.description.zombie',
        ':connect_south',
        'rjxYP',
        'ZOTFQ',
        'getPlayers',
        'endsWith',
        'sb_bf:big_flower_pot',
        'FormModule',
        'lnxUH',
        'CPFRZ',
        'KoDZS',
        'sb_bf:gray_glazed_terracotta_vase',
        'brokenBlockPermutation',
        'usMEm',
        'MjKwt',
        'EtgnT',
        'playAnimation',
        'kZMyy',
        '.achievement.reward',
        'textures/sb/bf/form/table',
        '/setblock\x20',
        'ZqRtV',
        'MveTe',
        'sb_bf:jar_pickle',
        'enderman_statue',
        'spawnOffset',
        'uKxpv',
        'kgicj',
        'GFxYI',
        'mIVGB',
        'FBBTW',
        'openCurtain',
        'minecraft:paper',
        'light_blue_chandelier',
        ':wall_connect',
        'FRKfd',
        'getTitle',
        'minecraft:tinted_glass',
        'ynPrv',
        'sb_bf.form.collector_items.description.1',
        'sb_bf.photobook.description.chicken_jockey',
        'nextStates',
        'join',
        'gray_chandelier',
        '.name',
        'nenGI',
        'FQQkz',
        'UUqmf',
        'SSnIF',
        'NGMEM',
        'edcZr',
        'addEnchantments',
        'mzabg',
        'startPoleUpdatePropagation',
        'ZErLq',
        '.form.not_rideable',
        'piston',
        'textures/sb/bf/form/scarecrow',
        'dig.stone',
        'nhtZu',
        'getGameMode',
        'minecraft:birch_stairs',
        'BIsXi',
        'txKbj',
        'AOgpr',
        'aOBTk',
        'sb_bf:magenta_glazed_terracotta_vase',
        'lingering_potion',
        'PheAE',
        'Failed\x20to\x20drop\x20inventory\x20',
        'HVgbV',
        'runCommandAsync',
        'BsdfC',
        'applyKnockback',
        'cherry',
        'minecraft:honey_bottle',
        'xQmGg',
        'showForm',
        'Atbnp',
        'Line\x20of\x20sight\x20blocked\x20by:\x20',
        'iQYGv',
        'minecraft:jungle_sapling',
        'disc_player:',
        'VpKQU',
        'textures/sb/bf/form/copper_ingot',
        'sb_bf.form.copper_ingot.title',
        'minecraft:music_disc_strad',
        'rXnOj',
        'lHFYx',
        'push',
        'wzVpk',
        'Qwafo',
        'above',
        'EiBHv',
        'kdehg',
        'sb_bf:warped_special_fence',
        'pig',
        'vRvzt',
        'sb_bf:acacia_special_fence',
        'IiibW',
        'UinZa',
        'NubbC',
        'sb_bf:wolf_picture',
        'playerHasItemGroup',
        'sb_bf:black_glazed_terracotta_vase',
        'item.',
        'updateVerticalBlocks',
        'description',
        ':has_joined',
        'Horse\x20Statue',
        'sb_bf.form.beetroot_soup.title',
        'entities',
        'record.13',
        'alesd',
        'EHjPV',
        'isLiquid',
        'golem_statue',
        'PYisX',
        'GRoDV',
        'sb_bf:brown_glazed_terracotta_vase',
        'pink_tulip',
        'OsKDZ',
        'step',
        'vYZfy',
        'isArray',
        'volume',
        '\x0aIsVertical:\x20',
        'jRTVh',
        'sb_bf:pale_oak_glass_trapdoor',
        'getDirection',
        'minecraft:orange_stained_glass_pane',
        'eEdVo',
        'startBatchedVerticalUpdate',
        'TskLE',
        'sb_bf.form.recipes.description.2',
        'entityInteractForms',
        'minecraft:cave_vines_body_with_berries',
        'QcPRY',
        'sb_bf.form.decorated_carpet.description.1',
        'location',
        'permutationToPlace',
        'hIoJY',
        'yOffset',
        'sb_bf.form.tutorial.description.1',
        'destroy',
        'Evshw',
        'vWRIG',
        'decorated_carpet',
        'Failed\x20to\x20spawn\x20particle\x20',
        'RbSPg',
        'WRRJt',
        'close.wooden_trapdoor',
        'sb_bf:enderman_statue',
        'getAllPlayers',
        'sb_bf:chicken_jockey_picture',
        'sb_bf:enderman_picture',
        ':cabinet_vertical_connect',
        'jRSkH',
        'UqnJv',
        'minecraft:mushroom_stew',
        'sb_bf.locked.description.pig',
        'iqgcq',
        'bWIbn',
        'sb_bf.form.special_glass.description.1',
        'minecraft:crimson_slab',
        'GefZm',
        'onUseOnEntityBefore',
        'map',
        'ctIQx',
        'HQhnT',
        'oPOhE',
        'textures/sb/bf/form/furniture_table',
        'heUav',
        'minecraft:light_gray_stained_glass',
        'ijBCz',
        'warden',
        'minecraft:brown_bundle',
        'compile',
        'baseIdentifier',
        'OjuVa',
        'kBbyF',
        'Ttbrk',
        'cushion',
        'NbCFv',
        'sb_bf:dolphin_picture',
        'blockComponentRegistry',
        'sb_bf:itemGroup.name.counter',
        'xp_bottle',
        'Creaking',
        'button',
        'clearActiveEffects',
        'destroyedBlockPermutation',
        'kXWVI',
        'SDNaV',
        'single_inner',
        'sqrt',
        'textures/sb/bf/form/trophy_copper',
        'JaJJb',
        'mob.armor_stand.hit',
        'record_cat',
        'nether',
        'count',
        'TTnKH',
        'sb_bf:',
        'minecraft:music_disc_pigstep',
        'xrcwb',
        'minecraft:white_bundle',
        'sb_bf.form.recipes.description.3',
        'delete',
        'scriptEventReceive',
        'ZukXt',
        'transformItem',
        'open.fence_gate',
        'getState',
        'acos',
        'minecraft:bundle',
        'states',
        'sb_bf.form.wiki.title',
        'minecraft:iron_trapdoor',
        'textures/sb/bf/form/special_fence',
        'sb_bf.main.description',
        'MUGSR',
        'minecraft:fortune',
        'sb_bf.form.table.title',
        'sb_bf.unlocked.text.message',
        'PsvdM',
        'minecraft:villager_v2',
        'NOITa',
        'WOekt',
        'warden_plushie',
        'sb_bf.form.oak_framed_glass_pane.title',
        'sb_bf.form.decorated_wool.title',
        'WLPAn',
        'WogUz',
        'sb_bf.photobook.description.piglin',
        'sb_bf:jungle_glass_door',
        'sb_bf.form.oak_framed_glass.description.1',
        'textures/sb/bf/form/sink',
        'Yjcpj',
        'kCBVF',
        'lmScL',
        'sb_bf:curtain.close',
        'afterEvents',
        'Head',
        'bmbUU',
        'runCommand',
        'minecraft:pale_oak_leaves',
        'rUYLW',
        'vLocM',
        'sb_bf.camera.error.no_paper',
        'NXCuD',
        'mnvyI',
        'lDeJR',
        'dYrsv',
        '_paint',
        'YsBsE',
        'Piglin',
        'wJoft',
        'minecraft:quartz_stairs',
        'frog',
        'sb_bf.photobook.description.wither',
        'MQcvg',
        'handleItemUse',
        'vyMsG',
        'minecraft:frog_spawn',
        'minecraft:white_tulip',
        'record.mellohi',
        'sequence',
        'registerSubclass',
        'ifgiz',
        'sb_bf.form.furniture_table.description.1',
        'GbjjY',
        'minecraft:deepslate_brick_stairs',
        'itOXX',
        'SrSMF',
        'EgrLh',
        'KXOoJ',
        'ilDNf',
        'IeWZf',
        'minecraft:warped_fence',
        'sb_bf.form.jars.title',
        'minecraft:flowering_azalea',
        'scqTU',
        'descriptionLabel',
        'floorAll',
        'cancelOnSneak',
        'sb_bf:furniture_table',
        'minecraft:music_disc_otherside',
        'CQich',
        'rkRKZ',
        'ydckK',
        'dot',
        'close.bamboo_wood_fence_gate',
        'hNlDV',
        'ErzuN',
        'ptRAL',
        'translateString',
        'GloIo',
        'EIVmO',
        'Chest',
        'SERwr',
        'OHvdd',
        'yHles',
        'pdyYb',
        'dfnLH',
        'zrElP',
        'fciia',
        'WcgDu',
        'sb_bf:wither_picture',
        'sb_bf:globe.spin',
        ':animation',
        ':table_connect',
        'dog',
        'minecraft:tuff_stairs',
        'zGftT',
        'nnana',
        'textures/sb/bf/items/painting/warden',
        'ShGIh',
        'rqJwP',
        'time',
        'areStatesValid',
        'textures/sb/bf/form/plushie_wolf',
        'sb_bf.form.honey_jar.description.1',
        'onPlace',
        ':mirror_door',
        'disc_player',
        'gdJtP',
        'World',
        'copper_trophy',
        'blockExists',
        'entity.wither.name',
        'minecraft:dark_oak_door',
        'VHnVl',
        'pVitE',
        'cJIxY',
        'sb_bf:oak_special_fence',
        'minecraft:birch_slab',
        'Entity:\x20',
        'sb_bf:frog_statue',
        'black_chandelier',
        'rhLmp',
        'ensureSingleStorageEntity',
        'getBlockId',
        'KssIw',
        'minecraft:lime_stained_glass',
        'DtJIX',
        'sb_bf.form.decorated_wool.description.1',
        'oHZQE',
        'sb_bf:paint_brush',
        'rEnZl',
        'minecraft:player',
        'placeParticles',
        '0|5|3|4|2|1',
        'bZxgY',
        'textures/sb/bf/form/stool',
        'worldInitialize',
        'sb_bf:warped_glass_door',
        'textures/sb/bf/items/picture/frog',
        'minecraft:beetroot_soup',
        'SaRfn',
        'playSoundOnEachBlock',
        'silk_touch',
        'kogQV',
        'sb_bf:playing',
        'minecraft:soul_torch',
        'sb_bf.form.disc_player.description.1',
        'minecraft:small_dripleaf',
        'minecraft:torchflower',
        'Czdfj',
        'YIHsM',
        'onScreenDisplay',
        'uJmQI',
        'lrzMo',
        'JZFRg',
        'HDvDl',
        'handleScriptEventTrigger',
        'minecraft:diorite_stairs',
        'qYVMt',
        'achievementOptions',
        'FRVhT',
        'place',
        'HiVnR',
        'textures/sb/bf/form/statue_villager',
        'minecraft:rose_bush',
        'rUitN',
        'BGpUC',
        'minecraft:cat',
        'sb_bf.form.warden_painting.description',
        'processInteract',
        'itemUseOn',
        'unlocked',
        'rzSjH',
        'durability',
        'EazHW',
        'uNAgO',
        'getBlock',
        'qsoSI',
        'JhyhM',
        'minecraft:music_disc_creator_music_box',
        'MtKCl',
        'sb_bf.photobook.description.wolf',
        'minecraft:carrots',
        'get',
        'lJHjE',
        'locked',
        ':leg_sw',
        'cornflower',
        'getComponent',
        'light_blue_candle_holder',
        'sb_bf.form.seats.description.1',
        'handleBeforePlacement',
        'sb_bf.form.chandelier.title',
        'minecraft:black_bundle',
        'kLKBA',
        'zvBKM',
        'mTpoa',
        'xKlEv',
        'sb_bf.form.storage_blocks.description.1',
        'minecraft:pale_oak_fence',
        'lIxqq',
        'sb_bf:crimson_special_fence',
        'geCxd',
        'triggers',
        'omogv',
        'inner_left',
        'close.cherry_wood_door',
        'UYToy',
        'FcFSA',
        'forEach',
        'DSbBe',
        'Ftcji',
        'WVarE',
        'TvpAh',
        'distanceTo',
        'QqjUQ',
        'villager_statue',
        'minecraft:blue_stained_glass',
        'RdurM',
        'minecraft:diorite_slab',
        'EeKBM',
        'QHXZi',
        'sb_bf.camera.picture_taken',
        'getCenterLocation',
        'showFormSelector',
        'HBHew',
        'sb_bf.form.creeper_plushie.description',
        'sb_bf:statue',
        'modalForms',
        'LwmRP',
        'sb_bf:creaking_picture',
        'textures/sb/bf/form/statue_wolf',
        'minecraft:light_gray_stained_glass_pane',
        'LegMS',
        'zaQFy',
        'entityKillForms',
        'ShjrH',
        'addLevels',
        'YdDGe',
        'sb_bf:sink',
        ']\x20Initialized!',
        'sb_bf:acacia_special_fence_gate',
        'door_cabinets',
        'dpBal',
        'hasCraftingTableRecipe',
        'TGGKY',
        'minecraft:green_stained_glass_pane',
        'wolf_plushie',
        'CLbWZ',
        'wgIEm',
        'textures/sb/bf/items/picture/dolphin',
        'getInteractionForEntity',
        'sb_bf.form.flower_pot.description.1',
        'rhCOs',
        'random.lever_click',
        'sb_bf.form.wide_planks.title',
        'aDPwo',
        'Max\x20curtain\x20update\x20limit\x20reached:\x20',
        'sb_bf.form.scarecrow.description.1',
        'yxuLr',
        'sb_bf:warped_shutter',
        'record.5',
        'DvZaw',
        'buttonLabel',
        'Bmlun',
        'minecraft:spruce_slab',
        'ARESX',
        'sMhtq',
        'PlayerJoinModule',
        'gxjLu',
        'peony',
        'sb_bf.form.glass.title',
        'main',
        'WulEw',
        'sb_bf.locked.description.dolphin',
        'OqyOI',
        'yiqai',
        'SGBNX',
        'gedYr',
        'horse',
        'sb_bf.form.scarecrow.title',
        'pFDjm',
        'sb_bf:mangrove_special_fence',
        'Dolphin',
        'books',
        'minecraft:cherry_slab',
        'oak_framed_glass',
        'isSprinting',
        'sb_bf.form.fences.title',
        'tnt_minecart',
        'Error\x20updating\x20pole\x20state\x20downwards:\x20',
        'minecraft:music_disc_mall',
        'QqhtT',
        'Mimxv',
        'sb_bf.form.flower_pot.title',
        'minecraft:lime_bundle',
        'parse',
        'xqrmk',
        'UPABF',
        'OkJFt',
        'sb_bf:special_warden_painting',
        'minecraft:music_disc_mellohi',
        'sb_bf.form.tutorial.description.2',
        'JJBip',
        'sb_bf:chandelier_flame',
        'useItem',
        'Error\x20updating\x20upward\x20connection:\x20',
        'minecraft:spruce_fence',
        '.form.tameable',
        'JEIFG',
        ':connect_north',
        'minecraft:water_bucket',
        'rhbWG',
        'minecraft:light_blue_stained_glass',
        'call',
        'remove',
        'brown_candle_holder',
        'mushroom_stew',
        'cctEN',
        'sb_bf.locked.description.creaking',
        'sb_bf:mangrove_glass_trapdoor',
        'addEffect',
        'BaanW',
        'EhRnB',
        'excludeAir',
        'blue',
        'minecraft:polished_tuff_stairs',
        'FlZEE',
        'minecraft:red_sandstone_stairs',
        'minecraft:sea_pickle',
        'sb_bf.form.framed_glass.title',
        'YXRLj',
        'handleHoverParticle',
        'body',
        'errorMessage',
        'left',
        'rfHgM',
        'pNwbb',
        'NmzSc',
        'Error\x20during\x20storage\x20cleanup:',
        'stringify',
        'green_chandelier',
        'sb_bf.form.tutorial.title',
        'sb_bf.form.lamps.title',
        'white_candle_holder',
        'sb_bf.form.oak_framed_glass.title',
        'TPseB',
        'sb_bf.form.lights.title',
        ':top',
        'wzAvV',
        'uOZnN',
        'dpAkH',
        'AvGcK',
        'MjgkZ',
        'cTwto',
        'sb_bf.form.lights.description.1',
        'birch',
        'EyZfD',
        'yoeVG',
        'seats',
        'tile.sb_bf:wolf_plushie.name',
        'YnUpK',
        'down',
        'LOBua',
        'ghBKA',
        'vIOFl',
        'MuFqJ',
        'BjGrH',
        'KcNDn',
        'warden_painting',
        'HvfOz',
        'setDynamicProperty',
        'minecraft:deadbush',
        'minecraft:jungle_door',
        'KRyDc',
        'sb_bf:flower',
        'textures/sb/bf/form/glass_door',
        'KRfqw',
        'playerInteractWithBlock',
        'initialize',
        ':connect_chair',
        'rotate',
        'minecraft:poppy',
        ':condition_check',
        ':door_mirror',
        'zDucW',
        'ROUss',
        'sb_bf.form.pig_plushie.description',
        'bUspk',
        'aCDDw',
        'Error\x20checking\x20block:\x20',
        'name',
        'sb_bf.form.sofa.title',
        'PZDZv',
        'MNtES',
        'bvQdT',
        'pZMRx',
        'bcRNv',
        'iYlzU',
        'minecraft:polished_tuff_slab',
        '_paint_brush',
        'text',
        'textures/sb/bf/form/herringbone_planks',
        'BewPy',
        'minecraft:brown_stained_glass',
        'Error\x20in\x20pole\x20update\x20propagation:\x20',
        'DIGfI',
        'record_pigstep',
        'minecraft:flint_and_steel',
        'checkAdjacentBlocks',
        'minecraft:cobblestone_slab',
        'GwUtp',
        'rxsMC',
        'sb_bf:birch_glass_trapdoor',
        'red_chandelier',
        'rJEZw',
        'minecraft:allium',
        'error',
        'West',
        'record.cat',
        'TXWPe',
        '.form.stonecutter',
        'slime_jar',
        'MzgEo',
        'North',
        'wwvPA',
        'handleSit',
        '.form.recipe',
        'rotateY',
        'tile.sb_bf:wither_painting.name',
        'onUse',
        'sb_bf:spruce_special_fence',
        'sb_bf.form.special_glass_pane.description.1',
        'minecraft:cherry_fence',
        'plank_variants',
        'register',
        'number',
        'dlRli',
        'IaDfF',
        'textures/sb/bf/items/picture/horse',
        'getEntitiesFromViewDirection',
        'tile.sb_bf:pig_plushie.name',
        'minecraft:gray_stained_glass',
        'XPnYB',
        'adjecentUpdate',
        'registerForms',
        'minecraft:end_rod',
        '13|11|9|7|8|12|1|4|0|5|6|10|3|2',
        'record_ward',
        'tkqvq',
        'xp_orb',
        'xgVNM',
        'fwkfY',
        'updateBlockConnectionStates',
        'vZTkV',
        ':cabinet_horizontal_connect',
        'aeDOs',
        'sb_bf.form.drawer_cabinets.description.1',
        'ifmzO',
        'photobook',
        'keepOnDeath',
        'PkgtG',
        'lBBtN',
        'BKQLX',
        'message',
        'minecraft:equippable',
        'JgrxR',
        'mangrove',
        'items',
        'MOKwo',
        'minecraft:wolf',
        'rOwyb',
        'trophies',
        'nBfsm',
        'zbKdk',
        'handleWallBreak',
        'formValues',
        'sb_bf:dark_oak_special_fence',
        'placeholder',
        'minecraft:unbreaking',
        'interact',
        'thrown_trident',
        'sb_bf.form.books.title',
        'sb_bf.locked.description.warden',
        'actionbar',
        'jIBcK',
        'pCSnS',
        'extinguish.candle',
        '/stopsound\x20@s\x20random.click',
        'sb_bf:zombie_statue',
        'SDeee',
        'brown_chandelier',
        'sb_bf:disc_player',
        'dark_oak',
        'vTSmn',
        'sb_bf.form.ink_and_quill.title',
        'close',
        'sb_bf:cherry_shutter',
        'BlockModule',
        'ReCzf',
        'minecraft:acacia_sapling',
        'minecraft:brick_slab',
        'zIpfN',
        'isAir',
        'UclZb',
        'okIbG',
        'UMPaF',
        'torchflower',
        'mvQmM',
        '500272lulxuE',
        'minecraft:snow_layer',
        'mBHqA',
        'playerInteractWithEntity',
        'sb_bf.form.candle_holder.description.1',
        'DnqIz',
        'nOLIp',
        'selection',
        'textures/sb/bf/items/picture/villager',
        'Creeper',
        'auyFh',
        'daMrm',
        'wDjzX',
        'CXSyO',
        'sb_bf.form.recipes.title',
        '.form.no_food',
        'ycLAt',
        ':base',
        'length',
        'sb_bf.form.golden_ingot.title',
        'fjnrV',
        'use.honey_block',
        'MrmKC',
        'WYSmQ',
        'zwNQA',
        'open.nether_wood_fence_gate',
        'placeBlock',
        'MfKqd',
        'iwvtP',
        'ijhuh',
        'CzjlW',
        'MrDoV',
        'WoROu',
        'oneBi',
        'dHvNa',
        'Enderman',
        'FHwTm',
        'jQTFs',
        'textures/sb/bf/form/wide_planks',
        'minecraft:crimson_door',
        ':multiblock',
        'entity.sb_bf:chicken_jockey.name',
        'sb_bf.form.pickle_jar.title',
        'sb_bf.form.creaking_painting.description',
        'xOPUg',
        'sb_bf:bowl',
        'setLowState',
        'TTMlk',
        'CANYt',
        'textures/sb/bf/form/golden_ingot',
        'KGFoc',
        'inventory:',
        'LPcmd',
        'gxxse',
        'HwbNF',
        'close.nether_wood_trapdoor',
        'GObwC',
        'Villager\x20Statue',
        'foerM',
        'oBWXk',
        'storage_blocks',
        'sb_bf:acacia_shutter',
        'ZnlcH',
        'uwbgV',
        'nPofx',
        'minecraft:closed_eyeblossom',
        'set',
        'TUXgx',
        'handleFinalState',
        'dim_',
        'SLNvG',
        'sb_bf:crimson_glass_trapdoor',
        'private',
        '_item',
        'hAcqf',
        'minecraft:azure_bluet',
        'getBlockFromViewDirection',
        'zbKvA',
        'sb_bf.form.globe.description.1',
        'bamboo',
        'eFQge',
        'BMMyK',
        'sb_bf.form.chair.title',
        'cookingPots',
        'handleFenceGatePlacement',
        'entity.creaking.name',
        'RBuaL',
        'dNaOh',
        'registerCustomComponent',
        'vZdEO',
        'QLoxl',
        'textures/sb/bf/form/plushie_enderman',
        'EwEpC',
        'ReSUq',
        'minecraft:mossy_cobblestone_slab',
        'MOEFI',
        'UKDYf',
        'Creeper\x20Statue',
        'NnJhX',
        'DTHKO',
        'north',
        'purple',
        'entity.cat.name',
        'terracotta_vase',
        'textures/sb/bf/form/decorated_wool.category',
        'bdovl',
        'recipes',
        'filter',
        'Legs',
        'sb_bf.photobook.statue.info.2x3',
        'CSejm',
        'tile.',
        'toLowerCase',
        'hurtEntity',
        'JfHNF',
        'iLjnn',
        'minecraft:basic_smoke_particle',
        'textures/sb/bf/form/oak_framed_glass',
        'UhaTE',
        'tpGTD',
        'Kccsp',
        'Jqued',
        'MwJBP',
        'TpUHA',
        'wither',
        'PyEQg',
        'qHdll',
        'dOcky',
        'uURlf',
        'sOWct',
        'UMQIy',
        'minecraft:music_disc_ward',
        'textures/sb/bf/form/decorated_carpet',
        'excludeFaces',
        'TFFHN',
        'ZcPsR',
        'textures/sb/bf/items/picture/golem',
        'blhuF',
        'sb_bf:oak_special_fence_gate',
        'jungle',
        'HuaxH',
        '\x20&\x20',
        'IZKnU',
        'sofa',
        'sb_bf.photobook.statue.info',
        'pink',
        'Dkgju',
        'center',
        '\x0aAngle:\x20',
        'ZAEQl',
        'frog_statue',
        'findCookingPot',
        'XqLZh',
        'setItem',
        'bxqyr',
        'entries',
        'nChaC',
        'gXqel',
        'textures/sb/bf/items/picture/enderman',
        'storage',
        'item.book.page_turn',
        'golden_ingot',
        'state',
        'xBvFG',
        'onCompleteUse',
        'minecraft:red_mushroom',
        'minecraft:bowl',
        'minecraft:polished_deepslate_slab',
        'Storage',
        'WNxoL',
        'sb_bf.form.tiled_glass.description.1',
        'ZhvaC',
        'placeSound',
        'XcdKH',
        'minecraft:music_disc_wait',
        'XRhzK',
        'McfQK',
        'textures/sb/bf/form/rabbit_stew',
        'orange_chandelier',
        'grtwc',
        'hKMAw',
        'chat',
        'entity.horse.name',
        'normalize',
        'amount',
        'fFzgK',
        'iUISG',
        'RDdHg',
        'event',
        'lights',
        'getItem',
        'sb_bf:cherry_glass_door',
        'uUJUj',
        'sb_bf:bamboo_special_fence_gate',
        'FsHKp',
        'minecraft:crimson_fungus',
        'minecraft:light_blue_bundle',
        'inner',
        'xlsrz',
        'MOMkX',
        'ZWYry',
        'IlGPX',
        'KPmyE',
        'sb_bf:bamboo_shutter',
        'iDbVa',
        'minecraft:andesite_stairs',
        'minecraft:reeds',
        'hRfqj',
        'minecraft:azalea_leaves',
        'sb_bf.form.special_fence_gate.description.1',
        'handleTick',
        'lootTable',
        'pink_chandelier',
        'minecraft:bucket',
        'lastEffectTick',
        'minecraft:acacia_door',
        'tPMrI',
        'IovGm',
        'IskQu',
        'minecraft:oxeye_daisy',
        'UMsfz',
        'getEffectsForBlock',
        'empty',
        'sb_bf.photobook.description.creaking',
        'sb_bf.form.cookie_jar.title',
        'sdMGa',
        'onlyOnBlock',
        'psAcy',
        'getViewDirection',
        'spruce',
        'GattS',
        'VDisR',
        'minecraft:music_disc_tears',
        'nqfRU',
        'rVFaY',
        'sb_bf:crimson_glass_door',
        'chest_boat',
        'permutation',
        'sb_bf.scarecrow.error',
        'OAPzX',
        'RJRrt',
        'sb_bf.locked.description.chicken_jockey',
        'handleOnPlace',
        'slczd',
        'LLMwy',
        'wwxwX',
        'TtHda',
        ':mirror_cabinet',
        'aKSqj',
        '\x20water\x20destroy',
        'sb_bf.photobook.description.villager',
        'textures/sb/bf/form/cookie_jar',
        'tile.sb_bf:villager_plushie.name',
        'sb_bf.locked.description.cat',
        'entity.warden.name',
        'KJAvA',
        'gGcLY',
        'minecraft:yellow_stained_glass',
        'fnWeY',
        'fromMC',
        'stateId',
        'sb_bf:lit',
        'minecraft:dark_oak_fence',
        'ceVMd',
        'textures/sb/bf/form/plushie_cat',
        'sGDqX',
        'FSler',
        'sb_bf:oak_shutter',
        'CXcPh',
        'record.mall',
        'hasEnchantment',
        'HFDdm',
        'dtxEU',
        'GPjIC',
        'SLuVZ',
        'includes',
        'wcziw',
        'MHfRL',
        'enderman_plushie',
        'foOyf',
        'minecraft:light_blue_stained_glass_pane',
        'HJvim',
        'OVzfS',
        'MuCuY',
        'NVPwO',
        'bCBzC',
        ']\x20Error:\x20',
        'dIhmC',
        '0|3|1|2|5|4',
        'tGAWy',
        'ekSDO',
        'JMhdq',
        'yFkaw',
        'clearTimeouts',
        'OYrcH',
        ':reset_forms',
        'generateBlock',
        'minecraft:deepslate_brick_slab',
        'ehNFi',
        'close.bamboo_wood_door',
        'TxMmm',
        'minecraft:music_disc_relic',
        'iOzJo',
        'corner_ne',
        'green',
        'creeper',
        'CfiWC',
        'record.11',
        'jzoUp',
        'BnKwT',
        'toFixed',
        'cqGbC',
        'conditions',
        'minecraft:dark_oak_stairs',
        'sb_bf.form.ink_and_quill.description.1',
        'indexOf',
        'FKICy',
        'blue_chandelier',
        'receiveItem',
        'KhpvT',
        'uPwEy',
        'IajWc',
        'nbUwO',
        '810mfeUcl',
        'handleBreak',
        'fEmyP',
        'bPTiV',
        'ealKa',
        'LazMv',
        'finalState',
        'ceil',
        'ayZSm',
        'DkJqt',
        'pale_oak',
        'toastTexture',
        'minecraft:brown_mushroom',
        'xGsgZ',
        'find',
        'add',
        'iconPath',
        'rotateX',
        'szFiN',
        'framed_glass',
        'textures/sb/bf/items/picture/creeper',
        'pmLbc',
        'cVWaQ',
        'record_far',
        'onDestroy',
        'JqOSm',
        'minecraft:orange_bundle',
        'rvlSB',
        'dig.fungus',
        'open.bamboo_wood_fence_gate',
        'sb_bf.form.copper_trophy.description.1',
        'lilac',
        'CxpFZ',
        'minecraft:torch',
        'qMyPe',
        'sb_bf.form.golden_ingot.description.1',
        'BTars',
        'adjustLocationForDirection',
        'lang',
        'jhOEx',
        ':pole',
        'vYPuR',
        'record_precipice',
        '\x0a§r',
        'sb_bf.photobook.statue.info.1x1',
        'lbxTQ',
        'tile.sb_bf:enderman_plushie.name',
        'ZubME',
        'URJgJ',
        'MQCPT',
        'applyMultipleStates',
        'zcVbt',
        'FmmjY',
        'decorated_wool',
        'AAsej',
        'RLNRI',
        'applyTransform',
        'horse_statue',
        '.form.custom.recipe',
        'blockMatchesState',
        'eWvKg',
        'blockPlace',
        'hQjEQ',
        'sb_bf:copper_ingot_pile',
        'textures/sb/bf/form/special_fence_gate',
        'sb_bf:scarecrow.thud',
        'QSxrU',
        'ISPPG',
        'textures/sb/bf/form/plushie_pig',
        'sb_bf.form.framed_glass_pane.description.1',
        'WdaMm',
        'PXOJm',
        'Sahvx',
        'sb_bf.form.tiled_glass_pane.title',
        'fences',
        'keys',
        'LRRLI',
        'all',
        'PNgbW',
        'loadStructure',
        '\x20air\x20destroy',
        'sb_bf.form.wolf_plushie.description',
        'textures/sb/bf/form/shutter',
        'minecraft:green_stained_glass',
        'gtbNn',
        'VQrQO',
        'south',
        'qMoOm',
        'behavior',
        'ftQfn',
        'Error\x20updating\x20pole\x20visibility:\x20',
        'wUkBg',
        'GsNqQ',
        'KfvbD',
        'drops',
        'MLESZ',
        'sb_bf:books',
        'pGmVr',
        'textures/sb/bf/items/picture/wither',
        'AQeXS',
        'AxZSy',
        'jars',
        'LQpGF',
        'pickle_jar',
        'IAxPr',
        'defineProperty',
        'zSCUE',
        'isMainForm',
        'DlckS',
        '.form.food',
        'tile.sb_bf:ender_dragon_painting.name',
        'toast.',
        'VlGFM',
        'textures/sb/bf/form/globe',
        'lHTwN',
        'wcMTC',
        'sink',
        'lzdWU',
        'Oqsvl',
        'GAyJR',
        'sb_bf.form.mushroom_stew.description.1',
        'mob.armor_stand.break',
        'ywFvY',
        'open.nether_wood_trapdoor',
        '.form.not_compostable',
        'references',
        'target',
        'AovlL',
        'black',
        'slider',
        'sb_bf.form.special_fence.description.1',
        'visualEffects',
        'Down',
        'wGOJh',
        'dqMfn',
        'VcdlT',
        'minecraft:lilac',
        'MPEkD',
        'max',
        'oKADU',
        'spawnEntity',
        'explosion',
        'sb_bf.photobook.description.frog',
        'minecraft:durability',
        '1105821bTYhsN',
        '_sofa',
        'sb_bf.form.furniture_table.title',
        'minecraft:gray_bundle',
        'lily_of_the_valley',
        'excludeLiquid',
        'sb_bf.form.stew.description.1',
        'wMXxH',
        'rKqjH',
        'sb_bf:camera.take_picture',
        'minecraft:spore_blossom',
        'lime_chandelier',
        'EhNqb',
        '.form.no_biomes',
        'UOdXt',
        'bBVhv',
        'cGLWX',
        'llvEF',
        'minecraft:quartz_slab',
        ':connect',
        'Select\x20a\x20guide',
        'YRPiT',
        'getRiders',
        'minecart',
        'record_11',
        'BimlN',
        'PpTRW',
        'AwpdM',
        'minecraft:dark_oak_slab',
        'HXcli',
        'hit.iron',
        'white_tulip',
        ':\x20§7',
        'world',
        ',\x20\x0a',
        'tile.sb_bf:creeper_plushie.name',
        'textures/sb/bf/form/pickle_jar',
        'curtains',
        'WKzEh',
        'zHIEk',
        'isTameable',
        'west',
        'textures/sb/bf/form/oak_framed_glass_pane',
        'sb_bf.form.framed_glass.description.1',
        '3|2|5|1|0|4',
        'sb_bf.form.candle_holder.title',
        'AyxmQ',
        'explodedBlockPermutation',
        'sb_bf:dolphin_statue',
        'RewFs',
        'EAPxN',
        'ZFJCL',
        'xWtFC',
        'textures/sb/bf/items/picture/chicken_jockey',
        'wDhXW',
        'itjMe',
        'OwDBd',
        'bWJYf',
        'itemUse',
        'subtract',
        'sb_bf.photobook.description.pig',
        'sb_bf.form.tutorial.description.4',
        'determineState',
        'oak',
        'minecraft:andesite_slab',
        'minecraft:andesite',
        'sb_bf:count',
        'FWoaZ',
        'yDYmY',
        'subscribe',
        'dSLOb',
        'nAaIU',
        'YGuxD',
        'minecraft:warden',
        'zHCTd',
        'bZeis',
        'ZNMPE',
        'getEquipment',
        'Qpqeh',
        'oKXcF',
        'LlELP',
        'bottom',
        '.form.no_drops',
        'clone',
        'minecraft:purple_stained_glass_pane',
        'iKaqt',
        'lacrn',
        'arrow',
        'minecraft:red_tulip',
        'sb_bf:multiblock',
        'ignoreInCreative',
        'efAwz',
        'minecraft:flowing_water',
        'warn',
        'toastTitle',
        'IwRJb',
        'random.burp',
        'HqcEk',
        'BKkCL',
        'record_blocks',
        'sb_bf.form.rabbit_stew.title',
        'minecraft:iron_bars',
        'herringbone_planks',
        'tiled_planks',
        'puqQv',
        'wPZjS',
        'sb_bf:dark_oak_shutter',
        'Failed\x20to\x20spawn\x20armor\x20item:\x20',
        'TgyOw',
        'unlockFormForTrigger',
        'entity.piglin.name',
        'dQJqW',
        'HSIBF',
        'Dkbhp',
        'blocks',
        'minecraft:villager_happy',
        'sb_bf.form.zombie_plushie.description.1',
        'textures/sb/bf/form/statue_zombie',
        'stonecutter',
        'tile.sb_bf:creaking_painting.name',
        'sound',
        'getEntities',
        'round',
        'kYyys',
        'blockInteract',
        'wMxLR',
        'zZGBm',
        'handleBackNavigation',
        'registerBehavior',
        'MhahY',
        'sb_bf:yellow_glazed_terracotta_vase',
        'cat_plushie',
        'minecraft:dark_oak_leaves',
        'sb_bf:blue_glazed_terracotta_vase',
        'dVtsc',
        'oxeye_daisy',
        'hasPoleAbove',
        'sb_bf.form.storage.title_2',
        'getBlockStates',
        'getSlot',
        'urjOZ',
        'tile.sb_bf:dolphin_plushie.name',
        'qOfii',
        'TUknb',
        'runInterval',
        'sb_bf.form.jars.description.1',
        'setPermutation',
        'QLwnQ',
        'GGOjk',
        'jHlGn',
        'vCWST',
        'end',
        'white',
        'getBlockKey',
        'ttzbG',
        'minecraft:zombie',
        'lrsRx',
        'mEGOZ',
        'DfzXa',
        'spawnCallback',
        'textures/sb/bf/form/plushie_warden',
        'damageSource',
        'blockInteractForms',
        'tVbim',
        'entity.pig.name',
        'IoCdn',
        'sb_bf:jungle_special_fence',
        'minecraft:spruce_door',
        '.form.rideable',
        'min',
        'sb_bf.form.awning.description.1',
        'lime',
        'qCzda',
        'dPqud',
        'sb_bf:dark_oak_glass_trapdoor',
        'armor:',
        'minecraft:mossy_stone_brick_slab',
        'VhCKC',
        'SpFpg',
        'sb_bf:mushroom_stew',
        'red_tulip',
        'Rbblq',
        'getOffset',
        'minecraft:villager_angry',
        ':storage_open',
        ':curtain',
        'Puout',
        'QqFkq',
        'GJLSJ',
        'textures/sb/bf/form/lamp',
        'PhJvv',
        'minecraft:creeper',
        'getInteractionForBlock',
        'dynamicProperty',
        'hakGl',
        'hwVIx',
        'East',
        'minecraft:lily_of_the_valley',
        'title',
        'minecraft:cyan_stained_glass',
        'jICyA',
        'position',
        'enchantable',
        'minecraft:pink_bundle',
        'CekJB',
        'componentId',
        'GLfsU',
        'Feet',
        'validDirections',
        'sendMessage',
        'FdjrS',
        'CQQyy',
        'sb_bf.form.tiled_glass_pane.description.1',
        'stateDurations',
        'zoYrR',
        'oFiwm',
        'hbpfC',
        'UUTRk',
        'ender_dragon_painting',
        'getLore',
        ':unlockedForms',
        'east',
        'ItGfK',
        'OanEf',
        'vrFLe',
        'fATSB',
        'orange_tulip',
        'minecraft:cherry_door',
        'corner_nw',
        'YvOxe',
        'sb_bf.form.trophies.description.1',
        'setblock\x20',
        'onUseOnEntityAfter',
        'marBO',
        'getEnchantments',
        'sb_bf.form.tiled_planks.title',
        'hasItem',
        'sb_bf:bamboo_glass_trapdoor',
        'minecraft:yellow_stained_glass_pane',
        'DhqGy',
        'gJrGo',
        'IlUmE',
        'sb_bf.form.globe.title',
        'stew',
        'PnkRE',
        'record.lava_chicken',
        'oMJZp',
        'textures/sb/bf/form/modular',
        'IxzcC',
        'dPzjv',
        'VmTpX',
        'warped',
        'OojlC',
        'EQyNF',
        'hoverParticle',
        'zombie_statue',
        'sb_bf',
        'Eqqet',
        'light_gray_chandelier',
        'unlockReferences',
        'sb_bf:iron_golem_statue',
        'random.orb',
        'sb_bf.form.awning.title',
        'hvLsv',
        'oABHS',
        '234mocWUk',
        'random.break',
        'PYHXJ',
        'achievement',
        '125237IKYdik',
        'minecraft:rideable',
        'qgzpN',
        'entity.enderman.name',
        'end_left',
        'record.ward',
        'xFzIm',
        'minecraft:spruce_stairs',
        'candle_holder',
        'PgWKW',
        'textures/sb/bf/form/books',
        'PUtaQ',
        'sb_bf.camera.error.no_valid_target',
        'minecraft:tall_grass',
        'minecraft:cobblestone_stairs',
        'record.precipice',
        'hPatX',
        ':low',
        'chicken_jockey_statue',
        'handleDestroy',
        'distance',
        'close.nether_wood_door',
        'record_strad',
        'minecraft:spruce_leaves',
        'creative',
        'record_otherside',
        '\x0aDistance:\x20',
        'ZGdlA',
        'EPxWf',
        'minecraft:tuff_slab',
        'OIGfB',
        'magenta_chandelier',
        'equals',
        'ZvecN',
        'textures/sb/bf/form/shelf',
        'minecraft:enchantable',
        'dolphin_statue',
        'UAdHV',
        'GeDjD',
        'OAYMU',
        'xxpqP',
        'sb_bf.form.gold_trophy.title',
        'minecraft:oak_sapling',
        'sb_bf:cherry_glass_trapdoor',
        '\x22\x20start_riding\x20@s',
        'minecraft:pitcher_plant',
        'tYSxJ',
        'mainForms',
        'Frog\x20Statue',
        'sb_bf.form.special_glass_pane.title',
        'qXrVN',
        'lwfLy',
        'sb_bf.form.oak_framed_glass_pane.description.1',
        'minecraft:cave_vines_head_with_berries',
        'yynjr',
        'ensureSingleStorageEntityByDimension',
        'nnYur',
        'CookingPotModule',
        'yellow_chandelier',
        'ZvtxC',
        'closed_eyeblossom',
        '.form.breedable',
        'jqJTp',
        'cat',
        'tag',
        'PZPLK',
        'LDDTR',
        'jAtoM',
        'laZwM',
        'lasCj',
        'getAllStates',
        'reward',
        'VafDS',
        'sb_bf.form.netherite_ingot.description.1',
        'raSoB',
        'sb_bf.locked.description.enderman',
        'JjLro',
        'OXCDl',
        'ceGHF',
        'HdEyC',
        'entity.creeper.name',
        'dFFyc',
        'sb_bf:warped_special_fence_gate',
        'BCZre',
        'EkbvR',
        'minecraft:chicken',
        'MQDBr',
        'sb_bf.photobook.description.dolphin',
        'ReCsH',
        'EldUV',
        'textures/sb/bf/form/statue_creeper',
        'player',
        'sb_bf:pink_glazed_terracotta_vase',
        'textures/sb/bf/form/ink_and_quill',
        'getAttachedBlocksLocations',
        'iron_trophy',
        'sb_bf.form.herringbone_planks.title',
        'pqTFv',
        'minecraft:sandstone_slab',
        'iTDMy',
        'minecraft:birch_door',
        'sb_bf.form.sink.description.1',
        'magenta',
        'jAFRc',
        'sb_bf.form.copper_trophy.title',
        'entityHurt',
        'top',
        'special_fence_gate',
        'xjHNW',
        '_chair',
        'sb_bf:green_glazed_terracotta_vase',
        'sb_bf.form.iron_trophy.title',
        'destroyBlock',
        'ZPeKm',
        'sb_bf:cherry_special_fence',
        'gdrDi',
        'Isbfi',
        'minecraft:blue_orchid',
        'getRotationFromCardinalDirection',
        'OorXF',
        'wikiInfo',
        ':seat',
        'open.wooden_trapdoor',
        'sb_bf.form.wallpaper_carpet.description.1',
        'charCodeAt',
        'sb_bf:warped_glass_trapdoor',
        'rotateOffsetByDirection',
        'xUlbx',
        'MsqCu',
        'fUIBr',
        'ndwTR',
        'setLore',
        'ysCpX',
        ':debug',
        'runTimeout',
        ':has_rider',
        'xQjlf',
        'CheCw',
        '1382436COJvMl',
        'MMJeb',
        'enchantments',
        'cpAFy',
        'block',
        'sb_bf:has_cooldown',
        'sb_bf:jar_empty',
        'size',
        'frjxX',
        'zbySh',
        'minecraft:music_disc_creator',
        'CHICKEN\x20JOCKEY\x20DETECTED',
        '§cYou\x20need\x20at\x20least\x203\x20blocks\x20of\x20andesite\x20to\x20carve\x20this\x20statue.',
        'sin',
        'gJSql',
        'end_right',
        'wSBKa',
        'registerActionBasedEvents',
        'translateStrings',
        'Wolf\x20Statue',
        'FBwIg',
        'minecraft:black_stained_glass_pane',
        'some',
        'JPoPB',
        'VrQmW',
        'sb_bf.form.stool.title',
        'sb_bf.photobook.statue.info.1x2',
        'dAwiA',
        'minecraft:frog',
        'gray_candle_holder',
        'BehAp',
        'close.nether_wood_fence_gate',
        'sb_bf.form.rabbit_stew.description.1',
        'wiki',
        'NQPvi',
        'controls',
        'camera',
        'PlrtE',
        'collector_items',
        'damagingEntity',
        'JcNcr',
        'getLoc',
        'minecraft:blue_bundle',
        'TnUqU',
        'piINR',
        'convertInto',
        'llTyY',
        'handleInteract',
        'ZiihI',
        'LXaNK',
        'aBelo',
        'bJUaY',
        'SAVUi',
        'minecraft:deepslate_tile_slab',
        'dwvWn',
        'GMaFk',
        'wallpaper_carpet',
        'XGRuI',
        'jPIzl',
        'vUrMn',
        'sb_bf.form.ender_dragon_painting.description',
        'yVghn',
        'particles',
        'Delayed\x20neighbor\x20update\x20error:',
        'sb_bf:camera',
        'multiply',
        'wallBlocks',
        'textures/sb/bf/form/framed_glass',
        'Plozv',
        'sb_bf:mangrove_shutter',
        'canceled',
        'bFUBq',
        'NzDiJ',
        'textures/sb/bf/form/honey_jar',
        'yellow',
        'ukzEJ',
        'ZPsWr',
        'GMBXM',
        'VrFEr',
        'sb_bf.form.iron_ingot.description.1',
        'value',
        'isWall',
        'symbol',
        'gWlsw',
        'sb_bf:easel',
        'minecraft:music_disc_stal',
        'sb_bf.form.recipes.description.5',
        'messages',
        'minecraft:cobbled_deepslate_stairs',
        'eQCjn',
        'wrgrK',
        'PtjxN',
        'dUSyk',
        'getDirectionFromFace',
        'xGWoj',
        'jZOkn',
        'jQlrz',
        'VBwim',
        'xkraW',
        'NyCGi',
        'sb_bf.form.special_glass.title',
        'sb_bf:silver_glazed_terracotta_vase',
        'minecraft:pink_stained_glass_pane',
        'dWIsU',
        'entity.dolphin.name',
        'minecraft:lime_stained_glass_pane',
        'green_candle_holder',
        '.joined.first_time',
        'blockID',
        'VDcFZ',
        'counter',
        'qtnfy',
        'options',
        'textures/sb/bf/form/statue_horse',
        'brown',
        'sb_bf:purple_glazed_terracotta_vase',
        'source',
        'Horse',
        'sb_bf.form.iron_trophy.description.1',
        'playerBreakBlock',
        'sb_bf.form.honey_jar.title',
        'gJCoi',
        'place.moss',
        'minecraft:gray_stained_glass_pane',
        'LNadL',
        'resolve',
        'minecraft:waterlily',
        'sb_bf.color_variants',
        'tile.sb_bf:zombie_plushie.name',
        ':leg_nw',
        'minecraft:bamboo_door',
        'getDynamicPropertyIds',
        'sb_bf.form.counter.title',
        'IbKcc',
        'hGjvi',
        'minecraft:cornflower',
        'pYPNN',
        'MkdGu',
        'minecraft:warped_stairs',
        'handleIdleEffects',
        'sb_bf.form.ingots.title',
        'floor',
        'modular_blocks',
        'corner',
        'sb_bf:attack_mode',
        'TieeB',
        'sb_bf:special_ender_dragon_painting',
        'beetroot_soup',
        '.form.behavior.',
        'PJjMu',
        'sb_bf.form.copper_ingot.description.1',
        'minecraft:heart_particle',
        'values',
        'WcgjD',
        'orange',
        'minecraft:azalea',
        'zCaoH',
        'uMpfD',
        'light_gray_candle_holder',
        'LnxTv',
        'DjpPh',
        'break.bamboo_wood',
        'PLVzI',
        'sb_bf:dark_oak_special_fence_gate',
        'minecraft:cyan_bundle',
        'onUseOnAfter',
        'UlqFz',
        'NognK',
        'damage',
        'wXlBV',
        'textures/sb/bf/form/plushie_dolphin',
        'textures/sb/bf/form/drawer_cabinet',
        'opdkY',
        'EyfUz',
        'JjHrE',
        'minecraft:pale_oak_stairs',
        'blockPlaceForms',
        'getEnchantment',
        'minecraft:granite_slab',
        'sb_bf.form.fences.description.1',
        'WOqln',
        'LnSDU',
        'sb_bf.form.photobook.description.1',
        'getProperty',
        'dpUbH',
        ':connect_up',
        'vMIAs',
        'BEakL',
        'hopper_minecart',
        'jNWiH',
        'sb_bf.photobook.unlocked',
        'ingots',
        'minecraft:warped_door',
        'jpeCI',
        'from',
        'textures/sb/bf/form/flower_pot',
        'tJkxh',
        'sb_bf:cherry_special_fence_gate',
        'minecraft:inventory',
        'sb_bf.form.gold_trophy.description.1',
        'oEbeN',
        'sb_bf.form.piglin_plushie.description',
        'textures/sb/bf/form/iron_ingot',
        'light_gray',
        'JZLDy',
        'tmbyz',
        'rqNyh',
        'VEqHr',
        'onUseOnBefore',
        'toString',
        'minecraft:ender_dragon',
        'pitch',
        'CZPup',
        'tHupx',
        'VCwii',
        'uYCxX',
        'inventorySize',
        'rqyLW',
        'tags',
        'minecraft:resin_brick_stairs',
        'qNaVl',
        'isOnGround',
        'TCJoB',
        'dolphin_plushie',
        'FIpWU',
        'sHrZw',
        'beforeEvents',
        'nMzHw',
        'EXpGH',
        'sXJQe',
        'jVugJ',
        'QXsQJ',
        'GfCrQ',
        'sb_bf.form.warden_plushie.description',
        'YRADW',
        'log',
        'minecraft:water',
        'nxxwQ',
        'oMhhu',
        'sb_bf:half',
        'JxOdO',
        'onPlayerDestroy',
        'minecraft:music_disc_blocks',
        'yzFjo',
        'record.creator_music_box',
        'TYnrg',
        'TfzZM',
        'dffOl',
        'close.cherry_wood_trapdoor',
        'mMDnj',
        'textures/sb/bf/form/disc_player',
        'aHVif',
        'xJPOp',
        'setRotation',
        'hIEsc',
        'sb_bf.locked.description.zombie',
        'zsZXw',
        'determineLegs',
        'minecraft:cherry_leaves',
        'lFjDH',
        'gvdEf',
        'GvEob',
        ':fence_gate_connect',
        'ibiVI',
        'record_stal',
        'sb_bf:mangrove_special_fence_gate',
        'JfWrX',
        'BoqeJ',
        'sb_bf.form.shutter.title',
        'oYVkg',
        'isCompostable',
        'sb_bf:spruce_glass_door',
        'FStzX',
        'pop',
        'golem',
        'SvhpN',
        'YJqon',
        'nonSolidBlocks',
        'level',
        'minecraft:sunflower',
        'JBohw',
        'sb_bf.photobook.locked',
        'armor_stand',
        'isRideable',
        'isBreedable',
        'hasCustomTableRecipe',
        'whzUG',
        'wajTv',
        'sb_bf:step',
        'minecraft:music_disc_11',
        'pig_plushie',
        'record_creator',
        'TESuV',
        'sb_bf.form.netherite_ingot.title',
        'components',
        'label',
        'order',
        ':vertical_connect',
        'textures/sb/bf/items/picture/zombie',
        'initializeState',
        'sb_bf.form.stool.description.1',
        'TJUrw',
        'SCLoL',
        'onInitialize',
        'minecraft:yellow_bundle',
        'sb_bf:open',
        'mgVJG',
        'sb_bf:jar_honey',
        'wUpRM',
        'KakPa',
        'ezSXD',
        'minecraft:music_disc_far',
        'oWcBF',
        'MSxBD',
        'textures/sb/bf/items/picture/warden',
        'villager',
        'interval',
        'textures/sb/bf/ui/logo',
        'particle',
        'JQDmf',
        'FLsIb',
        'ngmjp',
        'open.cherry_wood_trapdoor',
        'conditionCheckBlock',
        'ndqZg',
        'tiled_glass_pane',
        'sb_bf.form.framed_glass_pane.title',
        'toast',
        'sb_bf.form.collector_items.title',
        'magenta_candle_holder',
        'fhDha',
        'sb_bf.form.decorated_carpet.title',
        'No\x20registerBehavior\x20found\x20for\x20block\x20type:\x20',
        'ahXuT',
        'minecraft:music_disc_precipice',
        'front',
        'sb_bf:spruce_shutter',
        'sb_bf.form.chandelier.description.1',
        'progress',
        'mBMtr',
        'minecraft:acacia_stairs',
        '.form.custom.no_recipe',
        'yJTHw',
        'elqJM',
        'vertical',
        'sb_bf:bamboo_special_fence',
        'withState',
        'textures/sb/bf/form/candle_holder',
        'random.pop',
        'setEquipment',
        'minecraft:block_face',
        'AhIsn',
        'xAIgl',
        'minecraft:mud_brick_stairs',
        'ODCFv',
        'xwFPy',
        'DHtFZ',
        'minecraft:oak_fence',
        'lore',
        'textures/sb/bf/form/sofa',
        '.form.biome.',
        'tryPlaceBlock',
        'minecraft:oak_stairs',
        'MLgug',
        'blockFace',
        'gaCDp',
        'progressMessage',
        'animation.sb_bf.camera.use.first_person',
        'sb_bf:pale_oak_glass_door',
        'ktNBR',
        'single',
        'udKyn',
        'ttart',
        'ONXDI',
        'isValid',
        'sb_bf.form.terracotta_vase.description.1',
        'Luhne',
        'rmPtM',
        'registry',
        'MrPzD',
        '284447PHysCt',
        'aHnIU',
        'navigationStack',
        'storeTimeout',
        'minecraft:pig',
        'aqxzc',
        'NYRxT',
        'qBMqV',
        'nVzFW',
        'sb_bf:zombie_picture',
        'minecraft:cyan_stained_glass_pane',
        'lCyis',
        'minecraft:wooden_door',
        'item',
        'fCaNz',
        'textures/sb/bf/form/counter',
        'minecraft:wildflowers',
        'Nerog',
        'Vec3(',
        'nBnmf',
        'minecraft:yellow_flower',
        'textures/sb/bf/form/mushroom_stew',
        'every',
        'sb_bf.form.storage_blocks.description.3',
        'setTitle',
        'bind',
        'GbDdk',
        'ntuxa',
        'ISSOn',
        'entityCheck',
        'minecraft:cookie',
        'glass_door',
        'seat',
        'YdIHR',
        'minecraft:polished_deepslate_stairs',
        'YmdIQ',
        'SgLYO',
        'duration',
        'dolphin',
        '4cBiolg',
        'minecraft:black_stained_glass',
        'sb_bf.form.painting.description',
        'minecraft:cherry_stairs',
        'structureManager',
        'record_wait',
        'Offhand',
        'sb_bf.form.trophies.title',
        'abs',
        'random.toast_recipe_unlocking_in',
        'textures/sb/bf/form/recipe',
        'GHROh',
        'cyan_candle_holder',
        'entity',
        'placementOffset',
        'efdAP',
        'events',
        'vRVIk',
        'Vvnyx',
        'nIHsD',
        'FsVEc',
        'ykVlT',
        'sb_bf:crimson_shutter',
        'bPyfR',
        'sb_bf:rabbit_stew',
        'lcTJS',
        'lIYmT',
        'EacSZ',
        'IZpTF',
        'pNMTr',
        'JjgyF',
        'container',
        'Pmohr',
        'playerPlaceBlock',
        '.form.back',
        'dygep',
        'activeEffects',
        '.form.shearable',
        'CGtsy',
        ':connect_west',
        'ccCbK',
        'splice',
        'ender_dragon',
        'loot',
        'hAQJy',
        'QAInT',
        'LIzCD',
        'config',
        'sb_bf:birch_glass_door',
        'itemID',
        'creeper_plushie',
        'hHigQ',
        'textures/sb/bf/form/curtain',
        'yCMDe',
        'cZzaU',
        'UzXGY',
        'XdxIH',
        'face',
        'iron_ingot',
        'jKRFa',
        'sb_bf.form.seats.title',
        'maxAmount',
        'minecraft:purple_stained_glass',
        'cc:count',
        'minecraft:oak_slab',
        'cross',
        'record.wait',
        'range',
        'onlyUnlockWhenVisible',
        'textures/sb/bf/form/plushie_villager',
        'fjFYR',
        'theEnd',
        'textures/sb/bf/items/painting/wither',
        'setActionBar',
        'rwomG',
        'textures/sb/bf/form/decorated_wool',
        'Cgoea',
        'getEntitiesAtBlockLocation',
        'minecraft:short_grass',
        'takeItem',
        'sb_bf.form.drawer_cabinets.title',
        'mob.slime.squish',
        'minecraft:dolphin',
        'dJhKk',
        'DFdXq',
        'UtBSS',
        'playSound',
        'getInventoryId',
        ':cabinet_mirror',
        'vgFGo',
        'itemGroup.name.planks',
        'ZPTbJ',
        'QbfGa',
        'getBlockByIdentifier',
        '_stool',
        'BolWS',
        'adjecentFace',
        'GSGSq',
        'form',
        'close.bamboo_wood_trapdoor',
        ':open',
        'wmxdT',
        'SlUXi',
        '_glass_door',
        'oMuBN',
        'PkXlC',
        'minecraft:pale_oak_slab',
        'textures/sb/bf/form/beetroot_stew',
        'WSGac',
        'uSYIZ',
        'unlock',
        'KHSMs',
        'sb_bf.form.disc_player.title',
        'sb_bf.form.cat_plushie.description',
        'LOytt',
        'open.cherry_wood_door',
        'mzSZH',
        'sb_bf.photobook.statue.info.chisel',
        'getMainFormIdForCurrentForm',
        'oFSTo'
    ];
    _0x4213 = function () {
        return _0x21cb8a;
    };
    return _0x4213();
}
var _0x2bd013 = class {
    static [_0x21f734(0x48b)]() {
        const _0x235990 = _0x21f734, _0x530d40 = {
                'PUReM': function (_0x3d6d41, _0x400e89) {
                    return _0x3d6d41(_0x400e89);
                },
                'BsdfC': _0x235990(0x39e)
            };
        _0x36850e[_0x235990(0x959)][_0x235990(0x8ee)][_0x235990(0x725)](_0xc93de2 => {
            const _0x15c3ff = _0x235990, _0x5c47da = {
                    'FRVhT': function (_0x39e798, _0x2c07f2) {
                        return _0x530d40['PUReM'](_0x39e798, _0x2c07f2);
                    }
                };
            if (!_0xc93de2[_0x15c3ff(0x87b)][_0x15c3ff(0x206)](_0x207994 + ':disable_silk_touch'))
                return;
            if (!_0xc93de2['itemStack'])
                return;
            const _0x1b0c54 = _0xc93de2[_0x15c3ff(0xc1d)][_0x15c3ff(0x3cc)](_0x2ca2d9[_0x15c3ff(0x7ad)]);
            if (!_0x1b0c54)
                return;
            if (!_0x1b0c54[_0x15c3ff(0x61b)](_0x530d40[_0x15c3ff(0x27d)]))
                return;
            _0xc93de2['cancel'] = !![], _0x26de46[_0x15c3ff(0xb7e)](() => {
                const _0x7a5fa2 = _0x15c3ff;
                _0x45c2ab(_0xc93de2[_0x7a5fa2(0xb28)], _0xc93de2[_0x7a5fa2(0x87b)][_0x7a5fa2(0x2c0)]), _0x5c47da[_0x7a5fa2(0x3b0)](_0x2108be, _0xc93de2[_0x7a5fa2(0x848)]);
            });
        });
    }
};
import {
    system as _0x51eb72,
    world as _0x2d794d
} from '@minecraft/server';
var _0x36e5d5 = class _0x116b43 {
    constructor(_0x59e9ba) {
        const _0x2be995 = _0x21f734;
        this[_0x2be995(0xa49)] = _0x59e9ba;
    }
    static [_0x21f734(0x760)](_0x416ce9) {
        const _0x30238d = _0x21f734, _0x452e56 = new _0x116b43(_0x416ce9);
        this[_0x30238d(0x752)][_0x30238d(0x28e)](_0x452e56);
    }
    static [_0x21f734(0x48b)]() {
        const _0x22231a = _0x21f734, _0x91c1f3 = {
                'NmRev': _0x22231a(0x6a6),
                'KcNDn': 'north',
                'jAFRc': _0x22231a(0x7a4),
                'dpAkH': 'west',
                'IlUmE': _0x22231a(0x7bd),
                'fZHxM': _0x22231a(0xba4),
                'HyeIs': function (_0x27ebba, _0x4f69ff) {
                    return _0x27ebba + _0x4f69ff;
                },
                'UgUJo': function (_0x2cc24d, _0x52d695) {
                    return _0x2cc24d + _0x52d695;
                },
                'DhqGy': function (_0x99a7fd, _0x32fab4) {
                    return _0x99a7fd !== _0x32fab4;
                },
                'cJIxY': function (_0x4eb4f3, _0x26ddcb) {
                    return _0x4eb4f3 + _0x26ddcb;
                },
                'MrmKC': function (_0x4559f8, _0xee7be4) {
                    return _0x4559f8 + _0xee7be4;
                },
                'RLAwZ': function (_0x3f602f, _0x1efcbd) {
                    return _0x3f602f - _0x1efcbd;
                }
            };
        _0x2d794d[_0x22231a(0x959)][_0x22231a(0x398)][_0x22231a(0x725)](_0x894dc4 => {
            const _0xd99f2a = _0x22231a, _0x404833 = {
                    'QLwnQ': _0xd99f2a(0x4b8),
                    'GMaFk': _0x91c1f3[_0xd99f2a(0xa94)],
                    'ukzEJ': _0x91c1f3[_0xd99f2a(0x480)],
                    'zwNQA': _0x91c1f3[_0xd99f2a(0x854)],
                    'fciia': _0x91c1f3[_0xd99f2a(0x46f)],
                    'rqJwP': _0xd99f2a(0x4b2),
                    'ItGfK': _0x91c1f3[_0xd99f2a(0x7d1)],
                    'oMJZp': _0xd99f2a(0x6d4),
                    'tpGTD': _0x91c1f3[_0xd99f2a(0xbae)]
                };
            _0x894dc4[_0xd99f2a(0x2ee)]['registerCustomComponent'](_0x207994 + _0xd99f2a(0x535), {
                'beforeOnPlayerPlace': _0x1de3e8 => {
                    const _0x486c48 = _0xd99f2a, _0xee2494 = this[_0x486c48(0x752)][_0x486c48(0x65e)](_0x157b49 => _0x157b49['config']['id'] === _0x1de3e8['permutationToPlace'][_0x486c48(0xc08)]['id']);
                    if (!_0xee2494)
                        return;
                    if (_0xee2494[_0x486c48(0xa49)]['excludeFaces']?.[_0x486c48(0x620)](_0x1de3e8[_0x486c48(0xa53)][_0x486c48(0x57d)]())) {
                        _0x1de3e8[_0x486c48(0xaa9)] = !![];
                        return;
                    }
                    if (_0xee2494[_0x486c48(0xa49)][_0x486c48(0x9e3)]) {
                        const {
                            xDirection: _0x373b4b,
                            zDirection: _0x5e1251
                        } = this[_0x486c48(0x8d4)](_0x1de3e8[_0x486c48(0xa53)]);
                        let _0x2b088d;
                        switch (_0x1de3e8[_0x486c48(0xa53)]) {
                        case _0x404833[_0x486c48(0x773)]:
                            _0x2b088d = _0x404833[_0x486c48(0x8ae)];
                            break;
                        case _0x486c48(0xaac):
                            _0x2b088d = _0x404833[_0x486c48(0x8c2)];
                            break;
                        case _0x404833[_0x486c48(0x525)]:
                            _0x2b088d = _0x404833[_0x486c48(0x367)];
                            break;
                        case _0x404833[_0x486c48(0x373)]:
                            _0x2b088d = _0x404833[_0x486c48(0x7be)];
                            break;
                        case 'Up':
                        case _0x404833[_0x486c48(0x7d6)]:
                            _0x2b088d = _0x1de3e8[_0x486c48(0x2c1)][_0x486c48(0x30a)](_0x404833[_0x486c48(0x584)]);
                            break;
                        }
                        this[_0x486c48(0x9e0)](_0x1de3e8, _0xee2494, _0x373b4b, _0x5e1251, _0x2b088d);
                    } else {
                        const _0x3e1c16 = _0x1de3e8[_0x486c48(0x2c1)]['getState'](_0x404833[_0x486c48(0x584)]), {
                                xDirection: _0x54c839,
                                zDirection: _0x441361
                            } = this[_0x486c48(0x2b6)](_0x3e1c16);
                        this['tryPlaceBlock'](_0x1de3e8, _0xee2494, _0x54c839, _0x441361, _0x3e1c16);
                    }
                }
            });
        }), _0x2d794d[_0x22231a(0x959)]['playerBreakBlock']['subscribe'](_0x58d592 => {
            const _0x1d98d5 = _0x22231a, _0x5af28f = this[_0x1d98d5(0x752)]['find'](_0x229b00 => _0x229b00[_0x1d98d5(0xa49)]['id'] === _0x58d592[_0x1d98d5(0x87b)][_0x1d98d5(0x1b9)]);
            if (!_0x5af28f)
                return;
            _0x58d592[_0x1d98d5(0xaa9)] = !![], _0x51eb72['run'](() => this[_0x1d98d5(0x2c5)](_0x58d592['block']));
        }), _0x2d794d[_0x22231a(0x327)][_0x22231a(0xb6f)][_0x22231a(0x725)](_0x42f428 => {
            const _0x2b043a = _0x22231a, _0x2957a7 = {
                    'AovlL': function (_0xf7455d, _0x1ebf77) {
                        const _0x531a69 = _0x3124;
                        return _0x91c1f3[_0x531a69(0xac3)](_0xf7455d, _0x1ebf77);
                    },
                    'bDxhf': function (_0x10f394, _0x4aa6c9) {
                        return _0x10f394 - _0x4aa6c9;
                    },
                    'JfWrX': function (_0x4e8fe2, _0x34607b) {
                        const _0x26c7c3 = _0x3124;
                        return _0x91c1f3[_0x26c7c3(0xac3)](_0x4e8fe2, _0x34607b);
                    },
                    'BSkmK': function (_0x3f13f9, _0x2f07bf) {
                        const _0x47dd4e = _0x3124;
                        return _0x91c1f3[_0x47dd4e(0xad4)](_0x3f13f9, _0x2f07bf);
                    }
                }, _0x222718 = _0x42f428[_0x2b043a(0x26d)][_0x2b043a(0x84b)]();
            _0x51eb72['runTimeout'](() => {
                const _0x6386fc = _0x2b043a;
                for (const _0x24393a of _0x222718) {
                    const _0x25ae72 = [
                        {
                            'x': _0x2957a7[_0x6386fc(0x6cf)](_0x24393a['x'], 0x1),
                            'y': _0x24393a['y'],
                            'z': _0x24393a['z']
                        },
                        {
                            'x': _0x2957a7[_0x6386fc(0x1eb)](_0x24393a['x'], 0x1),
                            'y': _0x24393a['y'],
                            'z': _0x24393a['z']
                        },
                        {
                            'x': _0x24393a['x'],
                            'y': _0x24393a['y'],
                            'z': _0x2957a7[_0x6386fc(0x981)](_0x24393a['z'], 0x1)
                        },
                        {
                            'x': _0x24393a['x'],
                            'y': _0x24393a['y'],
                            'z': _0x24393a['z'] - 0x1
                        },
                        {
                            'x': _0x24393a['x'],
                            'y': _0x2957a7['BSkmK'](_0x24393a['y'], 0x1),
                            'z': _0x24393a['z']
                        },
                        {
                            'x': _0x24393a['x'],
                            'y': _0x2957a7[_0x6386fc(0x1eb)](_0x24393a['y'], 0x1),
                            'z': _0x24393a['z']
                        }
                    ];
                    for (const _0x54f4a1 of _0x25ae72) {
                        let _0x296a6d = void 0x0;
                        try {
                            _0x296a6d = _0x42f428['dimension'][_0x6386fc(0x3c0)](_0x54f4a1);
                        } catch {
                        }
                        if (!_0x296a6d)
                            continue;
                        const _0x41575b = this[_0x6386fc(0x752)][_0x6386fc(0x65e)](_0x297a4f => _0x297a4f[_0x6386fc(0xa49)]['id'] === _0x296a6d['typeId']);
                        if (!_0x41575b)
                            continue;
                        this[_0x6386fc(0x2c5)](_0x296a6d);
                    }
                }
            }, 0x5);
        }), _0x2d794d[_0x22231a(0x959)][_0x22231a(0x6dd)][_0x22231a(0x725)](_0x577150 => {
            const _0x28bf53 = _0x22231a, _0x2febeb = {
                    'iDbVa': function (_0x577dee, _0x2ba89a) {
                        const _0x710f95 = _0x3124;
                        return _0x91c1f3[_0x710f95(0x7cf)](_0x577dee, _0x2ba89a);
                    }
                };
            for (const _0x12bab2 of _0x577150[_0x28bf53(0xab6)]()) {
                if (!_0x12bab2)
                    continue;
                const _0x27946c = this[_0x28bf53(0x752)][_0x28bf53(0x65e)](_0x23f941 => _0x23f941['config']['id'] === _0x12bab2[_0x28bf53(0x1b9)]);
                if (!_0x27946c)
                    continue;
                const _0x43faa7 = _0x12bab2[_0x28bf53(0x1b9)], _0x3d31a2 = _0x12bab2[_0x28bf53(0x2c0)], _0x87395 = [
                        {
                            'x': _0x91c1f3[_0x28bf53(0x383)](_0x3d31a2['x'], 0x1),
                            'y': _0x3d31a2['y'],
                            'z': _0x3d31a2['z']
                        },
                        {
                            'x': _0x3d31a2['x'] - 0x1,
                            'y': _0x3d31a2['y'],
                            'z': _0x3d31a2['z']
                        },
                        {
                            'x': _0x3d31a2['x'],
                            'y': _0x3d31a2['y'],
                            'z': _0x91c1f3[_0x28bf53(0x523)](_0x3d31a2['z'], 0x1)
                        },
                        {
                            'x': _0x3d31a2['x'],
                            'y': _0x3d31a2['y'],
                            'z': _0x91c1f3['RLAwZ'](_0x3d31a2['z'], 0x1)
                        },
                        {
                            'x': _0x3d31a2['x'],
                            'y': _0x91c1f3['cJIxY'](_0x3d31a2['y'], 0x1),
                            'z': _0x3d31a2['z']
                        },
                        {
                            'x': _0x3d31a2['x'],
                            'y': _0x91c1f3['RLAwZ'](_0x3d31a2['y'], 0x1),
                            'z': _0x3d31a2['z']
                        }
                    ];
                _0x51eb72[_0x28bf53(0xb7e)](() => {
                    const _0x586308 = _0x28bf53;
                    for (const _0x4e1e42 of _0x87395) {
                        let _0x1699ae = void 0x0;
                        try {
                            _0x1699ae = _0x577150[_0x586308(0xb28)]['getBlock'](_0x4e1e42);
                        } catch {
                        }
                        if (!_0x1699ae || _0x2febeb[_0x586308(0x5d9)](_0x1699ae['typeId'], _0x43faa7))
                            continue;
                        this[_0x586308(0x2c5)](_0x1699ae);
                    }
                });
            }
        });
    }
    static [_0x21f734(0x2b6)](_0x4683ba) {
        const _0x44d383 = _0x21f734, _0x3b7801 = { 'nNJfZ': _0x44d383(0x709) };
        let _0x53ddb6 = {
                'x': 0x1,
                'z': 0x0
            }, _0x52b6d7 = {
                'x': 0x0,
                'z': 0x1
            };
        if (_0x4683ba)
            switch (_0x4683ba) {
            case _0x44d383(0x571):
                _0x53ddb6 = {
                    'x': 0x0,
                    'z': -0x1
                }, _0x52b6d7 = {
                    'x': 0x1,
                    'z': 0x0
                };
                break;
            case _0x3b7801[_0x44d383(0xb9c)]:
                _0x53ddb6 = {
                    'x': -0x1,
                    'z': 0x0
                }, _0x52b6d7 = {
                    'x': -0x0,
                    'z': -0x1
                };
                break;
            case 'south':
                _0x53ddb6 = {
                    'x': 0x0,
                    'z': 0x1
                }, _0x52b6d7 = {
                    'x': -0x1,
                    'z': 0x0
                };
                break;
            }
        return {
            'xDirection': _0x53ddb6,
            'zDirection': _0x52b6d7
        };
    }
    static [_0x21f734(0x8d4)](_0x329d59) {
        const _0x504963 = _0x21f734, _0x3e3d0d = { 'GLfsU': _0x504963(0x7a4) };
        let _0x2ccfed = {
                'x': 0x1,
                'z': 0x0
            }, _0xf59319 = {
                'x': 0x0,
                'z': 0x1
            };
        switch (_0x329d59) {
        case _0x504963(0x4b8):
            _0x2ccfed = {
                'x': 0x0,
                'z': 0x1
            }, _0xf59319 = {
                'x': -0x1,
                'z': 0x0
            };
            break;
        case _0x504963(0xaac):
            _0x2ccfed = {
                'x': 0x0,
                'z': -0x1
            }, _0xf59319 = {
                'x': 0x1,
                'z': 0x0
            };
            break;
        case _0x3e3d0d[_0x504963(0x7ae)]:
            _0x2ccfed = {
                'x': -0x1,
                'z': 0x0
            }, _0xf59319 = {
                'x': 0x0,
                'z': -0x1
            };
            break;
        case _0x504963(0x4b2):
            _0x2ccfed = {
                'x': 0x1,
                'z': 0x0
            }, _0xf59319 = {
                'x': 0x0,
                'z': 0x1
            };
            break;
        case 'Up':
        case _0x504963(0x6d4):
            break;
        }
        return {
            'xDirection': _0x2ccfed,
            'zDirection': _0xf59319
        };
    }
    static [_0x21f734(0x9e0)](_0x522126, _0x3c1ab0, _0x282fbc, _0x5a6b85, _0x84276a) {
        const _0x341b1a = _0x21f734, _0x425c2d = {
                'RbSPg': function (_0x580658, _0x185caa) {
                    return _0x580658 > _0x185caa;
                },
                'YnUpK': function (_0x57491b, _0x1c160c) {
                    return _0x57491b > _0x1c160c;
                },
                'kLlYV': function (_0x4de87b, _0x1bce42) {
                    return _0x4de87b <= _0x1bce42;
                },
                'jPKeh': function (_0x1faf44, _0x5198c1) {
                    return _0x1faf44 + _0x5198c1;
                },
                'MgFIU': function (_0x409591, _0x2e2fc5) {
                    return _0x409591 + _0x2e2fc5;
                },
                'VrFEr': function (_0x557343, _0x37b0df) {
                    return _0x557343 + _0x37b0df;
                },
                'ZnWeU': 'minecraft:item',
                'yhRaS': 'minecraft:arrow',
                'zWToC': _0x341b1a(0xbc7),
                'UMPaF': _0x341b1a(0xb44),
                'dAwiA': function (_0xa953bc, _0x30e112) {
                    return _0xa953bc && _0x30e112;
                },
                'cwLSl': function (_0x2d524e, _0x545283) {
                    return _0x2d524e <= _0x545283;
                }
            };
        _0x522126[_0x341b1a(0xaa9)] = !![];
        const _0x4c6157 = _0x522126[_0x341b1a(0xb28)], _0x4cdf8a = _0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0xa28)], _0x1d7c3b = this[_0x341b1a(0x8a0)](_0x522126[_0x341b1a(0x87b)][_0x341b1a(0x2c0)], _0x282fbc, _0x5a6b85, _0x4cdf8a), _0x2ea6aa = new Map();
        for (let _0x58c971 = 0x1; _0x425c2d[_0x341b1a(0xbbc)](_0x58c971, _0x3c1ab0[_0x341b1a(0xa49)]['size']['x']); _0x58c971++) {
            for (let _0x4113d9 = 0x1; _0x425c2d[_0x341b1a(0xbbc)](_0x4113d9, _0x3c1ab0[_0x341b1a(0xa49)]['size']['y']); _0x4113d9++) {
                for (let _0x169eee = 0x1; _0x169eee <= _0x3c1ab0['config'][_0x341b1a(0x87e)]['z']; _0x169eee++) {
                    let _0x16bd65 = void 0x0;
                    const _0x3861bf = this['getOffset'](_0x282fbc, _0x5a6b85, {
                            'x': _0x58c971,
                            'y': _0x4113d9,
                            'z': _0x169eee
                        }), _0x2a0026 = {
                            'x': _0x425c2d['jPKeh'](_0x1d7c3b['x'], _0x3861bf['x']),
                            'y': _0x425c2d['MgFIU'](_0x1d7c3b['y'], _0x3861bf['y']),
                            'z': _0x425c2d[_0x341b1a(0x8c5)](_0x1d7c3b['z'], _0x3861bf['z'])
                        };
                    try {
                        _0x16bd65 = _0x4c6157['getBlock'](_0x2a0026);
                    } catch {
                    }
                    if (!_0x16bd65 || !_0x16bd65[_0x341b1a(0x9ed)]()) {
                        this[_0x341b1a(0xab7)](_0x522126, _0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x45e)]);
                        return;
                    }
                    if (_0x4c6157[_0x341b1a(0x759)]({
                            'location': _0x16bd65[_0x341b1a(0x2c0)],
                            'volume': {
                                'x': 0x0,
                                'y': 0x0,
                                'z': 0x0
                            },
                            'excludeTypes': [
                                _0x425c2d['ZnWeU'],
                                _0x425c2d['yhRaS'],
                                _0x425c2d[_0x341b1a(0x215)],
                                _0x425c2d[_0x341b1a(0x50a)]
                            ]
                        })[0x0]) {
                        this['showErrorMessage'](_0x522126, _0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x45e)]);
                        return;
                    }
                    const _0x446509 = _0x3c1ab0[_0x341b1a(0xa49)]['replaceBlocks']?.['includes'](_0x16bd65[_0x341b1a(0x1b9)]), _0x583926 = !_0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x454)] && _0x16bd65[_0x341b1a(0x507)], _0x13aebc = !_0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x6e5)] && _0x16bd65[_0x341b1a(0x2a8)];
                    if (_0x425c2d[_0x341b1a(0x892)](!_0x446509, !_0x583926) && !_0x13aebc) {
                        this[_0x341b1a(0xab7)](_0x522126, _0x3c1ab0[_0x341b1a(0xa49)]['errorMessage']);
                        return;
                    }
                    if (_0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x592)]?.[_0x341b1a(0x620)](_0x522126[_0x341b1a(0xa53)])) {
                        this[_0x341b1a(0xab7)](_0x522126, _0x3c1ab0[_0x341b1a(0xa49)]['errorMessage']);
                        return;
                    }
                    _0x2ea6aa[_0x341b1a(0x54f)](JSON[_0x341b1a(0x464)](_0x3861bf), _0x16bd65);
                }
            }
        }
        for (let _0x4f543d = 0x1; _0x425c2d[_0x341b1a(0xbbc)](_0x4f543d, _0x3c1ab0['config'][_0x341b1a(0x87e)]['x']); _0x4f543d++) {
            for (let _0x25d91e = 0x1; _0x425c2d['cwLSl'](_0x25d91e, _0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x87e)]['y']); _0x25d91e++) {
                for (let _0x238b06 = 0x1; _0x425c2d[_0x341b1a(0xbbc)](_0x238b06, _0x3c1ab0[_0x341b1a(0xa49)][_0x341b1a(0x87e)]['z']); _0x238b06++) {
                    const _0x2218c7 = this[_0x341b1a(0x796)](_0x282fbc, _0x5a6b85, {
                            'x': _0x4f543d,
                            'y': _0x25d91e,
                            'z': _0x238b06
                        }), _0x205501 = _0x2ea6aa['get'](JSON[_0x341b1a(0x464)](_0x2218c7));
                    if (!_0x205501)
                        continue;
                    _0x51eb72['run'](() => {
                        const _0x4fdef = _0x341b1a;
                        _0x205501['setType'](_0x3c1ab0['config']['id']);
                        const _0x3c23b = _0x3c1ab0[_0x4fdef(0xa49)][_0x4fdef(0x394)];
                        let _0x1c81c3 = _0x205501[_0x4fdef(0x5fa)];
                        _0x425c2d[_0x4fdef(0x2ca)](_0x3c1ab0[_0x4fdef(0xa49)][_0x4fdef(0x87e)]['x'], 0x1) && (_0x1c81c3 = _0x1c81c3['withState'](_0x3c1ab0[_0x4fdef(0xa49)][_0x4fdef(0x611)] + '_x', _0x4f543d)), _0x425c2d[_0x4fdef(0x479)](_0x3c1ab0[_0x4fdef(0xa49)][_0x4fdef(0x87e)]['y'], 0x1) && (_0x1c81c3 = _0x1c81c3['withState'](_0x3c1ab0[_0x4fdef(0xa49)][_0x4fdef(0x611)] + '_y', _0x25d91e)), _0x3c1ab0[_0x4fdef(0xa49)]['size']['z'] > 0x1 && (_0x1c81c3 = _0x1c81c3[_0x4fdef(0x9d1)](_0x3c1ab0[_0x4fdef(0xa49)][_0x4fdef(0x611)] + '_z', _0x238b06)), _0x84276a && (_0x1c81c3 = _0x1c81c3[_0x4fdef(0x9d1)](_0x4fdef(0xba4), _0x84276a)), _0x3c23b && _0x3c23b['forEach'](_0x29f015 => {
                            const _0x1d1e3e = _0x4fdef;
                            _0x4c6157[_0x1d1e3e(0xb85)](_0x29f015, _0x205501[_0x1d1e3e(0x5a0)]());
                        }), _0x205501['setPermutation'](_0x1c81c3);
                    });
                }
            }
        }
        _0x51eb72[_0x341b1a(0xb7e)](() => {
            const _0x5904bb = _0x341b1a;
            if (_0x522126['player'])
                _0xed22af(_0x522126[_0x5904bb(0x848)], 0x1, !![]);
        }), _0x51eb72[_0x341b1a(0x873)](() => {
            const _0x5e21bb = _0x341b1a;
            if (_0x3c1ab0['config'][_0x5e21bb(0x5b9)])
                _0x4c6157[_0x5e21bb(0xa70)](_0x3c1ab0[_0x5e21bb(0xa49)][_0x5e21bb(0x5b9)]['id'], _0x522126[_0x5e21bb(0x87b)]['location'], {
                    'volume': _0x3c1ab0[_0x5e21bb(0xa49)][_0x5e21bb(0x5b9)][_0x5e21bb(0x2b2)],
                    'pitch': _0x3c1ab0[_0x5e21bb(0xa49)][_0x5e21bb(0x5b9)][_0x5e21bb(0x94a)]
                });
        });
    }
    static [_0x21f734(0xab7)](_0x3cb6bd, _0x81c7fd) {
        const _0x5ef1ae = _0x21f734;
        if (!_0x81c7fd || !_0x3cb6bd[_0x5ef1ae(0x848)])
            return;
        _0x51eb72[_0x5ef1ae(0xb7e)](() => {
            const _0x12bd5c = _0x5ef1ae;
            _0x3cb6bd[_0x12bd5c(0x848)]?.[_0x12bd5c(0x7b1)]({ 'rawtext': [{ 'text': _0x81c7fd }] });
        });
    }
    static [_0x21f734(0x796)](_0x4f5259, _0x15c1f2, _0x46dd66) {
        const _0x4b439c = _0x21f734, _0x2cffbd = {
                'afZrK': function (_0x337581, _0x2a9f32) {
                    return _0x337581 !== _0x2a9f32;
                },
                'WcgjD': function (_0x375fb5, _0x1c88c1) {
                    return _0x375fb5 * _0x1c88c1;
                },
                'fpwbq': function (_0x1c5aa4, _0x41ad4f) {
                    return _0x1c5aa4 - _0x41ad4f;
                },
                'SPNvO': function (_0x1ad1be, _0x4f4fe6) {
                    return _0x1ad1be - _0x4f4fe6;
                },
                'wqFfn': function (_0x3f1c4b, _0x5c8e01) {
                    return _0x3f1c4b - _0x5c8e01;
                }
            }, {
                x: _0x1c56b0,
                y: _0x260bdf,
                z: _0x361099
            } = _0x46dd66;
        return {
            'x': _0x2cffbd[_0x4b439c(0xb3c)](_0x4f5259['x'], 0x0) ? _0x2cffbd[_0x4b439c(0x910)](_0x2cffbd[_0x4b439c(0xb57)](_0x1c56b0, 0x1), _0x4f5259['x']) : _0x2cffbd[_0x4b439c(0x910)](_0x2cffbd['SPNvO'](_0x361099, 0x1), _0x15c1f2['x']),
            'y': _0x260bdf - 0x1,
            'z': _0x2cffbd[_0x4b439c(0xb3c)](_0x15c1f2['z'], 0x0) ? _0x2cffbd['WcgjD'](_0x2cffbd['wqFfn'](_0x361099, 0x1), _0x15c1f2['z']) : _0x2cffbd[_0x4b439c(0x910)](_0x2cffbd[_0x4b439c(0xb57)](_0x1c56b0, 0x1), _0x4f5259['z'])
        };
    }
    static [_0x21f734(0x8a0)](_0x37af73, _0x209106, _0xb6458f, _0x3f1f3d) {
        const _0xf026d3 = _0x21f734, _0x5cb3a3 = {
                'eWvKg': function (_0x27147c, _0x350f49) {
                    return _0x27147c + _0x350f49;
                },
                'GAyJR': function (_0x2ab027, _0x341dc0) {
                    return _0x2ab027 !== _0x341dc0;
                },
                'zbySh': function (_0x13889a, _0x50da46) {
                    return _0x13889a * _0x50da46;
                },
                'OorXF': function (_0x56422c, _0x24bfe0) {
                    return _0x56422c * _0x24bfe0;
                },
                'ifmzO': function (_0xf961d9, _0x3abfbb) {
                    return _0xf961d9 !== _0x3abfbb;
                }
            }, {
                x: _0x19486e,
                y: _0x3c3c56,
                z: _0x3ab738
            } = _0x37af73;
        return {
            'x': _0x5cb3a3[_0xf026d3(0x68c)](_0x19486e, _0x3f1f3d !== void 0x0 ? _0x5cb3a3[_0xf026d3(0x6c7)](_0x209106['x'], 0x0) ? _0x5cb3a3[_0xf026d3(0x880)](_0x3f1f3d['x'], _0x209106['x']) : _0x5cb3a3[_0xf026d3(0x864)](_0x3f1f3d['z'], _0xb6458f['x']) : 0x0),
            'y': _0x5cb3a3['eWvKg'](_0x3c3c56, _0x5cb3a3[_0xf026d3(0x6c7)](_0x3f1f3d, void 0x0) ? _0x3f1f3d['y'] : 0x0),
            'z': _0x5cb3a3['eWvKg'](_0x3ab738, _0x3f1f3d !== void 0x0 ? _0x5cb3a3[_0xf026d3(0x4da)](_0xb6458f['z'], 0x0) ? _0x5cb3a3[_0xf026d3(0x880)](_0x3f1f3d['z'], _0xb6458f['z']) : _0x5cb3a3[_0xf026d3(0x880)](_0x3f1f3d['x'], _0x209106['z']) : 0x0)
        };
    }
    static [_0x21f734(0x2c5)](_0x121e69) {
        const _0x40d777 = _0x21f734, _0x62b15b = {
                'fjnrV': _0x40d777(0xba4),
                'NnJhX': function (_0x1fcae4, _0x1ed6a3) {
                    return _0x1fcae4 - _0x1ed6a3;
                },
                'ARnaY': function (_0x1366e4, _0x532ce7) {
                    return _0x1366e4 - _0x532ce7;
                },
                'OojlC': function (_0xb7c372, _0xd2758c) {
                    return _0xb7c372 <= _0xd2758c;
                },
                'FUTkb': function (_0x4d8345, _0x396b6d) {
                    return _0x4d8345 <= _0x396b6d;
                },
                'ruQjq': function (_0x3d26f0, _0x42177e) {
                    return _0x3d26f0 + _0x42177e;
                },
                'jQlrz': function (_0x14cf67, _0x3795b4) {
                    return _0x14cf67 + _0x3795b4;
                },
                'swCnt': function (_0x252c19, _0x55edb0) {
                    return _0x252c19 !== _0x55edb0;
                },
                'mMDnj': function (_0x5ec71d, _0x31f5b9) {
                    return _0x5ec71d !== _0x31f5b9;
                },
                'ACAmC': function (_0x41cde9, _0x1955b6) {
                    return _0x41cde9 > _0x1955b6;
                },
                'zaQFy': function (_0x5e274b, _0x283d0f) {
                    return _0x5e274b !== _0x283d0f;
                },
                'Plozv': function (_0x2a83c9, _0x214fb7) {
                    return _0x2a83c9 !== _0x214fb7;
                }
            }, _0x21ef1c = this['blocks'][_0x40d777(0x65e)](_0x5b34f3 => _0x5b34f3[_0x40d777(0xa49)]['id'] === _0x121e69[_0x40d777(0x1b9)]);
        if (!_0x21ef1c)
            return;
        const _0x3b3924 = _0x121e69['dimension'], _0x5b76ab = _0x121e69[_0x40d777(0x1b9)], _0x42f92a = _0x121e69[_0x40d777(0x5fa)][_0x40d777(0x30a)](_0x62b15b[_0x40d777(0x521)]), {
                xDirection: _0x3be9e5,
                zDirection: _0x4647e6
            } = this['getDirection'](_0x42f92a), _0x299bcb = this[_0x40d777(0x76a)](_0x121e69['permutation'], _0x21ef1c), _0x44f4f1 = this[_0x40d777(0x8a0)](_0x121e69[_0x40d777(0x2c0)], _0x3be9e5, _0x4647e6, {
                'x': -_0x62b15b[_0x40d777(0x56f)](_0x299bcb['x'], 0x1),
                'y': -(_0x299bcb['y'] - 0x1),
                'z': -_0x62b15b['ARnaY'](_0x299bcb['z'], 0x1)
            });
        for (let _0x5113c1 = 0x1; _0x62b15b[_0x40d777(0x7dc)](_0x5113c1, _0x21ef1c[_0x40d777(0xa49)]['size']['x']); _0x5113c1++) {
            for (let _0x420e19 = 0x1; _0x62b15b['OojlC'](_0x420e19, _0x21ef1c[_0x40d777(0xa49)]['size']['y']); _0x420e19++) {
                for (let _0x1e7905 = 0x1; _0x62b15b['FUTkb'](_0x1e7905, _0x21ef1c[_0x40d777(0xa49)][_0x40d777(0x87e)]['z']); _0x1e7905++) {
                    let _0x5965f9 = void 0x0;
                    const _0x4e48dd = this[_0x40d777(0x796)](_0x3be9e5, _0x4647e6, {
                            'x': _0x5113c1,
                            'y': _0x420e19,
                            'z': _0x1e7905
                        }), _0x5e0fdc = {
                            'x': _0x62b15b[_0x40d777(0xc03)](_0x44f4f1['x'], _0x4e48dd['x']),
                            'y': _0x44f4f1['y'] + _0x4e48dd['y'],
                            'z': _0x62b15b[_0x40d777(0x8d7)](_0x44f4f1['z'], _0x4e48dd['z'])
                        };
                    try {
                        _0x5965f9 = _0x3b3924[_0x40d777(0x3c0)](_0x5e0fdc);
                    } catch {
                    }
                    if (!_0x5965f9 || !_0x5965f9[_0x40d777(0x9ed)]())
                        continue;
                    if (_0x62b15b['swCnt'](_0x5b76ab, _0x5965f9?.['typeId']) || _0x62b15b[_0x40d777(0x970)](_0x42f92a, _0x5965f9[_0x40d777(0x5fa)][_0x40d777(0x30a)](_0x62b15b[_0x40d777(0x521)])))
                        continue;
                    const _0x92144 = this[_0x40d777(0x76a)](_0x5965f9['permutation'], _0x21ef1c);
                    let _0x42a3ed = !![];
                    if (_0x62b15b[_0x40d777(0x1f6)](_0x21ef1c[_0x40d777(0xa49)][_0x40d777(0x87e)]['x'], 0x1) && _0x5113c1 !== _0x92144['x'])
                        _0x42a3ed = ![];
                    if (_0x62b15b[_0x40d777(0x1f6)](_0x21ef1c[_0x40d777(0xa49)][_0x40d777(0x87e)]['y'], 0x1) && _0x62b15b[_0x40d777(0x3fa)](_0x420e19, _0x92144['y']))
                        _0x42a3ed = ![];
                    if (_0x62b15b[_0x40d777(0x1f6)](_0x21ef1c[_0x40d777(0xa49)][_0x40d777(0x87e)]['z'], 0x1) && _0x62b15b[_0x40d777(0x8bb)](_0x1e7905, _0x92144['z']))
                        _0x42a3ed = ![];
                    if (!_0x42a3ed)
                        continue;
                    _0x5965f9['dimension']['runCommand'](_0x40d777(0x7c7) + _0x5e0fdc['x'] + '\x20' + _0x5e0fdc['y'] + '\x20' + _0x5e0fdc['z'] + _0x40d777(0x6a0));
                }
            }
        }
    }
    static [_0x21f734(0x76a)](_0x479429, _0x2a9687) {
        const _0x3c9eb0 = _0x21f734, _0x5a6d5e = {
                'gtbNn': function (_0x4c83f9, _0x48ce93) {
                    return _0x4c83f9(_0x48ce93);
                },
                'qMyPe': function (_0xb13a40, _0x295b60) {
                    return _0xb13a40(_0x295b60);
                }
            }, _0x3e8de6 = (_0x54f07e, _0x19d203 = 0x1) => {
                try {
                    const _0x5a3145 = _0x479429['getState'](_0x54f07e);
                    return _0x5a3145 !== void 0x0 ? _0x5a3145 : _0x19d203;
                } catch {
                    return _0x19d203;
                }
            };
        return {
            'x': _0x5a6d5e[_0x3c9eb0(0x6a4)](_0x3e8de6, _0x2a9687[_0x3c9eb0(0xa49)]['stateId'] + '_x'),
            'y': _0x5a6d5e[_0x3c9eb0(0x6a4)](_0x3e8de6, _0x2a9687[_0x3c9eb0(0xa49)][_0x3c9eb0(0x611)] + '_y'),
            'z': _0x5a6d5e[_0x3c9eb0(0x672)](_0x3e8de6, _0x2a9687[_0x3c9eb0(0xa49)][_0x3c9eb0(0x611)] + '_z')
        };
    }
};
_0x25e7d0(_0x36e5d5, _0x21f734(0x752), []);
var _0x49976e = _0x36e5d5;
function _0x46ab55() {
    const _0x3f0c91 = _0x21f734, _0x456df4 = {
            'DFdXq': _0x3f0c91(0x739),
            'TtHda': _0x3f0c91(0x26f),
            'WOqln': _0x3f0c91(0x721),
            'bFUBq': _0x3f0c91(0x3f3),
            'FBBTW': _0x3f0c91(0xc0b),
            'wzAvV': 'sb_bf:wolf_statue',
            'WYSmQ': '§cYou\x20need\x20at\x20least\x201\x20block\x20of\x20andesite\x20to\x20carve\x20this\x20statue.',
            'LtIeb': _0x3f0c91(0x918),
            'IzQPz': 'sb_bf:special_warden_painting',
            'tpDeX': _0x3f0c91(0x909),
            'wcMTC': _0x3f0c91(0x47a),
            'pIAMu': _0x3f0c91(0x387),
            'pdyYb': _0x3f0c91(0x710),
            'cStXE': _0x3f0c91(0x4f9),
            'VBwim': _0x3f0c91(0x7e4),
            'FWoaZ': '§cYou\x20need\x20at\x20least\x203\x20blocks\x20of\x20andesite\x20to\x20carve\x20this\x20statue.',
            'QLoxl': 'sb_bf:creeper_statue',
            'HJvim': _0x3f0c91(0xaf8),
            'AOgpr': _0x3f0c91(0x1e7),
            'JxOdO': _0x3f0c91(0xc1c),
            'ZPeKm': _0x3f0c91(0x2cd)
        }, _0x760bc9 = _0x3f0c91(0x4cf)[_0x3f0c91(0x1f5)]('|');
    let _0x3a3b43 = 0x0;
    while (!![]) {
        switch (_0x760bc9[_0x3a3b43++]) {
        case '0':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': 'sb_bf:villager_statue',
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x456df4['FBBTW']
                }
            });
            continue;
        case '1':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4[_0x3f0c91(0x46d)],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x1,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4['WOqln']],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4['bFUBq']],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x524)]
                }
            });
            continue;
        case '2':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x3f0c91(0x43c),
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x2
                    },
                    'placementOffset': {
                        'x': 0x0,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'blockFace': !![],
                    'excludeFaces': [
                        'up',
                        _0x3f0c91(0x47a)
                    ],
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0xad7)] }
                },
                'loot': {
                    'lootTable': [{
                            'id': _0x456df4[_0x3f0c91(0x21c)],
                            'count': 0x1
                        }]
                }
            });
            continue;
        case '3':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4['tpDeX'],
                'multiblock': {
                    'stateId': _0x3f0c91(0x739),
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x2
                    },
                    'placementOffset': {
                        'x': 0x0,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'blockFace': !![],
                    'excludeFaces': [
                        'up',
                        _0x456df4[_0x3f0c91(0x6c3)]
                    ],
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0xad7)] }
                },
                'loot': {
                    'lootTable': [{
                            'id': 'sb_bf:special_ender_dragon_painting',
                            'count': 0x1
                        }]
                }
            });
            continue;
        case '4':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4['pIAMu'],
                'multiblock': {
                    'stateId': _0x3f0c91(0x739),
                    'size': {
                        'x': 0x1,
                        'y': 0x1,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x524)]
                }
            });
            continue;
        case '5':
            _0xb54d87['register']({
                'id': _0x456df4[_0x3f0c91(0x364)],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x3f0c91(0x26f) },
                    'replaceBlocks': [_0x3f0c91(0x721)],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x253)]
                }
            });
            continue;
        case '6':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x3f0c91(0x1aa),
                'multiblock': {
                    'stateId': _0x456df4['DFdXq'],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x2
                    },
                    'placementOffset': {
                        'x': 0x0,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'blockFace': !![],
                    'excludeFaces': [
                        'up',
                        _0x456df4['wcMTC']
                    ],
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0xad7)] }
                },
                'loot': {
                    'lootTable': [{
                            'id': 'sb_bf:special_creaking_painting',
                            'count': 0x1
                        }]
                }
            });
            continue;
        case '7':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4['cStXE'],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x253)]
                }
            });
            continue;
        case '8':
            _0xb54d87['register']({
                'id': _0x456df4[_0x3f0c91(0x8d8)],
                'multiblock': {
                    'stateId': 'sb_bf:multiblock',
                    'size': {
                        'x': 0x1,
                        'y': 0x3,
                        'z': 0x2
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4['TtHda'] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x723)]
                }
            });
            continue;
        case '9':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4[_0x3f0c91(0x567)],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4['bFUBq']],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x253)]
                }
            });
            continue;
        case '10':
            _0xb54d87['register']({
                'id': _0x456df4[_0x3f0c91(0x626)],
                'multiblock': {
                    'stateId': _0x3f0c91(0x739),
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x2
                    },
                    'placementOffset': {
                        'x': 0x0,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'blockFace': !![],
                    'excludeFaces': [
                        'up',
                        'down'
                    ],
                    'placeSound': { 'id': _0x3f0c91(0x918) }
                },
                'loot': {
                    'lootTable': [{
                            'id': 'sb_bf:special_wither_painting',
                            'count': 0x1
                        }]
                }
            });
            continue;
        case '11':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4[_0x3f0c91(0x275)],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x2,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': ['sb_bf:statue'],
                    'blockFace': !![],
                    'errorMessage': _0x456df4[_0x3f0c91(0x253)]
                }
            });
            continue;
        case '12':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4[_0x3f0c91(0x967)],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x3,
                        'z': 0x2
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': _0x456df4[_0x3f0c91(0x603)] },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x3f0c91(0x883)
                }
            });
            continue;
        case '13':
            _0xb54d87[_0x3f0c91(0x4c3)]({
                'id': _0x456df4[_0x3f0c91(0x85e)],
                'multiblock': {
                    'stateId': _0x456df4[_0x3f0c91(0xa6e)],
                    'size': {
                        'x': 0x1,
                        'y': 0x3,
                        'z': 0x1
                    },
                    'placementOffset': {
                        'x': 0x1,
                        'y': 0x0,
                        'z': 0x0
                    },
                    'placeSound': { 'id': 'dig.stone' },
                    'replaceBlocks': [_0x456df4[_0x3f0c91(0x92b)]],
                    'excludeAir': !![],
                    'placeParticles': [_0x456df4[_0x3f0c91(0x8be)]],
                    'blockFace': !![],
                    'errorMessage': _0x3f0c91(0x883)
                }
            });
            continue;
        }
        break;
    }
}
import {
    system as _0x4b6259,
    world as _0x467a40
} from '@minecraft/server';
var _0x500771 = class _0x2e7edd {
    constructor(_0x5e3026) {
        const _0x2c223d = _0x21f734;
        this[_0x2c223d(0xa49)] = _0x5e3026;
    }
    static [_0x21f734(0x760)](_0x13046a) {
        const _0x3ab84a = _0x21f734, _0x5bbff7 = new _0x2e7edd(_0x13046a);
        this[_0x3ab84a(0x752)]['push'](_0x5bbff7);
    }
    static [_0x21f734(0x3c0)](_0x524666) {
        const _0x5c5619 = _0x21f734;
        return this[_0x5c5619(0x752)]['find'](_0x2c510f => _0x2c510f[_0x5c5619(0xa49)]['id'] === _0x524666);
    }
    static [_0x21f734(0x48b)]() {
        const _0x2a3dbd = _0x21f734, _0x5a0d06 = {
                'yJTHw': function (_0x32a1f9, _0x496f41) {
                    return _0x32a1f9 * _0x496f41;
                },
                'xydue': function (_0x34433c, _0x1650f3) {
                    return _0x34433c + _0x1650f3;
                },
                'iqgcq': _0x2a3dbd(0xba4),
                'LgthJ': function (_0x4fadf4, _0x416768) {
                    return _0x4fadf4 === _0x416768;
                },
                'GMBXM': _0x2a3dbd(0x571),
                'fZDDI': function (_0x41c5b6, _0x2596e6) {
                    return _0x41c5b6 === _0x2596e6;
                },
                'xJPOp': _0x2a3dbd(0x7bd),
                'uKxpv': _0x2a3dbd(0x6a6),
                'MQcvg': function (_0xa5d5b8, _0x20eee2) {
                    return _0xa5d5b8 === _0x20eee2;
                }
            };
        _0x467a40[_0x2a3dbd(0x959)]['worldInitialize'][_0x2a3dbd(0x725)](_0xe8b531 => {
            const _0x5437d7 = _0x2a3dbd;
            _0xe8b531['blockComponentRegistry'][_0x5437d7(0x565)](_0x207994 + ':entity_animation', {
                'onTick': _0x51a707 => {
                    const _0x2cccef = _0x5437d7, _0x3fa662 = _0x2e7edd['getBlock'](_0x51a707['block']['type']['id']);
                    if (!_0x3fa662)
                        return;
                    const _0x103407 = _0x3fa662[_0x2cccef(0xa49)], _0x5c78aa = _0x51a707[_0x2cccef(0x87b)][_0x2cccef(0xb28)][_0x2cccef(0x759)]({
                            'location': _0x51a707[_0x2cccef(0x87b)]['location'],
                            'maxDistance': 0.5,
                            'closest': 0x1
                        })[0x0], _0x48cb53 = _0x103407['entity'] === _0x5c78aa?.[_0x2cccef(0x1b9)];
                    if (_0x48cb53) {
                        _0x4b6259[_0x2cccef(0x873)](() => {
                            const _0x19aec6 = _0x2cccef;
                            _0x51a707[_0x19aec6(0x87b)][_0x19aec6(0x772)](_0x51a707[_0x19aec6(0x87b)]['permutation'][_0x19aec6(0x9d1)](_0x207994 + _0x19aec6(0x36b), ![]));
                        }, _0x5a0d06['yJTHw'](_0x103407[_0x2cccef(0x374)], 0x14));
                        return;
                    }
                    const _0x152794 = {
                            'x': _0x5a0d06[_0x2cccef(0xb71)](_0x51a707[_0x2cccef(0x87b)][_0x2cccef(0x2c0)]['x'], 0.5),
                            'y': _0x51a707[_0x2cccef(0x87b)][_0x2cccef(0x2c0)]['y'],
                            'z': _0x51a707[_0x2cccef(0x87b)][_0x2cccef(0x2c0)]['z'] + 0.5
                        }, _0x2894a4 = _0x51a707[_0x2cccef(0x87b)][_0x2cccef(0x5fa)][_0x2cccef(0x30a)](_0x5a0d06[_0x2cccef(0x2d6)]);
                    let _0x57102d = 0x0;
                    if (_0x5a0d06[_0x2cccef(0x1c6)](_0x2894a4, _0x5a0d06[_0x2cccef(0x8c4)]))
                        _0x57102d = 0x0;
                    else {
                        if (_0x5a0d06['fZDDI'](_0x2894a4, _0x5a0d06[_0x2cccef(0x973)]))
                            _0x57102d = 0x5a;
                        else {
                            if (_0x5a0d06[_0x2cccef(0x1c6)](_0x2894a4, _0x5a0d06[_0x2cccef(0x24f)]))
                                _0x57102d = 0xb4;
                            else
                                _0x5a0d06[_0x2cccef(0x33a)](_0x2894a4, 'west') && (_0x57102d = 0x10e);
                        }
                    }
                    const _0x4e1550 = _0x51a707[_0x2cccef(0x87b)][_0x2cccef(0xb28)][_0x2cccef(0x6dc)](_0x103407[_0x2cccef(0xa27)], _0x152794);
                    _0x4e1550[_0x2cccef(0x974)]({
                        'x': 0x0,
                        'y': _0x57102d
                    }), _0x4b6259[_0x2cccef(0x873)](() => {
                        const _0x143c50 = _0x2cccef;
                        try {
                            _0x51a707[_0x143c50(0x87b)][_0x143c50(0x772)](_0x51a707['block'][_0x143c50(0x5fa)][_0x143c50(0x9d1)](_0x207994 + _0x143c50(0x36b), ![])), _0x4b6259['runTimeout'](() => {
                                const _0x29273b = _0x143c50;
                                _0x4e1550[_0x29273b(0x44b)]();
                            }, 0x1);
                        } catch (_0x793840) {
                        }
                    }, _0x5a0d06[_0x2cccef(0x9cd)](_0x103407['time'], 0x14));
                }
            });
        });
    }
};
_0x25e7d0(_0x500771, _0x21f734(0x752), []);
var _0x3461dd = _0x500771;
import {
    EquipmentSlot as _0x1cfb66,
    GameMode as _0x57ec6d,
    ItemStack as _0x5aa122,
    system as _0x41b16f,
    world as _0x4339ad
} from '@minecraft/server';
var _0x33acff = class _0x350124 {
    constructor(_0x5a8646) {
        const _0x4518eb = _0x21f734;
        this[_0x4518eb(0xa49)] = _0x5a8646;
    }
    static [_0x21f734(0x760)](_0x264a8f) {
        const _0xd451c2 = _0x21f734, _0x137469 = new _0x350124(_0x264a8f);
        this[_0xd451c2(0x752)][_0xd451c2(0x28e)](_0x137469);
    }
    static ['initialize']() {
        const _0x25c855 = _0x21f734, _0x54dd2c = {
                'iceut': function (_0x4182e0, _0x41ef5a) {
                    return _0x4182e0 + _0x41ef5a;
                },
                'ITPIF': function (_0x57517a, _0x202858) {
                    return _0x57517a === _0x202858;
                },
                'JjHrE': function (_0x285aa0, _0x45c558, _0x27f04a) {
                    return _0x285aa0(_0x45c558, _0x27f04a);
                },
                'OEmuf': _0x25c855(0x810),
                'cVWaQ': _0x25c855(0xa59),
                'MLgug': _0x25c855(0xb07),
                'GDaTW': _0x25c855(0x313)
            };
        _0x4339ad['beforeEvents']['playerBreakBlock']['subscribe'](_0x565c79 => {
            const _0x733cca = _0x25c855, _0x34dcd1 = {
                    'FtCPW': function (_0x44ce74, _0x2da0f9) {
                        return _0x54dd2c['iceut'](_0x44ce74, _0x2da0f9);
                    }
                }, _0xc23e98 = _0x565c79[_0x733cca(0x87b)], _0x17f086 = this[_0x733cca(0x752)][_0x733cca(0x65e)](_0xb2f3f8 => _0xb2f3f8[_0x733cca(0xa49)]['id'] === _0xc23e98['typeId']);
            if (!_0x17f086)
                return;
            const _0x20d508 = _0x565c79[_0x733cca(0x848)];
            if (_0x54dd2c['ITPIF'](_0x20d508['getGameMode'](), _0x57ec6d['creative']))
                return;
            const _0x17f757 = _0x54dd2c[_0x733cca(0x925)](_0x59bdcb, _0x20d508, _0x1cfb66[_0x733cca(0xc15)]);
            if (_0x17f086[_0x733cca(0xa49)]['items'] && (!_0x17f757 || !_0x17f086[_0x733cca(0xa49)][_0x733cca(0x4e4)][_0x733cca(0x620)](_0x17f757[_0x733cca(0x1b9)])))
                return;
            const _0x31c30a = _0x17f086[_0x733cca(0xa49)][_0x733cca(0x5e0)] ?? [], _0x38a4bf = _0xc23e98[_0x733cca(0x5a0)](), _0x155fd5 = _0xc23e98['dimension'], _0x1d4873 = _0x17f757?.[_0x733cca(0x3cc)](_0x54dd2c['OEmuf']), _0x2ae518 = _0xc23e98[_0x733cca(0x5fa)][_0x733cca(0x30a)](_0x54dd2c[_0x733cca(0x666)]);
            if (_0x1d4873) {
                const _0x44dcc6 = _0x1d4873[_0x733cca(0x928)](_0x54dd2c[_0x733cca(0x9e2)]);
                if (_0x44dcc6)
                    return;
            }
            if (_0x1d4873?.[_0x733cca(0x61b)](_0x733cca(0x313)) && _0x17f086[_0x733cca(0xa49)][_0x733cca(0xbe3)]) {
                const _0xba9799 = _0x1d4873[_0x733cca(0x928)](_0x54dd2c['GDaTW'])?.[_0x733cca(0x98d)] ?? 0x0;
                _0x41b16f[_0x733cca(0x873)](() => {
                    const _0x525529 = _0x733cca;
                    _0x31c30a[_0x525529(0x3e1)](_0x5e0128 => {
                        const _0x2b7c19 = _0x525529, _0x354118 = _0x2ae518 ?? _0x34dcd1['FtCPW'](_0x5e0128['count'], _0xba9799);
                        _0x155fd5[_0x2b7c19(0x220)](new _0x5aa122(_0x5e0128['id'], _0x354118), _0x38a4bf);
                    });
                }, 0x1);
                return;
            }
            _0x41b16f[_0x733cca(0x873)](() => {
                const _0x73674e = _0x733cca;
                _0x31c30a[_0x73674e(0x3e1)](_0x44a32f => {
                    const _0x226fbc = _0x73674e, _0xb4aa9b = _0x2ae518 ?? _0x44a32f[_0x226fbc(0x2fe)];
                    _0x155fd5[_0x226fbc(0x220)](new _0x5aa122(_0x44a32f['id'], _0xb4aa9b), _0x38a4bf);
                });
            }, 0x1);
        });
    }
};
_0x25e7d0(_0x33acff, _0x21f734(0x752), []);
var _0x260c44 = _0x33acff;
function _0x50f691() {
    const _0x4bc78f = _0x21f734, _0x100539 = {
            'IeWZf': '3|4|2|0|1',
            'uuRFo': _0x4bc78f(0x87d),
            'CcAHL': _0x4bc78f(0xbe5),
            'GbDdk': 'minecraft:glass_bottle',
            'IoCdn': _0x4bc78f(0xb3f),
            'MFboo': 'mob.slime.squish',
            'GnSJL': _0x4bc78f(0x24c),
            'szFiN': _0x4bc78f(0x722),
            'noYbT': _0x4bc78f(0x459),
            'jHlGn': 'hand',
            'bcRNv': 'sb_bf:jar_cookie',
            'gedYr': _0x4bc78f(0x9d3),
            'nzbUR': 'minecraft:honey_bottle',
            'PJjMu': _0x4bc78f(0x1c7),
            'ZhvaC': 'minecraft:cookie'
        }, _0x2cf14e = _0x100539[_0x4bc78f(0x34b)][_0x4bc78f(0x1f5)]('|');
    let _0x48b5a7 = 0x0;
    while (!![]) {
        switch (_0x2cf14e[_0x48b5a7++]) {
        case '0':
            _0xb54d87[_0x4bc78f(0x4c3)]({
                'id': _0x4bc78f(0x9aa),
                'transform': {
                    'transforms': [{
                            'transformTo': { 'id': _0x100539[_0x4bc78f(0xb66)] },
                            'sound': _0x100539['CcAHL'],
                            'item': _0x100539[_0x4bc78f(0xa0d)],
                            'transformItem': _0x4bc78f(0x280),
                            'takeItem': !![]
                        }]
                }
            });
            continue;
        case '1':
            _0xb54d87[_0x4bc78f(0x4c3)]({
                'id': _0x100539[_0x4bc78f(0x785)],
                'transform': {
                    'transforms': [{
                            'transformTo': { 'id': _0x100539['uuRFo'] },
                            'item': _0x4bc78f(0xbf3),
                            'sound': _0x100539[_0x4bc78f(0x21f)],
                            'receiveItem': _0x4bc78f(0x1c7)
                        }]
                }
            });
            continue;
        case '2':
            _0xb54d87[_0x4bc78f(0x4c3)]({
                'id': _0x100539[_0x4bc78f(0xac0)],
                'transform': {
                    'transforms': [
                        {
                            'states': [{
                                    'state': _0x4bc78f(0x722),
                                    'value': 0x1
                                }],
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0xac0)],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x2
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x21f)],
                            'item': 'minecraft:sea_pickle',
                            'takeItem': !![]
                        },
                        {
                            'states': [{
                                    'state': _0x100539[_0x4bc78f(0x662)],
                                    'value': 0x2
                                }],
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0xac0)],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x3
                                    }]
                            },
                            'sound': _0x100539['MFboo'],
                            'item': _0x100539[_0x4bc78f(0xab1)],
                            'takeItem': !![]
                        },
                        {
                            'states': [{
                                    'state': _0x100539['szFiN'],
                                    'value': 0x3
                                }],
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0xac0)],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x2
                                    }]
                            },
                            'item': _0x100539[_0x4bc78f(0x775)],
                            'sound': _0x4bc78f(0xa6b),
                            'receiveItem': _0x4bc78f(0x459)
                        },
                        {
                            'states': [{
                                    'state': _0x100539[_0x4bc78f(0x662)],
                                    'value': 0x2
                                }],
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0xac0)],
                                'states': [{
                                        'state': _0x4bc78f(0x722),
                                        'value': 0x1
                                    }]
                            },
                            'item': _0x4bc78f(0xbf3),
                            'sound': 'mob.slime.squish',
                            'receiveItem': _0x4bc78f(0x459)
                        },
                        {
                            'states': [{
                                    'state': _0x100539['szFiN'],
                                    'value': 0x1
                                }],
                            'transformTo': { 'id': _0x100539[_0x4bc78f(0xb66)] },
                            'item': _0x100539[_0x4bc78f(0x775)],
                            'sound': _0x100539[_0x4bc78f(0x21f)],
                            'receiveItem': _0x100539[_0x4bc78f(0xab1)]
                        }
                    ]
                }
            });
            continue;
        case '3':
            _0xb54d87[_0x4bc78f(0x4c3)]({
                'id': _0x100539[_0x4bc78f(0xb66)],
                'transform': {
                    'transforms': [
                        {
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0x49d)],
                                'states': [{
                                        'state': _0x4bc78f(0x722),
                                        'value': 0x1
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': 'minecraft:cookie',
                            'takeItem': !![]
                        },
                        {
                            'transformTo': {
                                'id': _0x100539['GnSJL'],
                                'states': [{
                                        'state': _0x4bc78f(0x722),
                                        'value': 0x1
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x21f)],
                            'item': _0x100539['noYbT'],
                            'takeItem': !![]
                        },
                        {
                            'transformTo': { 'id': _0x4bc78f(0x9aa) },
                            'sound': _0x4bc78f(0x522),
                            'item': _0x100539['nzbUR'],
                            'takeItem': !![],
                            'transformItem': _0x100539['GbDdk']
                        },
                        {
                            'transformTo': { 'id': _0x4bc78f(0xb3f) },
                            'sound': _0x100539['MFboo'],
                            'item': _0x100539[_0x4bc78f(0x90c)],
                            'takeItem': !![]
                        }
                    ]
                }
            });
            continue;
        case '4':
            _0xb54d87['register']({
                'id': _0x100539[_0x4bc78f(0x49d)],
                'transform': {
                    'transforms': [
                        {
                            'states': [{
                                    'state': _0x100539['szFiN'],
                                    'value': 0x1
                                }],
                            'transformTo': {
                                'id': _0x100539['bcRNv'],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x2
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': _0x100539[_0x4bc78f(0x5b8)],
                            'takeItem': !![]
                        },
                        {
                            'states': [{
                                    'state': _0x100539[_0x4bc78f(0x662)],
                                    'value': 0x2
                                }],
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0x49d)],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x3
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': _0x100539[_0x4bc78f(0x5b8)],
                            'takeItem': !![]
                        },
                        {
                            'states': [{
                                    'state': _0x100539['szFiN'],
                                    'value': 0x3
                                }],
                            'transformTo': {
                                'id': 'sb_bf:jar_cookie',
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x4
                                    }]
                            },
                            'sound': _0x4bc78f(0x9d3),
                            'item': _0x100539['ZhvaC'],
                            'takeItem': !![]
                        },
                        {
                            'states': [{
                                    'state': _0x100539[_0x4bc78f(0x662)],
                                    'value': 0x4
                                }],
                            'transformTo': {
                                'id': _0x100539['bcRNv'],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x5
                                    }]
                            },
                            'sound': _0x4bc78f(0x9d3),
                            'item': _0x100539[_0x4bc78f(0x5b8)],
                            'takeItem': !![]
                        },
                        {
                            'states': [{
                                    'state': _0x4bc78f(0x722),
                                    'value': 0x5
                                }],
                            'transformTo': {
                                'id': _0x100539['bcRNv'],
                                'states': [{
                                        'state': _0x4bc78f(0x722),
                                        'value': 0x4
                                    }]
                            },
                            'sound': _0x4bc78f(0x9d3),
                            'item': _0x100539[_0x4bc78f(0x775)],
                            'receiveItem': _0x100539['ZhvaC']
                        },
                        {
                            'states': [{
                                    'state': _0x100539['szFiN'],
                                    'value': 0x4
                                }],
                            'transformTo': {
                                'id': _0x100539[_0x4bc78f(0x49d)],
                                'states': [{
                                        'state': _0x100539[_0x4bc78f(0x662)],
                                        'value': 0x3
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': _0x4bc78f(0xbf3),
                            'receiveItem': _0x100539[_0x4bc78f(0x5b8)]
                        },
                        {
                            'states': [{
                                    'state': _0x4bc78f(0x722),
                                    'value': 0x3
                                }],
                            'transformTo': {
                                'id': _0x4bc78f(0x1b6),
                                'states': [{
                                        'state': _0x100539['szFiN'],
                                        'value': 0x2
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': _0x100539[_0x4bc78f(0x775)],
                            'receiveItem': _0x100539['ZhvaC']
                        },
                        {
                            'states': [{
                                    'state': _0x100539[_0x4bc78f(0x662)],
                                    'value': 0x2
                                }],
                            'transformTo': {
                                'id': 'sb_bf:jar_cookie',
                                'states': [{
                                        'state': 'sb_bf:count',
                                        'value': 0x1
                                    }]
                            },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': _0x100539[_0x4bc78f(0x775)],
                            'receiveItem': _0x4bc78f(0xa11)
                        },
                        {
                            'states': [{
                                    'state': 'sb_bf:count',
                                    'value': 0x1
                                }],
                            'transformTo': { 'id': _0x100539['uuRFo'] },
                            'sound': _0x100539[_0x4bc78f(0x426)],
                            'item': _0x4bc78f(0xbf3),
                            'receiveItem': 'minecraft:cookie'
                        }
                    ]
                }
            });
            continue;
        }
        break;
    }
}
function _0x1397fd() {
    const _0x28809b = _0x21f734, _0x1364b1 = {
            'ifgiz': 'random.burp',
            'nPofx': _0x28809b(0xb2c),
            'itjMe': _0x28809b(0x53a),
            'uMpfD': _0x28809b(0x793),
            'eoQhV': _0x28809b(0x2d4),
            'qnWDy': _0x28809b(0xa32),
            'gxxse': 'minecraft:rabbit_stew',
            'PkgtG': 'minecraft:bowl',
            'FsHKp': 'sb_bf:beetroot_soup',
            'otTyl': _0x28809b(0x39b),
            'vIOFl': 'hand'
        };
    _0xb54d87[_0x28809b(0x4c3)]({
        'id': _0x1364b1['itjMe'],
        'transform': {
            'transforms': [
                {
                    'transformTo': { 'id': _0x1364b1[_0x28809b(0x914)] },
                    'item': _0x1364b1[_0x28809b(0xb4a)],
                    'sound': _0x28809b(0x522),
                    'takeItem': !![],
                    'transformItem': _0x28809b(0x5b3)
                },
                {
                    'transformTo': { 'id': _0x1364b1[_0x28809b(0xb10)] },
                    'item': _0x1364b1[_0x28809b(0x542)],
                    'takeItem': !![],
                    'sound': 'use.honey_block',
                    'transformItem': _0x1364b1[_0x28809b(0x4dd)]
                },
                {
                    'transformTo': { 'id': _0x1364b1[_0x28809b(0x5cf)] },
                    'item': _0x1364b1['otTyl'],
                    'takeItem': !![],
                    'sound': _0x28809b(0x522),
                    'transformItem': _0x1364b1[_0x28809b(0x4dd)]
                }
            ]
        }
    }), _0xb54d87['register']({
        'id': _0x1364b1[_0x28809b(0x914)],
        'transform': {
            'transforms': [{
                    'transformTo': { 'id': _0x1364b1[_0x28809b(0x717)] },
                    'function': _0x568092 => {
                        const _0x354cd9 = _0x28809b;
                        _0x568092[_0x354cd9(0xb28)][_0x354cd9(0xa70)](_0x1364b1['ifgiz'], _0x568092['location']), _0x568092[_0x354cd9(0x451)](_0x1364b1['nPofx'], 0x14, {
                            'amplifier': 0x5,
                            'showParticles': ![]
                        });
                    },
                    'item': _0x1364b1[_0x28809b(0x47d)]
                }]
        }
    }), _0xb54d87['register']({
        'id': _0x1364b1[_0x28809b(0xb10)],
        'transform': {
            'transforms': [{
                    'transformTo': { 'id': _0x1364b1['itjMe'] },
                    'function': _0x4dc668 => {
                        const _0x1337df = _0x28809b;
                        _0x4dc668[_0x1337df(0xb28)][_0x1337df(0xa70)](_0x1364b1[_0x1337df(0x342)], _0x4dc668['location']), _0x4dc668[_0x1337df(0x451)]('minecraft:saturation', 0x14, {
                            'amplifier': 0x9,
                            'showParticles': ![]
                        });
                    },
                    'item': _0x28809b(0xbf3)
                }]
        }
    }), _0xb54d87['register']({
        'id': _0x1364b1[_0x28809b(0x5cf)],
        'transform': {
            'transforms': [{
                    'transformTo': { 'id': _0x1364b1[_0x28809b(0x717)] },
                    'function': _0x506d0c => {
                        const _0x5a3f43 = _0x28809b;
                        _0x506d0c[_0x5a3f43(0xb28)][_0x5a3f43(0xa70)](_0x5a3f43(0x740), _0x506d0c[_0x5a3f43(0x2c0)]), _0x506d0c['addEffect'](_0x1364b1[_0x5a3f43(0x54d)], 0x14, {
                            'amplifier': 0x5,
                            'showParticles': ![]
                        });
                    },
                    'item': _0x1364b1['vIOFl']
                }]
        }
    });
}
function _0x214944() {
    const _0x26617e = _0x21f734, _0x533cd2 = {
            'aOBTk': _0x26617e(0x6fe),
            'MNtES': _0x26617e(0x6c9),
            'bPTiV': 'sb_bf:lit',
            'JjLro': 'vertical',
            'iKaqt': _0x26617e(0x40e),
            'DjpPh': 'all',
            'hwVIx': _0x26617e(0x4a8),
            'wDhXW': _0x26617e(0x4f7),
            'zHIEk': _0x26617e(0x440),
            'ijhuh': function (_0x9721a8, _0x243ae3) {
                return _0x9721a8 === _0x243ae3;
            },
            'lHTwN': _0x26617e(0x9d5),
            'bZeis': function (_0xeb37af, _0x36dd5d) {
                return _0xeb37af !== _0x36dd5d;
            },
            'EAPxN': function (_0x45800b, _0x3f7b5d) {
                return _0x45800b !== _0x3f7b5d;
            },
            'tVbim': function (_0x1241f9, _0x210812) {
                return _0x1241f9(_0x210812);
            },
            'bWJYf': function (_0x5a0d01, _0x1fc57f) {
                return _0x5a0d01 === _0x1fc57f;
            },
            'lJHjE': 'fire.ignite',
            'Yjcpj': _0x26617e(0x9a8),
            'MOMkX': _0x26617e(0xba4),
            'fwkfY': _0x26617e(0x571),
            'FQQkz': _0x26617e(0x47a),
            'FmmjY': _0x26617e(0x7bd),
            'RdurM': _0x26617e(0x709),
            'cPzep': _0x26617e(0x6a6),
            'VlGFM': _0x26617e(0x487),
            'eDSvO': _0x26617e(0x5eb),
            'qgKBb': _0x26617e(0x291),
            'sGDqX': _0x26617e(0x857),
            'YUckr': 'below',
            'VCwii': 'sb_bf:half',
            'VoZBU': 'transform',
            'TTMlk': _0x26617e(0x6d3),
            'WoROu': _0x26617e(0xa13),
            'GwUtp': _0x26617e(0xa2a),
            'RDdHg': _0x26617e(0x22a),
            'oHZQE': 'multiblock',
            'ROUss': _0x26617e(0xaa0),
            'pJsVH': _0x26617e(0xa45),
            'JJBip': function (_0x4fdfea) {
                return _0x4fdfea();
            },
            'kCBVF': function (_0x309c73) {
                return _0x309c73();
            },
            'PyEQg': 'sb_bf:gold_ingot_pile',
            'kgicj': 'sb_bf:iron_ingot_pile',
            'OqyOI': _0x26617e(0x68f),
            'FlZEE': 'sb_bf:netherite_ingot_pile',
            'bUspk': 'sb_bf:globe',
            'MSxBD': 'sb_bf:animation',
            'FThxd': 'sb_bf:scarecrow',
            'FRKfd': _0x26617e(0x8cb),
            'GObwC': _0x26617e(0x71f),
            'ntuxa': _0x26617e(0x5f2),
            'TdgQS': _0x26617e(0x598),
            'frjxX': 'acacia',
            'CSejm': _0x26617e(0x4fd),
            'Pmohr': _0x26617e(0x4e3),
            'YAqWP': _0x26617e(0x27f),
            'vZdEO': _0x26617e(0x65a),
            'XcdKH': _0x26617e(0x7db),
            'kgEhl': _0x26617e(0x942),
            'cqgLV': _0x26617e(0x6d0),
            'WSGac': _0x26617e(0x911),
            'YbAlw': 'magenta',
            'SNlVO': _0x26617e(0xc0c),
            'GtumZ': _0x26617e(0x78b),
            'jKRFa': _0x26617e(0x59e),
            'GVwxp': 'purple',
            'HQhnT': 'blue',
            'msOkj': _0x26617e(0x8e9),
            'eTpDL': 'green',
            'wMxLR': _0x26617e(0xaf1),
            'TpUHA': 'cyan',
            'dVtsc': _0x26617e(0xa9d),
            'KHSMs': _0x26617e(0x7e2),
            'vloKD': _0x26617e(0x260),
            'sOWct': _0x26617e(0x388),
            'VHnVl': _0x26617e(0x5bf),
            'NGMEM': _0x26617e(0x256),
            'ptTsp': _0x26617e(0x827),
            'xKlEv': _0x26617e(0x6eb),
            'eQCjn': _0x26617e(0x64a),
            'kQYMz': _0x26617e(0x465),
            'NOITa': _0x26617e(0xbc3),
            'RRzfU': _0x26617e(0x915),
            'MMJeb': _0x26617e(0x894),
            'pGCLR': 'black_candle_holder',
            'vbPvw': _0x26617e(0x3cd),
            'ywFvY': _0x26617e(0xbb8),
            'bKkom': 'lime_candle_holder',
            'wUkBg': _0x26617e(0xbc6),
            'yfyYf': _0x26617e(0xb9d),
            'oFiwm': _0x26617e(0x44c),
            'rVFaY': _0x26617e(0x8e1),
            'EyfUz': _0x26617e(0xb70),
            'sEsAA': _0x26617e(0xa26),
            'JEIFG': _0x26617e(0x597),
            'WdaMm': _0x26617e(0xbf8),
            'PXOJm': _0x26617e(0xbee),
            'IovGm': _0x26617e(0x309),
            'zcVbt': _0x26617e(0xbd4),
            'KhpvT': _0x26617e(0x401),
            'ODCFv': _0x26617e(0x91a),
            'MloSu': _0x26617e(0x980),
            'Atbnp': _0x26617e(0x93c),
            'tGAWy': 'open.cherry_wood_fence_gate',
            'kgAzl': 'close.cherry_wood_fence_gate',
            'TgyOw': _0x26617e(0xb3a),
            'VQrQO': _0x26617e(0x5ce),
            'UAdHV': _0x26617e(0x359),
            'FsVEc': _0x26617e(0x526),
            'bPyfR': _0x26617e(0x896),
            'nOLIp': _0x26617e(0x83f),
            'lPpsI': _0x26617e(0x618),
            'thyWm': _0x26617e(0xbbd),
            'JQDmf': _0x26617e(0x54a),
            'ZPsWr': _0x26617e(0x8bc),
            'TxMmm': 'sb_bf:pale_oak_shutter',
            'rhLmp': _0x26617e(0x5d8),
            'OjuVa': _0x26617e(0x66d),
            'OwDBd': _0x26617e(0xa30),
            'fjFYR': _0x26617e(0x414),
            'QYjij': _0x26617e(0xa9a),
            'gHxzh': 'dandelion',
            'sDhLn': 'poppy',
            'gYBrI': _0x26617e(0x862),
            'LnxTv': 'minecraft:allium',
            'JmsoI': 'minecraft:azure_bluet',
            'WiXsu': 'azure_bluet',
            'nxxwQ': _0x26617e(0x738),
            'JaJJb': _0x26617e(0x7c2),
            'oEbeN': _0x26617e(0x6ff),
            'GHROh': _0x26617e(0xa97),
            'rKqjH': _0x26617e(0x2ad),
            'GSGSq': 'minecraft:oxeye_daisy',
            'OTLXB': _0x26617e(0x767),
            'WuiHD': _0x26617e(0x8fe),
            'aNFNa': _0x26617e(0x7a5),
            'MjgkZ': _0x26617e(0x6e4),
            'kdehg': _0x26617e(0xb0a),
            'VEqHr': 'wither_rose',
            'qQVNb': _0x26617e(0x3a4),
            'tOOQv': _0x26617e(0x54e),
            'ZGdlA': _0x26617e(0x829),
            'iLvcQ': _0x26617e(0x3b4),
            'dIhmC': _0x26617e(0x6d8),
            'ghBKA': _0x26617e(0x66f),
            'lrzMo': _0x26617e(0xb0c),
            'dgmah': _0x26617e(0x41e),
            'pjREh': _0x26617e(0x2ac),
            'jzoUp': 'sb_bf:cyan_glazed_terracotta_vase',
            'Mimxv': _0x26617e(0x85b),
            'yFkaw': _0x26617e(0x240),
            'dHvNa': _0x26617e(0x8dc),
            'hTsKB': _0x26617e(0x1e0),
            'qgzpN': _0x26617e(0x277),
            'idPMv': _0x26617e(0xb98),
            'YdIHR': _0x26617e(0x849),
            'ZAEQl': _0x26617e(0x8ea),
            'mZwwh': 'sb_bf:red_glazed_terracotta_vase',
            'gJrGo': 'sb_bf:white_glazed_terracotta_vase',
            'OHvdd': _0x26617e(0x762),
            'hAcqf': 'sb_bf:big_flower_pot',
            'vMIAs': _0x26617e(0xb90),
            'QkNKx': _0x26617e(0xb4d),
            'kidZU': 'bucket.fill_water',
            'iyuvW': _0x26617e(0x5e2),
            'CbxqG': _0x26617e(0x447),
            'tRgTC': _0x26617e(0xbf3),
            'uQBIU': 'sb_bf:oak_glass_door',
            'nnYur': _0x26617e(0xbd0),
            'HiVnR': 'close.wooden_door',
            'iQYGv': _0x26617e(0xa4a),
            'scqTU': _0x26617e(0x986),
            'NXrqv': _0x26617e(0x320),
            'QqFkq': 'sb_bf:mangrove_glass_door',
            'ndqZg': _0x26617e(0xaaf),
            'PpTRW': 'open.bamboo_wood_door',
            'pmLbc': _0x26617e(0x638),
            'IaDfF': _0x26617e(0xb4b),
            'LPYfX': 'sb_bf:acacia_glass_door',
            'ZtNmv': _0x26617e(0x5f8),
            'DSbBe': _0x26617e(0xb23),
            'ynPrv': _0x26617e(0x399),
            'jQTFs': _0x26617e(0x802),
            'EwEpC': _0x26617e(0x5cc),
            'NVPwO': _0x26617e(0xa8d),
            'YwERF': _0x26617e(0x9e7),
            'ouAIF': _0x26617e(0x6b0),
            'crChu': _0x26617e(0x66c),
            'PgWKW': _0x26617e(0xabb),
            'ibiVI': _0x26617e(0x867),
            'wmxdT': _0x26617e(0x2cc),
            'fjfOs': _0x26617e(0x22d),
            'UNpot': _0x26617e(0xac8),
            'fFzgK': _0x26617e(0x450),
            'ycLAt': _0x26617e(0x7cd),
            'wwxwX': 'open.bamboo_wood_trapdoor',
            'vTSmn': _0x26617e(0x78e),
            'UMsfz': 'sb_bf:acacia_glass_trapdoor',
            'qYVMt': _0x26617e(0x554),
            'NognK': _0x26617e(0x6cb),
            'IjZGm': 'close.nether_wood_trapdoor_close',
            'mWAng': _0x26617e(0x86a),
            'PEQkU': _0x26617e(0x544),
            'LRRLI': _0x26617e(0x818),
            'yiqai': _0x26617e(0x96f),
            'PNgbW': _0x26617e(0x2b5)
        };
    _0xb54d87[_0x26617e(0x341)](_0x3fa9b2), _0xb54d87[_0x26617e(0x341)](_0xa93c07), _0xb54d87[_0x26617e(0x341)](_0x28b227), _0xb54d87[_0x26617e(0x341)](_0x28def9), _0xb54d87[_0x26617e(0x341)](_0x4537ac), _0xb54d87[_0x26617e(0x341)](_0x70c0aa), _0xb54d87[_0x26617e(0x341)](_0x533cd2[_0x26617e(0x1bf)], _0x398ddd), _0xb54d87[_0x26617e(0x341)](_0x58d8f0), _0xb54d87[_0x26617e(0x341)](_0x3228e9), _0xb54d87[_0x26617e(0x341)](_0x484f16), _0xb54d87[_0x26617e(0x341)](_0x59694b), _0xb54d87[_0x26617e(0x341)](_0x45dda2), _0xb54d87['registerSubclass'](_0x2d5af9), _0xb54d87['registerSubclass'](_0x533cd2[_0x26617e(0x53c)], _0x330c84), _0xb54d87[_0x26617e(0x341)](_0x533cd2[_0x26617e(0x52d)], _0x4a07fe), _0xb54d87[_0x26617e(0x341)](_0x533cd2[_0x26617e(0x4ab)], _0x425a4d), _0xb54d87[_0x26617e(0x341)](_0x2b1988), _0xb54d87[_0x26617e(0x341)](_0x533cd2[_0x26617e(0x5c8)], _0x4a8742), _0xb54d87[_0x26617e(0x341)]('multiPlacement', _0x2234ce), _0xb54d87[_0x26617e(0x341)](_0x2bd013), _0xb54d87[_0x26617e(0x341)](_0x533cd2[_0x26617e(0x390)], _0x49976e), _0xb54d87[_0x26617e(0x341)](_0x533cd2[_0x26617e(0x492)], _0x3461dd), _0xb54d87[_0x26617e(0x341)](_0x533cd2['pJsVH'], _0x260c44), _0x2d869c(), _0x533cd2[_0x26617e(0x43f)](_0x46ab55), _0x533cd2[_0x26617e(0x43f)](_0x50f691), _0x533cd2[_0x26617e(0x324)](_0x1397fd);
    const _0x482f74 = [
        _0x533cd2[_0x26617e(0x58a)],
        _0x533cd2[_0x26617e(0x250)],
        _0x533cd2[_0x26617e(0x423)],
        _0x533cd2[_0x26617e(0x457)]
    ];
    _0x482f74[_0x26617e(0x3e1)](_0x25755d => {
        const _0x41cc7e = _0x26617e;
        _0xb54d87['register']({
            'id': _0x25755d,
            'multiPlacement': {
                'states': 0x8,
                'sound': _0x533cd2[_0x41cc7e(0x276)]
            }
        });
    }), _0xb54d87[_0x26617e(0x4c3)]({
        'id': _0x533cd2[_0x26617e(0x494)],
        'transform': {
            'transforms': [{
                    'states': [{
                            'state': _0x533cd2['MSxBD'],
                            'value': ![]
                        }],
                    'item': _0x533cd2[_0x26617e(0x917)],
                    'sound': _0x26617e(0x36a),
                    'takeItem': ![],
                    'transformTo': {
                        'states': [{
                                'state': _0x26617e(0xbd5),
                                'value': !![]
                            }]
                    }
                }]
        },
        'entityAnimation': {
            'entity': _0x533cd2[_0x26617e(0x494)],
            'time': 0.75
        }
    }), _0xb54d87['register']({
        'id': _0x533cd2[_0x26617e(0xc00)],
        'transform': {
            'transforms': [{
                    'states': [{
                            'state': _0x533cd2['MSxBD'],
                            'value': ![]
                        }],
                    'item': _0x533cd2[_0x26617e(0x917)],
                    'sound': _0x26617e(0x691),
                    'particle': _0x26617e(0xb4c),
                    'takeItem': ![],
                    'transformTo': {
                        'states': [{
                                'state': _0x533cd2[_0x26617e(0x9b0)],
                                'value': !![]
                            }]
                    }
                }]
        },
        'entityAnimation': {
            'entity': _0x533cd2[_0x26617e(0xc00)],
            'time': 1.2
        },
        'events': {
            'onDestroy': _0x1e907d => {
                const _0x31ec5b = _0x26617e;
                _0x1e907d['dimension'][_0x31ec5b(0xa70)](_0x533cd2[_0x31ec5b(0x49a)], _0x1e907d[_0x31ec5b(0x87b)][_0x31ec5b(0x2c0)]);
            }
        }
    }), _0xb54d87[_0x26617e(0x4c3)]({
        'id': _0x26617e(0x8cb),
        'loot': {
            'lootTable': [{
                    'id': _0x533cd2[_0x26617e(0x258)],
                    'count': 0x1
                }]
        }
    });
    const _0x22602e = [
        _0x533cd2[_0x26617e(0x545)],
        _0x533cd2[_0x26617e(0xa0e)],
        _0x26617e(0x474),
        _0x533cd2[_0x26617e(0xad5)],
        _0x533cd2[_0x26617e(0x87f)],
        _0x533cd2[_0x26617e(0x57b)],
        _0x533cd2[_0x26617e(0xa3a)],
        _0x533cd2[_0x26617e(0xc1a)],
        _0x533cd2[_0x26617e(0x566)],
        _0x26617e(0x55c),
        _0x26617e(0x1c3),
        _0x533cd2[_0x26617e(0x5ba)]
    ];
    _0x22602e[_0x26617e(0x3e1)](_0x196c51 => {
        const _0x4095fd = _0x26617e;
        _0xb54d87[_0x4095fd(0x4c3)]({
            'id': _0x4095fd(0x300) + _0x196c51 + _0x4095fd(0xa81),
            'loot': {
                'lootTable': [{
                        'id': _0x4095fd(0x300) + _0x196c51 + _0x4095fd(0xa81),
                        'count': 0x1
                    }]
            }
        }), _0xb54d87[_0x4095fd(0x4c3)]({
            'id': _0x4095fd(0x300) + _0x196c51 + _0x4095fd(0x85a),
            'seat': {
                'position': {
                    'x': 0.5,
                    'y': 0.45,
                    'z': 0.5
                }
            }
        }), _0xb54d87[_0x4095fd(0x4c3)]({
            'id': _0x4095fd(0x300) + _0x196c51 + _0x4095fd(0xa78),
            'seat': {
                'position': {
                    'x': 0.5,
                    'y': 0.45,
                    'z': 0.5
                }
            }
        });
    });
    const _0x44d799 = [
        'white',
        _0x533cd2[_0x26617e(0x1ff)],
        _0x26617e(0xbf5),
        _0x533cd2['cqgLV'],
        _0x533cd2[_0x26617e(0xa86)],
        _0x533cd2['YbAlw'],
        _0x533cd2['SNlVO'],
        _0x26617e(0x8c1),
        _0x533cd2['GtumZ'],
        _0x533cd2[_0x26617e(0xa55)],
        _0x533cd2['GVwxp'],
        _0x533cd2[_0x26617e(0x2de)],
        _0x533cd2['msOkj'],
        _0x533cd2['eTpDL'],
        _0x533cd2[_0x26617e(0x75d)],
        _0x533cd2[_0x26617e(0x588)]
    ];
    _0x44d799[_0x26617e(0x3e1)](_0x42d612 => {
        const _0x4faedd = _0x26617e;
        _0xb54d87[_0x4faedd(0x4c3)]({
            'id': _0x4faedd(0x300) + _0x42d612 + '_lamp',
            'transform': {
                'transforms': [
                    {
                        'states': [{
                                'state': _0x533cd2[_0x4faedd(0x653)],
                                'value': ![]
                            }],
                        'adjecentUpdate': _0x533cd2[_0x4faedd(0x839)],
                        'cancelOnSneak': !![],
                        'sound': _0x533cd2['iKaqt'],
                        'item': _0x4faedd(0x69d),
                        'takeItem': ![],
                        'transformTo': {
                            'states': [{
                                    'state': _0x4faedd(0x612),
                                    'value': !![]
                                }]
                        }
                    },
                    {
                        'states': [{
                                'state': _0x533cd2['bPTiV'],
                                'value': !![]
                            }],
                        'adjecentUpdate': _0x533cd2[_0x4faedd(0x839)],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'sound': _0x533cd2[_0x4faedd(0x735)],
                        'item': _0x533cd2[_0x4faedd(0x917)],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x4faedd(0x653)],
                                    'value': ![]
                                }]
                        }
                    }
                ]
            }
        }), _0xb54d87[_0x4faedd(0x4c3)]({
            'id': 'sb_bf:' + _0x42d612 + _0x4faedd(0x6e1),
            'seat': {
                'position': {
                    'x': 0.5,
                    'y': 0.35,
                    'z': 0.5
                }
            }
        });
    });
    const _0x35ba21 = [
        _0x533cd2[_0x26617e(0x766)],
        'white_chandelier',
        _0x533cd2[_0x26617e(0xa89)],
        _0x533cd2[_0x26617e(0xc19)],
        _0x533cd2[_0x26617e(0x58e)],
        _0x533cd2[_0x26617e(0x381)],
        _0x26617e(0x80c),
        _0x533cd2[_0x26617e(0x266)],
        _0x533cd2[_0x26617e(0xc02)],
        _0x533cd2[_0x26617e(0x3d5)],
        _0x26617e(0x5e1),
        'purple_chandelier',
        _0x533cd2[_0x26617e(0x8d0)],
        _0x26617e(0x4fb),
        _0x533cd2['kQYMz'],
        _0x26617e(0x4ae),
        _0x533cd2[_0x26617e(0x318)]
    ];
    _0x35ba21[_0x26617e(0x3e1)](_0x11fc64 => {
        const _0x4323b4 = _0x26617e;
        _0xb54d87['register']({
            'id': 'sb_bf:' + _0x11fc64,
            'transform': {
                'transforms': [
                    {
                        'states': [{
                                'state': 'sb_bf:lit',
                                'value': ![]
                            }],
                        'sound': 'fire.ignite',
                        'item': _0x533cd2[_0x4323b4(0x7a3)],
                        'takeItem': ![],
                        'function': (_0x5248c1, _0x2d52fc) => {
                            _0x2108be(_0x5248c1);
                        },
                        'transformTo': {
                            'states': [{
                                    'state': _0x4323b4(0x612),
                                    'value': !![]
                                }]
                        }
                    },
                    {
                        'states': [{
                                'state': _0x533cd2['bPTiV'],
                                'value': !![]
                            }],
                        'sound': _0x533cd2['wDhXW'],
                        'item': _0x533cd2[_0x4323b4(0x917)],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x4323b4(0x653)],
                                    'value': ![]
                                }]
                        }
                    }
                ]
            },
            'visualEffects': {
                'particles': [
                    {
                        'id': _0x533cd2[_0x4323b4(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0.37,
                            'y': 0.24,
                            'z': 0x0
                        }
                    },
                    {
                        'id': _0x533cd2['zHIEk'],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': -0.37,
                            'y': 0.24,
                            'z': 0x0
                        }
                    },
                    {
                        'id': _0x4323b4(0x440),
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0x0,
                            'y': 0.24,
                            'z': -0.37
                        }
                    },
                    {
                        'id': _0x533cd2[_0x4323b4(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0x0,
                            'y': 0.24,
                            'z': 0.37
                        }
                    }
                ]
            }
        });
    });
    const _0x573cd5 = [
        'candle_holder',
        _0x26617e(0x468),
        _0x533cd2[_0x26617e(0xb74)],
        _0x533cd2[_0x26617e(0x878)],
        _0x533cd2[_0x26617e(0xb36)],
        _0x26617e(0xb42),
        _0x26617e(0x9c0),
        _0x533cd2[_0x26617e(0x20c)],
        _0x533cd2[_0x26617e(0x6ca)],
        _0x533cd2['bKkom'],
        _0x533cd2[_0x26617e(0x6ab)],
        _0x533cd2['yfyYf'],
        'blue_candle_holder',
        _0x533cd2[_0x26617e(0x7b7)],
        _0x533cd2[_0x26617e(0x5f7)],
        _0x533cd2[_0x26617e(0x924)],
        _0x533cd2[_0x26617e(0x1bb)]
    ];
    _0x573cd5[_0x26617e(0x3e1)](_0x865f2d => {
        const _0x2233fc = _0x26617e, _0x371c45 = {
                'DvZaw': function (_0x2d0a74, _0x5b04f3) {
                    const _0x32250f = _0x3124;
                    return _0x533cd2[_0x32250f(0x783)](_0x2d0a74, _0x5b04f3);
                },
                'IwRJb': function (_0x190abe, _0x12fa39) {
                    const _0x976962 = _0x3124;
                    return _0x533cd2[_0x976962(0x719)](_0x190abe, _0x12fa39);
                }
            };
        _0xb54d87[_0x2233fc(0x4c3)]({
            'id': _0x2233fc(0x300) + _0x865f2d,
            'transform': {
                'transforms': [
                    {
                        'states': [{
                                'state': _0x533cd2['bPTiV'],
                                'value': ![]
                            }],
                        'sound': _0x533cd2[_0x2233fc(0x3c8)],
                        'item': _0x2233fc(0x4a8),
                        'takeItem': ![],
                        'function': (_0x4975b1, _0x5207d5) => {
                            const _0xe03372 = _0x2233fc;
                            _0x371c45[_0xe03372(0x416)](_0x2108be, _0x4975b1);
                        },
                        'transformTo': {
                            'states': [{
                                    'state': _0x2233fc(0x612),
                                    'value': !![]
                                }]
                        }
                    },
                    {
                        'states': [{
                                'state': _0x2233fc(0x612),
                                'value': !![]
                            }],
                        'sound': _0x533cd2[_0x2233fc(0x716)],
                        'item': _0x533cd2[_0x2233fc(0x917)],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x2233fc(0x653)],
                                    'value': ![]
                                }]
                        }
                    }
                ]
            },
            'visualEffects': {
                'particles': [
                    {
                        'id': _0x533cd2[_0x2233fc(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0x0,
                            'y': 0.55,
                            'z': 0x0
                        },
                        'conditions': _0x5313c5 => {
                            const _0xeda8ca = _0x2233fc;
                            return _0x5313c5[_0xeda8ca(0x5fa)][_0xeda8ca(0x30a)](_0xeda8ca(0x9d5)) === 'up';
                        }
                    },
                    {
                        'id': _0x533cd2[_0x2233fc(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0x0,
                            'y': 0.48,
                            'z': -0.31
                        },
                        'conditions': _0x5e9c84 => {
                            const _0x1e962a = _0x2233fc;
                            return _0x533cd2[_0x1e962a(0x52a)](_0x5e9c84[_0x1e962a(0x5fa)][_0x1e962a(0x30a)](_0x533cd2[_0x1e962a(0x6c2)]), 'up');
                        }
                    },
                    {
                        'id': _0x533cd2[_0x2233fc(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0x0,
                            'y': 0.48,
                            'z': 0.31
                        },
                        'conditions': _0x377b9c => {
                            const _0x5d12d6 = _0x2233fc;
                            return _0x371c45[_0x5d12d6(0x73f)](_0x377b9c[_0x5d12d6(0x5fa)][_0x5d12d6(0x30a)]('minecraft:block_face'), 'up');
                        }
                    },
                    {
                        'id': _0x533cd2[_0x2233fc(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0.125,
                            'y': 0.5,
                            'z': 0x0
                        },
                        'conditions': _0x2eb265 => {
                            const _0x4912b7 = _0x2233fc;
                            return _0x533cd2[_0x4912b7(0x72b)](_0x2eb265[_0x4912b7(0x5fa)][_0x4912b7(0x30a)](_0x533cd2[_0x4912b7(0x6c2)]), 'up');
                        }
                    },
                    {
                        'id': _0x533cd2[_0x2233fc(0x707)],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0.125,
                            'y': 0.41,
                            'z': 0.31
                        },
                        'conditions': _0x6068df => {
                            const _0x15e5b5 = _0x2233fc;
                            return _0x533cd2[_0x15e5b5(0x72b)](_0x6068df[_0x15e5b5(0x5fa)][_0x15e5b5(0x30a)](_0x533cd2[_0x15e5b5(0x6c2)]), 'up');
                        }
                    },
                    {
                        'id': _0x533cd2['zHIEk'],
                        'chance': 0x1,
                        'interval': 0x8,
                        'location': {
                            'x': 0.125,
                            'y': 0.41,
                            'z': -0.31
                        },
                        'conditions': _0x573e1e => {
                            const _0xabe5b9 = _0x2233fc;
                            return _0x533cd2[_0xabe5b9(0x712)](_0x573e1e['permutation'][_0xabe5b9(0x30a)](_0x533cd2[_0xabe5b9(0x6c2)]), 'up');
                        }
                    }
                ]
            }
        });
    });
    const _0x3921c1 = [
        {
            'id': _0x533cd2[_0x26617e(0x445)],
            'sound': {
                'open': _0x26617e(0x309),
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x697)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2['WdaMm']
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x683)],
            'sound': {
                'open': 'open.fence_gate',
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': 'sb_bf:jungle_special_fence_gate',
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x26617e(0xbf8)
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x64c)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x9d9)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0xbe9)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x283)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x62e)],
                'close': _0x533cd2[_0x26617e(0xadd)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x74c)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x6a5)],
            'sound': {
                'open': _0x26617e(0x66d),
                'close': _0x533cd2['UAdHV']
            }
        },
        {
            'id': 'sb_bf:crimson_special_fence_gate',
            'sound': {
                'open': _0x533cd2['FsVEc'],
                'close': _0x533cd2[_0x26617e(0xa31)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x513)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0xa2e)],
                'close': _0x533cd2[_0x26617e(0xa31)]
            }
        }
    ];
    _0x3921c1[_0x26617e(0x3e1)](_0x3fb5b9 => {
        const _0x2a2729 = _0x26617e;
        _0xb54d87[_0x2a2729(0x4c3)]({
            'id': _0x3fb5b9['id'],
            'transform': {
                'transforms': [
                    {
                        'states': [
                            {
                                'state': _0x533cd2[_0x2a2729(0x323)],
                                'value': ![]
                            },
                            {
                                'state': _0x533cd2[_0x2a2729(0x5d4)],
                                'value': [
                                    _0x2a2729(0x6a6),
                                    _0x533cd2[_0x2a2729(0x4d4)]
                                ]
                            }
                        ],
                        'face': [
                            'north',
                            'up',
                            _0x533cd2[_0x2a2729(0x263)],
                            _0x533cd2[_0x2a2729(0x684)],
                            _0x533cd2[_0x2a2729(0x3ea)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x533cd2['Yjcpj'],
                                    'value': !![]
                                },
                                {
                                    'state': _0x533cd2[_0x2a2729(0x5d4)],
                                    'value': _0x2a2729(0x6a6)
                                }
                            ]
                        },
                        'item': _0x533cd2[_0x2a2729(0x917)],
                        'sound': _0x3fb5b9[_0x2a2729(0x758)][_0x2a2729(0xaa6)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x2a2729(0x9a8),
                                'value': !![]
                            },
                            {
                                'state': _0x2a2729(0xba4),
                                'value': [
                                    _0x533cd2[_0x2a2729(0xb19)],
                                    _0x533cd2['fwkfY']
                                ]
                            }
                        ],
                        'face': [
                            'north',
                            'up',
                            _0x533cd2[_0x2a2729(0x263)],
                            _0x2a2729(0x7bd),
                            _0x533cd2[_0x2a2729(0x3ea)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x2a2729(0x9a8),
                                    'value': ![]
                                },
                                {
                                    'state': _0x533cd2[_0x2a2729(0x5d4)],
                                    'value': _0x533cd2['cPzep']
                                }
                            ]
                        },
                        'item': _0x2a2729(0x69d),
                        'sound': _0x3fb5b9[_0x2a2729(0x758)]['close']
                    },
                    {
                        'states': [
                            {
                                'state': _0x533cd2[_0x2a2729(0x323)],
                                'value': ![]
                            },
                            {
                                'state': _0x533cd2[_0x2a2729(0x5d4)],
                                'value': [
                                    _0x533cd2[_0x2a2729(0xb19)],
                                    'north'
                                ]
                            }
                        ],
                        'face': [
                            _0x533cd2[_0x2a2729(0xb19)],
                            'up',
                            _0x533cd2['FQQkz'],
                            _0x533cd2['FmmjY'],
                            _0x533cd2[_0x2a2729(0x3ea)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': 'sb_bf:open',
                                    'value': !![]
                                },
                                {
                                    'state': _0x533cd2[_0x2a2729(0x5d4)],
                                    'value': _0x533cd2[_0x2a2729(0x4d4)]
                                }
                            ]
                        },
                        'item': _0x2a2729(0x69d),
                        'sound': _0x3fb5b9[_0x2a2729(0x758)]['open']
                    },
                    {
                        'states': [
                            {
                                'state': _0x2a2729(0x9a8),
                                'value': !![]
                            },
                            {
                                'state': _0x533cd2['MOMkX'],
                                'value': [
                                    _0x533cd2[_0x2a2729(0xb19)],
                                    _0x2a2729(0x571)
                                ]
                            }
                        ],
                        'face': [
                            'south',
                            'up',
                            _0x533cd2[_0x2a2729(0x263)],
                            _0x533cd2[_0x2a2729(0x684)],
                            _0x533cd2[_0x2a2729(0x3ea)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x2a2729(0x9a8),
                                    'value': ![]
                                },
                                {
                                    'state': _0x2a2729(0xba4),
                                    'value': _0x533cd2['cPzep']
                                }
                            ]
                        },
                        'item': _0x533cd2[_0x2a2729(0x917)],
                        'sound': _0x3fb5b9[_0x2a2729(0x758)][_0x2a2729(0x500)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x533cd2[_0x2a2729(0x323)],
                                'value': ![]
                            },
                            {
                                'state': _0x2a2729(0xba4),
                                'value': [
                                    _0x2a2729(0x7bd),
                                    'west'
                                ]
                            }
                        ],
                        'face': [
                            _0x533cd2[_0x2a2729(0x684)],
                            'up',
                            _0x533cd2[_0x2a2729(0x263)],
                            'north',
                            _0x533cd2[_0x2a2729(0xb19)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x533cd2[_0x2a2729(0x323)],
                                    'value': !![]
                                },
                                {
                                    'state': _0x533cd2[_0x2a2729(0x5d4)],
                                    'value': _0x533cd2[_0x2a2729(0x3ea)]
                                }
                            ]
                        },
                        'item': _0x533cd2['DjpPh'],
                        'sound': _0x3fb5b9[_0x2a2729(0x758)][_0x2a2729(0xaa6)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x2a2729(0x9a8),
                                'value': !![]
                            },
                            {
                                'state': _0x533cd2[_0x2a2729(0x5d4)],
                                'value': [
                                    _0x2a2729(0x7bd),
                                    _0x533cd2[_0x2a2729(0x3ea)]
                                ]
                            }
                        ],
                        'face': [
                            _0x533cd2[_0x2a2729(0x684)],
                            'up',
                            _0x2a2729(0x47a),
                            _0x533cd2[_0x2a2729(0x4d4)],
                            _0x533cd2[_0x2a2729(0xb19)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x533cd2[_0x2a2729(0x323)],
                                    'value': ![]
                                },
                                {
                                    'state': _0x533cd2['MOMkX'],
                                    'value': _0x533cd2[_0x2a2729(0x3ea)]
                                }
                            ]
                        },
                        'item': _0x533cd2[_0x2a2729(0x917)],
                        'sound': _0x3fb5b9['sound'][_0x2a2729(0x500)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x533cd2['Yjcpj'],
                                'value': ![]
                            },
                            {
                                'state': _0x533cd2['MOMkX'],
                                'value': [
                                    _0x2a2729(0x7bd),
                                    _0x2a2729(0x709)
                                ]
                            }
                        ],
                        'face': [
                            _0x2a2729(0x709),
                            'up',
                            _0x533cd2[_0x2a2729(0x263)],
                            'north',
                            _0x533cd2['cPzep']
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x2a2729(0x9a8),
                                    'value': !![]
                                },
                                {
                                    'state': _0x533cd2[_0x2a2729(0x5d4)],
                                    'value': _0x533cd2[_0x2a2729(0x684)]
                                }
                            ]
                        },
                        'item': _0x533cd2[_0x2a2729(0x917)],
                        'sound': _0x3fb5b9[_0x2a2729(0x758)][_0x2a2729(0xaa6)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x533cd2['Yjcpj'],
                                'value': !![]
                            },
                            {
                                'state': _0x533cd2[_0x2a2729(0x5d4)],
                                'value': [
                                    _0x533cd2['FmmjY'],
                                    _0x533cd2[_0x2a2729(0x3ea)]
                                ]
                            }
                        ],
                        'face': [
                            _0x533cd2['RdurM'],
                            'up',
                            _0x533cd2[_0x2a2729(0x263)],
                            _0x533cd2[_0x2a2729(0x4d4)],
                            _0x533cd2[_0x2a2729(0xb19)]
                        ],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [
                                {
                                    'state': _0x533cd2[_0x2a2729(0x323)],
                                    'value': ![]
                                },
                                {
                                    'state': _0x533cd2['MOMkX'],
                                    'value': _0x533cd2[_0x2a2729(0x684)]
                                }
                            ]
                        },
                        'item': 'all',
                        'sound': _0x3fb5b9[_0x2a2729(0x758)][_0x2a2729(0x500)]
                    }
                ]
            }
        });
    });
    const _0x282eaf = [
        {
            'id': _0x533cd2[_0x26617e(0xb62)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x26617e(0xbf8)
            }
        },
        {
            'id': _0x26617e(0x9c7),
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2['WdaMm']
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0xb40)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x26617e(0xb00),
            'sound': {
                'open': _0x26617e(0x309),
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x9b6)],
            'sound': {
                'open': _0x26617e(0x309),
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x26617e(0x74a),
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x8c3)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x5e6)],
                'close': _0x533cd2[_0x26617e(0x696)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x639)],
            'sound': {
                'open': _0x26617e(0x309),
                'close': _0x533cd2['WdaMm']
            }
        },
        {
            'id': _0x26617e(0x501),
            'sound': {
                'open': 'open.cherry_wood_fence_gate',
                'close': _0x533cd2[_0x26617e(0xadd)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x389)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x2e8)],
                'close': _0x533cd2[_0x26617e(0x812)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x718)],
            'sound': {
                'open': _0x26617e(0x526),
                'close': _0x533cd2[_0x26617e(0xa31)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0xa60)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0xa2e)],
                'close': _0x533cd2[_0x26617e(0xa31)]
            }
        }
    ];
    _0x282eaf[_0x26617e(0x3e1)](_0x2e3b05 => {
        const _0x3f6283 = _0x26617e;
        _0xb54d87[_0x3f6283(0x4c3)]({
            'id': _0x2e3b05['id'],
            'transform': {
                'transforms': [
                    {
                        'states': [{
                                'state': _0x533cd2[_0x3f6283(0x323)],
                                'value': ![]
                            }],
                        'adjecentUpdate': _0x533cd2[_0x3f6283(0x839)],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x3f6283(0x323)],
                                    'value': !![]
                                }]
                        },
                        'item': _0x533cd2[_0x3f6283(0x917)],
                        'sound': _0x2e3b05[_0x3f6283(0x758)][_0x3f6283(0xaa6)]
                    },
                    {
                        'states': [{
                                'state': _0x533cd2[_0x3f6283(0x323)],
                                'value': !![]
                            }],
                        'adjecentUpdate': _0x533cd2[_0x3f6283(0x839)],
                        'cancelOnSneak': !![],
                        'takeItem': ![],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x3f6283(0x323)],
                                    'value': ![]
                                }]
                        },
                        'item': _0x533cd2[_0x3f6283(0x917)],
                        'sound': _0x2e3b05['sound'][_0x3f6283(0x500)]
                    }
                ]
            }
        });
    });
    const _0xc92a1b = [
            {
                'item': _0x533cd2['QYjij'],
                'value': _0x533cd2[_0x26617e(0x230)]
            },
            {
                'item': _0x26617e(0x48e),
                'value': _0x533cd2['sDhLn']
            },
            {
                'item': _0x533cd2[_0x26617e(0xafa)],
                'value': _0x26617e(0xacb)
            },
            {
                'item': _0x533cd2[_0x26617e(0x916)],
                'value': 'allium'
            },
            {
                'item': _0x533cd2['JmsoI'],
                'value': _0x533cd2['WiXsu']
            },
            {
                'item': _0x533cd2[_0x26617e(0x964)],
                'value': _0x26617e(0x794)
            },
            {
                'item': _0x26617e(0x222),
                'value': _0x533cd2[_0x26617e(0x2fa)]
            },
            {
                'item': _0x26617e(0x33e),
                'value': _0x533cd2[_0x26617e(0x93f)]
            },
            {
                'item': _0x533cd2[_0x26617e(0xa25)],
                'value': _0x533cd2[_0x26617e(0x6e8)]
            },
            {
                'item': _0x533cd2[_0x26617e(0xa7b)],
                'value': _0x533cd2['OTLXB']
            },
            {
                'item': _0x533cd2[_0x26617e(0xbe7)],
                'value': _0x26617e(0x3cb)
            },
            {
                'item': _0x533cd2[_0x26617e(0xbcd)],
                'value': _0x533cd2[_0x26617e(0x471)]
            },
            {
                'item': _0x533cd2[_0x26617e(0x293)],
                'value': _0x533cd2[_0x26617e(0x946)]
            },
            {
                'item': _0x533cd2[_0x26617e(0x1fc)],
                'value': _0x26617e(0x50b)
            },
            {
                'item': _0x533cd2[_0x26617e(0xb59)],
                'value': _0x533cd2[_0x26617e(0x808)]
            }
        ], _0x23a9d1 = [
            {
                'item': _0x533cd2[_0x26617e(0xbd8)],
                'value': _0x26617e(0xb15)
            },
            {
                'item': _0x533cd2[_0x26617e(0x62c)],
                'value': _0x533cd2[_0x26617e(0x47c)]
            },
            {
                'item': _0x533cd2[_0x26617e(0x3a9)],
                'value': _0x533cd2['dgmah']
            }
        ], _0x124412 = [
            _0x26617e(0x29d),
            _0x533cd2['pjREh'],
            _0x26617e(0x765),
            _0x533cd2[_0x26617e(0x641)],
            _0x533cd2[_0x26617e(0x435)],
            _0x533cd2[_0x26617e(0x631)],
            _0x26617e(0xa95),
            _0x533cd2[_0x26617e(0x52f)],
            _0x533cd2['hTsKB'],
            _0x533cd2[_0x26617e(0x7ef)],
            _0x533cd2['idPMv'],
            _0x533cd2[_0x26617e(0xa14)],
            _0x533cd2[_0x26617e(0x5a2)],
            _0x533cd2['mZwwh'],
            _0x533cd2[_0x26617e(0x7d0)],
            _0x533cd2[_0x26617e(0x362)]
        ];
    _0x124412[_0x26617e(0x3e1)](_0x56010f => {
        const _0x3b3cde = _0x26617e, _0x522c52 = _0xc92a1b[_0x3b3cde(0x2dc)](_0xb80d3b => ({
                'transformTo': {
                    'id': _0x56010f,
                    'states': [{
                            'state': _0x3b3cde(0x487),
                            'value': _0xb80d3b[_0x3b3cde(0x8c7)]
                        }]
                },
                'states': [{
                        'state': _0x3b3cde(0x487),
                        'value': 'empty'
                    }],
                'takeItem': !![],
                'item': _0xb80d3b[_0x3b3cde(0xa00)],
                'sound': 'place.moss'
            })), _0x17f23d = _0xc92a1b[_0x3b3cde(0x2dc)](_0x468b60 => ({
                'transformTo': {
                    'id': _0x56010f,
                    'states': [{
                            'state': _0x3b3cde(0x487),
                            'value': _0x3b3cde(0x5eb)
                        }]
                },
                'states': [{
                        'state': _0x3b3cde(0x487),
                        'value': _0x468b60[_0x3b3cde(0x8c7)]
                    }],
                'item': _0x3b3cde(0xbf3),
                'receiveItem': _0x468b60[_0x3b3cde(0xa00)],
                'sound': 'place.moss'
            }));
        _0xb54d87[_0x3b3cde(0x4c3)]({
            'id': _0x56010f,
            'events': {
                'onDestroy': _0x101a6c => {
                    const _0x4bbfe2 = _0x3b3cde;
                    let _0x1ecf9c;
                    _0x101a6c instanceof _0x5aab8a ? _0x1ecf9c = _0x101a6c[_0x4bbfe2(0x70f)][_0x4bbfe2(0x30a)]('sb_bf:flower') : _0x1ecf9c = _0x101a6c[_0x4bbfe2(0x241)][_0x4bbfe2(0x30a)](_0x533cd2[_0x4bbfe2(0x6c0)]), _0x1ecf9c !== _0x533cd2[_0x4bbfe2(0xabd)] && _0x101a6c[_0x4bbfe2(0xb28)][_0x4bbfe2(0x220)](new _0x3c7a3f(_0x1ecf9c), _0x101a6c[_0x4bbfe2(0x87b)][_0x4bbfe2(0x2c0)]);
                }
            },
            'transform': {
                'transforms': [
                    ..._0x522c52,
                    ..._0x17f23d
                ]
            }
        });
    });
    const _0x45250d = _0x23a9d1[_0x26617e(0x2dc)](_0x2d162d => ({
            'transformTo': {
                'id': _0x26617e(0x23b),
                'states': [{
                        'state': _0x26617e(0x487),
                        'value': _0x2d162d[_0x26617e(0x8c7)]
                    }]
            },
            'states': [{
                    'state': _0x26617e(0x487),
                    'value': _0x26617e(0x5eb)
                }],
            'takeItem': !![],
            'item': _0x2d162d[_0x26617e(0xa00)],
            'sound': _0x26617e(0x8f1)
        })), _0x6fc4e9 = _0x23a9d1[_0x26617e(0x2dc)](_0x1f3252 => ({
            'transformTo': {
                'id': _0x26617e(0x23b),
                'states': [{
                        'state': _0x26617e(0x487),
                        'value': _0x26617e(0x5eb)
                    }]
            },
            'states': [{
                    'state': _0x26617e(0x487),
                    'value': _0x1f3252[_0x26617e(0x8c7)]
                }],
            'item': _0x26617e(0xbf3),
            'receiveItem': _0x1f3252[_0x26617e(0xa00)],
            'sound': _0x26617e(0x8f1)
        }));
    _0xb54d87['register']({
        'id': _0x533cd2[_0x26617e(0x557)],
        'events': {
            'onDestroy': _0x36e613 => {
                const _0x144ab7 = _0x26617e;
                let _0x24a7ad;
                _0x36e613 instanceof _0x5aab8a ? _0x24a7ad = _0x36e613['explodedBlockPermutation']['getState'](_0x533cd2['VlGFM']) : _0x24a7ad = _0x36e613['brokenBlockPermutation'][_0x144ab7(0x30a)]('sb_bf:flower'), _0x533cd2['bZeis'](_0x24a7ad, 'empty') && _0x36e613[_0x144ab7(0xb28)][_0x144ab7(0x220)](new _0x3c7a3f(_0x24a7ad), _0x36e613['block'][_0x144ab7(0x2c0)]);
            }
        },
        'transform': {
            'transforms': [
                ..._0x45250d,
                ..._0x6fc4e9
            ]
        }
    }), _0xb54d87[_0x26617e(0x4c3)]({
        'id': _0x26617e(0x3ff),
        'transform': {
            'transforms': [
                {
                    'states': [{
                            'state': 'sb_bf:filled',
                            'value': ![]
                        }],
                    'sound': _0x533cd2[_0x26617e(0x931)],
                    'item': _0x533cd2['DjpPh'],
                    'takeItem': ![],
                    'transformTo': {
                        'states': [{
                                'state': _0x533cd2['QkNKx'],
                                'value': !![]
                            }]
                    }
                },
                {
                    'states': [{
                            'state': _0x533cd2['QkNKx'],
                            'value': !![]
                        }],
                    'sound': _0x533cd2[_0x26617e(0xb60)],
                    'item': _0x533cd2[_0x26617e(0x209)],
                    'takeItem': !![],
                    'transformItem': _0x533cd2['CbxqG'],
                    'transformTo': {
                        'states': [{
                                'state': _0x533cd2['QkNKx'],
                                'value': ![]
                            }]
                    }
                },
                {
                    'states': [{
                            'state': 'sb_bf:filled',
                            'value': !![]
                        }],
                    'sound': _0x533cd2[_0x26617e(0xb60)],
                    'item': _0x533cd2['tRgTC'],
                    'transformTo': {
                        'states': [{
                                'state': _0x533cd2[_0x26617e(0x1ef)],
                                'value': ![]
                            }]
                    }
                }
            ]
        }
    });
    const _0x4e0bc4 = [
        {
            'id': _0x533cd2['uQBIU'],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x825)],
                'close': _0x533cd2[_0x26617e(0x3b2)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x285)],
            'sound': {
                'open': _0x26617e(0xbd0),
                'close': _0x533cd2[_0x26617e(0x3b2)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x34f)],
            'sound': {
                'open': _0x26617e(0xbd0),
                'close': _0x533cd2['HiVnR']
            }
        },
        {
            'id': _0x533cd2['NXrqv'],
            'sound': {
                'open': _0x533cd2['nnYur'],
                'close': _0x533cd2['HiVnR']
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x79b)],
            'sound': {
                'open': _0x26617e(0xbd0),
                'close': _0x533cd2[_0x26617e(0x3b2)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x9bb)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x6fa)],
                'close': _0x533cd2[_0x26617e(0x665)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x4c6)],
            'sound': {
                'open': 'open.wooden_door',
                'close': _0x533cd2[_0x26617e(0x3b2)]
            }
        },
        {
            'id': _0x533cd2['LPYfX'],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x825)],
                'close': _0x533cd2[_0x26617e(0x3b2)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0xc11)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x3e2)],
                'close': 'close.nether_wood_door_close'
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x25b)],
            'sound': {
                'open': _0x26617e(0xb23),
                'close': _0x533cd2[_0x26617e(0x532)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x569)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x629)],
                'close': _0x26617e(0x3de)
            }
        },
        {
            'id': _0x533cd2['YwERF'],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x825)],
                'close': _0x533cd2[_0x26617e(0x3b2)]
            }
        }
    ];
    _0x4e0bc4[_0x26617e(0x3e1)](_0x54d67e => {
        const _0x176eb5 = _0x26617e;
        _0xb54d87[_0x176eb5(0x4c3)]({
            'id': _0x54d67e['id'],
            'transform': {
                'transforms': [
                    {
                        'states': [
                            {
                                'state': _0x176eb5(0x9a8),
                                'value': ![]
                            },
                            {
                                'state': _0x176eb5(0x966),
                                'value': _0x176eb5(0x731)
                            }
                        ],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x176eb5(0x323)],
                                    'value': !![]
                                }]
                        },
                        'item': _0x533cd2['DjpPh'],
                        'takeItem': ![],
                        'adjecentUpdate': _0x533cd2['qgKBb'],
                        'sound': _0x54d67e[_0x176eb5(0x758)][_0x176eb5(0xaa6)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x533cd2['Yjcpj'],
                                'value': ![]
                            },
                            {
                                'state': 'sb_bf:half',
                                'value': _0x533cd2[_0x176eb5(0x616)]
                            }
                        ],
                        'transformTo': {
                            'states': [{
                                    'state': _0x176eb5(0x9a8),
                                    'value': !![]
                                }]
                        },
                        'item': _0x533cd2[_0x176eb5(0x917)],
                        'takeItem': ![],
                        'adjecentUpdate': _0x533cd2['YUckr'],
                        'sound': _0x54d67e[_0x176eb5(0x758)][_0x176eb5(0x500)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x176eb5(0x9a8),
                                'value': !![]
                            },
                            {
                                'state': _0x533cd2['VCwii'],
                                'value': _0x176eb5(0x731)
                            }
                        ],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x176eb5(0x323)],
                                    'value': ![]
                                }]
                        },
                        'item': _0x533cd2[_0x176eb5(0x917)],
                        'takeItem': ![],
                        'adjecentUpdate': 'above',
                        'sound': _0x54d67e[_0x176eb5(0x758)][_0x176eb5(0x500)]
                    },
                    {
                        'states': [
                            {
                                'state': _0x176eb5(0x9a8),
                                'value': !![]
                            },
                            {
                                'state': _0x533cd2[_0x176eb5(0x94d)],
                                'value': _0x533cd2['sGDqX']
                            }
                        ],
                        'transformTo': {
                            'states': [{
                                    'state': _0x176eb5(0x9a8),
                                    'value': ![]
                                }]
                        },
                        'item': _0x533cd2['DjpPh'],
                        'takeItem': ![],
                        'adjecentUpdate': _0x533cd2[_0x176eb5(0xc18)],
                        'sound': _0x54d67e[_0x176eb5(0x758)][_0x176eb5(0x500)]
                    }
                ]
            }
        });
    }), _0xb54d87[_0x26617e(0x4c3)]({
        'id': _0x533cd2[_0x26617e(0x1f8)],
        'multiPlacement': {
            'sound': _0x533cd2['crChu'],
            'states': 0x4
        }
    });
    const _0x1a6d68 = [
        {
            'id': _0x533cd2[_0x26617e(0x7f6)],
            'sound': {
                'open': _0x533cd2['ibiVI'],
                'close': _0x533cd2[_0x26617e(0xa7f)]
            }
        },
        {
            'id': _0x26617e(0x4ad),
            'sound': {
                'open': _0x533cd2[_0x26617e(0x97e)],
                'close': _0x533cd2[_0x26617e(0xa7f)]
            }
        },
        {
            'id': _0x533cd2['fjfOs'],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x97e)],
                'close': _0x26617e(0x2cc)
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x1f3)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x97e)],
                'close': _0x533cd2['wmxdT']
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x5c6)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x97e)],
                'close': _0x533cd2[_0x26617e(0xa7f)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x51d)],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x602)],
                'close': _0x26617e(0xa7d)
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x4fe)],
            'sound': {
                'open': _0x533cd2['ibiVI'],
                'close': _0x533cd2[_0x26617e(0xa7f)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x5e9)],
            'sound': {
                'open': _0x26617e(0x867),
                'close': _0x533cd2[_0x26617e(0xa7f)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x3ae)],
            'sound': {
                'open': _0x533cd2['NognK'],
                'close': _0x533cd2[_0x26617e(0xa98)]
            }
        },
        {
            'id': _0x533cd2['mWAng'],
            'sound': {
                'open': _0x533cd2[_0x26617e(0x91e)],
                'close': _0x533cd2['PEQkU']
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x69c)],
            'sound': {
                'open': _0x26617e(0x9b9),
                'close': _0x533cd2[_0x26617e(0x424)]
            }
        },
        {
            'id': _0x533cd2[_0x26617e(0x69e)],
            'sound': {
                'open': _0x533cd2['ibiVI'],
                'close': _0x533cd2[_0x26617e(0xa7f)]
            }
        }
    ];
    _0x1a6d68[_0x26617e(0x3e1)](_0xa702fb => {
        const _0x59cc2e = _0x26617e;
        _0xb54d87[_0x59cc2e(0x4c3)]({
            'id': _0xa702fb['id'],
            'transform': {
                'transforms': [
                    {
                        'states': [{
                                'state': _0x533cd2[_0x59cc2e(0x323)],
                                'value': ![]
                            }],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2[_0x59cc2e(0x323)],
                                    'value': !![]
                                }]
                        },
                        'cancelOnSneak': !![],
                        'item': _0x533cd2[_0x59cc2e(0x917)],
                        'sound': _0xa702fb['sound'][_0x59cc2e(0xaa6)]
                    },
                    {
                        'states': [{
                                'state': _0x533cd2['Yjcpj'],
                                'value': !![]
                            }],
                        'transformTo': {
                            'states': [{
                                    'state': _0x533cd2['Yjcpj'],
                                    'value': ![]
                                }]
                        },
                        'cancelOnSneak': !![],
                        'item': _0x533cd2[_0x59cc2e(0x917)],
                        'sound': _0xa702fb[_0x59cc2e(0x758)]['close']
                    }
                ]
            }
        });
    }), _0xb54d87['initialize']();
}
var _0xb54d87 = class {
    static ['register'](_0x327093) {
        const _0x28401a = _0x21f734, _0x5a4fdb = {
                'sCEgs': function (_0x329f48, _0x14c522) {
                    return _0x329f48 === _0x14c522;
                },
                'HBHew': _0x28401a(0x228)
            }, {
                id: _0x636f01,
                ..._0x999e03
            } = _0x327093;
        Object['entries'](_0x999e03)[_0x28401a(0x3e1)](([_0x4f3f0f, _0x511c9d]) => {
            const _0x2daec9 = _0x28401a;
            if (this[_0x2daec9(0x9f1)][_0x4f3f0f]) {
                const _0x5bafda = this[_0x2daec9(0x9f1)][_0x4f3f0f];
                _0x5bafda && _0x5a4fdb['sCEgs'](typeof _0x5bafda[_0x2daec9(0x760)], _0x5a4fdb[_0x2daec9(0x3f1)]) ? _0x5bafda[_0x2daec9(0x760)]({
                    'id': _0x636f01,
                    ..._0x511c9d
                }) : console[_0x2daec9(0x4b1)](_0x2daec9(0x9c3) + _0x4f3f0f);
            }
        });
    }
    static [_0x21f734(0x341)](_0x18ae39, _0xf31a88) {
        const _0x154275 = _0x21f734, _0x9fd9d6 = { 'lmScL': 'string' };
        if (typeof _0x18ae39 === _0x9fd9d6[_0x154275(0x325)])
            this[_0x154275(0x9f1)][_0x18ae39] = _0xf31a88;
        else {
            const _0xb5f5d8 = _0x18ae39[_0x154275(0x497)]['toLowerCase']();
            this[_0x154275(0x9f1)][_0xb5f5d8] = _0x18ae39;
        }
    }
    static [_0x21f734(0x48b)]() {
        const _0x345aa7 = _0x21f734, _0x3a200a = {
                'AQeXS': function (_0xf47375, _0x385241) {
                    return _0xf47375 === _0x385241;
                },
                'tPMrI': function (_0x106635, _0x33564c) {
                    return _0x106635 === _0x33564c;
                },
                'xwmTS': 'function'
            };
        Object[_0x345aa7(0x5a8)](this['registry'])[_0x345aa7(0x3e1)](([_0x5946f6, _0x8daf6a]) => {
            const _0x5ba0f = _0x345aa7;
            if (_0x3a200a[_0x5ba0f(0x6b3)](typeof _0x8daf6a[_0x5ba0f(0x48b)], _0x5ba0f(0x228)))
                _0x8daf6a[_0x5ba0f(0x48b)]();
            else
                _0x3a200a[_0x5ba0f(0x5e5)](typeof _0x8daf6a, _0x3a200a[_0x5ba0f(0xb9e)]) && new _0x8daf6a();
        });
    }
};
_0x25e7d0(_0xb54d87, _0x21f734(0x9f1), {});
var _0x100bea = class extends _0x2e442a {
    constructor() {
        const _0x5efbc9 = _0x21f734, _0x28fc85 = { 'xXiCP': _0x5efbc9(0x502) };
        super(_0x28fc85[_0x5efbc9(0xb3d)]);
    }
    [_0x21f734(0x9a6)]() {
        const _0x41561b = _0x21f734, _0x4e4a9c = {
                'urjOZ': function (_0x473e5b) {
                    return _0x473e5b();
                }
            };
        _0x4e4a9c[_0x41561b(0x76c)](_0x214944);
    }
};
import {
    EquipmentSlot as _0x2cff23,
    ItemStack as _0x39218f,
    system as _0x5b1866,
    world as _0x5cf797
} from '@minecraft/server';
var _0x490425 = {
    'wither': {
        'sequence': [
            _0x21f734(0x8e9),
            _0x21f734(0xaf1),
            _0x21f734(0x911),
            _0x21f734(0xbf5),
            _0x21f734(0xc0c)
        ],
        'reward': _0x21f734(0xaf8)
    },
    'creaking': {
        'sequence': [
            _0x21f734(0x63d),
            'light_gray',
            _0x21f734(0xbf5),
            _0x21f734(0x911),
            'yellow'
        ],
        'reward': _0x21f734(0x1aa)
    },
    'ender_dragon': {
        'sequence': [
            _0x21f734(0x572),
            _0x21f734(0x778),
            _0x21f734(0x6d0),
            _0x21f734(0x59e),
            _0x21f734(0x853)
        ],
        'reward': _0x21f734(0x909)
    },
    'warden': {
        'sequence': [
            'black',
            _0x21f734(0x455),
            _0x21f734(0xb9a),
            _0x21f734(0x78b),
            _0x21f734(0xc0c)
        ],
        'reward': 'sb_bf:special_warden_painting'
    }
};
function _0x41a454(_0x2047b7, _0x293fb8) {
    const _0x2dfa14 = _0x21f734, _0x4716bc = {
            'hRfqj': _0x2dfa14(0x997),
            'grtwc': _0x2dfa14(0x857),
            'llTyY': _0x2dfa14(0x966),
            'yzFjo': _0x2dfa14(0x581),
            'qXrVN': _0x2dfa14(0x9d3)
        };
    return {
        'state': [
            {
                'value': 0x1,
                'identifier': _0x4716bc['hRfqj']
            },
            {
                'value': _0x2047b7,
                'identifier': _0x2dfa14(0xbd9)
            },
            {
                'value': _0x4716bc[_0x2dfa14(0x5c0)],
                'identifier': _0x4716bc[_0x2dfa14(0x8a5)]
            }
        ],
        'duration': 0x0,
        'visualEffects': {
            'onEnd': {
                'particles': [_0x4716bc[_0x2dfa14(0x96a)]],
                'sounds': [_0x4716bc[_0x2dfa14(0x81f)]]
            }
        },
        'nextStates': [{
                'item': _0x2dfa14(0x300) + _0x293fb8 + '_picture',
                'transformItem': _0x2dfa14(0x300) + _0x2047b7 + _0x2dfa14(0xa92),
                'state': [
                    {
                        'value': _0x293fb8,
                        'identifier': _0x2dfa14(0xbd9)
                    },
                    {
                        'value': 0x1,
                        'identifier': _0x4716bc[_0x2dfa14(0x5dc)]
                    }
                ]
            }]
    };
}
function _0x579d2f(_0x2e60f8, _0x1670f5, _0x30ecea, _0x5afcd6 = []) {
    const _0x26ba8d = _0x21f734, _0x1a6980 = {
            'euiHa': _0x26ba8d(0x805),
            'fATSB': function (_0x40b5f7, _0x18aa2f, _0x16d0ef) {
                return _0x40b5f7(_0x18aa2f, _0x16d0ef);
            },
            'hjpmS': _0x26ba8d(0x9d3),
            'jAtoM': function (_0xb8813c, _0x3ad73d) {
                return _0xb8813c + _0x3ad73d;
            },
            'PrmTr': 'sb_bf:step',
            'tkqvq': _0x26ba8d(0xbd9),
            'jACko': _0x26ba8d(0x966),
            'YIHsM': function (_0x3ae398, _0x353658) {
                return _0x3ae398 + _0x353658;
            },
            'xGsgZ': 'top',
            'nqYKB': _0x26ba8d(0x581),
            'pNMTr': _0x26ba8d(0xbf3),
            'ZMjxD': 'random.levelup'
        }, _0x1e0c96 = {
            'state': [
                {
                    'value': 0x0,
                    'identifier': _0x1a6980[_0x26ba8d(0x1a8)]
                },
                {
                    'value': _0x1a6980[_0x26ba8d(0x65d)],
                    'identifier': _0x26ba8d(0x966)
                }
            ],
            'duration': 0x0,
            'nextStates': [{
                    'item': _0x26ba8d(0x300) + _0x2e60f8 + _0x26ba8d(0xa92),
                    'state': [
                        {
                            'value': _0x2e60f8,
                            'identifier': _0x1a6980[_0x26ba8d(0x4d1)]
                        },
                        {
                            'value': 0x1,
                            'identifier': _0x26ba8d(0x997)
                        }
                    ],
                    'removeItem': !![]
                }],
            'visualEffects': {
                'onEnd': {
                    'particles': [_0x1a6980['nqYKB']],
                    'sounds': [_0x1a6980['hjpmS']]
                }
            }
        }, _0x510245 = _0x5afcd6[_0x26ba8d(0x2dc)](_0x2cdece => _0x41a454(_0x2e60f8, _0x2cdece)), _0x1eee40 = _0x1670f5[_0x26ba8d(0x2dc)]((_0x2f7d23, _0x479cb4) => {
            const _0x29116a = _0x26ba8d, _0x12c791 = {
                    'rLcyV': _0x1a6980['euiHa'],
                    'YmdIQ': function (_0x4fcf50, _0x4c126b, _0xd85461) {
                        const _0x5977db = _0x3124;
                        return _0x1a6980[_0x5977db(0x7c1)](_0x4fcf50, _0x4c126b, _0xd85461);
                    },
                    'dffOl': _0x1a6980[_0x29116a(0xb25)]
                };
            return {
                'state': [
                    {
                        'value': _0x1a6980[_0x29116a(0x830)](_0x479cb4, 0x1),
                        'identifier': _0x1a6980[_0x29116a(0x1a8)]
                    },
                    {
                        'value': _0x2e60f8,
                        'identifier': _0x1a6980[_0x29116a(0x4d1)]
                    },
                    {
                        'value': _0x29116a(0x857),
                        'identifier': _0x1a6980[_0x29116a(0x22f)]
                    }
                ],
                'duration': 0x0,
                'visualEffects': {
                    'onEnd': {
                        'particles': [_0x29116a(0x300) + _0x2f7d23 + _0x29116a(0x333)],
                        'sounds': [_0x1a6980['hjpmS']]
                    }
                },
                'hoverParticle': _0x29116a(0x300) + _0x2f7d23 + _0x29116a(0x4a0),
                'hoverParticleOffset': {
                    'x': 0x0,
                    'y': 0.5,
                    'z': 0.4
                },
                'nextStates': [{
                        'item': _0x29116a(0x300) + _0x2f7d23 + _0x29116a(0x4a0),
                        'state': [
                            {
                                'value': _0x1a6980[_0x29116a(0x3a6)](_0x479cb4, 0x2),
                                'identifier': _0x1a6980[_0x29116a(0x1a8)]
                            },
                            {
                                'value': _0x2e60f8,
                                'identifier': _0x1a6980[_0x29116a(0x4d1)]
                            }
                        ],
                        'removeItem': ![],
                        'function': _0x41ec96 => {
                            const _0xbd2ccc = _0x29116a;
                            if (_0x41ec96[_0xbd2ccc(0x271)]() === _0x12c791['rLcyV'])
                                return;
                            _0x12c791[_0xbd2ccc(0xa16)](_0x2108be, _0x41ec96, {
                                'convertInto': _0xbd2ccc(0x391),
                                'destructionSound': _0x12c791[_0xbd2ccc(0x96e)]
                            });
                        }
                    }]
            };
        }), _0x43edca = _0x1670f5[0x0], _0x4ad096 = _0x510245[_0x26ba8d(0x2dc)](_0x53ba54 => {
            const _0x545e38 = _0x26ba8d;
            return {
                ..._0x53ba54,
                'hoverParticle': _0x545e38(0x300) + _0x43edca + _0x545e38(0x4a0),
                'hoverParticleOffset': {
                    'x': 0x0,
                    'y': 0.5,
                    'z': 0.4
                }
            };
        }), _0x2defbe = {
            'state': [
                {
                    'value': _0x1a6980['jAtoM'](_0x1670f5[_0x26ba8d(0x51f)], 0x1),
                    'identifier': _0x1a6980[_0x26ba8d(0x1a8)]
                },
                {
                    'value': _0x2e60f8,
                    'identifier': _0x1a6980[_0x26ba8d(0x4d1)]
                }
            ],
            'duration': 0x0,
            'finalState': {
                'item': _0x1a6980[_0x26ba8d(0xa37)],
                'transformItem': _0x30ecea,
                'state': {
                    'value': 0x0,
                    'identifier': _0x1a6980[_0x26ba8d(0x1a8)]
                }
            },
            'visualEffects': {
                'onEnd': {
                    'particles': [_0x26ba8d(0xb12)],
                    'sounds': [_0x1a6980[_0x26ba8d(0xbff)]]
                }
            },
            'hoverParticle': _0x26ba8d(0x753),
            'hoverParticleOffset': {
                'x': 0x0,
                'y': 0.8,
                'z': -0.1
            }
        };
    return [
        _0x1e0c96,
        ..._0x4ad096,
        ..._0x1eee40,
        _0x2defbe
    ];
}
function _0x475762() {
    const _0x4da6bc = _0x21f734, _0x368711 = {
            'SGBNX': function (_0x54304f, _0x10131a, _0x5b9a65, _0x3095ad, _0x4526d5) {
                return _0x54304f(_0x10131a, _0x5b9a65, _0x3095ad, _0x4526d5);
            },
            'zILEM': _0x4da6bc(0x8cb)
        }, _0x425efc = Object[_0x4da6bc(0x69b)](_0x490425);
    let _0x58da8a = [];
    _0x425efc[_0x4da6bc(0x3e1)](_0x201650 => {
        const _0x5d7a29 = _0x4da6bc, _0x19bb87 = _0x490425[_0x201650], _0x438306 = _0x425efc[_0x5d7a29(0x578)](_0x2b0df5 => _0x2b0df5 !== _0x201650);
        _0x58da8a = [
            ..._0x58da8a,
            ..._0x368711[_0x5d7a29(0x425)](_0x579d2f, _0x201650, _0x19bb87[_0x5d7a29(0x340)], _0x19bb87[_0x5d7a29(0x834)], _0x438306)
        ];
    }), _0x169ae2[_0x4da6bc(0x4c3)]({
        'baseIdentifier': _0x368711[_0x4da6bc(0x1d5)],
        'multipleBlocks': ![],
        'progressMessage': _0x4da6bc(0x9c9),
        'states': _0x58da8a
    }), _0x169ae2[_0x4da6bc(0x9a6)]();
}
var _0x169ae2 = class {
    static [_0x21f734(0x4c3)](_0x20d5ee) {
        const _0x30b714 = _0x21f734, _0x33e68d = new _0x5675c9(_0x20d5ee);
        this[_0x30b714(0x560)]['push'](_0x33e68d);
    }
    static [_0x21f734(0x9a6)]() {
        const _0x116f8e = _0x21f734;
        _0x5cf797[_0x116f8e(0x959)]['worldInitialize'][_0x116f8e(0x725)](_0x4845a4 => {
            const _0x4c214b = _0x116f8e;
            _0x4845a4[_0x4c214b(0x2ee)]['registerCustomComponent'](_0x207994 + _0x4c214b(0xbd7), {
                'onTick': this[_0x4c214b(0x5df)][_0x4c214b(0xa0c)](this),
                'onPlayerInteract': this[_0x4c214b(0x8a6)]['bind'](this),
                'onPlayerDestroy': this[_0x4c214b(0x651)][_0x4c214b(0xa0c)](this)
            });
        }), _0x5b1866[_0x116f8e(0x770)](() => {
            const _0x283fed = _0x116f8e;
            _0x5cf797[_0x283fed(0x239)]()['forEach'](this[_0x283fed(0x45c)][_0x283fed(0xa0c)](this));
        }, 0x14);
    }
    static [_0x21f734(0x5df)](_0x225e7c) {
        const _0xb9b7a8 = _0x21f734, _0x5dee35 = {
                'tHupx': function (_0x43b8f2, _0x1bd624) {
                    return _0x43b8f2 !== _0x1bd624;
                },
                'BjGrH': function (_0x40548b, _0x482f32) {
                    return _0x40548b * _0x482f32;
                }
            }, _0x17ce03 = this[_0xb9b7a8(0x5a4)](_0x225e7c[_0xb9b7a8(0x87b)]);
        if (!_0x17ce03)
            return;
        const _0x20e55c = this[_0xb9b7a8(0xb7f)](_0x225e7c[_0xb9b7a8(0x87b)]);
        if (!_0x20e55c)
            return;
        const _0x407c14 = this[_0xb9b7a8(0x779)](_0x225e7c[_0xb9b7a8(0x87b)]);
        let _0x1da1e3 = this['stateDurations'][_0xb9b7a8(0x3c7)](_0x407c14);
        if (_0x17ce03[_0xb9b7a8(0x5ef)]) {
            const {
                block: _0xd0e635,
                state: _0xc11920
            } = _0x17ce03[_0xb9b7a8(0x5ef)];
            if (_0x5dee35[_0xb9b7a8(0x94c)](_0x225e7c['block'][_0xb9b7a8(0xbd3)]()?.[_0xb9b7a8(0x1b9)], _0xd0e635) || !this[_0xb9b7a8(0x68b)](_0x225e7c[_0xb9b7a8(0x87b)][_0xb9b7a8(0xbd3)](), _0xc11920)) {
                this[_0xb9b7a8(0x2f3)](_0x407c14);
                return;
            }
        }
        _0x1da1e3 === void 0x0 && (this[_0xb9b7a8(0x7b5)][_0xb9b7a8(0x54f)](_0x407c14, _0x5dee35[_0xb9b7a8(0x47f)](_0x20e55c[_0xb9b7a8(0xa18)], 0x14)), _0x1da1e3 = _0x5dee35[_0xb9b7a8(0x47f)](_0x20e55c['duration'], 0x14));
        if (_0x1da1e3 > 0x0)
            _0x1da1e3 -= 0x1, this[_0xb9b7a8(0x7b5)]['set'](_0x407c14, _0x1da1e3), this['processEffects'](_0x225e7c[_0xb9b7a8(0x87b)], _0x20e55c);
        else
            _0x1da1e3 === 0x0 && (_0x20e55c['stateOnComplete'] && this[_0xb9b7a8(0x9a2)](_0x225e7c[_0xb9b7a8(0x87b)], _0x20e55c['stateOnComplete']));
    }
    static [_0x21f734(0x68b)](_0x50d240, _0x5829a5) {
        const _0x528326 = _0x21f734, _0xf987d6 = {
                'TieeB': function (_0x52026a, _0x39fe74) {
                    return _0x52026a === _0x39fe74;
                }
            }, _0x46af75 = _0x50d240[_0x528326(0x5fa)][_0x528326(0x833)]();
        return _0xf987d6[_0x528326(0x908)](_0x46af75[_0x5829a5[_0x528326(0x5af)]], _0x5829a5['value']);
    }
    static [_0x21f734(0x8a6)](_0x5ee5aa) {
        const _0x13200f = _0x21f734, _0x279953 = this[_0x13200f(0x5a4)](_0x5ee5aa[_0x13200f(0x87b)]);
        _0x279953 && this[_0x13200f(0x3b9)](_0x5ee5aa, _0x5ee5aa[_0x13200f(0x848)]);
    }
    static ['handleBreak'](_0x5f1fd7) {
        const _0x20b696 = _0x21f734, _0xbfcd54 = this['getBlockKey'](_0x5f1fd7[_0x20b696(0x87b)]);
        this[_0x20b696(0x2f3)](_0xbfcd54), this[_0x20b696(0x7b5)][_0x20b696(0x305)](_0xbfcd54);
    }
    static [_0x21f734(0x5a4)](_0x3fee3e) {
        const _0x1a9c0a = _0x21f734;
        return this[_0x1a9c0a(0x560)][_0x1a9c0a(0x65e)](_0x81859b => _0x3fee3e[_0x1a9c0a(0x1b9)] === _0x81859b['baseIdentifier'] || _0x3fee3e[_0x1a9c0a(0x1b9)][_0x1a9c0a(0xbf1)](_0x81859b[_0x1a9c0a(0x2e7)] + '_'));
    }
    static [_0x21f734(0x38b)](_0x3c75ba, _0x5621a2) {
        const _0x2a5dc9 = _0x21f734, _0x568427 = {
                'UUrTY': function (_0x3dc4e4, _0x3d78ee) {
                    return _0x3dc4e4 === _0x3d78ee;
                }
            }, _0x227dfc = _0x3c75ba['split'](':'), _0xc89f53 = this[_0x2a5dc9(0x560)][_0x2a5dc9(0x65e)](_0x955277 => _0x955277[_0x2a5dc9(0x2e7)] === _0x3c75ba);
        if (_0x568427['UUrTY'](_0xc89f53?.[_0x2a5dc9(0xab5)], ![]))
            return _0x3c75ba;
        const _0x4c537a = _0x5621a2[_0x2a5dc9(0x1f5)](':');
        return _0x227dfc[0x0] + ':' + _0x227dfc[0x1] + '_' + _0x4c537a[0x1];
    }
    static ['getCurrentState'](_0x21c1fd) {
        const _0x53d9f6 = _0x21f734, _0x47626a = {
                'CZPup': function (_0x138eec, _0x4e672c) {
                    return _0x138eec === _0x4e672c;
                }
            }, _0x2e2028 = this['findCookingPot'](_0x21c1fd);
        if (!_0x2e2028)
            return void 0x0;
        const _0x2afa0c = _0x21c1fd[_0x53d9f6(0x5fa)][_0x53d9f6(0x833)]();
        for (const _0x8055f1 of _0x2e2028[_0x53d9f6(0x30d)]) {
            if (Array[_0x53d9f6(0x2b1)](_0x8055f1[_0x53d9f6(0x5af)])) {
                const _0xb738e5 = _0x8055f1['state'][_0x53d9f6(0xa09)](_0x9f56a6 => _0x2afa0c[_0x9f56a6[_0x53d9f6(0xb76)]] === _0x9f56a6[_0x53d9f6(0x8c7)]);
                if (_0xb738e5)
                    return _0x8055f1;
            } else {
                const {
                    identifier: _0x5dc271,
                    value: _0x3eec97
                } = _0x8055f1[_0x53d9f6(0x5af)];
                if (_0x47626a[_0x53d9f6(0x94b)](_0x2afa0c[_0x5dc271], _0x3eec97))
                    return _0x8055f1;
            }
        }
        return void 0x0;
    }
    static [_0x21f734(0x3b9)](_0x477e59, _0x2d5c2f) {
        const _0xc770e8 = _0x21f734, _0x243c18 = {
                'GtJDD': function (_0xb714d7, _0x548bb5) {
                    return _0xb714d7 !== _0x548bb5;
                },
                'tAHtf': function (_0x41caf8, _0x28520b) {
                    return _0x41caf8 > _0x28520b;
                },
                'RBuaL': function (_0x1d4738, _0x54be61, _0x4c078e) {
                    return _0x1d4738(_0x54be61, _0x4c078e);
                },
                'UUTRk': function (_0x6f565, _0x11ebc8, _0x231ed1, _0x5b22c1) {
                    return _0x6f565(_0x11ebc8, _0x231ed1, _0x5b22c1);
                },
                'AhIsn': function (_0x8a0083, _0x2014b9, _0x39467a) {
                    return _0x8a0083(_0x2014b9, _0x39467a);
                }
            }, _0xe1ab2f = this[_0xc770e8(0x779)](_0x477e59[_0xc770e8(0x87b)]), _0x28eb65 = this[_0xc770e8(0xb7f)](_0x477e59['block']);
        if (!_0x28eb65)
            return;
        const _0xeaee80 = this[_0xc770e8(0x7b5)]['get'](_0xe1ab2f);
        if (_0x243c18['GtJDD'](_0xeaee80, void 0x0) && _0x243c18['tAHtf'](_0xeaee80, 0x0)) {
            _0x2d5c2f['sendMessage']({ 'translate': this[_0xc770e8(0x5a4)](_0x477e59[_0xc770e8(0x87b)])?.[_0xc770e8(0x9e5)] });
            return;
        }
        if (_0x28eb65[_0xc770e8(0x656)]) {
            this[_0xc770e8(0x551)](_0x477e59, _0x28eb65[_0xc770e8(0x656)]);
            return;
        }
        const _0x5809c1 = _0x243c18[_0xc770e8(0x563)](_0x59bdcb, _0x477e59[_0xc770e8(0x848)], _0x2cff23[_0xc770e8(0xc15)]);
        if (!_0x5809c1)
            return;
        const _0x57de31 = this[_0xc770e8(0x5a4)](_0x477e59[_0xc770e8(0x87b)]);
        if (!_0x57de31)
            return;
        const _0x13475a = _0x477e59['block'][_0xc770e8(0x5fa)][_0xc770e8(0x833)](), _0x49fa66 = _0x57de31[_0xc770e8(0x30d)][_0xc770e8(0x578)](_0x4c83e6 => {
                const _0x6aec1b = _0xc770e8;
                return Array[_0x6aec1b(0x2b1)](_0x4c83e6[_0x6aec1b(0x5af)]) ? _0x4c83e6[_0x6aec1b(0x5af)][_0x6aec1b(0xa09)](_0xaff175 => _0x13475a[_0xaff175[_0x6aec1b(0xb76)]] === _0xaff175['value']) : _0x13475a[_0x4c83e6[_0x6aec1b(0x5af)][_0x6aec1b(0xb76)]] === _0x4c83e6[_0x6aec1b(0x5af)][_0x6aec1b(0x8c7)];
            });
        for (const _0x1dd370 of _0x49fa66) {
            const _0x55d686 = _0x1dd370[_0xc770e8(0x25e)]?.['find'](_0x413a48 => _0x413a48['item'] === _0x5809c1[_0xc770e8(0x1b9)]);
            if (_0x55d686) {
                this['triggerEffects'](_0x477e59['block'], _0x1dd370['visualEffects']?.[_0xc770e8(0xb47)]), this[_0xc770e8(0x9a2)](_0x477e59[_0xc770e8(0x87b)], _0x55d686[_0xc770e8(0x5af)]);
                if (_0x55d686[_0xc770e8(0xbf0)])
                    _0x243c18[_0xc770e8(0x7b9)](_0xed22af, _0x477e59['player'], 0x1, !![]);
                const _0x5d8701 = _0x55d686[_0xc770e8(0x308)] ? new _0x39218f(_0x55d686['transformItem']) : void 0x0;
                if (_0x5d8701) {
                    const _0x324a5e = _0x243c18[_0xc770e8(0x9d6)](_0x59bdcb, _0x477e59[_0xc770e8(0x848)], _0x2cff23[_0xc770e8(0xc15)]);
                    _0x324a5e ? _0x243c18[_0xc770e8(0x563)](_0x467466, _0x477e59[_0xc770e8(0x848)], _0x5d8701) : _0x243c18['UUTRk'](_0x5c2500, _0x477e59['player'], _0x2cff23[_0xc770e8(0xc15)], _0x5d8701);
                }
                _0x55d686[_0xc770e8(0x228)] && _0x55d686[_0xc770e8(0x228)](_0x477e59[_0xc770e8(0x848)]);
                if (_0x1dd370['interactSound'])
                    try {
                        _0x477e59[_0xc770e8(0x87b)][_0xc770e8(0xb28)][_0xc770e8(0xa70)](_0x1dd370[_0xc770e8(0xadb)], this['getCenterLocation'](_0x477e59[_0xc770e8(0x87b)]));
                    } catch (_0x57a833) {
                    }
                return;
            }
        }
    }
    static ['handleFinalState'](_0x2191f6, _0x46e652) {
        const _0x1e277a = _0x21f734, _0xe0f65f = {
                'mnvyI': function (_0xd602cc, _0x51205c, _0x30be8e) {
                    return _0xd602cc(_0x51205c, _0x30be8e);
                },
                'KakPa': function (_0x4e9d57, _0x12ee87) {
                    return _0x4e9d57 === _0x12ee87;
                },
                'jsaDu': function (_0x2c683a, _0x4ba619) {
                    return _0x2c683a !== _0x4ba619;
                },
                'EeKBM': function (_0x3da16e, _0x2a815f) {
                    return _0x3da16e === _0x2a815f;
                },
                'EIVmO': function (_0x5b1597, _0x58fdd3) {
                    return _0x5b1597 === _0x58fdd3;
                },
                'kGiRK': function (_0x72d425, _0x181e2f) {
                    return _0x72d425 - _0x181e2f;
                }
            }, _0x37b931 = _0xe0f65f[_0x1e277a(0x330)](_0x59bdcb, _0x2191f6['player'], _0x2cff23[_0x1e277a(0xc15)]);
        if (_0xe0f65f[_0x1e277a(0x9ac)](_0x46e652[_0x1e277a(0xa00)], _0x1e277a(0xbf3)) || _0x37b931 && _0x37b931[_0x1e277a(0x1b9)] === _0x46e652[_0x1e277a(0xa00)]) {
            _0x46e652[_0x1e277a(0xbf0)] && _0x37b931 && _0xed22af(_0x2191f6[_0x1e277a(0x848)], 0x1, !![]);
            if (_0x46e652[_0x1e277a(0x308)]) {
                const _0x155fc3 = new _0x39218f(_0x46e652[_0x1e277a(0x308)]);
                if (_0x155fc3) {
                    const _0x464129 = _0x59bdcb(_0x2191f6[_0x1e277a(0x848)], _0x2cff23[_0x1e277a(0xc15)]);
                    _0x464129 ? _0xe0f65f['mnvyI'](_0x467466, _0x2191f6['player'], _0x155fc3) : _0x5c2500(_0x2191f6[_0x1e277a(0x848)], _0x2cff23[_0x1e277a(0xc15)], _0x155fc3);
                }
            }
            const _0x5f0851 = _0x2191f6['block'][_0x1e277a(0x5fa)]['getState'](_0x207994 + _0x1e277a(0x1c8));
            _0xe0f65f[_0x1e277a(0xb5c)](_0x5f0851, void 0x0) && _0x2191f6[_0x1e277a(0x87b)][_0x1e277a(0x5fa)][_0x1e277a(0x9d1)](_0x207994 + _0x1e277a(0x1c8), _0x5f0851 - 0x1);
            const _0x4c0cfa = this[_0x1e277a(0x5a4)](_0x2191f6[_0x1e277a(0x87b)]);
            if (_0x4c0cfa && _0x4c0cfa[_0x1e277a(0x30d)]) {
                const _0x1abac0 = this[_0x1e277a(0xb7f)](_0x2191f6[_0x1e277a(0x87b)]);
                if (_0x1abac0?.[_0x1e277a(0xadb)])
                    try {
                        _0x2191f6['block'][_0x1e277a(0xb28)]['playSound'](_0x1abac0[_0x1e277a(0xadb)], this[_0x1e277a(0x3ef)](_0x2191f6['block']));
                    } catch (_0x529535) {
                    }
            }
            if (_0xe0f65f[_0x1e277a(0x3ec)](_0x5f0851, void 0x0) || _0xe0f65f[_0x1e277a(0x35f)](_0xe0f65f['kGiRK'](_0x5f0851, 0x1), 0x0)) {
                if (Array[_0x1e277a(0x2b1)](_0x46e652[_0x1e277a(0x5af)]))
                    this[_0x1e277a(0x9a2)](_0x2191f6[_0x1e277a(0x87b)], _0x46e652[_0x1e277a(0x5af)]);
                else {
                    if (_0x46e652[_0x1e277a(0x5af)]) {
                        const _0x29b7bc = this[_0x1e277a(0x38b)](this[_0x1e277a(0x5a4)](_0x2191f6[_0x1e277a(0x87b)])[_0x1e277a(0x2e7)], _0x46e652[_0x1e277a(0x5af)]['identifier']), _0x13ed60 = _0x2191f6[_0x1e277a(0x87b)]['permutation'][_0x1e277a(0x833)]();
                        _0x2191f6['block'][_0x1e277a(0xb28)]['setBlockType'](_0x2191f6['block'][_0x1e277a(0x2c0)], _0x29b7bc);
                        const _0x469561 = _0x2191f6[_0x1e277a(0x87b)]['dimension'][_0x1e277a(0x3c0)](_0x2191f6['block'][_0x1e277a(0x2c0)]);
                        let _0x3d973a = _0x469561['permutation'][_0x1e277a(0x9d1)](_0x46e652['state'][_0x1e277a(0xb76)], _0x46e652[_0x1e277a(0x5af)]['value']);
                        for (const [_0x7007cd, _0x3abe1b] of Object[_0x1e277a(0x5a8)](_0x13ed60)) {
                            _0x7007cd !== _0x46e652[_0x1e277a(0x5af)][_0x1e277a(0xb76)] && (_0x3d973a = _0x3d973a[_0x1e277a(0x9d1)](_0x7007cd, _0x3abe1b));
                        }
                        _0x469561[_0x1e277a(0x772)](_0x3d973a);
                    }
                }
            }
        }
    }
    static ['processEffects'](_0x323b80, _0x4949ea) {
        const _0x4e159b = _0x21f734, _0x4c74cf = {
                'zsZXw': function (_0x478b18, _0x162e69) {
                    return _0x478b18 === _0x162e69;
                },
                'izpUn': function (_0x45012d, _0x5d7edc) {
                    return _0x45012d <= _0x5d7edc;
                },
                'UUqmf': function (_0x3a6a29, _0x10ccb0) {
                    return _0x3a6a29 * _0x10ccb0;
                },
                'YJqon': function (_0x2f6f88, _0x8f655c) {
                    return _0x2f6f88 - _0x8f655c;
                }
            }, _0x51cc67 = this[_0x4e159b(0x779)](_0x323b80);
        let _0x2225ef = this[_0x4e159b(0x7b5)][_0x4e159b(0x3c7)](_0x51cc67);
        if (_0x4c74cf[_0x4e159b(0x977)](_0x2225ef, void 0x0) || _0x4c74cf['izpUn'](_0x2225ef, 0x0))
            return;
        _0x4c74cf[_0x4e159b(0x977)](_0x2225ef, _0x4c74cf[_0x4e159b(0x264)](_0x4949ea['duration'], 0x14)) && this[_0x4e159b(0xaa3)](_0x323b80, _0x4949ea[_0x4e159b(0x6d3)]?.[_0x4e159b(0xb03)]);
        _0x2225ef = Math['max'](0x0, _0x4c74cf[_0x4e159b(0x98b)](_0x2225ef, 0x1)), this[_0x4e159b(0x7b5)][_0x4e159b(0x54f)](_0x51cc67, _0x2225ef), this[_0x4e159b(0x902)](_0x323b80, _0x4949ea);
        if (_0x2225ef === 0x0) {
            this[_0x4e159b(0xaa3)](_0x323b80, _0x4949ea[_0x4e159b(0x6d3)]?.['onEnd']), this[_0x4e159b(0x2f3)](_0x51cc67);
            if (_0x4949ea['hoverParticle'])
                try {
                    _0x323b80[_0x4e159b(0xb28)][_0x4e159b(0xb85)](_0x4949ea[_0x4e159b(0x7de)], this[_0x4e159b(0x3ef)](_0x323b80));
                } catch (_0x33328d) {
                }
            _0x4949ea[_0x4e159b(0xbe1)] && this['initializeState'](_0x323b80, _0x4949ea[_0x4e159b(0xbe1)]);
        }
    }
    static [_0x21f734(0x902)](_0x19646d, _0x46d204) {
        const _0x5dd23e = _0x21f734, _0x5e54ed = this[_0x5dd23e(0x779)](_0x19646d);
        if (this[_0x5dd23e(0xa3e)][_0x5dd23e(0x1b2)](_0x5e54ed))
            return;
        const _0x13b180 = [];
        _0x46d204['visualEffects']?.['onInterval']?.[_0x5dd23e(0x8b5)]?.[_0x5dd23e(0x3e1)](_0x3d8418 => {
            const _0x4a0922 = _0x5dd23e;
            _0x13b180['push'](_0x5b1866[_0x4a0922(0x770)](() => {
                const _0x5c9282 = _0x4a0922;
                try {
                    _0x19646d['dimension']['spawnParticle'](_0x3d8418['id'], this[_0x5c9282(0x3ef)](_0x19646d));
                } catch (_0x1fb910) {
                }
            }, _0x3d8418[_0x4a0922(0x9b3)]));
        }), _0x46d204['visualEffects']?.[_0x5dd23e(0xba2)]?.[_0x5dd23e(0x22e)]?.[_0x5dd23e(0x3e1)](_0x46f17d => {
            const _0x2f918e = _0x5dd23e;
            _0x13b180['push'](_0x5b1866[_0x2f918e(0x770)](() => {
                const _0x1725b2 = _0x2f918e;
                try {
                    _0x19646d[_0x1725b2(0xb28)][_0x1725b2(0xa70)](_0x46f17d['id'], this[_0x1725b2(0x3ef)](_0x19646d));
                } catch (_0x25bf8b) {
                }
            }, _0x46f17d[_0x2f918e(0x9b3)]));
        }), _0x13b180[_0x5dd23e(0x51f)] > 0x0 && this[_0x5dd23e(0xa3e)]['set'](_0x5e54ed, _0x13b180);
    }
    static [_0x21f734(0xaa3)](_0x161a83, _0x1fe575) {
        const _0x2c7695 = _0x21f734;
        if (!_0x1fe575)
            return;
        _0x1fe575['particles']?.['forEach'](_0x2a0d39 => {
            const _0x175e4d = _0x3124;
            try {
                _0x161a83[_0x175e4d(0xb28)]['spawnParticle'](_0x2a0d39, this[_0x175e4d(0x3ef)](_0x161a83));
            } catch (_0x4ba7d7) {
                console['warn'](_0x175e4d(0x2c9) + _0x2a0d39 + ':\x20' + _0x4ba7d7);
            }
        }), _0x1fe575['sounds']?.[_0x2c7695(0x3e1)](_0x1de697 => {
            const _0x280e78 = _0x2c7695;
            try {
                _0x161a83[_0x280e78(0xb28)]['playSound'](_0x1de697, this[_0x280e78(0x3ef)](_0x161a83));
            } catch (_0x2147ae) {
                console[_0x280e78(0x73d)](_0x280e78(0xac6) + _0x1de697 + ':\x20' + _0x2147ae);
            }
        });
    }
    static [_0x21f734(0x9a2)](_0x53b91a, _0x48596f) {
        const _0x537d46 = _0x21f734, _0x75efc4 = {
                'DlckS': function (_0x28e123, _0x35929d) {
                    return _0x28e123 === _0x35929d;
                },
                'YRADW': function (_0x1473d2, _0x28302a) {
                    return _0x1473d2 !== _0x28302a;
                },
                'INOOS': function (_0x35257e, _0x43de81) {
                    return _0x35257e * _0x43de81;
                }
            }, _0x24e7bf = this[_0x537d46(0x5a4)](_0x53b91a);
        if (!_0x24e7bf)
            return;
        if (Array[_0x537d46(0x2b1)](_0x48596f)) {
            let _0x55e759 = _0x53b91a;
            for (const _0x559bb6 of _0x48596f) {
                if (_0x75efc4[_0x537d46(0x6bc)](_0x48596f[_0x537d46(0x648)](_0x559bb6), 0x0)) {
                    const _0x5853ca = this[_0x537d46(0x38b)](_0x24e7bf[_0x537d46(0x2e7)], _0x559bb6[_0x537d46(0xb76)]);
                    _0x75efc4[_0x537d46(0x961)](_0x55e759[_0x537d46(0x1b9)], _0x5853ca) && (_0x53b91a['dimension']['setBlockType'](_0x53b91a[_0x537d46(0x2c0)], _0x5853ca), _0x55e759 = _0x53b91a['dimension'][_0x537d46(0x3c0)](_0x53b91a[_0x537d46(0x2c0)]));
                }
                _0x55e759[_0x537d46(0x772)](_0x55e759[_0x537d46(0x5fa)][_0x537d46(0x9d1)](_0x559bb6['identifier'], _0x559bb6[_0x537d46(0x8c7)]));
            }
            let _0x2684a7;
            for (const _0x3d5601 of _0x24e7bf[_0x537d46(0x30d)]) {
                if (Array[_0x537d46(0x2b1)](_0x3d5601[_0x537d46(0x5af)]) && _0x3d5601[_0x537d46(0x5af)][_0x537d46(0x51f)] === _0x48596f[_0x537d46(0x51f)] && _0x3d5601['state'][_0x537d46(0xa09)]((_0x3c79c1, _0x222b73) => _0x3c79c1[_0x537d46(0xb76)] === _0x48596f[_0x222b73][_0x537d46(0xb76)] && _0x3c79c1[_0x537d46(0x8c7)] === _0x48596f[_0x222b73]['value'])) {
                    _0x2684a7 = _0x3d5601;
                    break;
                }
            }
            !_0x2684a7 && (_0x2684a7 = _0x24e7bf[_0x537d46(0x30d)][_0x537d46(0x65e)](_0x50628d => !Array[_0x537d46(0x2b1)](_0x50628d[_0x537d46(0x5af)]) && _0x50628d[_0x537d46(0x5af)]['identifier'] === _0x48596f[0x0][_0x537d46(0xb76)] && _0x50628d[_0x537d46(0x5af)][_0x537d46(0x8c7)] === _0x48596f[0x0][_0x537d46(0x8c7)]));
            if (_0x2684a7) {
                const _0x469350 = this['getBlockKey'](_0x53b91a);
                this[_0x537d46(0x7b5)][_0x537d46(0x54f)](_0x469350, _0x2684a7['duration'] * 0x14), this['clearActiveEffects'](_0x469350), this['triggerEffects'](_0x53b91a, _0x2684a7['visualEffects']?.[_0x537d46(0xb03)]);
            }
            return;
        }
        const _0x40e0a3 = this[_0x537d46(0x38b)](_0x24e7bf[_0x537d46(0x2e7)], _0x48596f['identifier']), _0x33d49d = _0x53b91a[_0x537d46(0x5fa)][_0x537d46(0x833)]();
        _0x75efc4[_0x537d46(0x961)](_0x53b91a['typeId'], _0x40e0a3) && (_0x53b91a[_0x537d46(0xb28)][_0x537d46(0xb8d)](_0x53b91a[_0x537d46(0x2c0)], _0x40e0a3), _0x53b91a = _0x53b91a[_0x537d46(0xb28)][_0x537d46(0x3c0)](_0x53b91a[_0x537d46(0x2c0)]));
        let _0xe0386d = _0x53b91a[_0x537d46(0x5fa)]['withState'](_0x48596f[_0x537d46(0xb76)], _0x48596f[_0x537d46(0x8c7)]);
        for (const [_0x554dd0, _0x32061d] of Object[_0x537d46(0x5a8)](_0x33d49d)) {
            _0x75efc4['YRADW'](_0x554dd0, _0x48596f[_0x537d46(0xb76)]) && (_0xe0386d = _0xe0386d[_0x537d46(0x9d1)](_0x554dd0, _0x32061d));
        }
        _0x53b91a[_0x537d46(0x772)](_0xe0386d);
        let _0x2209af;
        _0x2209af = _0x24e7bf[_0x537d46(0x30d)]['find'](_0x473845 => !Array[_0x537d46(0x2b1)](_0x473845[_0x537d46(0x5af)]) && _0x473845['state'][_0x537d46(0xb76)] === _0x48596f['identifier'] && _0x473845['state'][_0x537d46(0x8c7)] === _0x48596f[_0x537d46(0x8c7)]);
        !_0x2209af && (_0x2209af = _0x24e7bf[_0x537d46(0x30d)][_0x537d46(0x65e)](_0xd36332 => Array[_0x537d46(0x2b1)](_0xd36332[_0x537d46(0x5af)]) && _0xd36332[_0x537d46(0x5af)]['some'](_0x16294a => _0x16294a[_0x537d46(0xb76)] === _0x48596f[_0x537d46(0xb76)] && _0x16294a[_0x537d46(0x8c7)] === _0x48596f[_0x537d46(0x8c7)])));
        if (_0x2209af) {
            const _0xf8b81c = this[_0x537d46(0x779)](_0x53b91a);
            this['stateDurations'][_0x537d46(0x54f)](_0xf8b81c, _0x75efc4['INOOS'](_0x2209af[_0x537d46(0xa18)], 0x14)), this[_0x537d46(0x2f3)](_0xf8b81c), this[_0x537d46(0xaa3)](_0x53b91a, _0x2209af[_0x537d46(0x6d3)]?.['onStart']);
        }
    }
    static [_0x21f734(0x2f3)](_0x690b96) {
        const _0x3a4c61 = _0x21f734, _0x343a04 = this[_0x3a4c61(0xa3e)][_0x3a4c61(0x3c7)](_0x690b96);
        _0x343a04 && (_0x343a04[_0x3a4c61(0x3e1)](_0x57bd11 => _0x5b1866['clearRun'](_0x57bd11)), this[_0x3a4c61(0xa3e)][_0x3a4c61(0x305)](_0x690b96));
    }
    static [_0x21f734(0x45c)](_0x2a4584) {
        const _0x8c4c2c = _0x21f734, _0x5b4ca7 = {
                'KRfqw': function (_0xc43b12, _0x517c2c) {
                    return _0xc43b12 <= _0x517c2c;
                },
                'aDPwo': _0x8c4c2c(0xba4),
                'lBBtN': function (_0x4ec4e7, _0x480313) {
                    return _0x4ec4e7 + _0x480313;
                },
                'yPzBa': function (_0x4032f6, _0x3404bf) {
                    return _0x4032f6 + _0x3404bf;
                }
            }, _0x5c7e41 = _0x2a4584[_0x8c4c2c(0x559)]({ 'maxDistance': 0x5 })?.[_0x8c4c2c(0x87b)];
        if (!_0x5c7e41)
            return;
        const _0x5db93d = this['getCurrentState'](_0x5c7e41);
        if (_0x5db93d?.['hoverParticle'] && _0x5b4ca7[_0x8c4c2c(0x489)](this[_0x8c4c2c(0x7b5)][_0x8c4c2c(0x3c7)](this['getBlockKey'](_0x5c7e41)) ?? 0x0, 0x0))
            try {
                const _0x4a96a5 = this[_0x8c4c2c(0x3ef)](_0x5c7e41);
                let _0x588d13 = _0x4a96a5;
                if (_0x5db93d[_0x8c4c2c(0x1d6)]) {
                    const _0x5e0e51 = _0x5c7e41[_0x8c4c2c(0x5fa)][_0x8c4c2c(0x30a)](_0x5b4ca7[_0x8c4c2c(0x410)]), _0x1bb7f6 = this[_0x8c4c2c(0x86b)](_0x5db93d[_0x8c4c2c(0x1d6)], _0x5e0e51);
                    _0x588d13 = {
                        'x': _0x5b4ca7[_0x8c4c2c(0x4de)](_0x4a96a5['x'], _0x1bb7f6['x']),
                        'y': _0x4a96a5['y'] + _0x1bb7f6['y'],
                        'z': _0x5b4ca7['yPzBa'](_0x4a96a5['z'], _0x1bb7f6['z'])
                    };
                }
                _0x5c7e41['dimension'][_0x8c4c2c(0xb85)](_0x5db93d[_0x8c4c2c(0x7de)], _0x588d13);
            } catch (_0x3d879e) {
                console['warn']('Failed\x20to\x20spawn\x20hover\x20particle:\x20' + _0x3d879e);
            }
    }
    static [_0x21f734(0x86b)](_0x41448a, _0x4e46c6) {
        const _0x59ba6d = _0x21f734, _0x174806 = {
                'UGOqe': _0x59ba6d(0x571),
                'UkJoU': 'south',
                'dwvWn': 'east'
            };
        if (!_0x4e46c6)
            return _0x41448a;
        let _0x559d27 = { ..._0x41448a };
        switch (_0x4e46c6) {
        case _0x174806[_0x59ba6d(0xaf9)]:
            break;
        case _0x174806[_0x59ba6d(0x223)]:
            _0x559d27['x'] = -_0x41448a['x'], _0x559d27['z'] = -_0x41448a['z'];
            break;
        case _0x174806[_0x59ba6d(0x8ad)]:
            _0x559d27['x'] = -_0x41448a['z'], _0x559d27['z'] = _0x41448a['x'];
            break;
        case _0x59ba6d(0x709):
            _0x559d27['x'] = _0x41448a['z'], _0x559d27['z'] = -_0x41448a['x'];
            break;
        }
        return _0x559d27;
    }
    static [_0x21f734(0x3ef)](_0x5ae24e) {
        const _0x29040a = _0x21f734, _0x17b1dc = {
                'rUYLW': function (_0x47b158, _0x21b86f) {
                    return _0x47b158 + _0x21b86f;
                }
            };
        return {
            'x': _0x17b1dc[_0x29040a(0x32c)](_0x5ae24e[_0x29040a(0x2c0)]['x'], 0.5),
            'y': _0x5ae24e['location']['y'],
            'z': _0x5ae24e[_0x29040a(0x2c0)]['z'] + 0.5
        };
    }
    static ['getBlockKey'](_0x5b4381) {
        const {
            x: _0x2e9035,
            y: _0x3bc655,
            z: _0x4c8764
        } = _0x5b4381['location'];
        return _0x2e9035 + ',' + _0x3bc655 + ',' + _0x4c8764;
    }
};
_0x25e7d0(_0x169ae2, _0x21f734(0x560), []), _0x25e7d0(_0x169ae2, _0x21f734(0xa3e), new Map()), _0x25e7d0(_0x169ae2, 'stateDurations', new Map());
var _0x5675c9 = class {
        constructor({
            baseIdentifier: _0x5448e0,
            progressMessage: _0x3431f7,
            states: _0x4c05f0,
            multipleBlocks: multipleBlocks = !![],
            onlyOnBlock: _0x1a4c40
        }) {
            const _0x57321f = _0x21f734, _0x490f3b = {
                    'EkbvR': _0x57321f(0xb32),
                    'lHFYx': function (_0x1d1ead, _0x30c418, _0x17c0e7) {
                        return _0x1d1ead(_0x30c418, _0x17c0e7);
                    },
                    'jSmsH': _0x57321f(0x5ef),
                    'WVarE': function (_0xb766dd, _0x4ed7b0, _0x503a62) {
                        return _0xb766dd(_0x4ed7b0, _0x503a62);
                    },
                    'xFzIm': function (_0x4cd23c, _0x22666f, _0x3a1c8f) {
                        return _0x4cd23c(_0x22666f, _0x3a1c8f);
                    },
                    'xAIgl': function (_0x30d821, _0x3cb032, _0x732a6c) {
                        return _0x30d821(_0x3cb032, _0x732a6c);
                    },
                    'zSCUE': _0x57321f(0xab5)
                }, _0x250665 = _0x490f3b[_0x57321f(0x841)]['split']('|');
            let _0x511dfb = 0x0;
            while (!![]) {
                switch (_0x250665[_0x511dfb++]) {
                case '0':
                    _0x490f3b[_0x57321f(0x28d)](_0x25e7d0, this, _0x490f3b[_0x57321f(0xbcf)]);
                    continue;
                case '1':
                    this[_0x57321f(0x9e5)] = _0x3431f7;
                    continue;
                case '2':
                    _0x490f3b[_0x57321f(0x3e4)](_0x25e7d0, this, 'states');
                    continue;
                case '3':
                    this['multipleBlocks'] = multipleBlocks;
                    continue;
                case '4':
                    _0x490f3b[_0x57321f(0x7f3)](_0x25e7d0, this, 'baseIdentifier');
                    continue;
                case '5':
                    _0x490f3b[_0x57321f(0x3e4)](_0x25e7d0, this, 'progressMessage');
                    continue;
                case '6':
                    this[_0x57321f(0x5ef)] = _0x1a4c40;
                    continue;
                case '7':
                    this['states'] = _0x4c05f0;
                    continue;
                case '8':
                    _0x490f3b[_0x57321f(0x9d7)](_0x25e7d0, this, _0x490f3b[_0x57321f(0x6ba)]);
                    continue;
                case '9':
                    this[_0x57321f(0x2e7)] = _0x5448e0;
                    continue;
                }
                break;
            }
        }
    }, _0x147c24 = class extends _0x2e442a {
        constructor() {
            const _0x15a017 = _0x21f734, _0x561f0e = { 'HDvDl': _0x15a017(0x826) };
            super(_0x561f0e[_0x15a017(0x3ab)]);
        }
        [_0x21f734(0x9a6)]() {
            const _0x25361a = _0x21f734, _0x48d579 = {
                    'lzdWU': function (_0xc746a2) {
                        return _0xc746a2();
                    }
                };
            _0x48d579[_0x25361a(0x6c5)](_0x475762);
        }
    };
import {
    system as _0x258468,
    world as _0x904e7a
} from '@minecraft/server';
var _0x5d0530 = class extends _0x2e442a {
    constructor() {
        super('DebugModule');
    }
    [_0x21f734(0x9a6)]() {
        const _0x48553b = _0x21f734, _0x56d60d = {
                'Oqsvl': _0x48553b(0x702),
                'GefZm': _0x48553b(0x907),
                'QAcHn': 'sb_bf:attack_range',
                'XyMLN': _0x48553b(0x87c),
                'ShjrH': function (_0x3a1ddf, _0x117ab4) {
                    return _0x3a1ddf === _0x117ab4;
                },
                'QJMJr': _0x48553b(0x805)
            };
        _0x258468['runInterval'](() => {
            const _0x159496 = _0x48553b;
            _0x904e7a[_0x159496(0x239)]()[_0x159496(0x3e1)](_0xd65362 => {
                const _0x31df25 = _0x159496;
                if (_0xd65362['hasTag'](_0x207994 + _0x31df25(0x872))) {
                    const _0x290a9c = _0xd65362['getBlockFromViewDirection']({ 'maxDistance': 0xa })?.[_0x31df25(0x87b)];
                    if (_0x290a9c) {
                        const _0x2e41b4 = _0x290a9c['permutation']['getAllStates'](), _0x123661 = Object[_0x31df25(0x5a8)](_0x2e41b4)[_0x31df25(0x2dc)](([_0x5a7971, _0x31c15f]) => '§8' + _0x5a7971 + _0x31df25(0x700) + _0x31c15f + '§8')[_0x31df25(0x25f)](_0x56d60d[_0x31df25(0x6c6)]);
                        _0xd65362['runCommandAsync'](_0x31df25(0xb2e) + _0x123661);
                    }
                }
                if (_0xd65362[_0x31df25(0x206)](_0x207994 + ':debug_boss')) {
                    const _0x3fd864 = _0xd65362[_0x31df25(0x4c8)]({ 'maxDistance': 0xa })[0x0];
                    if (_0x3fd864) {
                        const _0x174a8e = _0x3fd864[_0x31df25(0xa27)]['getProperty'](_0x56d60d[_0x31df25(0x2da)]), _0xe4e352 = _0x3fd864[_0x31df25(0xa27)][_0x31df25(0x92e)](_0x56d60d[_0x31df25(0xaf3)]), _0x18510c = _0x3fd864[_0x31df25(0xa27)][_0x31df25(0x92e)](_0x56d60d[_0x31df25(0xbba)]);
                        _0xd65362['runCommandAsync'](_0x31df25(0xb2e) + _0x3fd864['entity'][_0x31df25(0x1b9)] + ',\x20' + _0x174a8e + ',\x20' + _0xe4e352 + ',\x20' + _0x18510c);
                    }
                }
                if (_0xd65362['hasTag'](_0x207994 + ':speed') && _0x56d60d[_0x31df25(0x3fc)](_0xd65362['getGameMode'](), _0x56d60d['QJMJr'])) {
                    if (_0xd65362[_0x31df25(0x42f)] && !_0xd65362[_0x31df25(0x954)]) {
                        const _0x16c2d3 = _0xd65362[_0x31df25(0x5f1)]();
                        _0xd65362[_0x31df25(0x27e)](_0x16c2d3['x'], _0x16c2d3['z'], 0x4, _0x16c2d3['y'] * 0x2);
                    }
                }
            }, 0x1);
        });
    }
};
import {
    system as _0x154163,
    world as _0x3e82c5,
    Player as _0x1795c4,
    ItemStack as _0x565fb3
} from '@minecraft/server';
import { ActionFormData as _0x3de7db } from '@minecraft/server-ui';
import { world as _0x54008f } from '@minecraft/server';
import {
    ActionFormData,
    ModalFormData
} from '@minecraft/server-ui';
function _0x41cda8(_0x14ef3d, _0x19fb8f, _0x437500, _0xc6697d, _0x38eab4, _0x10934d) {
    const _0x5bdc45 = _0x21f734, _0x171dd8 = {
            'TITJE': function (_0x2f858b, _0x30db96) {
                return _0x2f858b === _0x30db96;
            },
            'UPABF': _0x5bdc45(0x701),
            'ealKa': _0x5bdc45(0x848),
            'RJeRa': function (_0x1cd76e, _0x4cd28b) {
                return _0x1cd76e === _0x4cd28b;
            },
            'lrsRx': function (_0x22b8a8) {
                return _0x22b8a8();
            },
            'rjxYP': function (_0x5517ea, _0x32ab11) {
                return _0x5517ea(_0x32ab11);
            },
            'lpNYZ': function (_0x36de32, _0x3e0292) {
                return _0x36de32 instanceof _0x3e0292;
            }
        };
    let _0x343bce = 0x0;
    const _0x34a29f = _0xc6697d[_0x5bdc45(0x3c7)](_0x19fb8f);
    return _0x34a29f && _0x34a29f[_0x5bdc45(0x3e1)](_0x286d42 => {
        const _0xb95b5e = _0x5bdc45, _0x4424ed = _0x437500[_0xb95b5e(0x3c7)](_0x286d42);
        if (!_0x4424ed)
            return;
        const _0x45e70b = _0x171dd8['TITJE'](_0x4424ed[_0xb95b5e(0x8e7)][_0xb95b5e(0xa88)]?.[_0xb95b5e(0x1e9)], _0x171dd8[_0xb95b5e(0x43a)]) ? _0x171dd8[_0xb95b5e(0x43a)] : _0x171dd8[_0xb95b5e(0x654)], _0x2856d0 = _0x171dd8[_0xb95b5e(0xba5)](_0x45e70b, _0x171dd8[_0xb95b5e(0x43a)]) ? _0x171dd8[_0xb95b5e(0x77c)](_0x160d53) : _0x144c82(_0x10934d);
        let _0x36ea05 = !![];
        if (_0x4424ed[_0xb95b5e(0x8e7)]['showOnlyWhenReferencesUnlocked'] && _0x4424ed[_0xb95b5e(0x8e7)]['references'])
            for (const _0x2068c3 of _0x4424ed[_0xb95b5e(0x8e7)][_0xb95b5e(0x6cd)]) {
                const _0x15ec1a = _0x437500[_0xb95b5e(0x3c7)](_0x2068c3);
                if (_0x15ec1a) {
                    const _0x4e0898 = _0x171dd8[_0xb95b5e(0xba5)](_0x15ec1a[_0xb95b5e(0x8e7)][_0xb95b5e(0xa88)]?.[_0xb95b5e(0x1e9)], _0x171dd8['UPABF']) ? _0xb95b5e(0x701) : _0x171dd8['ealKa'], _0x12bd1d = _0x4e0898 === _0x171dd8[_0xb95b5e(0x43a)] ? _0x160d53()['has'](_0x2068c3) : _0x171dd8[_0xb95b5e(0x237)](_0x144c82, _0x10934d)['has'](_0x2068c3);
                    if (!_0x12bd1d) {
                        _0x36ea05 = ![];
                        break;
                    }
                }
            }
        if (_0x171dd8['lpNYZ'](_0x4424ed, _0x2a6cb3)) {
            const _0x290353 = _0x2856d0['has'](_0x286d42), _0x1ec899 = _0x4424ed[_0xb95b5e(0x259)](), _0x6a2a6c = _0x290353 ? _0x4424ed['achievementOptions'][_0xb95b5e(0x660)]?.[_0xb95b5e(0x3bb)] || _0x4424ed[_0xb95b5e(0x8e7)][_0xb95b5e(0x660)] || '' : _0x4424ed[_0xb95b5e(0x3af)][_0xb95b5e(0x660)]?.[_0xb95b5e(0x3c9)] || _0x4424ed[_0xb95b5e(0x8e7)][_0xb95b5e(0x660)] || '', _0x43812d = _0x290353 ? _0x4424ed['achievementOptions'][_0xb95b5e(0x417)]?.[_0xb95b5e(0x3bb)] : _0x4424ed[_0xb95b5e(0x3af)][_0xb95b5e(0x417)]?.['locked'];
            _0x14ef3d[_0xb95b5e(0x2f2)]({
                'rawtext': [
                    _0x1ec899,
                    { 'text': '\x0a' },
                    ..._0x43812d ? [{ 'translate': _0x43812d }] : []
                ]
            }, _0x6a2a6c), _0x343bce++;
        } else {
            if (_0x36ea05) {
                if (_0x2856d0['has'](_0x286d42) || !_0x4424ed[_0xb95b5e(0x8e7)][_0xb95b5e(0xa88)]) {
                    const _0x59e2b7 = _0x4424ed instanceof _0xd980f0 ? _0x4424ed[_0xb95b5e(0x259)]() : { 'translate': _0x4424ed[_0xb95b5e(0x259)]() }, _0x11c623 = _0x4424ed[_0xb95b5e(0x8e7)][_0xb95b5e(0x660)] || '';
                    _0x14ef3d['button'](_0x59e2b7, _0x11c623), _0x343bce++;
                }
            }
        }
    }), _0x343bce;
}
var _0xd980f0 = class {
        constructor(_0x4d0b7a, _0x449404, _0x2fd2c4 = ![]) {
            const _0x4cd9ad = _0x21f734, _0x1a64f9 = {
                    'ZiihI': function (_0x31c351, _0x26403b, _0x1c0820) {
                        return _0x31c351(_0x26403b, _0x1c0820);
                    },
                    'aFMQN': _0x4cd9ad(0xade)
                };
            this['id'] = _0x4d0b7a, this[_0x4cd9ad(0x8e7)] = _0x449404, _0x1a64f9[_0x4cd9ad(0x8a7)](_0x25e7d0, this, _0x1a64f9[_0x4cd9ad(0x229)]), this[_0x4cd9ad(0xade)] = _0x2fd2c4;
        }
        [_0x21f734(0x35d)](_0x22a8dd) {
            return { 'translate': _0x22a8dd };
        }
        [_0x21f734(0x889)](_0x5c23d9) {
            const _0x1b793a = _0x21f734;
            return _0x5c23d9[_0x1b793a(0x2dc)](_0x588953 => ({ 'translate': _0x588953 }));
        }
        [_0x21f734(0x259)]() {
            const _0x2b756f = _0x21f734;
            return this['translateString'](this[_0x2b756f(0x8e7)][_0x2b756f(0x7a6)] || _0x2b756f(0x29e) + _0x207994 + ':' + this['id']);
        }
        get ['isMainForm']() {
            const _0x34135f = _0x21f734;
            return this[_0x34135f(0xade)];
        }
        [_0x21f734(0x2e6)](_0x3d8693, _0x522ac5, _0x42d87e, _0x56c899) {
            const _0x5852c8 = _0x21f734, _0x5291be = {
                    'IxzcC': function (_0x3b663f, _0x2d3b74) {
                        return _0x3b663f !== _0x2d3b74;
                    },
                    'AamXw': function (_0x3f5ac3, _0x1f57b3) {
                        return _0x3f5ac3 !== _0x1f57b3;
                    },
                    'geCxd': function (_0x477fb6, _0x5e2811) {
                        return _0x477fb6 === _0x5e2811;
                    },
                    'vUrMn': function (_0x12aa66, _0x28df4b) {
                        return _0x12aa66 !== _0x28df4b;
                    },
                    'rEnZl': _0x5852c8(0xa99),
                    'OYrcH': function (_0x3f2d3a, _0x5e29a4) {
                        return _0x3f2d3a !== _0x5e29a4;
                    },
                    'iqZvb': function (_0x537241, _0x2bb382, _0x5e440f, _0x421ed5, _0x277e87, _0x59e0ef, _0x3ec79a) {
                        return _0x537241(_0x2bb382, _0x5e440f, _0x421ed5, _0x277e87, _0x59e0ef, _0x3ec79a);
                    }
                }, _0x4be25e = new ActionFormData();
            _0x4be25e[_0x5852c8(0x7a6)](this[_0x5852c8(0x259)]());
            const _0x1d7926 = [], _0x31c553 = { 'text': '\x0a\x0a' }, _0x29f8ad = { 'text': '\x0a' };
            this['options']['description'] && this[_0x5852c8(0x889)](this[_0x5852c8(0x8e7)][_0x5852c8(0x2a0)])[_0x5852c8(0x3e1)](_0x366222 => {
                const _0x584506 = _0x5852c8;
                _0x1d7926[_0x584506(0x28e)](_0x29f8ad, _0x366222);
            });
            const _0x3eb659 = this[_0x5852c8(0x8e7)][_0x5852c8(0x865)];
            if (_0x3eb659) {
                if (_0x3eb659) {
                    if (_0x3eb659[_0x5852c8(0xb37)]) {
                        if (_0x3eb659['biomes'][_0x5852c8(0x51f)] === 0x0)
                            _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x6ed) });
                        else {
                            _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x207994 + '.form.biomes' }, { 'text': '\x20' });
                            for (const _0xa5acc4 of _0x3eb659['biomes']) {
                                _0x1d7926[_0x5852c8(0x28e)]({ 'translate': _0x207994 + _0x5852c8(0x9df) + _0xa5acc4 }, { 'text': ',\x20' });
                            }
                            _0x1d7926[_0x5852c8(0x988)]();
                        }
                    }
                    _0x5291be[_0x5852c8(0x7d8)](_0x3eb659['isRideable'], void 0x0) && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x3eb659[_0x5852c8(0x992)] ? _0x207994 + _0x5852c8(0x788) : _0x207994 + _0x5852c8(0x26c) });
                    _0x5291be[_0x5852c8(0x7d8)](_0x3eb659['isBreedable'], void 0x0) && _0x1d7926['push'](_0x31c553, { 'translate': _0x3eb659[_0x5852c8(0x993)] ? _0x207994 + _0x5852c8(0x82a) : _0x207994 + '.form.not_breedable' });
                    _0x5291be[_0x5852c8(0x1ea)](_0x3eb659[_0x5852c8(0x708)], void 0x0) && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x3eb659['isTameable'] ? _0x207994 + _0x5852c8(0x444) : _0x207994 + _0x5852c8(0x1e1) });
                    _0x3eb659[_0x5852c8(0x6a8)] && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x90b) + _0x3eb659[_0x5852c8(0x6a8)] });
                    if (_0x3eb659[_0x5852c8(0xb0b)]) {
                        if (_0x5291be['geCxd'](_0x3eb659[_0x5852c8(0xb0b)]['length'], 0x0))
                            _0x1d7926['push'](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x51c) });
                        else {
                            _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x6bd) }, { 'text': '\x20' });
                            for (const _0x42d842 of _0x3eb659['food']) {
                                _0x1d7926[_0x5852c8(0x28e)]({ 'translate': _0x42d842 }, { 'text': ',\x20' });
                            }
                            _0x1d7926[_0x5852c8(0x988)]();
                        }
                    }
                    if (_0x3eb659[_0x5852c8(0x6ae)]) {
                        if (_0x5291be[_0x5852c8(0x3da)](_0x3eb659['drops'][_0x5852c8(0x51f)], 0x0))
                            _0x1d7926['push'](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x732) });
                        else {
                            _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x1ca) }, { 'text': '\x20' });
                            for (const _0x52446a of _0x3eb659[_0x5852c8(0x6ae)]) {
                                _0x1d7926[_0x5852c8(0x28e)]({ 'translate': _0x52446a }, { 'text': ',\x20' });
                            }
                            _0x1d7926[_0x5852c8(0x988)]();
                        }
                    }
                    _0x3eb659[_0x5852c8(0x404)] !== void 0x0 && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x3eb659[_0x5852c8(0x404)] ? _0x207994 + _0x5852c8(0x4bb) : _0x207994 + _0x5852c8(0xb4f) }), _0x5291be[_0x5852c8(0x8b2)](_0x3eb659[_0x5852c8(0x994)], void 0x0) && (_0x5291be[_0x5852c8(0x7d8)](_0x3eb659['hasCustomTableRecipe'][_0x5852c8(0x1ee)], void 0x0) && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x3eb659['hasCustomTableRecipe'][_0x5852c8(0x1ee)] ? _0x207994 + _0x5852c8(0x68a) : _0x207994 + _0x5852c8(0x9cc) }, { 'translate': _0x5852c8(0x57c) + _0x3eb659['hasCustomTableRecipe'][_0x5852c8(0x8e3)] + _0x5852c8(0x261) }, { 'text': _0x5291be[_0x5852c8(0x392)] })), _0x5291be[_0x5852c8(0x633)](_0x3eb659['isShearable'], void 0x0) && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x3eb659[_0x5852c8(0xad0)] ? _0x207994 + _0x5852c8(0xa3f) : _0x207994 + '.form.no_shearable' }), _0x5291be['OYrcH'](_0x3eb659[_0x5852c8(0x985)], void 0x0) && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x3eb659[_0x5852c8(0x985)] ? _0x207994 + _0x5852c8(0xbd2) : _0x207994 + _0x5852c8(0x6cc) }), _0x5291be[_0x5852c8(0x633)](_0x3eb659[_0x5852c8(0x756)], void 0x0) && _0x1d7926[_0x5852c8(0x28e)](_0x31c553, { 'translate': _0x207994 + _0x5852c8(0x4b5) }, { 'translate': _0x3eb659['stonecutter'] }, { 'text': _0x5291be[_0x5852c8(0x392)] });
                }
            }
            let _0x68a476 = _0x5291be[_0x5852c8(0x1b8)](_0x41cda8, _0x4be25e, this['id'], _0x522ac5, _0x42d87e, _0x56c899, _0x3d8693), _0x3d0f2c;
            return !this['isMainForm'] && (_0x4be25e['button']({ 'translate': _0x207994 + _0x5852c8(0xa3c) }), _0x3d0f2c = _0x68a476, _0x68a476++), _0x1d7926[_0x5852c8(0x28e)](_0x31c553), _0x4be25e[_0x5852c8(0x45d)]({ 'rawtext': _0x1d7926 }), {
                'form': _0x4be25e,
                'buttonCount': _0x68a476,
                'backButtonIndex': _0x3d0f2c
            };
        }
    }, _0x380dcf = class {
        constructor(_0x31a88b, _0x2e82ef, _0x1aac78 = ![]) {
            const _0x4fe4db = _0x21f734;
            this['id'] = _0x31a88b, this['options'] = _0x2e82ef, this[_0x4fe4db(0xade)] = _0x1aac78;
        }
        ['getTitle']() {
            const _0x161fb4 = _0x21f734;
            return this[_0x161fb4(0x8e7)][_0x161fb4(0x7a6)];
        }
        get [_0x21f734(0x6bb)]() {
            const _0x3e8347 = _0x21f734;
            return this[_0x3e8347(0xade)];
        }
        ['compile']() {
            const _0x54a1b5 = _0x21f734, _0xb5e3af = {
                    'abaPW': function (_0x191aa4, _0x393820) {
                        return _0x191aa4 !== _0x393820;
                    },
                    'kKSWQ': 'toggle',
                    'TFFHN': _0x54a1b5(0x6d1),
                    'tmbyz': _0x54a1b5(0xac2),
                    'yPucZ': _0x54a1b5(0x1cb)
                }, _0x27afec = new ModalFormData()['title'](this[_0x54a1b5(0x8e7)][_0x54a1b5(0x7a6)]);
            return this[_0x54a1b5(0x8e7)][_0x54a1b5(0x89a)]['forEach'](_0x47a4fb => {
                const _0x1d947d = _0x54a1b5;
                let _0x28e144 = _0x47a4fb['defaultValue'];
                if (_0x47a4fb[_0x1d947d(0x7a1)]) {
                    const _0xb7336f = _0x54008f[_0x1d947d(0xb95)](_0x47a4fb[_0x1d947d(0x7a1)]);
                    _0xb5e3af[_0x1d947d(0xb0e)](_0xb7336f, void 0x0) && (_0x28e144 = _0xb7336f);
                }
                switch (_0x47a4fb['type']) {
                case _0xb5e3af[_0x1d947d(0xbe6)]:
                    _0x27afec['toggle'](_0x47a4fb['label'], _0x28e144);
                    break;
                case _0xb5e3af[_0x1d947d(0x593)]:
                    _0x27afec[_0x1d947d(0x6d1)](_0x47a4fb[_0x1d947d(0x99e)], _0x47a4fb[_0x1d947d(0x8e7)][_0x1d947d(0x789)], _0x47a4fb[_0x1d947d(0x8e7)][_0x1d947d(0x6da)], _0x47a4fb[_0x1d947d(0x8e7)][_0x1d947d(0x2af)], _0x28e144);
                    break;
                case _0xb5e3af[_0x1d947d(0x944)]:
                    _0x27afec['dropdown'](_0x47a4fb[_0x1d947d(0x99e)], _0x47a4fb['options'], _0x28e144);
                    break;
                case _0xb5e3af['yPucZ']:
                    _0x27afec[_0x1d947d(0x1cb)](_0x47a4fb[_0x1d947d(0x99e)], _0x47a4fb[_0x1d947d(0x8e7)][_0x1d947d(0x4ee)], _0x28e144);
                    break;
                }
            }), _0x27afec;
        }
    }, _0x2a6cb3 = class extends _0xd980f0 {
        constructor(_0x2588a2, _0x70e9, _0x1acb2f = ![]) {
            const _0x73b630 = _0x21f734;
            super(_0x2588a2, {
                'title': _0x70e9[_0x73b630(0x7a6)],
                'description': _0x70e9[_0x73b630(0x2a0)],
                'references': _0x70e9['references'],
                'iconPath': '',
                'unlock': _0x70e9['unlock']
            }, _0x1acb2f), _0x25e7d0(this, _0x73b630(0x3af)), this[_0x73b630(0x3af)] = _0x70e9;
        }
        [_0x21f734(0x2e6)](_0x4c1a51, _0x5eeed2, _0x347294, _0x49a969) {
            const _0x33f5b7 = _0x21f734, _0x260dda = {
                    'alesd': _0x33f5b7(0x59a),
                    'Luhne': function (_0x4d0e36, _0x3102f4) {
                        return _0x4d0e36 === _0x3102f4;
                    },
                    'NXCuD': function (_0x1cc930, _0x2b822f) {
                        return _0x1cc930 > _0x2b822f;
                    }
                }, _0x297086 = new ActionFormData(), _0x5f0e39 = _0x49a969['has'](this['id']);
            _0x297086[_0x33f5b7(0x7a6)]({ 'translate': this[_0x33f5b7(0x3af)][_0x33f5b7(0x7a6)] });
            const _0x8a01d0 = [], _0x4533fe = { 'text': '\x0a\x0a' }, _0x48fca8 = { 'text': '\x0a' }, _0x4f994e = _0x5f0e39 ? this[_0x33f5b7(0x3af)][_0x33f5b7(0x2a0)] : this['achievementOptions'][_0x33f5b7(0xc06)] || this[_0x33f5b7(0x3af)][_0x33f5b7(0x2a0)];
            _0x4f994e[_0x33f5b7(0x3e1)](_0x4000d2 => {
                _0x8a01d0['push'](_0x48fca8, { 'translate': _0x4000d2 });
            }), _0x8a01d0[_0x33f5b7(0x28e)](_0x4533fe);
            if (this['achievementOptions'][_0x33f5b7(0x350)]) {
                const _0x239dfb = _0x5f0e39 ? this[_0x33f5b7(0x3af)][_0x33f5b7(0x350)][_0x33f5b7(0x3bb)] : this[_0x33f5b7(0x3af)][_0x33f5b7(0x350)][_0x33f5b7(0x3c9)];
                _0x239dfb && _0x8a01d0['push'](_0x48fca8, { 'translate': _0x239dfb });
            }
            const _0x373a5f = this[_0x33f5b7(0x3af)]['unlock'];
            if (_0x373a5f && _0x373a5f['reward']) {
                const {
                    xp: _0x46a11f,
                    items: _0x579eae
                } = _0x373a5f[_0x33f5b7(0x834)];
                _0x8a01d0[_0x33f5b7(0x28e)]({ 'text': '\x0a\x0a' }, { 'translate': _0x207994 + _0x33f5b7(0x247) }, { 'text': '\x20' });
                let _0x36a5bd = !![];
                _0x260dda[_0x33f5b7(0x9ef)](typeof _0x46a11f, _0x33f5b7(0x4c4)) && (_0x8a01d0[_0x33f5b7(0x28e)]({ 'text': _0x46a11f + 'xp' }), _0x36a5bd = ![]), _0x579eae && _0x260dda[_0x33f5b7(0x32f)](_0x579eae[_0x33f5b7(0x51f)], 0x0) && _0x579eae[_0x33f5b7(0x3e1)](_0x3887e6 => {
                    const _0x5837f4 = _0x33f5b7;
                    !_0x36a5bd && _0x8a01d0[_0x5837f4(0x28e)]({ 'text': _0x260dda[_0x5837f4(0x2a6)] }), _0x8a01d0[_0x5837f4(0x28e)]({ 'translate': _0x5837f4(0x29e) + _0x3887e6['id'] }, { 'text': '\x20(' + _0x3887e6['count'] + 'x)' }), _0x36a5bd = ![];
                }), _0x8a01d0[_0x33f5b7(0x28e)](_0x4533fe);
            }
            let _0x323907 = _0x41cda8(_0x297086, this['id'], _0x5eeed2, _0x347294, _0x49a969, _0x4c1a51), _0x4b5aef;
            return !this['isMainForm'] ? (_0x297086[_0x33f5b7(0x2f2)]({ 'translate': _0x207994 + _0x33f5b7(0xa3c) }), _0x4b5aef = _0x323907, _0x323907++) : _0x8a01d0['push'](_0x4533fe), _0x297086['body']({ 'rawtext': _0x8a01d0 }), {
                'form': _0x297086,
                'buttonCount': _0x323907,
                'backButtonIndex': _0x4b5aef
            };
        }
    }, _0x59d38b = 'main', _0x48ca60 = [
        new _0xd980f0(_0x21f734(0x420), {
            'title': '',
            'description': [_0x21f734(0x311)],
            'iconPath': ''
        }),
        new _0xd980f0(_0x21f734(0x898), {
            'title': _0x21f734(0x30e),
            'iconPath': _0x21f734(0x9de),
            'description': ['sb_bf.form.wiki.description.1'],
            'references': [_0x21f734(0x420)]
        }),
        new _0xd980f0(_0x21f734(0xbaf), {
            'title': _0x21f734(0x466),
            'iconPath': 'textures/sb/bf/form/books',
            'description': [
                _0x21f734(0x2c4),
                '',
                _0x21f734(0x43e),
                '',
                'sb_bf.form.tutorial.description.3',
                '',
                _0x21f734(0x71d)
            ],
            'references': [_0x21f734(0x420)]
        }),
        new _0xd980f0(_0x21f734(0x577), {
            'title': _0x21f734(0x51b),
            'iconPath': _0x21f734(0xa24),
            'description': [
                'sb_bf.form.recipes.description.1',
                '',
                _0x21f734(0x2bb),
                '',
                _0x21f734(0x304),
                '',
                'sb_bf.form.recipes.description.4',
                '',
                _0x21f734(0x8cd)
            ],
            'references': [_0x21f734(0xbaf)]
        }),
        new _0xd980f0('modular_blocks', {
            'title': 'sb_bf.form.modular.title',
            'iconPath': _0x21f734(0x7d7),
            'description': [_0x21f734(0xb82)],
            'references': [_0x21f734(0xbaf)]
        }),
        new _0xd980f0('storage_blocks', {
            'title': 'sb_bf.form.storage.title',
            'iconPath': _0x21f734(0x922),
            'description': [
                _0x21f734(0x3d6),
                '',
                'sb_bf.form.storage_blocks.description.2',
                '',
                _0x21f734(0xa0a),
                ''
            ],
            'references': [_0x21f734(0xbaf)]
        }),
        new _0xd980f0('support', {
            'title': 'sb_bf.form.support.title',
            'iconPath': _0x21f734(0x9b4),
            'description': [
                'sb_bf.form.info_contact.1',
                '',
                'sb_bf.form.info_contact.2',
                '',
                'sb_bf.form.info_contact.3'
            ],
            'references': [_0x21f734(0x420)]
        }),
        new _0xd980f0(_0x21f734(0x4c2), {
            'title': 'sb_bf.form.plank_variants.title',
            'iconPath': _0x21f734(0xb51),
            'description': ['sb_bf.form.plank_variants.description.1'],
            'references': ['wiki']
        }),
        new _0xd980f0(_0x21f734(0x477), {
            'title': _0x21f734(0xa56),
            'iconPath': _0x21f734(0x9de),
            'description': [_0x21f734(0x3ce)],
            'references': ['wiki']
        }),
        new _0xd980f0('table', {
            'title': _0x21f734(0x314),
            'iconPath': _0x21f734(0x248),
            'description': [
                'sb_bf.form.table.modular',
                '',
                'sb_bf.wood_variants'
            ],
            'references': [
                _0x21f734(0x898),
                _0x21f734(0x905)
            ],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x5ac), {
            'title': _0x21f734(0x769),
            'iconPath': 'textures/sb/bf/form/drawer_cabinet',
            'description': ['sb_bf.form.storage.description.1'],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0x69a), {
            'title': _0x21f734(0x430),
            'iconPath': 'textures/sb/bf/form/special_fence',
            'description': [_0x21f734(0x92a)],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0xabe), {
            'title': _0x21f734(0x41f),
            'iconPath': _0x21f734(0xbb1),
            'description': [''],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0x89d), {
            'title': _0x21f734(0x9bf),
            'iconPath': _0x21f734(0x971),
            'description': [_0x21f734(0x25c)],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0x5ca), {
            'title': _0x21f734(0x46b),
            'iconPath': 'textures/sb/bf/form/lamp',
            'description': [_0x21f734(0x473)],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0x8af), {
            'title': 'sb_bf.form.wallpaper_carpet.title',
            'iconPath': _0x21f734(0x575),
            'description': [_0x21f734(0x868)],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0x746), {
            'title': _0x21f734(0x84d),
            'iconPath': _0x21f734(0x4a2),
            'description': [
                _0x21f734(0xb9f),
                '',
                'sb_bf.wood_variants'
            ],
            'references': [_0x21f734(0x4c2)],
            'wikiInfo': { 'stonecutter': _0x21f734(0xa74) }
        }),
        new _0xd980f0(_0x21f734(0x1b0), {
            'title': _0x21f734(0x40f),
            'iconPath': _0x21f734(0x533),
            'description': [
                'sb_bf.form.wide_planks.description.1',
                '',
                'sb_bf.wood_variants'
            ],
            'references': [_0x21f734(0x4c2)],
            'wikiInfo': { 'stonecutter': _0x21f734(0xa74) }
        }),
        new _0xd980f0(_0x21f734(0x747), {
            'title': _0x21f734(0x7cb),
            'iconPath': 'textures/sb/bf/form/tiled_planks',
            'description': [
                'sb_bf.form.tiled_planks.description.1',
                '',
                _0x21f734(0xbb3)
            ],
            'references': ['plank_variants'],
            'wikiInfo': { 'stonecutter': _0x21f734(0xa74) }
        }),
        new _0xd980f0('special_fence', {
            'title': 'sb_bf.form.special_fence.title',
            'iconPath': _0x21f734(0x310),
            'description': [
                _0x21f734(0x6d2),
                '',
                'sb_bf.wood_variants'
            ],
            'references': [_0x21f734(0x69a)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x858), {
            'title': _0x21f734(0xc01),
            'iconPath': _0x21f734(0x690),
            'description': [
                _0x21f734(0x5de),
                '',
                _0x21f734(0xbb3)
            ],
            'references': ['fences'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('shutter', {
            'title': _0x21f734(0x983),
            'iconPath': _0x21f734(0x6a2),
            'description': [
                _0x21f734(0xbb4),
                '',
                _0x21f734(0xbb3)
            ],
            'references': [_0x21f734(0x5ca)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xa12), {
            'title': _0x21f734(0x20f),
            'iconPath': _0x21f734(0x488),
            'description': [
                'sb_bf.form.glass_door.description.1',
                '',
                _0x21f734(0xbb3)
            ],
            'references': [_0x21f734(0x898)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('chair', {
            'title': _0x21f734(0x55f),
            'iconPath': 'textures/sb/bf/form/chair',
            'description': [
                'sb_bf.form.chair.description.1',
                '',
                _0x21f734(0xbb3)
            ],
            'references': [
                _0x21f734(0x477),
                'modular_blocks'
            ],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('stool', {
            'title': _0x21f734(0x890),
            'iconPath': _0x21f734(0x397),
            'description': [
                _0x21f734(0x9a3),
                '',
                'sb_bf.wood_variants'
            ],
            'references': [_0x21f734(0x477)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xaa1), {
            'title': _0x21f734(0x1c1),
            'iconPath': _0x21f734(0x80f),
            'description': [
                'sb_bf.form.shelf.description.1',
                '',
                _0x21f734(0xbb3)
            ],
            'references': [_0x21f734(0x5ac)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x8e5), {
            'title': _0x21f734(0x8fb),
            'iconPath': _0x21f734(0xa02),
            'description': [
                'sb_bf.form.counter.description.1',
                '',
                'sb_bf.wood_variants'
            ],
            'references': ['storage'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x402), {
            'title': _0x21f734(0x219),
            'iconPath': 'textures/sb/bf/form/door_cabinet',
            'description': [
                _0x21f734(0xadc),
                '',
                'sb_bf.wood_variants'
            ],
            'references': [
                _0x21f734(0x5ac),
                'modular_blocks',
                'storage_blocks'
            ],
            'wikiInfo': { 'stonecutter': _0x21f734(0x2ef) }
        }),
        new _0xd980f0('drawer_cabinets', {
            'title': _0x21f734(0xa6a),
            'iconPath': _0x21f734(0x922),
            'description': [
                _0x21f734(0x4d9),
                '',
                'sb_bf.wood_variants'
            ],
            'references': [
                _0x21f734(0x5ac),
                _0x21f734(0x905),
                _0x21f734(0x549)
            ],
            'wikiInfo': { 'stonecutter': _0x21f734(0x2ef) }
        }),
        new _0xd980f0('tiled_glass', {
            'title': _0x21f734(0xab4),
            'iconPath': 'textures/sb/bf/form/tiled_glass',
            'description': [_0x21f734(0x5b7)],
            'references': [_0x21f734(0xabe)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x9bc), {
            'title': _0x21f734(0x699),
            'iconPath': 'textures/sb/bf/form/tiled_glass_pane',
            'description': [_0x21f734(0x7b4)],
            'references': [_0x21f734(0xabe)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x663), {
            'title': _0x21f734(0x45a),
            'iconPath': _0x21f734(0x8ba),
            'description': [_0x21f734(0x70b)],
            'references': ['glass'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xaa7), {
            'title': _0x21f734(0x9bd),
            'iconPath': 'textures/sb/bf/form/framed_glass_pane',
            'description': [_0x21f734(0x695)],
            'references': ['glass'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x42e), {
            'title': _0x21f734(0x469),
            'iconPath': _0x21f734(0x582),
            'description': [
                _0x21f734(0x321),
                '',
                _0x21f734(0xbb3)
            ],
            'references': ['glass'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('oak_framed_glass_pane', {
            'title': _0x21f734(0x31b),
            'iconPath': _0x21f734(0x70a),
            'description': [
                _0x21f734(0x821),
                '',
                _0x21f734(0xbb3)
            ],
            'references': [_0x21f734(0xabe)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x1b3), {
            'title': _0x21f734(0x4ff),
            'iconPath': _0x21f734(0x84a),
            'description': [_0x21f734(0x647)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x6b5), {
            'title': _0x21f734(0x34d),
            'iconPath': 'textures/sb/bf/form/empty_jar',
            'description': [_0x21f734(0x771)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('trophies', {
            'title': _0x21f734(0xa21),
            'iconPath': 'textures/sb/bf/form/trophy_gold',
            'description': [_0x21f734(0x7c6)],
            'references': ['collector_items'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x37d), {
            'title': _0x21f734(0x855),
            'iconPath': _0x21f734(0x2f9),
            'description': [_0x21f734(0x66e)],
            'references': [_0x21f734(0x4e8)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x84c), {
            'title': _0x21f734(0x85c),
            'iconPath': 'textures/sb/bf/form/trophy_iron',
            'description': [_0x21f734(0x8ed)],
            'references': [_0x21f734(0x4e8)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('gold_trophy', {
            'title': _0x21f734(0x816),
            'iconPath': _0x21f734(0xb2f),
            'description': [_0x21f734(0x93e)],
            'references': [_0x21f734(0x4e8)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('ingots', {
            'title': _0x21f734(0x903),
            'iconPath': 'textures/sb/bf/form/golden_ingot',
            'description': [_0x21f734(0x200)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xa54), {
            'title': 'sb_bf.form.iron_ingot.title',
            'iconPath': _0x21f734(0x941),
            'description': [_0x21f734(0x8c6)],
            'references': [_0x21f734(0x936)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xb5e), {
            'title': _0x21f734(0x28a),
            'iconPath': _0x21f734(0x289),
            'description': [_0x21f734(0x90d)],
            'references': [_0x21f734(0x936)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x5ae), {
            'title': _0x21f734(0x520),
            'iconPath': _0x21f734(0x53e),
            'description': [_0x21f734(0x673)],
            'references': [_0x21f734(0x936)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('netherite_ingot', {
            'title': _0x21f734(0x99c),
            'iconPath': 'textures/sb/bf/form/netherite_ingot',
            'description': [_0x21f734(0x836)],
            'references': [_0x21f734(0x936)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('cookie_jar', {
            'title': _0x21f734(0x5ed),
            'iconPath': _0x21f734(0x608),
            'description': ['sb_bf.form.cookie_jar.description.1'],
            'references': ['jars']
        }),
        new _0xd980f0(_0x21f734(0x6b7), {
            'title': _0x21f734(0x537),
            'iconPath': _0x21f734(0x704),
            'description': ['sb_bf.form.pickle_jar.description.1'],
            'references': ['jars']
        }),
        new _0xd980f0(_0x21f734(0x4b6), {
            'title': 'sb_bf.form.slime_jar.title',
            'iconPath': _0x21f734(0xb26),
            'description': [_0x21f734(0xabc)],
            'references': ['jars']
        }),
        new _0xd980f0('honey_jar', {
            'title': _0x21f734(0x8ef),
            'iconPath': _0x21f734(0x8c0),
            'description': [_0x21f734(0x377)],
            'references': [_0x21f734(0x6b5)]
        }),
        new _0xd980f0(_0x21f734(0x6c4), {
            'title': _0x21f734(0xbfd),
            'iconPath': _0x21f734(0x322),
            'description': [_0x21f734(0x852)],
            'references': [_0x21f734(0x5ac)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xac5), {
            'title': _0x21f734(0x428),
            'iconPath': _0x21f734(0x26e),
            'description': [_0x21f734(0x412)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0('globe', {
            'title': _0x21f734(0x7d2),
            'iconPath': _0x21f734(0x6c1),
            'description': [_0x21f734(0x55b)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x37a), {
            'title': _0x21f734(0xa8a),
            'iconPath': _0x21f734(0x971),
            'description': [_0x21f734(0x3a2)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x42c), {
            'title': _0x21f734(0x4f2),
            'iconPath': _0x21f734(0x7f7),
            'description': [_0x21f734(0xb34)],
            'references': [_0x21f734(0x89d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xb1e), {
            'title': _0x21f734(0x436),
            'iconPath': _0x21f734(0x93a),
            'description': [_0x21f734(0x40c)],
            'references': [_0x21f734(0x898)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x705), {
            'title': _0x21f734(0xbdd),
            'iconPath': _0x21f734(0xa4e),
            'description': [
                'sb_bf.form.curtains.description.1',
                '',
                _0x21f734(0x8f6)
            ],
            'references': [
                _0x21f734(0x5ca),
                _0x21f734(0x905)
            ],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('lamps', {
            'title': _0x21f734(0x467),
            'iconPath': _0x21f734(0x79d),
            'description': [
                _0x21f734(0xbfa),
                '',
                _0x21f734(0x8f6)
            ],
            'references': [
                'lights',
                'modular_blocks'
            ],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0xa9d), {
            'title': _0x21f734(0x3d0),
            'iconPath': 'textures/sb/bf/form/chandelier',
            'description': [
                _0x21f734(0x9c8),
                '',
                'sb_bf.color_variants'
            ],
            'references': [_0x21f734(0x5ca)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x7f5), {
            'title': _0x21f734(0x70d),
            'iconPath': _0x21f734(0x9d2),
            'description': [
                _0x21f734(0x511),
                '',
                _0x21f734(0x8f6)
            ],
            'references': [_0x21f734(0x5ca)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x59c), {
            'title': _0x21f734(0x498),
            'iconPath': _0x21f734(0x9de),
            'description': [
                'sb_bf.form.sofa.description.1',
                '',
                _0x21f734(0x8f6)
            ],
            'references': [
                _0x21f734(0x477),
                _0x21f734(0x905)
            ],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x574), {
            'title': 'sb_bf.form.terracotta_vase.title',
            'iconPath': 'textures/sb/bf/form/vase',
            'description': [
                _0x21f734(0x9ee),
                '',
                _0x21f734(0x8f6)
            ],
            'references': [_0x21f734(0x898)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x685), {
            'title': _0x21f734(0x31c),
            'iconPath': _0x21f734(0xa65),
            'description': [
                _0x21f734(0x38f),
                '',
                'sb_bf.color_variants'
            ],
            'references': ['wallpaper_carpet'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x2c8), {
            'title': _0x21f734(0x9c2),
            'iconPath': _0x21f734(0x591),
            'description': [
                _0x21f734(0x2bf),
                '',
                _0x21f734(0x8f6)
            ],
            'references': [_0x21f734(0x8af)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x1c4), {
            'title': _0x21f734(0x8db),
            'iconPath': 'textures/sb/bf/form/special_glass',
            'description': [
                _0x21f734(0x2d8),
                '',
                _0x21f734(0x8f6)
            ],
            'references': ['glass'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0('special_glass_pane', {
            'title': _0x21f734(0x81e),
            'iconPath': _0x21f734(0xb65),
            'description': [
                _0x21f734(0x4c0),
                '',
                _0x21f734(0x8f6)
            ],
            'references': [_0x21f734(0xabe)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('furniture_table', {
            'title': _0x21f734(0x6e2),
            'iconPath': _0x21f734(0x2e0),
            'description': [
                _0x21f734(0x343),
                '',
                'crafting_furniture_table'
            ],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0('awning', {
            'title': _0x21f734(0x7e6),
            'iconPath': 'textures/sb/bf/form/awning',
            'description': [
                _0x21f734(0x78a),
                '',
                _0x21f734(0xaed)
            ],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0('stew', {
            'title': _0x21f734(0xba8),
            'iconPath': 'textures/sb/bf/form/rabbit_stew',
            'description': [
                _0x21f734(0x6e6),
                '',
                _0x21f734(0xaed)
            ],
            'references': [_0x21f734(0x898)]
        }),
        new _0xd980f0(_0x21f734(0x44d), {
            'title': _0x21f734(0xb14),
            'iconPath': _0x21f734(0xa08),
            'description': [
                _0x21f734(0x6c8),
                '',
                _0x21f734(0xaed)
            ],
            'references': ['stew']
        }),
        new _0xd980f0(_0x21f734(0x1a6), {
            'title': _0x21f734(0x744),
            'iconPath': _0x21f734(0x5be),
            'description': [
                _0x21f734(0x897),
                '',
                _0x21f734(0xaed)
            ],
            'references': [_0x21f734(0x7d3)]
        }),
        new _0xd980f0(_0x21f734(0x90a), {
            'title': _0x21f734(0x2a3),
            'iconPath': _0x21f734(0xa85),
            'description': [
                'sb_bf.form.beetroot_soup.description.1',
                '',
                'crafting_furniture_table'
            ],
            'references': [_0x21f734(0x7d3)]
        })
    ], _0x3e7338 = 'photobook', _0x2df68 = [
        new _0xd980f0('photobook', {
            'title': 'sb_bf.form.photobook.title',
            'description': [_0x21f734(0x92d)],
            'iconPath': ''
        }),
        new _0x2a6cb3(_0x21f734(0x295), {
            'title': 'Pig',
            'description': [_0x21f734(0x71c)],
            'lockedDescription': [_0x21f734(0x2d5)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': 'textures/sb/bf/ui/locked',
                'unlocked': 'textures/sb/bf/items/picture/pig'
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': !![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x1f1),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0x63e), {
            'title': _0x21f734(0x516),
            'description': [_0x21f734(0xbb7)],
            'lockedDescription': ['sb_bf.locked.description.creeper'],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x664)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': 'player',
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:creeper_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0xa19), {
            'title': _0x21f734(0x42b),
            'description': [_0x21f734(0x844)],
            'lockedDescription': [_0x21f734(0x422)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x40a)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x2ed),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': 'chat',
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3('warden', {
            'title': 'Warden',
            'description': [_0x21f734(0xbcc)],
            'lockedDescription': [_0x21f734(0x4f3)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x9b1)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:warden_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3(_0x21f734(0x1bd), {
            'title': _0x21f734(0xbc4),
            'description': [_0x21f734(0x235)],
            'lockedDescription': [_0x21f734(0x976)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x9a1)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x9fc),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0x1d9), {
            'title': _0x21f734(0x530),
            'description': ['sb_bf.photobook.description.enderman'],
            'lockedDescription': [_0x21f734(0x838)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x5ab)
            },
            'buttonLabel': {
                'locked': 'sb_bf.photobook.locked',
                'unlocked': 'sb_bf.photobook.unlocked'
            },
            'unlock': {
                'property': 'player',
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x2d0),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3('cat', {
            'title': _0x21f734(0xb1b),
            'description': ['sb_bf.photobook.description.cat'],
            'lockedDescription': [_0x21f734(0x60a)],
            'references': ['photobook'],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': 'textures/sb/bf/items/picture/cat'
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': 'sb_bf.photobook.unlocked'
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:cat_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3(_0x21f734(0x36d), {
            'title': _0x21f734(0xb22),
            'description': [_0x21f734(0x3c5)],
            'lockedDescription': ['sb_bf.locked.description.wolf'],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': 'textures/sb/bf/items/picture/wolf'
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x29b),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3('piglin', {
            'title': _0x21f734(0x335),
            'description': [_0x21f734(0x31f)],
            'lockedDescription': [_0x21f734(0x1be)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': 'textures/sb/bf/items/picture/piglin'
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:piglin_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': 'chat',
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0x9b2), {
            'title': 'Villager',
            'description': [_0x21f734(0x607)],
            'lockedDescription': ['sb_bf.locked.description.villager'],
            'references': ['photobook'],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x515)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:villager_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3('iron_golem', {
            'title': 'Iron\x20Golem',
            'description': [_0x21f734(0x1d3)],
            'lockedDescription': ['sb_bf.locked.description.golem'],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x595)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': 'sb_bf.photobook.unlocked'
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:iron_golem_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0x427), {
            'title': _0x21f734(0x8ec),
            'description': ['sb_bf.photobook.description.horse'],
            'lockedDescription': ['sb_bf.locked.description.horse'],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x4c7)
            },
            'buttonLabel': {
                'locked': 'sb_bf.photobook.locked',
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0xb33),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0x338), {
            'title': _0x21f734(0xb96),
            'description': [_0x21f734(0x6de)],
            'lockedDescription': [_0x21f734(0xb55)],
            'references': ['photobook'],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x39a)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': 'sb_bf.photobook.unlocked'
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:frog_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3(_0x21f734(0x22c), {
            'title': 'Chicken\x20Jockey',
            'description': [_0x21f734(0x25d)],
            'lockedDescription': [_0x21f734(0x5fe)],
            'references': ['photobook'],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x715)
            },
            'buttonLabel': {
                'locked': 'sb_bf.photobook.locked',
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': 'player',
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x2cf),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3(_0x21f734(0xc12), {
            'title': _0x21f734(0x2f1),
            'description': [_0x21f734(0x5ec)],
            'lockedDescription': [_0x21f734(0x44f)],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': 'textures/sb/bf/ui/locked',
                'unlocked': _0x21f734(0xc0f)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x3f6),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': 'random.orb'
            }
        }),
        new _0x2a6cb3('ender_dragon', {
            'title': _0x21f734(0xb46),
            'description': [_0x21f734(0xbfc)],
            'lockedDescription': ['sb_bf.locked.description.ender_dragon'],
            'references': [_0x21f734(0x4db)],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': 'textures/sb/bf/items/picture/ender_dragon'
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': 'sb_bf:ender_dragon_picture',
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': 'sb_bf.unlocked.text.message',
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0x2a6cb3(_0x21f734(0x589), {
            'title': 'Wither',
            'description': [_0x21f734(0x339)],
            'lockedDescription': ['sb_bf.locked.description.wither'],
            'references': ['photobook'],
            'iconPath': {
                'locked': _0x21f734(0xb3b),
                'unlocked': _0x21f734(0x6b2)
            },
            'buttonLabel': {
                'locked': _0x21f734(0x990),
                'unlocked': _0x21f734(0x935)
            },
            'unlock': {
                'property': _0x21f734(0x848),
                'unlockReferences': ![],
                'onlyUnlockWhenVisible': !![],
                'trigger': {
                    'hasItem': [[{
                                'id': _0x21f734(0x369),
                                'count': 0x1
                            }]]
                },
                'messages': [{
                        'text': _0x21f734(0x315),
                        'target': _0x21f734(0x5c2),
                        'private': !![]
                    }],
                'sound': _0x21f734(0x7e5)
            }
        }),
        new _0xd980f0(_0x21f734(0xa4c), {
            'title': _0x21f734(0x703),
            'iconPath': 'textures/sb/bf/form/plushie_creeper',
            'description': [_0x21f734(0x3f2)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x63e)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('creeper_statue', {
            'title': _0x21f734(0x56e),
            'iconPath': _0x21f734(0x847),
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0x891),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x63e)]
        }),
        new _0xd980f0(_0x21f734(0x623), {
            'title': _0x21f734(0x67e),
            'iconPath': _0x21f734(0x568),
            'description': ['sb_bf.form.enderman_plushie.description'],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': ['enderman'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x24d), {
            'title': 'Enderman\x20Statue',
            'iconPath': 'textures/sb/bf/form/statue_enderman',
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0xadf),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x1d9)]
        }),
        new _0xd980f0(_0x21f734(0x407), {
            'title': _0x21f734(0x478),
            'iconPath': _0x21f734(0x376),
            'description': [_0x21f734(0x6a1)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x36d)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0('wolf_statue', {
            'title': _0x21f734(0x88a),
            'iconPath': _0x21f734(0x3f7),
            'description': [
                'sb_bf.photobook.statue.info',
                '',
                _0x21f734(0x67c),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x36d)]
        }),
        new _0xd980f0('zombie_plushie', {
            'title': _0x21f734(0x8f7),
            'iconPath': 'textures/sb/bf/form/plushie_zombie',
            'description': [_0x21f734(0x754)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x1bd)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x7df), {
            'title': 'Zombie\x20Statue',
            'iconPath': _0x21f734(0x755),
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0x891),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': ['zombie']
        }),
        new _0xd980f0(_0x21f734(0x2a9), {
            'title': 'Golem\x20Statue',
            'iconPath': 'textures/sb/bf/form/statue_iron_golem',
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0x57a),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x989)]
        }),
        new _0xd980f0(_0x21f734(0x689), {
            'title': _0x21f734(0x2a2),
            'iconPath': _0x21f734(0x8e8),
            'description': [
                'sb_bf.photobook.statue.info',
                '',
                _0x21f734(0x57a),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x427)]
        }),
        new _0xd980f0(_0x21f734(0x201), {
            'title': _0x21f734(0x609),
            'iconPath': _0x21f734(0xa5f),
            'description': [_0x21f734(0xac9)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x9b2)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x3e8), {
            'title': _0x21f734(0x546),
            'iconPath': _0x21f734(0x3b3),
            'description': [
                'sb_bf.photobook.statue.info',
                '',
                _0x21f734(0x891),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x9b2)]
        }),
        new _0xd980f0(_0x21f734(0x956), {
            'title': _0x21f734(0x76d),
            'iconPath': _0x21f734(0x921),
            'description': ['sb_bf.form.dolphin_plushie.description'],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': ['dolphin'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x811), {
            'title': 'Dolphin\x20Statue',
            'iconPath': _0x21f734(0xb52),
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0x891),
                '',
                'sb_bf.photobook.statue.info.chisel'
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0xa19)]
        }),
        new _0xd980f0(_0x21f734(0x7ff), {
            'title': _0x21f734(0xb99),
            'iconPath': 'textures/sb/bf/form/statue_chicken_jockey',
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0x891),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x22c)]
        }),
        new _0xd980f0(_0x21f734(0x5a3), {
            'title': _0x21f734(0x81d),
            'iconPath': 'textures/sb/bf/form/statue_frog',
            'description': [
                _0x21f734(0x59d),
                '',
                _0x21f734(0x67c),
                '',
                _0x21f734(0xa8f)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x338)]
        }),
        new _0xd980f0('piglin_plushie', {
            'title': _0x21f734(0x1dc),
            'iconPath': _0x21f734(0xae8),
            'description': [_0x21f734(0x940)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0xc04)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x763), {
            'title': 'tile.sb_bf:cat_plushie.name',
            'iconPath': _0x21f734(0x615),
            'description': [_0x21f734(0xa8b)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x82c)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x31a), {
            'title': 'tile.sb_bf:warden_plushie.name',
            'iconPath': _0x21f734(0x780),
            'description': [_0x21f734(0x960)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x2e4)],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': _0x21f734(0x353)
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x999), {
            'title': _0x21f734(0x4c9),
            'iconPath': _0x21f734(0x694),
            'description': [_0x21f734(0x493)],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': ['pig'],
            'wikiInfo': {
                'hasCustomTableRecipe': {
                    'recipe': !![],
                    'blockID': 'sb_bf:furniture_table'
                }
            }
        }),
        new _0xd980f0(_0x21f734(0x481), {
            'title': _0x21f734(0x1d2),
            'iconPath': _0x21f734(0x371),
            'description': [
                _0x21f734(0x3b8),
                '',
                'sb_bf.form.painting.description'
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': ['warden']
        }),
        new _0xd980f0(_0x21f734(0x7ba), {
            'title': _0x21f734(0x6be),
            'iconPath': 'textures/sb/bf/items/painting/ender_dragon',
            'description': [
                _0x21f734(0x8b3),
                '',
                _0x21f734(0xa1c)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0xa44)]
        }),
        new _0xd980f0(_0x21f734(0xafc), {
            'title': _0x21f734(0x757),
            'iconPath': 'textures/sb/bf/items/painting/creaking',
            'description': [
                _0x21f734(0x538),
                '',
                _0x21f734(0xa1c)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0xc12)]
        }),
        new _0xd980f0(_0x21f734(0xc07), {
            'title': _0x21f734(0x4bd),
            'iconPath': _0x21f734(0xa62),
            'description': [
                _0x21f734(0xbec),
                '',
                _0x21f734(0xa1c)
            ],
            'showOnlyWhenReferencesUnlocked': !![],
            'references': [_0x21f734(0x589)]
        })
    ], _0x6911b3 = [
        {
            'forms': _0x48ca60,
            'trigger': _0x21f734(0xb7a),
            'mainForm': _0x59d38b
        },
        {
            'forms': _0x2df68,
            'trigger': 'sb_bf:photobook',
            'mainForm': _0x3e7338
        }
    ], _0xbfef7b = _0x207994 + _0x21f734(0x7bc), _0x16ec4f = class extends _0x2e442a {
        constructor() {
            const _0xa23bc6 = _0x21f734, _0x60d70b = {
                    'rUitN': function (_0x181d7b, _0x560eb5) {
                        return _0x181d7b > _0x560eb5;
                    },
                    'XdxIH': function (_0x4ff719, _0x4a6807) {
                        return _0x4ff719 === _0x4a6807;
                    },
                    'BewPy': _0xa23bc6(0x701),
                    'vLocM': _0xa23bc6(0x848),
                    'QqCti': function (_0x2206e1, _0x273232) {
                        return _0x2206e1 === _0x273232;
                    },
                    'VDisR': function (_0x254322) {
                        return _0x254322();
                    },
                    'IBgFr': function (_0x3ff538, _0x466a78) {
                        return _0x3ff538(_0x466a78);
                    },
                    'FCadw': function (_0x170b0a, _0x417479) {
                        return _0x170b0a > _0x417479;
                    },
                    'ceGHF': _0xa23bc6(0x23c),
                    'IHJxF': function (_0x4f8da2, _0xd4082e, _0x52361a, _0x3a069c) {
                        return _0x4f8da2(_0xd4082e, _0x52361a, _0x3a069c);
                    },
                    'JjgyF': _0xa23bc6(0xb20),
                    'vOhpg': function (_0x534894, _0x1b1c84, _0x3b9ffd, _0x1bc320) {
                        return _0x534894(_0x1b1c84, _0x3b9ffd, _0x1bc320);
                    },
                    'zZGBm': _0xa23bc6(0x3f4),
                    'MuCuY': function (_0x2203ca, _0xf77602, _0x14ec88, _0x26cc9e) {
                        return _0x2203ca(_0xf77602, _0x14ec88, _0x26cc9e);
                    },
                    'PDqjq': _0xa23bc6(0x6cd),
                    'WNxoL': function (_0x4a063e, _0x4f6ed5, _0x24dd00, _0x3b1d18) {
                        return _0x4a063e(_0x4f6ed5, _0x24dd00, _0x3b1d18);
                    },
                    'ftQfn': _0xa23bc6(0x81c),
                    'dpUbH': function (_0x5e3549, _0x30c3ed, _0x3de3a1, _0xf9e06d) {
                        return _0x5e3549(_0x30c3ed, _0x3de3a1, _0xf9e06d);
                    },
                    'vgFGo': _0xa23bc6(0xc0e),
                    'lwxUs': function (_0x7a2ba8, _0x5e43b7, _0x487b86, _0x48be2b) {
                        return _0x7a2ba8(_0x5e43b7, _0x487b86, _0x48be2b);
                    },
                    'kZMyy': _0xa23bc6(0xb73),
                    'FSler': _0xa23bc6(0x927),
                    'yKICe': 'blockInteractForms',
                    'KROVD': function (_0x3794a6, _0x56b924, _0x1449c6, _0x13f5f0) {
                        return _0x3794a6(_0x56b924, _0x1449c6, _0x13f5f0);
                    },
                    'QXsQJ': _0xa23bc6(0x2bc),
                    'ISSOn': _0xa23bc6(0x33b)
                };
            super(_0x60d70b[_0xa23bc6(0x83b)]), _0x60d70b['IHJxF'](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0xa38)], new Map()), _0x60d70b['vOhpg'](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0x75e)], new Map()), _0x60d70b[_0xa23bc6(0xb94)](_0x25e7d0, this, _0xa23bc6(0x3db), new Map()), _0x60d70b[_0xa23bc6(0x628)](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0x225)], new Map()), _0x60d70b[_0xa23bc6(0x5b6)](_0x25e7d0, this, _0xa23bc6(0x9f5), []), _0x25e7d0(this, _0x60d70b[_0xa23bc6(0x6a9)], new Map()), _0x60d70b[_0xa23bc6(0x92f)](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0xa73)], ![]), _0x60d70b[_0xa23bc6(0x628)](_0x25e7d0, this, _0xa23bc6(0x3fb), []), _0x60d70b['lwxUs'](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0x246)], []), _0x60d70b['WNxoL'](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0x617)], []), _0x25e7d0(this, _0x60d70b['yKICe'], []), _0x60d70b[_0xa23bc6(0xc14)](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0x95e)], []), _0x60d70b[_0xa23bc6(0xc14)](_0x25e7d0, this, 'useItemForms', []), _0x60d70b[_0xa23bc6(0x92f)](_0x25e7d0, this, _0x60d70b[_0xa23bc6(0xa0f)], _0x49c0b5 => {
                const _0x38cf01 = _0xa23bc6, _0x58af8c = _0x49c0b5[_0x38cf01(0x8eb)], _0x2fc023 = _0x49c0b5[_0x38cf01(0xc1d)][_0x38cf01(0x1b9)], _0x51ae67 = this[_0x38cf01(0x1ad)]['filter'](({form: _0x5a659f}) => _0x5a659f[_0x38cf01(0x8e7)][_0x38cf01(0xa88)]?.[_0x38cf01(0x99f)] !== void 0x0)['sort']((_0x4e810a, _0x40634e) => (_0x4e810a[_0x38cf01(0xa7c)][_0x38cf01(0x8e7)]['unlock']?.[_0x38cf01(0x99f)] || 0x0) - (_0x40634e[_0x38cf01(0xa7c)][_0x38cf01(0x8e7)]['unlock']?.[_0x38cf01(0x99f)] || 0x0));
                if (_0x60d70b[_0x38cf01(0x3b5)](_0x51ae67[_0x38cf01(0x51f)], 0x0))
                    for (const {
                                form: _0xe36a36,
                                items: _0x12217d
                            } of _0x51ae67) {
                        const _0x56f4d9 = _0x60d70b[_0x38cf01(0xa52)](_0xe36a36['options']['unlock']?.['property'], _0x38cf01(0x701)) ? _0x60d70b[_0x38cf01(0x4a3)] : _0x60d70b[_0x38cf01(0x32d)], _0x5d9e64 = _0x60d70b[_0x38cf01(0xb02)](_0x56f4d9, 'world') ? _0x60d70b[_0x38cf01(0x5f4)](_0x160d53) : _0x60d70b['IBgFr'](_0x144c82, _0x58af8c);
                        if (!_0x5d9e64[_0x38cf01(0x1b2)](_0xe36a36['id'])) {
                            const _0x53c316 = _0x12217d[_0x38cf01(0x65e)](_0x3db403 => _0x3db403['id'] === _0x2fc023);
                            if (_0x53c316) {
                                _0x53c316[_0x38cf01(0xbf0)] && _0x2c8ecf(_0x58af8c, _0x2fc023);
                                this[_0x38cf01(0x74d)](_0xe36a36, _0x58af8c);
                                return;
                            }
                        }
                    }
                if (this[_0x38cf01(0x3db)]['has'](_0x2fc023)) {
                    const _0x1b580f = _0x58af8c['getEntitiesFromViewDirection']({ 'maxDistance': 0x6 });
                    for (const _0x463883 of _0x1b580f) {
                        const _0xfc5a4 = this[_0x38cf01(0x40b)](_0x463883[_0x38cf01(0xa27)][_0x38cf01(0x1b9)], _0x2fc023);
                        if (_0xfc5a4) {
                            this[_0x38cf01(0x282)](_0x58af8c, _0xfc5a4['id'], ![], !![]);
                            return;
                        }
                    }
                    const _0x27f958 = _0x58af8c['getBlockFromViewDirection']({ 'maxDistance': 0x6 });
                    if (_0x27f958) {
                        const _0x1ee76e = this['getInteractionForBlock'](_0x27f958[_0x38cf01(0x87b)][_0x38cf01(0x1b9)], _0x2fc023);
                        if (_0x1ee76e) {
                            this[_0x38cf01(0x282)](_0x58af8c, _0x1ee76e['id'], ![], !![]);
                            return;
                        }
                    }
                    const _0x40a542 = this[_0x38cf01(0x3db)][_0x38cf01(0x3c7)](_0x2fc023);
                    if (_0x40a542 && _0x60d70b['FCadw'](_0x40a542[_0x38cf01(0x51f)], 0x0)) {
                        const _0x336355 = this[_0x38cf01(0x81c)]['get'](_0x2fc023);
                        if (_0x336355)
                            this['showForm'](_0x58af8c, _0x336355, !![]);
                        else
                            _0x40a542[_0x38cf01(0x51f)] === 0x1 ? this[_0x38cf01(0x282)](_0x58af8c, _0x40a542[0x0], !![]) : this[_0x38cf01(0x3f0)](_0x58af8c, _0x40a542, !![]);
                    }
                }
            }), this[_0xa23bc6(0x4cd)]();
        }
        ['onInitialize']() {
            const _0x287da4 = _0x21f734, _0x5da085 = {
                    'VnZAE': function (_0x89ef7e, _0x20bbd1) {
                        return _0x89ef7e == _0x20bbd1;
                    }
                };
            _0x3e82c5[_0x287da4(0x327)][_0x287da4(0x71a)]['subscribe'](this[_0x287da4(0x33b)]), _0x154163[_0x287da4(0x770)](() => {
                const _0x1e0419 = _0x287da4;
                _0x3e82c5['getPlayers']()[_0x1e0419(0x3e1)](_0x24ee56 => this['triggerFormFromInventory'](_0x24ee56));
            }, 0x5), _0x154163['afterEvents'][_0x287da4(0x306)][_0x287da4(0x725)](_0xe2cf6c => {
                const _0x1538f1 = _0x287da4;
                if (_0x5da085[_0x1538f1(0xb48)](_0xe2cf6c['id'], _0x207994 + _0x1538f1(0x634))) {
                    const _0x537bf1 = _0x3e82c5[_0x1538f1(0x8fa)]();
                    for (const _0x5f27c4 of _0x537bf1) {
                        _0x5f27c4[_0x1538f1(0xbf1)](_0xbfef7b) && _0x3e82c5[_0x1538f1(0x483)](_0x5f27c4, ![]);
                    }
                    _0x3e82c5['getPlayers']()[_0x1538f1(0x3e1)](_0x12845f => {
                        const _0x6b8197 = _0x1538f1, _0x59246c = _0x12845f[_0x6b8197(0x8fa)]();
                        for (const _0xcf619f of _0x59246c) {
                            _0xcf619f[_0x6b8197(0xbf1)](_0xbfef7b) && _0x12845f['setDynamicProperty'](_0xcf619f, ![]);
                        }
                    });
                }
                this[_0x1538f1(0x3ac)](_0xe2cf6c['id'], _0xe2cf6c[_0x1538f1(0x4e0)]);
            }), this[_0x287da4(0x888)]();
        }
        ['handleScriptEventTrigger'](_0x5412d2, _0x2f93af) {
            const _0x1bbba7 = _0x21f734, _0x3b61b6 = {
                    'Puout': function (_0x40206d, _0x2a0f19) {
                        return _0x40206d === _0x2a0f19;
                    },
                    'jgrGT': _0x1bbba7(0x701),
                    'NzDiJ': function (_0x1da2fd) {
                        return _0x1da2fd();
                    },
                    'tHToh': function (_0x1414f1, _0x293c79) {
                        return _0x1414f1(_0x293c79);
                    },
                    'CtxzS': function (_0x5f4899, _0x1c6ffb) {
                        return _0x5f4899(_0x1c6ffb);
                    },
                    'TCJoB': function (_0xcfca1b, _0x4b231d, _0x3b128b) {
                        return _0xcfca1b(_0x4b231d, _0x3b128b);
                    },
                    'rzSjH': function (_0x415199, _0x4266dd) {
                        return _0x415199 === _0x4266dd;
                    },
                    'HVgbV': function (_0x2a8433, _0x5d73ab) {
                        return _0x2a8433 > _0x5d73ab;
                    },
                    'eFQge': function (_0x55d192, _0x2d4bd9) {
                        return _0x55d192 === _0x2d4bd9;
                    },
                    'OGxCT': 'number',
                    'vzvIc': function (_0x44a147, _0x268197) {
                        return _0x44a147 === _0x268197;
                    }
                };
            this['actionForms'][_0x1bbba7(0x3e1)](_0x316b84 => {
                const _0x326c99 = _0x1bbba7, _0x338bc0 = _0x316b84[_0x326c99(0x8e7)][_0x326c99(0xa88)];
                if (_0x338bc0?.[_0x326c99(0xae4)]['scriptEvent']) {
                    const {
                        id: _0x2e368a,
                        message: _0xde952e
                    } = _0x338bc0['trigger'][_0x326c99(0xc0a)];
                    if (_0x3b61b6[_0x326c99(0x3bc)](_0x2e368a, _0x5412d2) && (!_0xde952e || _0x3b61b6['vzvIc'](_0xde952e, _0x2f93af))) {
                        const _0x47d75a = _0x3b61b6[_0x326c99(0x3bc)](_0x338bc0[_0x326c99(0x1e9)], _0x3b61b6[_0x326c99(0xaae)]) ? _0x3b61b6[_0x326c99(0xaae)] : 'player';
                        _0x3e82c5[_0x326c99(0x239)]()['forEach'](_0x146bce => {
                            const _0x18b77f = _0x326c99;
                            let _0x2a81f6 = _0x3b61b6['Puout'](_0x47d75a, _0x3b61b6[_0x18b77f(0xaae)]) ? _0x3b61b6[_0x18b77f(0x8bf)](_0x160d53) : _0x3b61b6[_0x18b77f(0xb41)](_0x144c82, _0x146bce);
                            if (!_0x2a81f6[_0x18b77f(0x1b2)](_0x316b84['id'])) {
                                _0x2a81f6[_0x18b77f(0x65f)](_0x316b84['id']);
                                _0x3b61b6[_0x18b77f(0x79a)](_0x47d75a, _0x3b61b6[_0x18b77f(0xaae)]) ? _0x3b61b6['CtxzS'](_0xe08d9d, _0x2a81f6) : _0x3b61b6[_0x18b77f(0x955)](_0x504be6, _0x146bce, _0x2a81f6);
                                _0x338bc0[_0x18b77f(0x758)] && _0x146bce['playSound'](_0x338bc0[_0x18b77f(0x758)]);
                                _0x338bc0[_0x18b77f(0x8ce)] && this[_0x18b77f(0xaf7)](_0x338bc0[_0x18b77f(0x8ce)], _0x146bce);
                                const _0x484579 = _0x338bc0[_0x18b77f(0x834)];
                                if (_0x3b61b6[_0x18b77f(0x3bc)](_0x47d75a, _0x3b61b6[_0x18b77f(0xaae)])) {
                                    _0xe08d9d(_0x2a81f6);
                                    const _0x4e2371 = _0x3e82c5['getAllPlayers']();
                                    if (_0x484579) {
                                        if (typeof _0x484579['xp'] === _0x18b77f(0x4c4) && _0x3b61b6[_0x18b77f(0x27b)](_0x484579['xp'], 0x0))
                                            for (const _0x5d0413 of _0x4e2371) {
                                                _0x5d0413[_0x18b77f(0x3fd)](_0x484579['xp']);
                                            }
                                        if (_0x484579[_0x18b77f(0x4e4)] && Array['isArray'](_0x484579['items']))
                                            for (const _0x21ab0c of _0x4e2371) {
                                                for (const _0x2e8353 of _0x484579[_0x18b77f(0x4e4)]) {
                                                    _0x467466(_0x21ab0c, new _0x565fb3(_0x2e8353['id'], _0x2e8353[_0x18b77f(0x2fe)]));
                                                }
                                            }
                                    }
                                } else {
                                    if (_0x484579) {
                                        _0x3b61b6[_0x18b77f(0x55d)](typeof _0x484579['xp'], _0x3b61b6['OGxCT']) && _0x3b61b6[_0x18b77f(0x27b)](_0x484579['xp'], 0x0) && _0x146bce['addLevels'](_0x484579['xp']);
                                        if (_0x484579[_0x18b77f(0x4e4)] && Array[_0x18b77f(0x2b1)](_0x484579[_0x18b77f(0x4e4)]))
                                            for (const _0x1e812e of _0x484579[_0x18b77f(0x4e4)]) {
                                                _0x467466(_0x146bce, new _0x565fb3(_0x1e812e['id'], _0x1e812e[_0x18b77f(0x2fe)]));
                                            }
                                    }
                                }
                            }
                        });
                    }
                }
            });
        }
        [_0x21f734(0x40b)](_0x246687, _0x504dde) {
            const _0x47513c = _0x21f734;
            for (const _0x3ca568 of this[_0x47513c(0xb20)][_0x47513c(0x90f)]()) {
                if (_0x3ca568[_0x47513c(0x8e7)][_0x47513c(0x4f0)]?.[_0x47513c(0x2a4)]?.[_0x47513c(0x620)](_0x246687))
                    return _0x3ca568;
            }
            for (const _0x453cfa of this['modalForms'][_0x47513c(0x90f)]()) {
                if (_0x453cfa[_0x47513c(0x8e7)]['interact']?.[_0x47513c(0x2a4)]?.[_0x47513c(0x620)](_0x246687))
                    return _0x453cfa;
            }
            return null;
        }
        ['getUnlockedForms']() {
            const _0x4f4d3f = _0x21f734, _0x6151d5 = _0x3e82c5['getDynamicProperty'](_0xbfef7b) || '[]';
            return new Set(JSON[_0x4f4d3f(0x438)](_0x6151d5));
        }
        ['setUnlockedForms'](_0x4d212a) {
            const _0x1ea983 = _0x21f734;
            _0x3e82c5[_0x1ea983(0x483)](_0xbfef7b, JSON[_0x1ea983(0x464)](Array[_0x1ea983(0x939)](_0x4d212a)));
        }
        [_0x21f734(0xaf7)](_0x947bc8, _0x5085ad) {
            const _0x382799 = _0x21f734, _0x1a4c04 = {
                    'KZWsS': function (_0x510b81, _0x5866ab) {
                        return _0x510b81 === _0x5866ab;
                    },
                    'LQpGF': _0x382799(0x4f4),
                    'BGpUC': function (_0x2bac1e, _0x2760e4) {
                        return _0x2bac1e === _0x2760e4;
                    },
                    'TnUqU': _0x382799(0x9be),
                    'omogv': _0x382799(0x67b),
                    'rhCOs': function (_0x23acfa, _0x329a16, _0x4ec6f0, _0x1bf1bf) {
                        return _0x23acfa(_0x329a16, _0x4ec6f0, _0x1bf1bf);
                    }
                };
            _0x947bc8[_0x382799(0x3e1)](_0xf09112 => {
                const _0x11f08e = _0x382799;
                if (_0xf09112['target'] === _0x11f08e(0x5c2))
                    _0xf09112[_0x11f08e(0x555)] ? _0x5085ad[_0x11f08e(0x7b1)]({
                        'translate': _0xf09112['text'],
                        'with': [_0x5085ad[_0x11f08e(0x497)]]
                    }) : _0x3e82c5[_0x11f08e(0x7b1)]({
                        'translate': _0xf09112[_0x11f08e(0x4a1)],
                        'with': [_0x5085ad[_0x11f08e(0x497)]]
                    });
                else {
                    if (_0x1a4c04['KZWsS'](_0xf09112[_0x11f08e(0x6ce)], _0x1a4c04[_0x11f08e(0x6b6)]))
                        _0xf09112[_0x11f08e(0x555)] ? _0x5085ad[_0x11f08e(0x3a7)][_0x11f08e(0xa63)]({
                            'translate': _0xf09112[_0x11f08e(0x4a1)],
                            'with': [_0x5085ad['name']]
                        }) : _0x3e82c5[_0x11f08e(0x2ce)]()['forEach'](_0xe00428 => {
                            const _0x907370 = _0x11f08e;
                            _0xe00428[_0x907370(0x3a7)][_0x907370(0xa63)]({
                                'translate': _0xf09112[_0x907370(0x4a1)],
                                'with': [_0x5085ad['name']]
                            });
                        });
                    else {
                        if (_0x1a4c04[_0x11f08e(0x3b6)](_0xf09112[_0x11f08e(0x6ce)], _0x11f08e(0x7a6)))
                            _0xf09112[_0x11f08e(0x555)] ? _0x5085ad['onScreenDisplay'][_0x11f08e(0xa0b)]({
                                'translate': _0xf09112[_0x11f08e(0x4a1)],
                                'with': [_0x5085ad[_0x11f08e(0x497)]]
                            }) : _0x3e82c5['getAllPlayers']()['forEach'](_0x35daf4 => {
                                const _0x1f21c8 = _0x11f08e;
                                _0x35daf4[_0x1f21c8(0x3a7)][_0x1f21c8(0xa0b)]({
                                    'translate': _0xf09112[_0x1f21c8(0x4a1)],
                                    'with': [_0x5085ad[_0x1f21c8(0x497)]]
                                });
                            });
                        else {
                            if (_0x1a4c04[_0x11f08e(0x3b6)](_0xf09112[_0x11f08e(0x6ce)], _0x1a4c04[_0x11f08e(0x8a2)])) {
                                let _0x8ac9d5 = [
                                    _0xf09112[_0x11f08e(0x73e)] ? {
                                        'rawtext': [
                                            { 'translate': _0xf09112['toastTitle'] },
                                            { 'text': _0x1a4c04[_0x11f08e(0x3dc)] }
                                        ]
                                    } : '',
                                    { 'rawtext': [{ 'translate': _0xf09112['text'] }] }
                                ];
                                _0xf09112[_0x11f08e(0x555)] && _0x1a4c04[_0x11f08e(0x40d)](_0x269639, _0x5085ad, _0x8ac9d5, _0xf09112['toastTexture'] ? _0xf09112[_0x11f08e(0x65b)] : '');
                            }
                        }
                    }
                }
            });
        }
        [_0x21f734(0x29c)](_0x1aaa9b, _0x2b0dca) {
            const _0x3b9301 = _0x21f734, _0x483783 = {
                    'usMEm': function (_0x5e6fbe, _0x38e2c2) {
                        return _0x5e6fbe < _0x38e2c2;
                    },
                    'aNaXo': function (_0x51fe8f, _0x3978f0) {
                        return _0x51fe8f >= _0x3978f0;
                    }
                }, _0x1ea71c = _0x1aaa9b['getComponent']('inventory'), _0x27b0e2 = _0x1ea71c[_0x3b9301(0xa39)];
            return _0x2b0dca['every'](_0x340af9 => {
                const _0x6df472 = _0x3b9301;
                let _0x210243 = 0x0;
                for (let _0x55a5f7 = 0x0; _0x483783[_0x6df472(0x242)](_0x55a5f7, _0x27b0e2[_0x6df472(0x87e)]); _0x55a5f7++) {
                    const _0x3d6bed = _0x27b0e2[_0x6df472(0x5cb)](_0x55a5f7);
                    if (_0x3d6bed && _0x3d6bed['typeId'] === _0x340af9['id']) {
                        _0x210243 += _0x3d6bed[_0x6df472(0x5c5)];
                        if (_0x483783[_0x6df472(0xb08)](_0x210243, _0x340af9[_0x6df472(0x2fe)] || 0x1))
                            return !![];
                    }
                }
                return ![];
            });
        }
        [_0x21f734(0xab8)](_0x47240b, _0x3a489a) {
            const _0x5d38f7 = _0x21f734, _0x3c7d48 = {
                    'oWcBF': function (_0x412939, _0x18d5b1) {
                        return _0x412939 === _0x18d5b1;
                    },
                    'mvQmM': _0x5d38f7(0x701),
                    'xBvFG': 'player',
                    'sLvTg': function (_0x2c0da4, _0x23f69c) {
                        return _0x2c0da4 === _0x23f69c;
                    },
                    'QtVni': function (_0x18d90a) {
                        return _0x18d90a();
                    },
                    'ZvtxC': function (_0x428f1d, _0x5ace4f) {
                        return _0x428f1d(_0x5ace4f);
                    },
                    'IiibW': function (_0x4f477e, _0xe57852) {
                        return _0x4f477e < _0xe57852;
                    },
                    'BMMyK': function (_0x126e41, _0x3f870f, _0x2c8639) {
                        return _0x126e41(_0x3f870f, _0x2c8639);
                    },
                    'qHdll': function (_0xab3c16, _0x438eb8) {
                        return _0xab3c16 === _0x438eb8;
                    },
                    'MwJBP': function (_0x596726, _0x57aa0c) {
                        return _0x596726 === _0x57aa0c;
                    },
                    'mgVJG': function (_0x4d6f21, _0x3e85c6) {
                        return _0x4d6f21 in _0x3e85c6;
                    },
                    'aCDDw': function (_0x31e783, _0x222e12) {
                        return _0x31e783 || _0x222e12;
                    },
                    'CLsTc': function (_0x1fdddb, _0x22a616) {
                        return _0x1fdddb === _0x22a616;
                    },
                    'PYisX': function (_0x138d93, _0x3be270) {
                        return _0x138d93(_0x3be270);
                    },
                    'uHwJF': function (_0x9dddd3, _0x3151d8) {
                        return _0x9dddd3 === _0x3151d8;
                    },
                    'tHnjN': function (_0xf3d730) {
                        return _0xf3d730();
                    },
                    'XPnYB': function (_0x379640, _0x24a547) {
                        return _0x379640(_0x24a547);
                    },
                    'WHAQA': function (_0x23198b, _0x51c629, _0x3f1ee2) {
                        return _0x23198b(_0x51c629, _0x3f1ee2);
                    },
                    'EacSZ': function (_0x191cdb, _0x24a4df) {
                        return _0x191cdb === _0x24a4df;
                    },
                    'bWIbn': _0x5d38f7(0x4c4),
                    'IajWc': function (_0x15f025, _0x497393) {
                        return _0x15f025 > _0x497393;
                    }
                };
            for (const _0x1b1306 of this[_0x5d38f7(0xb20)][_0x5d38f7(0x90f)]()) {
                const _0x439280 = _0x1b1306[_0x5d38f7(0x8e7)][_0x5d38f7(0xa88)];
                if (!_0x439280)
                    continue;
                if (_0x439280[_0x5d38f7(0xa5e)] && _0x1b1306[_0x5d38f7(0x8e7)][_0x5d38f7(0x6cd)]) {
                    let _0x2d7cc8 = ![];
                    for (const _0x899049 of _0x1b1306[_0x5d38f7(0x8e7)][_0x5d38f7(0x6cd)]) {
                        const _0x45fa58 = this[_0x5d38f7(0xb20)][_0x5d38f7(0x3c7)](_0x899049) || this['modalForms'][_0x5d38f7(0x3c7)](_0x899049);
                        if (!_0x45fa58)
                            continue;
                        if (!_0x45fa58[_0x5d38f7(0x8e7)][_0x5d38f7(0xa88)]) {
                            _0x2d7cc8 = !![];
                            break;
                        }
                        const _0x1bc049 = _0x3c7d48[_0x5d38f7(0x58b)](_0x439280[_0x5d38f7(0x1e9)], _0x3c7d48[_0x5d38f7(0x50c)]) ? _0x3c7d48[_0x5d38f7(0x50c)] : _0x3c7d48[_0x5d38f7(0x5b0)];
                        let _0x504008 = _0x3c7d48[_0x5d38f7(0x587)](_0x1bc049, 'world') ? _0x3c7d48[_0x5d38f7(0xc1b)](_0x160d53) : _0x144c82(_0x47240b);
                        if (_0x504008[_0x5d38f7(0x1b2)](_0x899049)) {
                            _0x2d7cc8 = !![];
                            break;
                        }
                    }
                    if (!_0x2d7cc8)
                        return;
                }
                const _0x2375c4 = _0x3c7d48[_0x5d38f7(0x9a9)](_0x5d38f7(0xa4b), _0x439280[_0x5d38f7(0xae4)]) && _0x439280[_0x5d38f7(0xae4)][_0x5d38f7(0xa4b)] === _0x3a489a, _0x1b1f68 = _0x439280[_0x5d38f7(0xae4)][_0x5d38f7(0x7cc)]?.[_0x5d38f7(0x88d)](_0x555873 => this[_0x5d38f7(0x29c)](_0x47240b, _0x555873)), _0x3fa0c2 = _0x439280[_0x5d38f7(0xae4)][_0x5d38f7(0x7ec)]?.[_0x5d38f7(0x88d)](_0x50f2da => {
                        const _0x1d0a4a = _0x5d38f7, _0xbc49ac = _0x3c7d48[_0x1d0a4a(0x9af)](_0x439280[_0x1d0a4a(0x1e9)], _0x3c7d48[_0x1d0a4a(0x50c)]) ? _0x3c7d48[_0x1d0a4a(0x50c)] : _0x3c7d48[_0x1d0a4a(0x5b0)], _0x6dae3d = _0x3c7d48['sLvTg'](_0xbc49ac, _0x3c7d48['mvQmM']) ? _0x3c7d48[_0x1d0a4a(0xc1b)](_0x160d53) : _0x3c7d48['ZvtxC'](_0x144c82, _0x47240b);
                        return _0x6dae3d[_0x1d0a4a(0x1b2)](_0x50f2da);
                    });
                if (_0x3c7d48[_0x5d38f7(0x495)](_0x2375c4, _0x1b1f68) || _0x3fa0c2) {
                    const _0x31c011 = _0x3c7d48['CLsTc'](_0x439280[_0x5d38f7(0x1e9)], 'world') ? _0x3c7d48[_0x5d38f7(0x50c)] : _0x3c7d48[_0x5d38f7(0x5b0)];
                    let _0x2edcad = _0x31c011 === _0x3c7d48[_0x5d38f7(0x50c)] ? _0x160d53() : _0x3c7d48[_0x5d38f7(0x2aa)](_0x144c82, _0x47240b);
                    if (!_0x2edcad[_0x5d38f7(0x1b2)](_0x1b1306['id'])) {
                        if (_0x439280[_0x5d38f7(0xa5e)] && _0x1b1306[_0x5d38f7(0x8e7)][_0x5d38f7(0x6cd)]) {
                            let _0x564b8a = ![];
                            for (const _0x2a4677 of _0x1b1306[_0x5d38f7(0x8e7)][_0x5d38f7(0x6cd)]) {
                                const _0x5eb228 = _0x3c7d48['uHwJF'](_0x439280[_0x5d38f7(0x1e9)], _0x3c7d48[_0x5d38f7(0x50c)]) ? _0x3c7d48[_0x5d38f7(0x50c)] : 'player';
                                let _0x264461 = _0x5eb228 === _0x3c7d48[_0x5d38f7(0x50c)] ? _0x3c7d48['tHnjN'](_0x160d53) : _0x3c7d48[_0x5d38f7(0x828)](_0x144c82, _0x47240b);
                                if (_0x264461[_0x5d38f7(0x1b2)](_0x2a4677)) {
                                    _0x564b8a = !![];
                                    break;
                                }
                            }
                            if (!_0x564b8a)
                                continue;
                        }
                        _0x2edcad['add'](_0x1b1306['id']);
                        _0x31c011 === _0x3c7d48[_0x5d38f7(0x50c)] ? _0x3c7d48[_0x5d38f7(0x4cb)](_0xe08d9d, _0x2edcad) : _0x3c7d48[_0x5d38f7(0x226)](_0x504be6, _0x47240b, _0x2edcad);
                        _0x439280[_0x5d38f7(0x758)] && _0x47240b['playSound'](_0x439280[_0x5d38f7(0x758)]);
                        _0x439280['messages'] && this[_0x5d38f7(0xaf7)](_0x439280[_0x5d38f7(0x8ce)], _0x47240b);
                        if (_0x1b1f68) {
                            const _0x46291c = _0x439280[_0x5d38f7(0xae4)][_0x5d38f7(0x7cc)]?.[_0x5d38f7(0x65e)](_0x26daf2 => this[_0x5d38f7(0x29c)](_0x47240b, _0x26daf2));
                            _0x46291c && _0x46291c[_0x5d38f7(0x3e1)](_0x356177 => {
                                const _0x4c8fc8 = _0x5d38f7;
                                if (_0x356177[_0x4c8fc8(0xbf0)] === !![])
                                    for (let _0x1829cc = 0x0; _0x3c7d48[_0x4c8fc8(0x298)](_0x1829cc, _0x356177[_0x4c8fc8(0x2fe)] || 0x1); _0x1829cc++) {
                                        _0x3c7d48[_0x4c8fc8(0x55e)](_0x2c8ecf, _0x47240b, _0x356177['id']);
                                    }
                            });
                        }
                        const _0x8c7b74 = _0x439280[_0x5d38f7(0x834)];
                        if (_0x3c7d48[_0x5d38f7(0x587)](_0x31c011, _0x3c7d48[_0x5d38f7(0x50c)])) {
                            _0xe08d9d(_0x2edcad);
                            const _0x6cd407 = _0x3e82c5[_0x5d38f7(0x2ce)]();
                            if (_0x8c7b74) {
                                if (_0x3c7d48[_0x5d38f7(0xa35)](typeof _0x8c7b74['xp'], _0x3c7d48[_0x5d38f7(0x2d7)]) && _0x3c7d48[_0x5d38f7(0x64e)](_0x8c7b74['xp'], 0x0))
                                    for (const _0x305baa of _0x6cd407) {
                                        _0x305baa[_0x5d38f7(0x3fd)](_0x8c7b74['xp']);
                                    }
                                if (_0x8c7b74[_0x5d38f7(0x4e4)] && Array[_0x5d38f7(0x2b1)](_0x8c7b74[_0x5d38f7(0x4e4)]))
                                    for (const _0x417dd2 of _0x6cd407) {
                                        for (const _0x246bd2 of _0x8c7b74['items']) {
                                            _0x3c7d48[_0x5d38f7(0x55e)](_0x467466, _0x417dd2, new _0x565fb3(_0x246bd2['id'], _0x246bd2['count']));
                                        }
                                    }
                            }
                        } else {
                            if (_0x8c7b74) {
                                _0x3c7d48['MwJBP'](typeof _0x8c7b74['xp'], _0x5d38f7(0x4c4)) && _0x3c7d48[_0x5d38f7(0x64e)](_0x8c7b74['xp'], 0x0) && _0x47240b[_0x5d38f7(0x3fd)](_0x8c7b74['xp']);
                                if (_0x8c7b74[_0x5d38f7(0x4e4)] && Array[_0x5d38f7(0x2b1)](_0x8c7b74[_0x5d38f7(0x4e4)]))
                                    for (const _0x335354 of _0x8c7b74[_0x5d38f7(0x4e4)]) {
                                        _0x467466(_0x47240b, new _0x565fb3(_0x335354['id'], _0x335354[_0x5d38f7(0x2fe)]));
                                    }
                            }
                        }
                    }
                }
            }
        }
        [_0x21f734(0xb72)](_0x430185) {
            const _0x23881f = _0x21f734, _0xc9250a = {
                    'iCqdQ': function (_0x313ec0, _0x13df77) {
                        return _0x313ec0 === _0x13df77;
                    },
                    'AwpdM': _0x23881f(0x701),
                    'NmzSc': function (_0x27fa3d, _0x4b3f60) {
                        return _0x27fa3d === _0x4b3f60;
                    },
                    'Qpqeh': function (_0x5b169a, _0x29bf9) {
                        return _0x5b169a(_0x29bf9);
                    },
                    'ToYgG': function (_0x5c376d, _0x50b48b) {
                        return _0x5c376d >= _0x50b48b;
                    }
                }, _0x5e9205 = Array[_0x23881f(0x939)](this[_0x23881f(0xb20)]['values']())[_0x23881f(0x578)](_0x3c41b4 => _0x3c41b4[_0x23881f(0x8e7)][_0x23881f(0xa88)]?.[_0x23881f(0xae4)][_0x23881f(0x7cc)]);
            for (const _0x21496a of _0x5e9205) {
                const _0x2df12c = _0x21496a[_0x23881f(0x8e7)]['unlock'];
                if (!_0x2df12c)
                    continue;
                const _0x445dfb = _0xc9250a[_0x23881f(0xc13)](_0x2df12c[_0x23881f(0x1e9)], _0x23881f(0x701)) ? _0xc9250a[_0x23881f(0x6fb)] : 'player';
                let _0x126e85 = _0xc9250a[_0x23881f(0x462)](_0x445dfb, _0xc9250a[_0x23881f(0x6fb)]) ? _0x160d53() : _0xc9250a[_0x23881f(0x72e)](_0x144c82, _0x430185);
                if (_0x126e85[_0x23881f(0x1b2)](_0x21496a['id']))
                    continue;
                const _0x38d45f = _0x2df12c[_0x23881f(0xae4)][_0x23881f(0x7cc)]?.[_0x23881f(0x88d)](_0x271e2e => this[_0x23881f(0x29c)](_0x430185, _0x271e2e));
                if (_0x38d45f) {
                    this[_0x23881f(0x74d)](_0x21496a, _0x430185);
                    if (_0xc9250a['ToYgG'](_0x5e9205['indexOf'](_0x21496a), 0x3))
                        break;
                }
            }
        }
        [_0x21f734(0x7a0)](_0x46697a, _0x590f1b) {
            const _0x4aec30 = _0x21f734;
            for (const _0x36c725 of this[_0x4aec30(0xb20)][_0x4aec30(0x90f)]()) {
                if (_0x36c725[_0x4aec30(0x8e7)][_0x4aec30(0x4f0)]?.['blocks']?.[_0x4aec30(0x620)](_0x46697a))
                    return _0x36c725;
            }
            for (const _0x1bfa59 of this[_0x4aec30(0x3f4)][_0x4aec30(0x90f)]()) {
                if (_0x1bfa59[_0x4aec30(0x8e7)][_0x4aec30(0x4f0)]?.[_0x4aec30(0x752)]?.[_0x4aec30(0x620)](_0x46697a))
                    return _0x1bfa59;
            }
            return null;
        }
        async [_0x21f734(0x3f0)](_0x56c982, _0x162375, _0x30efa2 = ![]) {
            const _0x2af40f = _0x21f734, _0x32f47f = {
                    'FLsIb': _0x2af40f(0x6f4),
                    'UhaTE': _0x2af40f(0x217),
                    'QExwE': function (_0x22dfeb, _0x190186) {
                        return _0x22dfeb !== _0x190186;
                    }
                };
            _0x30efa2 && (this[_0x2af40f(0x9f5)] = []);
            const _0x3e9e63 = new _0x3de7db()[_0x2af40f(0x7a6)](_0x32f47f[_0x2af40f(0x9b7)])[_0x2af40f(0x45d)](_0x32f47f[_0x2af40f(0x583)]);
            _0x162375['forEach'](_0x3b0e0c => {
                const _0x287581 = _0x2af40f, _0x2bf68c = this[_0x287581(0xb20)][_0x287581(0x3c7)](_0x3b0e0c) || this[_0x287581(0x3f4)][_0x287581(0x3c7)](_0x3b0e0c);
                if (_0x2bf68c) {
                    const _0x3e8ef6 = _0x2bf68c instanceof _0xd980f0 ? _0x2bf68c[_0x287581(0x259)]() : { 'text': _0x2bf68c[_0x287581(0x259)]() }, _0x2bd7c5 = _0x2bf68c['options'][_0x287581(0x660)] || '';
                    _0x3e9e63['button'](_0x3e8ef6, _0x2bd7c5);
                }
            });
            const _0x1e1587 = await _0x3e9e63[_0x2af40f(0xb75)](_0x56c982);
            !_0x1e1587['canceled'] && _0x32f47f[_0x2af40f(0x231)](_0x1e1587[_0x2af40f(0x514)], void 0x0) && this['showForm'](_0x56c982, _0x162375[_0x1e1587[_0x2af40f(0x514)]], ![]);
        }
        async [_0x21f734(0x282)](_0x5de0d8, _0x515a85, _0x4b0655 = ![], _0x3b76b1 = ![]) {
            const _0x246a1d = _0x21f734, _0x5be009 = {
                    'hNlDV': _0x246a1d(0x4f8),
                    'Zhazf': _0x246a1d(0x5ad),
                    'lIxqq': _0x246a1d(0x701),
                    'juETw': _0x246a1d(0x848),
                    'NnqFA': function (_0x2cb53c, _0x2d2365) {
                        return _0x2cb53c === _0x2d2365;
                    },
                    'uwbgV': function (_0x199e99, _0x3762ea) {
                        return _0x199e99(_0x3762ea);
                    },
                    'ljUVl': function (_0x4d6dc7, _0xad64c6) {
                        return _0x4d6dc7 !== _0xad64c6;
                    },
                    'XRhzK': function (_0x4ce2d9, _0x48f6ca) {
                        return _0x4ce2d9 < _0x48f6ca;
                    },
                    'dJhKk': function (_0x13c458, _0x17e1ff) {
                        return _0x13c458 instanceof _0x17e1ff;
                    },
                    'LNrRs': function (_0x2010de, _0x48dbc9) {
                        return _0x2010de > _0x48dbc9;
                    },
                    'grSOP': 'ModalForm\x20response:'
                }, _0xfe0b81 = this[_0x246a1d(0xb20)][_0x246a1d(0x3c7)](_0x515a85) || this['modalForms'][_0x246a1d(0x3c7)](_0x515a85);
            if (!_0xfe0b81)
                return;
            _0x5de0d8[_0x246a1d(0x32a)](_0x5be009[_0x246a1d(0x35a)]), _0x5de0d8[_0x246a1d(0xa70)](_0x5be009['Zhazf']);
            _0x4b0655 && (this['navigationStack'] = []);
            this[_0x246a1d(0x9f5)][_0x246a1d(0x28e)](_0x515a85), this[_0x246a1d(0xc0e)] = _0x3b76b1;
            const _0x472679 = _0xfe0b81[_0x246a1d(0x8e7)]['unlock']?.[_0x246a1d(0x1e9)] === _0x5be009[_0x246a1d(0x3d8)] ? _0x5be009[_0x246a1d(0x3d8)] : _0x5be009['juETw'], _0x59052a = _0x5be009['NnqFA'](_0x472679, _0x5be009[_0x246a1d(0x3d8)]) ? _0x160d53() : _0x5be009[_0x246a1d(0x54c)](_0x144c82, _0x5de0d8);
            if (_0xfe0b81 instanceof _0xd980f0) {
                const {
                        form: _0xb891fa,
                        buttonCount: _0x465f68,
                        backButtonIndex: _0x3bcdbb
                    } = _0xfe0b81['compile'](_0x5de0d8, new Map([
                        ...this[_0x246a1d(0xb20)],
                        ...this[_0x246a1d(0x3f4)]
                    ]), this[_0x246a1d(0x6cd)], _0x59052a), _0x366ed0 = await _0xb891fa[_0x246a1d(0xb75)](_0x5de0d8);
                if (_0x366ed0[_0x246a1d(0x8bd)])
                    return;
                if (_0x366ed0['selection'] === void 0x0)
                    return;
                if (_0x5be009['ljUVl'](_0x3bcdbb, void 0x0) && _0x366ed0[_0x246a1d(0x514)] === _0x3bcdbb) {
                    this[_0x246a1d(0x75f)](_0x5de0d8);
                    return;
                }
                const _0x16d180 = this[_0x246a1d(0x6cd)][_0x246a1d(0x3c7)](_0x515a85) || [];
                if (_0x5be009[_0x246a1d(0x5bc)](_0x366ed0[_0x246a1d(0x514)], _0x16d180[_0x246a1d(0x51f)])) {
                    const _0x11e1f2 = _0x16d180[_0x366ed0[_0x246a1d(0x514)]];
                    if (this[_0x246a1d(0xb20)][_0x246a1d(0x1b2)](_0x11e1f2) || this['modalForms']['has'](_0x11e1f2)) {
                        this['showForm'](_0x5de0d8, _0x11e1f2);
                        return;
                    }
                }
            } else {
                if (_0x5be009[_0x246a1d(0xa6d)](_0xfe0b81, _0x380dcf)) {
                    const _0x9b481a = _0xfe0b81[_0x246a1d(0x2e6)](), _0x4e1807 = await _0x9b481a[_0x246a1d(0xb75)](_0x5de0d8);
                    if (_0x4e1807[_0x246a1d(0x8bd)]) {
                        const _0x1c0b91 = _0xfe0b81['options'][_0x246a1d(0x6cd)] || [];
                        _0x5be009['LNrRs'](_0x1c0b91[_0x246a1d(0x51f)], 0x0) && this['showForm'](_0x5de0d8, _0x1c0b91[0x0]);
                        return;
                    } else
                        _0x4e1807[_0x246a1d(0x4ec)] && (console[_0x246a1d(0x962)](_0x5be009['grSOP'], _0x4e1807[_0x246a1d(0x4ec)]), _0xfe0b81[_0x246a1d(0x8e7)]['controls'][_0x246a1d(0x3e1)]((_0x2175bc, _0xc88878) => {
                            const _0x54e7e7 = _0x246a1d;
                            if (_0x2175bc[_0x54e7e7(0x7a1)] && _0x4e1807[_0x54e7e7(0x4ec)]) {
                                const _0x2f50e9 = _0x4e1807[_0x54e7e7(0x4ec)][_0xc88878];
                                this[_0x54e7e7(0x483)](_0x2175bc[_0x54e7e7(0x7a1)], _0x2f50e9);
                            }
                        }));
                }
            }
        }
        [_0x21f734(0x75f)](_0x52ec80) {
            const _0x400cc6 = _0x21f734, _0x127673 = {
                    'SAVUi': function (_0x292120, _0x33630f) {
                        return _0x292120 > _0x33630f;
                    }
                };
            _0x52ec80[_0x400cc6(0x32a)](_0x400cc6(0x4f8));
            if (this[_0x400cc6(0xc0e)]) {
                const _0x312474 = this[_0x400cc6(0xa90)]();
                _0x312474 && this['showForm'](_0x52ec80, _0x312474, !![]);
            } else {
                if (_0x127673[_0x400cc6(0x8ab)](this[_0x400cc6(0x9f5)][_0x400cc6(0x51f)], 0x1)) {
                    this[_0x400cc6(0x9f5)][_0x400cc6(0x988)]();
                    const _0x5e46d8 = this[_0x400cc6(0x9f5)][_0x400cc6(0x988)]();
                    _0x5e46d8 && this[_0x400cc6(0x282)](_0x52ec80, _0x5e46d8);
                } else {
                }
            }
        }
        [_0x21f734(0xa90)]() {
            const _0x49fe4b = _0x21f734, _0x2109fe = {
                    'vRVIk': function (_0x1a6545, _0x123b5a) {
                        return _0x1a6545 - _0x123b5a;
                    }
                }, _0x352efb = this[_0x49fe4b(0x9f5)][_0x2109fe[_0x49fe4b(0xa2b)](this[_0x49fe4b(0x9f5)][_0x49fe4b(0x51f)], 0x1)];
            for (const [_0x28424b, _0x4a60bd] of this[_0x49fe4b(0x81c)]) {
                if (this[_0x49fe4b(0x3db)][_0x49fe4b(0x3c7)](_0x28424b)?.[_0x49fe4b(0x620)](_0x352efb))
                    return _0x4a60bd;
            }
            return void 0x0;
        }
        [_0x21f734(0x4cd)]() {
            const _0x33ce84 = _0x21f734, _0x4cc098 = {
                    'fANPF': function (_0x3cfb0f, _0x3e25b5) {
                        return _0x3cfb0f === _0x3e25b5;
                    },
                    'okIbG': function (_0x1fdc27, _0x439f3f) {
                        return _0x1fdc27 instanceof _0x439f3f;
                    },
                    'vcvEv': function (_0x2a6642, _0x5ab226) {
                        return _0x2a6642 instanceof _0x5ab226;
                    },
                    'mqlGK': function (_0x1af706, _0x1858f5) {
                        return _0x1af706 in _0x1858f5;
                    },
                    'IFQjU': function (_0x116b33, _0x4dad7e) {
                        return _0x116b33 instanceof _0x4dad7e;
                    },
                    'cYgzM': function (_0x4de741, _0x34c302) {
                        return _0x4de741 instanceof _0x34c302;
                    },
                    'XlrrB': function (_0x4c7fa1, _0x19610a) {
                        return _0x4c7fa1 instanceof _0x19610a;
                    },
                    'rtkEo': function (_0x11972d) {
                        return _0x11972d();
                    }
                };
            _0x6911b3['forEach'](({
                forms: _0x44a034,
                trigger: _0x318b05,
                mainForm: _0xe056cf
            }) => {
                const _0xf0dc0d = _0x3124;
                _0x44a034[_0xf0dc0d(0x3e1)](_0x14675c => {
                    const _0x1bc99b = _0xf0dc0d, _0x264113 = _0x4cc098['fANPF'](_0x14675c['id'], _0xe056cf);
                    let _0x59ca65;
                    if (_0x4cc098[_0x1bc99b(0x509)](_0x14675c, _0x2a6cb3))
                        _0x59ca65 = _0x14675c, this[_0x1bc99b(0xb20)]['set'](_0x59ca65['id'], _0x59ca65);
                    else {
                        if (_0x4cc098[_0x1bc99b(0x509)](_0x14675c, _0xd980f0))
                            _0x59ca65 = _0x14675c, this[_0x1bc99b(0xb20)][_0x1bc99b(0x54f)](_0x59ca65['id'], _0x59ca65);
                        else {
                            if (_0x14675c instanceof _0x380dcf)
                                _0x59ca65 = _0x14675c, this[_0x1bc99b(0x3f4)][_0x1bc99b(0x54f)](_0x59ca65['id'], _0x59ca65);
                            else
                                throw new Error(_0x1bc99b(0xbea) + _0x14675c['id']);
                        }
                    }
                    _0x264113 && this[_0x1bc99b(0x81c)]['set'](_0x318b05, _0x59ca65['id']);
                    !this[_0x1bc99b(0x3db)][_0x1bc99b(0x1b2)](_0x318b05) && this['triggers']['set'](_0x318b05, []);
                    this[_0x1bc99b(0x3db)][_0x1bc99b(0x3c7)](_0x318b05)?.['push'](_0x59ca65['id']);
                    _0x14675c[_0x1bc99b(0x8e7)][_0x1bc99b(0x6cd)] && _0x14675c[_0x1bc99b(0x8e7)]['references'][_0x1bc99b(0x3e1)](_0x1ab56a => {
                        const _0x28ea88 = _0x1bc99b;
                        !this[_0x28ea88(0x6cd)]['has'](_0x1ab56a) && this['references'][_0x28ea88(0x54f)](_0x1ab56a, []), this[_0x28ea88(0x6cd)][_0x28ea88(0x3c7)](_0x1ab56a)?.[_0x28ea88(0x28e)](_0x59ca65['id']);
                    });
                    !this[_0x1bc99b(0x6cd)][_0x1bc99b(0x1b2)](_0x59ca65['id']) && this[_0x1bc99b(0x6cd)][_0x1bc99b(0x54f)](_0x59ca65['id'], []);
                    if (_0x59ca65 instanceof _0xd980f0 && _0x59ca65[_0x1bc99b(0x8e7)][_0x1bc99b(0xa88)]) {
                        const _0x42cd9e = _0x59ca65['options'][_0x1bc99b(0xa88)];
                        _0x42cd9e[_0x1bc99b(0xae4)] && (Array['isArray'](_0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0xba3)]) && this[_0x1bc99b(0x3fb)][_0x1bc99b(0x28e)]({
                            'form': _0x59ca65,
                            'entityTypes': _0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0xba3)]
                        }), Array[_0x1bc99b(0x2b1)](_0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0x207)]) && this[_0x1bc99b(0xb73)][_0x1bc99b(0x28e)]({
                            'form': _0x59ca65,
                            'blockTypes': _0x42cd9e['trigger']['blockDestroy']
                        }), Array[_0x1bc99b(0x2b1)](_0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0x68d)]) && this[_0x1bc99b(0x927)][_0x1bc99b(0x28e)]({
                            'form': _0x59ca65,
                            'blockTypes': _0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0x68d)]
                        }), Array[_0x1bc99b(0x2b1)](_0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0x75c)]) && this[_0x1bc99b(0x782)][_0x1bc99b(0x28e)]({
                            'form': _0x59ca65,
                            'blockTypes': _0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0x75c)]
                        }), Array[_0x1bc99b(0x2b1)](_0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0xb18)]) && this[_0x1bc99b(0x2bc)][_0x1bc99b(0x28e)]({
                            'form': _0x59ca65,
                            'entityTypes': _0x42cd9e[_0x1bc99b(0xae4)][_0x1bc99b(0xb18)]
                        }), _0x4cc098[_0x1bc99b(0x21b)](_0x59ca65, _0xd980f0) && _0x59ca65['options'][_0x1bc99b(0xa88)]?.['trigger'][_0x1bc99b(0x441)] && this['useItemForms'][_0x1bc99b(0x28e)]({
                            'form': _0x59ca65,
                            'items': _0x59ca65['options']['unlock']['trigger'][_0x1bc99b(0x441)][_0x1bc99b(0x2dc)](_0x257d61 => ({
                                'id': _0x257d61['id'],
                                'count': _0x257d61['count'] || 0x1,
                                'removeItem': _0x257d61[_0x1bc99b(0xbf0)]
                            }))
                        }), _0x42cd9e['trigger'][_0x1bc99b(0x7ec)] && _0x42cd9e[_0x1bc99b(0xae4)]['achievement'][_0x1bc99b(0x3e1)](_0x335772 => {
                            const _0x30dffb = _0x1bc99b;
                            !this['triggers']['has'](_0x335772) && this[_0x30dffb(0x3db)][_0x30dffb(0x54f)](_0x335772, []), this[_0x30dffb(0x3db)][_0x30dffb(0x3c7)](_0x335772)?.['push'](_0x59ca65['id']);
                        }));
                    }
                });
            });
            const _0x19776c = () => {
                    const _0x46fca7 = _0x3124, _0x36fd14 = {
                            'AxZSy': function (_0x43c1c1, _0x224bed) {
                                return _0x4cc098['XlrrB'](_0x43c1c1, _0x224bed);
                            },
                            'owzKT': function (_0x30d3ff, _0x4d8957) {
                                return _0x30d3ff instanceof _0x4d8957;
                            }
                        };
                    let _0x360381 = new Map();
                    for (const [_0x1017dd, _0x3c66ac] of this[_0x46fca7(0xb20)]) {
                        _0x360381[_0x46fca7(0x54f)](_0x1017dd, _0x3c66ac);
                    }
                    for (const [_0x141d62, _0x4ccc27] of this[_0x46fca7(0x3f4)]) {
                        _0x360381[_0x46fca7(0x54f)](_0x141d62, _0x4ccc27);
                    }
                    return _0x6911b3[_0x46fca7(0x3e1)](({forms: _0x57180f}) => {
                        const _0x52f649 = _0x46fca7;
                        if (Array[_0x52f649(0x2b1)](_0x57180f))
                            _0x57180f[_0x52f649(0x3e1)](_0x562a2b => {
                                const _0x2e6a66 = _0x52f649;
                                (_0x36fd14[_0x2e6a66(0x6b4)](_0x562a2b, _0xd980f0) || _0x562a2b instanceof _0x380dcf || _0x36fd14['owzKT'](_0x562a2b, _0x2a6cb3)) && _0x360381['set'](_0x562a2b['id'], _0x562a2b);
                            });
                        else {
                            const _0x52ec99 = _0x57180f;
                            if (_0x52ec99 && _0x4cc098[_0x52f649(0x227)]('id', _0x52ec99)) {
                                _0x360381[_0x52f649(0x54f)](_0x52ec99['id'], _0x52ec99);
                                if (_0x4cc098['IFQjU'](_0x52ec99, _0xd980f0) || _0x4cc098['cYgzM'](_0x52ec99, _0x2a6cb3))
                                    this['actionForms'][_0x52f649(0x54f)](_0x52ec99['id'], _0x52ec99);
                                else
                                    _0x4cc098['vcvEv'](_0x52ec99, _0x380dcf) && this[_0x52f649(0x3f4)][_0x52f649(0x54f)](_0x52ec99['id'], _0x52ec99);
                            }
                        }
                    }), _0x360381;
                }, _0x19fbb7 = _0x4cc098['rtkEo'](_0x19776c);
            for (const [_0x46f1f7, _0x4eaadb] of _0x19fbb7) {
                _0x4eaadb[_0x33ce84(0x8e7)][_0x33ce84(0x6cd)] && _0x4eaadb[_0x33ce84(0x8e7)]['references'][_0x33ce84(0x3e1)](_0x3fac8a => {
                    const _0x17db42 = _0x33ce84;
                    !this['references'][_0x17db42(0x1b2)](_0x3fac8a) && this[_0x17db42(0x6cd)][_0x17db42(0x54f)](_0x3fac8a, []);
                    const _0x42ad74 = this[_0x17db42(0x6cd)][_0x17db42(0x3c7)](_0x3fac8a) || [];
                    !_0x42ad74[_0x17db42(0x620)](_0x46f1f7) && (_0x42ad74[_0x17db42(0x28e)](_0x46f1f7), this[_0x17db42(0x6cd)][_0x17db42(0x54f)](_0x3fac8a, _0x42ad74));
                });
            }
        }
        ['registerActionBasedEvents']() {
            const _0x132cb8 = _0x21f734, _0x438d16 = {
                    'Isbfi': function (_0x4a8f1, _0x5786cf) {
                        return _0x4a8f1 > _0x5786cf;
                    },
                    'wrgrK': function (_0x3d4c4e, _0x107dd1) {
                        return _0x3d4c4e instanceof _0x107dd1;
                    },
                    'kQKhJ': function (_0x496610, _0x2793c7) {
                        return _0x496610 > _0x2793c7;
                    },
                    'hIoJY': function (_0x5171ac, _0xefbf10) {
                        return _0x5171ac === _0xefbf10;
                    },
                    'fSuCr': 'world',
                    'MOKwo': _0x132cb8(0x848),
                    'fhDha': function (_0x21d716) {
                        return _0x21d716();
                    },
                    'gWlsw': function (_0x4d3b1d, _0x23c18d) {
                        return _0x4d3b1d(_0x23c18d);
                    },
                    'RyWJP': function (_0x275c07, _0x5c11f3) {
                        return _0x275c07 > _0x5c11f3;
                    },
                    'fldGd': function (_0x36a8ca, _0xbab3cc) {
                        return _0x36a8ca !== _0xbab3cc;
                    }
                };
            _0x3e82c5[_0x132cb8(0x327)]['entityDie'][_0x132cb8(0x725)](_0x5e4381 => {
                const _0x22df00 = _0x132cb8;
                if (_0x438d16[_0x22df00(0x861)](this['entityKillForms'][_0x22df00(0x51f)], 0x0)) {
                    const _0x5987b9 = _0x5e4381['damageSource'][_0x22df00(0x89e)];
                    if (_0x438d16[_0x22df00(0x8d1)](_0x5987b9, _0x1795c4)) {
                        const _0x5a6937 = _0x5e4381[_0x22df00(0x1c2)][_0x22df00(0x1b9)];
                        for (const {
                                    form: _0x57193e,
                                    entityTypes: _0x10b3a4
                                } of this[_0x22df00(0x3fb)]) {
                            _0x10b3a4[_0x22df00(0x620)](_0x5a6937) && this['unlockFormForTrigger'](_0x57193e, _0x5987b9);
                        }
                    }
                }
            }), _0x3e82c5['afterEvents'][_0x132cb8(0x8ee)][_0x132cb8(0x725)](_0x33dd24 => {
                const _0x2977fd = _0x132cb8;
                if (_0x438d16['kQKhJ'](this['blockBreakForms'][_0x2977fd(0x51f)], 0x0)) {
                    const _0x530bfa = _0x33dd24['player'], _0x4b7794 = _0x33dd24['brokenBlockPermutation'][_0x2977fd(0xc08)]['id'];
                    for (const {
                                form: _0x18765a,
                                blockTypes: _0x1abcf2
                            } of this[_0x2977fd(0xb73)]) {
                        if (_0x18765a[_0x2977fd(0x8e7)][_0x2977fd(0xa88)]?.[_0x2977fd(0xa5e)] && _0x18765a[_0x2977fd(0x8e7)][_0x2977fd(0x6cd)]) {
                            let _0x559136 = ![];
                            for (const _0x52c239 of _0x18765a[_0x2977fd(0x8e7)][_0x2977fd(0x6cd)]) {
                                const _0x5c2205 = _0x438d16[_0x2977fd(0x2c2)](_0x18765a[_0x2977fd(0x8e7)][_0x2977fd(0xa88)][_0x2977fd(0x1e9)], _0x2977fd(0x701)) ? _0x438d16[_0x2977fd(0xbbf)] : _0x438d16[_0x2977fd(0x4e5)];
                                let _0x45fc9e = _0x438d16[_0x2977fd(0x2c2)](_0x5c2205, _0x438d16['fSuCr']) ? _0x438d16[_0x2977fd(0x9c1)](_0x160d53) : _0x438d16[_0x2977fd(0x8ca)](_0x144c82, _0x530bfa);
                                if (_0x45fc9e['has'](_0x52c239)) {
                                    _0x559136 = !![];
                                    break;
                                }
                            }
                            if (!_0x559136)
                                continue;
                        }
                        _0x1abcf2['includes'](_0x4b7794) && this[_0x2977fd(0x74d)](_0x18765a, _0x530bfa);
                    }
                }
            }), _0x3e82c5['afterEvents'][_0x132cb8(0xa3b)][_0x132cb8(0x725)](_0x4090c0 => {
                const _0x1c8c2b = _0x132cb8;
                if (_0x438d16['kQKhJ'](this[_0x1c8c2b(0x927)][_0x1c8c2b(0x51f)], 0x0)) {
                    const _0x4ba31b = _0x4090c0[_0x1c8c2b(0x848)], _0x57fcc8 = _0x4090c0[_0x1c8c2b(0x87b)][_0x1c8c2b(0x1b9)];
                    for (const {
                                form: _0x5c1051,
                                blockTypes: _0x54b36a
                            } of this[_0x1c8c2b(0xb73)]) {
                        _0x54b36a[_0x1c8c2b(0x620)](_0x57fcc8) && this['unlockFormForTrigger'](_0x5c1051, _0x4ba31b);
                    }
                }
            }), _0x3e82c5[_0x132cb8(0x959)][_0x132cb8(0x48a)][_0x132cb8(0x725)](_0x266235 => {
                const _0x324351 = _0x132cb8;
                if (this[_0x324351(0x782)][_0x324351(0x51f)] > 0x0) {
                    const _0x4a76a6 = _0x266235[_0x324351(0x848)], _0x4baa40 = _0x266235[_0x324351(0x87b)]['typeId'];
                    for (const {
                                form: _0xb155b,
                                blockTypes: _0x2cfdcc
                            } of this[_0x324351(0x782)]) {
                        _0x2cfdcc[_0x324351(0x620)](_0x4baa40) && this[_0x324351(0x74d)](_0xb155b, _0x4a76a6);
                    }
                }
            }), _0x3e82c5[_0x132cb8(0x959)][_0x132cb8(0x510)][_0x132cb8(0x725)](_0x4ad0f3 => {
                const _0x5324f2 = _0x132cb8;
                if (this[_0x5324f2(0x2bc)][_0x5324f2(0x51f)] > 0x0) {
                    const _0x33d826 = _0x4ad0f3[_0x5324f2(0x848)], _0x20fe53 = _0x4ad0f3['target'][_0x5324f2(0x1b9)];
                    for (const {
                                form: _0x219aca,
                                entityTypes: _0x137683
                            } of this[_0x5324f2(0x2bc)]) {
                        _0x137683[_0x5324f2(0x620)](_0x20fe53) && this[_0x5324f2(0x74d)](_0x219aca, _0x33d826);
                    }
                }
            }), _0x3e82c5[_0x132cb8(0x327)][_0x132cb8(0x71a)][_0x132cb8(0x725)](_0x180164 => {
                const _0x3826a9 = _0x132cb8;
                if (_0x438d16['RyWJP'](this[_0x3826a9(0x1ad)][_0x3826a9(0x51f)], 0x0)) {
                    const _0xc2a378 = _0x180164['source'], _0x3c70bb = _0x180164[_0x3826a9(0xc1d)][_0x3826a9(0x1b9)];
                    for (const {
                                form: _0xe2f6b3,
                                items: _0x446a03
                            } of this[_0x3826a9(0x1ad)]) {
                        if (_0x438d16['fldGd'](_0xe2f6b3['options'][_0x3826a9(0xa88)]?.['order'], void 0x0))
                            continue;
                        const _0xcfe27c = _0x446a03['find'](_0x24a140 => _0x24a140['id'] === _0x3c70bb);
                        _0xcfe27c && (_0xcfe27c[_0x3826a9(0xbf0)] && _0x2c8ecf(_0xc2a378, _0x3c70bb), this[_0x3826a9(0x74d)](_0xe2f6b3, _0xc2a378));
                    }
                }
            });
        }
        ['setDynamicProperty'](_0x2b3acf, _0x210911) {
            const _0x1d7460 = _0x21f734;
            try {
                _0x3e82c5[_0x1d7460(0x483)](_0x2b3acf, _0x210911);
            } catch (_0x56e194) {
            }
        }
        [_0x21f734(0x74d)](_0x482bf4, _0x5939a1) {
            const _0x412776 = _0x21f734, _0x8a5084 = {
                    'AAsej': function (_0x1a35fe, _0x2f9b91) {
                        return _0x1a35fe === _0x2f9b91;
                    },
                    'jVugJ': 'world',
                    'vCWST': _0x412776(0x848),
                    'GwoUB': function (_0x41ceb4) {
                        return _0x41ceb4();
                    },
                    'DkJqt': function (_0x1a5133, _0x2b201e) {
                        return _0x1a5133(_0x2b201e);
                    },
                    'MQDBr': function (_0x412e07, _0x5f58de, _0x431c04) {
                        return _0x412e07(_0x5f58de, _0x431c04);
                    },
                    'nnana': _0x412776(0x4c4),
                    'GsNqQ': function (_0x278e3b, _0x422705) {
                        return _0x278e3b > _0x422705;
                    },
                    'SaRfn': function (_0x5b9ce5, _0xab864a) {
                        return _0x5b9ce5 === _0xab864a;
                    }
                }, _0x1537c6 = _0x482bf4[_0x412776(0x8e7)]['unlock'];
            if (!_0x1537c6)
                return;
            const _0x3afd1b = _0x8a5084['AAsej'](_0x1537c6[_0x412776(0x1e9)], _0x8a5084[_0x412776(0x95d)]) ? _0x412776(0x701) : _0x8a5084[_0x412776(0x776)];
            let _0x40219b = _0x3afd1b === _0x8a5084[_0x412776(0x95d)] ? _0x8a5084['GwoUB'](_0x160d53) : _0x8a5084[_0x412776(0x659)](_0x144c82, _0x5939a1);
            if (!_0x40219b[_0x412776(0x1b2)](_0x482bf4['id'])) {
                _0x40219b['add'](_0x482bf4['id']);
                _0x8a5084[_0x412776(0x686)](_0x3afd1b, _0x8a5084[_0x412776(0x95d)]) ? _0xe08d9d(_0x40219b) : _0x8a5084[_0x412776(0x843)](_0x504be6, _0x5939a1, _0x40219b);
                _0x1537c6[_0x412776(0x758)] && _0x5939a1[_0x412776(0xa70)](_0x1537c6[_0x412776(0x758)]);
                _0x1537c6[_0x412776(0x8ce)] && this[_0x412776(0xaf7)](_0x1537c6[_0x412776(0x8ce)], _0x5939a1);
                const _0x5691c7 = _0x1537c6[_0x412776(0x834)];
                if (_0x8a5084[_0x412776(0x686)](_0x3afd1b, _0x8a5084[_0x412776(0x95d)])) {
                    _0x8a5084['DkJqt'](_0xe08d9d, _0x40219b);
                    const _0x174f56 = _0x3e82c5['getAllPlayers']();
                    if (_0x5691c7) {
                        if (_0x8a5084[_0x412776(0x686)](typeof _0x5691c7['xp'], _0x8a5084[_0x412776(0x370)]) && _0x8a5084[_0x412776(0x6ac)](_0x5691c7['xp'], 0x0))
                            for (const _0x489728 of _0x174f56) {
                                _0x489728[_0x412776(0x3fd)](_0x5691c7['xp']);
                            }
                        if (_0x5691c7[_0x412776(0x4e4)] && Array[_0x412776(0x2b1)](_0x5691c7[_0x412776(0x4e4)]))
                            for (const _0x424965 of _0x174f56) {
                                for (const _0x33ffb7 of _0x5691c7[_0x412776(0x4e4)]) {
                                    _0x467466(_0x424965, new _0x565fb3(_0x33ffb7['id'], _0x33ffb7[_0x412776(0x2fe)]));
                                }
                            }
                    }
                } else {
                    if (_0x5691c7) {
                        _0x8a5084[_0x412776(0x39c)](typeof _0x5691c7['xp'], _0x8a5084[_0x412776(0x370)]) && _0x8a5084[_0x412776(0x6ac)](_0x5691c7['xp'], 0x0) && _0x5939a1[_0x412776(0x3fd)](_0x5691c7['xp']);
                        if (_0x5691c7['items'] && Array[_0x412776(0x2b1)](_0x5691c7[_0x412776(0x4e4)]))
                            for (const _0xc2b29f of _0x5691c7['items']) {
                                _0x8a5084[_0x412776(0x843)](_0x467466, _0x5939a1, new _0x565fb3(_0xc2b29f['id'], _0xc2b29f[_0x412776(0x2fe)]));
                            }
                    }
                }
                this[_0x412776(0xab8)](_0x5939a1, '');
            }
            _0x1537c6[_0x412776(0x7e3)] && this[_0x412776(0x6cd)][_0x412776(0x3e1)]((_0x349169, _0x4324ca) => {
                const _0x28537f = _0x412776;
                if (_0x349169[_0x28537f(0x620)](_0x482bf4['id'])) {
                    const _0x2b723a = this[_0x28537f(0xb20)][_0x28537f(0x3c7)](_0x4324ca) || this[_0x28537f(0x3f4)][_0x28537f(0x3c7)](_0x4324ca);
                    _0x2b723a instanceof _0xd980f0 && this[_0x28537f(0x74d)](_0x2b723a, _0x5939a1);
                }
            });
        }
    };
function _0x160d53() {
    const _0x5ad30f = _0x21f734, _0x3aa837 = _0x3e82c5[_0x5ad30f(0xb95)](_0x207994 + ':unlockedForms') || '[]';
    return new Set(JSON['parse'](_0x3aa837));
}
function _0xe08d9d(_0x130d07) {
    const _0x262970 = _0x21f734;
    _0x3e82c5[_0x262970(0x483)](_0x207994 + _0x262970(0x7bc), JSON[_0x262970(0x464)](Array[_0x262970(0x939)](_0x130d07)));
}
function _0x144c82(_0x1f2066) {
    const _0x52796f = _0x21f734, _0x39e9aa = _0x207994 + ':unlockedForms', _0x6aec6f = _0x1f2066[_0x52796f(0xb95)](_0x39e9aa) || '[]';
    return new Set(JSON['parse'](_0x6aec6f));
}
function _0x504be6(_0x5c4c51, _0x4ef646) {
    const _0x19af04 = _0x21f734, _0x50c660 = _0x207994 + _0x19af04(0x7bc);
    _0x5c4c51[_0x19af04(0x483)](_0x50c660, JSON[_0x19af04(0x464)](Array['from'](_0x4ef646)));
}
var _0x144caf = new _0x16ec4f();
import {
    BlockPermutation as _0x1b7838,
    system as _0x9976e1
} from '@minecraft/server';
import {
    system as _0x15ccbe,
    world as _0x4cfd0f,
    EquipmentSlot as _0x441c0b
} from '@minecraft/server';
var _0x8579f8 = class _0x5e3f83 {
    constructor(_0x1112b8) {
        const _0x3e3c6e = _0x21f734;
        this[_0x3e3c6e(0xa49)] = _0x1112b8;
    }
    static [_0x21f734(0x760)](_0x1be03b) {
        const _0x33fac9 = _0x21f734, _0x266d1b = new _0x5e3f83(_0x1be03b);
        this[_0x33fac9(0x4e4)][_0x33fac9(0x28e)](_0x266d1b);
    }
    static [_0x21f734(0x5cb)](_0x1195d2) {
        const _0x324515 = _0x21f734;
        return this[_0x324515(0x4e4)][_0x324515(0x65e)](_0xc12a47 => _0xc12a47[_0x324515(0xa49)]['id'] === _0x1195d2);
    }
    static [_0x21f734(0x48b)]() {
        const _0x507bee = _0x21f734, _0x411ba2 = {
                'MzgEo': function (_0x14e495, _0x45297f, _0x26557d) {
                    return _0x14e495(_0x45297f, _0x26557d);
                },
                'MtKCl': function (_0x1842fd, _0xc7483e) {
                    return _0x1842fd === _0xc7483e;
                },
                'RnXos': function (_0x492659, _0x9e32c2, _0x555b98) {
                    return _0x492659(_0x9e32c2, _0x555b98);
                },
                'carbv': function (_0x1784a0, _0x452322) {
                    return _0x1784a0 === _0x452322;
                }
            };
        _0x4cfd0f[_0x507bee(0x327)]['playerBreakBlock'][_0x507bee(0x725)](_0x386704 => {
            const _0x1d3eb0 = _0x507bee, {
                    player: _0x58fa6a,
                    block: _0x3d1123
                } = _0x386704, _0x42252f = _0x411ba2[_0x1d3eb0(0x4b7)](_0x59bdcb, _0x58fa6a, _0x441c0b[_0x1d3eb0(0xc15)]);
            if (!_0x42252f)
                return;
            const _0x22fe68 = _0x5e3f83['getItem'](_0x42252f[_0x1d3eb0(0x1b9)]);
            if (!_0x22fe68)
                return;
            _0x411ba2[_0x1d3eb0(0x3c4)](_0x42252f?.[_0x1d3eb0(0x1b9)], _0x22fe68[_0x1d3eb0(0xa49)]['id']) && _0x22fe68[_0x1d3eb0(0xa49)][_0x1d3eb0(0xb8c)] && _0x22fe68[_0x1d3eb0(0xa49)][_0x1d3eb0(0xb8c)](_0x58fa6a, _0x3d1123[_0x1d3eb0(0x2c0)]);
        }), _0x4cfd0f['afterEvents'][_0x507bee(0x856)][_0x507bee(0x725)](_0x16d457 => {
            const _0x469f63 = _0x507bee, _0x1bd409 = _0x16d457[_0x469f63(0x57e)], _0x446faa = _0x16d457[_0x469f63(0x781)]['damagingEntity'];
            if (!_0x446faa)
                return;
            const _0x1aade0 = _0x411ba2['RnXos'](_0x59bdcb, _0x446faa, _0x441c0b[_0x469f63(0xc15)]);
            if (!_0x1aade0)
                return;
            const _0x22a374 = _0x5e3f83[_0x469f63(0x5cb)](_0x1aade0[_0x469f63(0x1b9)]);
            if (!_0x22a374)
                return;
            _0x1aade0?.['typeId'] === _0x22a374['config']['id'] && _0x22a374['config'][_0x469f63(0xb93)] && _0x22a374[_0x469f63(0xa49)][_0x469f63(0xb93)](_0x446faa, _0x1bd409);
        }), _0x4cfd0f['afterEvents'][_0x507bee(0x71a)][_0x507bee(0x725)](_0x13be34 => {
            const _0x14fa57 = _0x507bee, {
                    itemStack: _0x4077ad,
                    source: _0x543851
                } = _0x13be34;
            if (!_0x4077ad)
                return;
            const _0x40245b = _0x5e3f83[_0x14fa57(0x5cb)](_0x4077ad[_0x14fa57(0x1b9)]);
            if (!_0x40245b)
                return;
            _0x411ba2[_0x14fa57(0x3c4)](_0x4077ad?.['typeId'], _0x40245b['config']['id']) && _0x40245b['config'][_0x14fa57(0x4be)] && _0x40245b['config']['onUse'](_0x543851);
        }), _0x4cfd0f[_0x507bee(0x327)][_0x507bee(0x3ba)][_0x507bee(0x725)](_0x186432 => {
            const _0x33b841 = _0x507bee, {
                    itemStack: _0x20f7cb,
                    source: _0x2e39bd
                } = _0x186432;
            if (!_0x20f7cb)
                return;
            const _0x51d65c = _0x5e3f83[_0x33b841(0x5cb)](_0x20f7cb[_0x33b841(0x1b9)]);
            if (!_0x51d65c)
                return;
            _0x20f7cb?.[_0x33b841(0x1b9)] === _0x51d65c[_0x33b841(0xa49)]['id'] && _0x51d65c[_0x33b841(0xa49)][_0x33b841(0x91c)] && _0x51d65c[_0x33b841(0xa49)][_0x33b841(0x91c)](_0x186432);
        }), _0x4cfd0f[_0x507bee(0x959)][_0x507bee(0x3ba)][_0x507bee(0x725)](_0x5e3194 => {
            const _0x524a6d = _0x507bee, {
                    itemStack: _0x3e3ced,
                    source: _0x5a34d5
                } = _0x5e3194;
            if (!_0x3e3ced)
                return;
            if (!_0x5e3194[_0x524a6d(0x212)])
                return;
            const _0x4ca12d = _0x5e3f83[_0x524a6d(0x5cb)](_0x3e3ced['typeId']);
            if (!_0x4ca12d)
                return;
            _0x3e3ced?.[_0x524a6d(0x1b9)] === _0x4ca12d[_0x524a6d(0xa49)]['id'] && _0x4ca12d[_0x524a6d(0xa49)][_0x524a6d(0x947)] && _0x4ca12d[_0x524a6d(0xa49)][_0x524a6d(0x947)](_0x5e3194);
        }), _0x4cfd0f[_0x507bee(0x327)]['itemCompleteUse'][_0x507bee(0x725)](_0x42c299 => {
            const _0xd1ddff = _0x507bee, {
                    itemStack: _0x58b14e,
                    source: _0x300945
                } = _0x42c299;
            if (!_0x58b14e)
                return;
            const _0x3de7da = _0x5e3f83[_0xd1ddff(0x5cb)](_0x58b14e['typeId']);
            if (!_0x3de7da)
                return;
            _0x411ba2[_0xd1ddff(0x1d8)](_0x58b14e?.[_0xd1ddff(0x1b9)], _0x3de7da[_0xd1ddff(0xa49)]['id']) && _0x3de7da[_0xd1ddff(0xa49)]['onCompleteUse'] && _0x3de7da['config'][_0xd1ddff(0x5b1)](_0x300945);
        }), _0x4cfd0f[_0x507bee(0x327)][_0x507bee(0xaef)][_0x507bee(0x725)](_0x10a95f => {
            const _0x26bc39 = _0x507bee, {
                    itemStack: _0x24517b,
                    source: _0x5846b6
                } = _0x10a95f;
            if (!_0x24517b)
                return;
            const _0xcf1073 = _0x5e3f83[_0x26bc39(0x5cb)](_0x24517b['typeId']);
            if (!_0xcf1073)
                return;
            _0x24517b?.[_0x26bc39(0x1b9)] === _0xcf1073[_0x26bc39(0xa49)]['id'] && _0xcf1073[_0x26bc39(0xa49)]['onRelease'] && _0xcf1073[_0x26bc39(0xa49)]['onRelease'](_0x5846b6);
        }), _0x4cfd0f[_0x507bee(0x327)][_0x507bee(0x510)][_0x507bee(0x725)](_0x45b4bc => {
            const _0x354e2f = _0x507bee, {itemStack: _0x45d72c} = _0x45b4bc;
            if (!_0x45d72c)
                return;
            const _0x5ddee4 = _0x5e3f83[_0x354e2f(0x5cb)](_0x45d72c[_0x354e2f(0x1b9)]);
            if (!_0x5ddee4)
                return;
            _0x45d72c?.[_0x354e2f(0x1b9)] === _0x5ddee4['config']['id'] && _0x5ddee4[_0x354e2f(0xa49)][_0x354e2f(0x7c8)] && _0x5ddee4['config']['onUseOnEntityAfter'](_0x45b4bc);
        }), _0x4cfd0f[_0x507bee(0x959)][_0x507bee(0x510)]['subscribe'](_0x59f723 => {
            const _0x1c8361 = _0x507bee, {itemStack: _0x2cdc92} = _0x59f723;
            if (!_0x2cdc92)
                return;
            const _0x3e6f9f = _0x5e3f83[_0x1c8361(0x5cb)](_0x2cdc92[_0x1c8361(0x1b9)]);
            if (!_0x3e6f9f)
                return;
            _0x15ccbe[_0x1c8361(0xb7e)](() => {
                const _0x22d62f = _0x1c8361;
                _0x411ba2[_0x22d62f(0x3c4)](_0x2cdc92?.[_0x22d62f(0x1b9)], _0x3e6f9f['config']['id']) && _0x3e6f9f[_0x22d62f(0xa49)][_0x22d62f(0x2db)] && _0x3e6f9f[_0x22d62f(0xa49)]['onUseOnEntityBefore'](_0x59f723);
            });
        });
    }
};
_0x25e7d0(_0x8579f8, _0x21f734(0x4e4), []);
var _0x4b6274 = _0x8579f8;
import {
    system as _0x1ea475,
    ItemStack as _0x5e5400
} from '@minecraft/server';
function _0x347ee5() {
    const _0x28cf2c = _0x21f734, _0x2eda1c = {
            'Evijc': function (_0x52b38b, _0x2c6ae1) {
                return _0x52b38b + _0x2c6ae1;
            },
            'dQJqW': function (_0x502099, _0x3e3912) {
                return _0x502099 * _0x3e3912;
            },
            'dpBal': function (_0x47d066, _0x2ecc6e) {
                return _0x47d066 < _0x2ecc6e;
            },
            'TTnKH': function (_0x2f1f6f, _0x469412) {
                return _0x2f1f6f / _0x469412;
            },
            'SLuVZ': function (_0x1abdca, _0x3a611c) {
                return _0x1abdca / _0x3a611c;
            },
            'rOwyb': function (_0x53f2fe, _0x304cda) {
                return _0x53f2fe - _0x304cda;
            },
            'pGmjQ': function (_0x464659, _0x5bac39) {
                return _0x464659 + _0x5bac39;
            },
            'iOzJo': function (_0x288121, _0x29b56c) {
                return _0x288121 * _0x29b56c;
            },
            'ARESX': function (_0x5849fd, _0x346c48) {
                return _0x5849fd * _0x346c48;
            },
            'eJZgs': function (_0xb39ac9, _0x2cb6e9) {
                return _0xb39ac9 / _0x2cb6e9;
            },
            'SLNvG': function (_0x1b81a2, _0x641e10) {
                return _0x1b81a2 * _0x641e10;
            },
            'BehAp': function (_0x29ca72, _0x59623c) {
                return _0x29ca72 === _0x59623c;
            },
            'mBMtr': 'minecraft:basic_flame_particle',
            'hbpfC': _0x28cf2c(0x496),
            'KfvbD': '2|4|0|1|3',
            'hIEsc': _0x28cf2c(0x6e9),
            'aeDOs': function (_0x23a7cd, _0x51d2dc) {
                return _0x23a7cd > _0x51d2dc;
            },
            'YGuxD': _0x28cf2c(0x255),
            'JPoPB': function (_0x3a4ae3, _0x997c46) {
                return _0x3a4ae3 !== _0x997c46;
            },
            'QSxrU': _0x28cf2c(0x805),
            'WRRJt': _0x28cf2c(0x32e),
            'iJxut': function (_0x192723, _0x4ecf4d) {
                return _0x192723 <= _0x4ecf4d;
            },
            'FIpWU': function (_0x384de2, _0x250b9a) {
                return _0x384de2 / _0x250b9a;
            },
            'dOcky': function (_0x49a7be, _0x39d775) {
                return _0x49a7be + _0x39d775;
            },
            'dWIsU': function (_0x564cb3, _0x18eb15) {
                return _0x564cb3 * _0x18eb15;
            },
            'ZErLq': function (_0x29d2be, _0x546c46) {
                return _0x29d2be * _0x546c46;
            },
            'mIVGB': 'minecraft:blue_flame_particle',
            'ErzuN': function (_0x33629f, _0x14cb78) {
                return _0x33629f === _0x14cb78;
            },
            'mlfUa': function (_0x957515, _0x790b08) {
                return _0x957515 % _0x790b08;
            },
            'dzfFt': function (_0xf8f183, _0x2d2e66) {
                return _0xf8f183 / _0x2d2e66;
            },
            'qJGnJ': function (_0x1ddae5, _0x4de7b5) {
                return _0x1ddae5 * _0x4de7b5;
            },
            'GiWZE': function (_0x75e8b5, _0x122b6b) {
                return _0x75e8b5 * _0x122b6b;
            },
            'MhahY': function (_0x319990, _0x277f29) {
                return _0x319990 + _0x277f29;
            },
            'FHwTm': function (_0x55ff12, _0x512abb) {
                return _0x55ff12 + _0x512abb;
            },
            'QHFHK': function (_0x263467, _0x3f7ea3) {
                return _0x263467 * _0x3f7ea3;
            },
            'jZOkn': function (_0x306ef8, _0x33f929) {
                return _0x306ef8 > _0x33f929;
            },
            'yhYAG': function (_0x129852, _0x1755d8) {
                return _0x129852 / _0x1755d8;
            },
            'wUpRM': function (_0x6360cf, _0x5b1e86) {
                return _0x6360cf + _0x5b1e86;
            },
            'bJhmf': function (_0x50916a, _0x33c704) {
                return _0x50916a * _0x33c704;
            },
            'yynjr': function (_0x29a01c, _0x5a1ba0) {
                return _0x29a01c + _0x5a1ba0;
            },
            'YlbCe': function (_0x39249a, _0x2e888e) {
                return _0x39249a * _0x2e888e;
            },
            'leZxi': function (_0x3aaf06, _0x13579f) {
                return _0x3aaf06 + _0x13579f;
            },
            'MjKwt': function (_0x42ebca, _0x2b2121) {
                return _0x42ebca * _0x2b2121;
            },
            'NDXld': function (_0x341509, _0x552a95) {
                return _0x341509 * _0x552a95;
            },
            'DOfdk': function (_0x554421, _0x6a1c6d) {
                return _0x554421 === _0x6a1c6d;
            },
            'GShWg': function (_0x1b922f, _0x65d8a1) {
                return _0x1b922f === _0x65d8a1;
            },
            'eekAy': _0x28cf2c(0x842),
            'IMrtS': _0x28cf2c(0x7ee),
            'ccCbK': _0x28cf2c(0x882),
            'vLWmo': function (_0x4964c0, _0x473150) {
                return _0x4964c0 - _0x473150;
            },
            'PLVzI': function (_0x291643, _0x48f108) {
                return _0x291643 - _0x48f108;
            },
            'nChaC': function (_0x3b7b02, _0x3db3b2) {
                return _0x3b7b02 + _0x3db3b2;
            },
            'ZjMxP': function (_0x218f81, _0x4d17c8) {
                return _0x218f81 * _0x4d17c8;
            },
            'HiGRQ': function (_0x1fca6, _0x5ca56c) {
                return _0x1fca6 * _0x5ca56c;
            },
            'NZPvZ': function (_0x299265, _0x4e3167) {
                return _0x299265(_0x4e3167);
            },
            'lIYmT': function (_0xc3584d, _0x1be0b8) {
                return _0xc3584d + _0x1be0b8;
            },
            'LXaNK': function (_0x4a9e5c, _0x3e8c0d) {
                return _0x4a9e5c * _0x3e8c0d;
            },
            'DRyBI': function (_0x12a898, _0x32c3b3) {
                return _0x12a898 / _0x32c3b3;
            },
            'YdDGe': function (_0x1693db, _0x506ac8) {
                return _0x1693db * _0x506ac8;
            },
            'dhrfP': function (_0xd1c7e, _0x5525b2) {
                return _0xd1c7e + _0x5525b2;
            },
            'DZfZO': function (_0x1a6ad0, _0x3773d3) {
                return _0x1a6ad0 > _0x3773d3;
            },
            'wDjzX': function (_0x22fd88, _0x1fc43b) {
                return _0x22fd88 - _0x1fc43b;
            },
            'TESuV': function (_0xdc91eb, _0x2148b7) {
                return _0xdc91eb <= _0x2148b7;
            },
            'qMoOm': function (_0x4413fc, _0x1d47bd) {
                return _0x4413fc / _0x1d47bd;
            },
            'wRIhq': function (_0x291333, _0x27737e, _0x639f6a, _0x462b47) {
                return _0x291333(_0x27737e, _0x639f6a, _0x462b47);
            },
            'xrcwb': _0x28cf2c(0x90e),
            'kogQV': 'minecraft:villager_angry',
            'PYHXJ': _0x28cf2c(0x581),
            'adjog': function (_0xa62fbe, _0x2d7b9f) {
                return _0xa62fbe && _0x2d7b9f;
            },
            'JMhdq': _0x28cf2c(0x9e6),
            'zfmAh': _0x28cf2c(0x7f9),
            'jIBcK': _0x28cf2c(0x784),
            'PsvdM': _0x28cf2c(0x893),
            'PZPLK': 'frog',
            'GPjIC': 'entity.frog.name',
            'JUtxu': 'wolf',
            'OipqH': 'entity.wolf.name',
            'NbCFv': _0x28cf2c(0xc04),
            'pYPNN': _0x28cf2c(0x74e),
            'FdjrS': _0x28cf2c(0x3b7),
            'JIiQL': _0x28cf2c(0x82c),
            'EtgnT': 'enderman',
            'gTtaW': _0x28cf2c(0x7f0),
            'jhOEx': 'entity.zombie.name',
            'Rbblq': _0x28cf2c(0x79f),
            'bvQdT': _0x28cf2c(0x63e),
            'GBeWv': _0x28cf2c(0x83d),
            'FZTgh': _0x28cf2c(0x729),
            'HuaxH': 'warden',
            'qNaVl': _0x28cf2c(0x60b),
            'ysCpX': 'minecraft:creaking',
            'ZukXt': _0x28cf2c(0xc12),
            'WOekt': _0x28cf2c(0x562),
            'tiBDY': _0x28cf2c(0xa6c),
            'nbUwO': _0x28cf2c(0x8df),
            'czmJH': 'minecraft:villager',
            'ezSXD': _0x28cf2c(0x9b2),
            'aBelo': 'entity.villager.name',
            'efAwz': _0x28cf2c(0x317),
            'BKQLX': 'minecraft:iron_golem',
            'aXzBc': _0x28cf2c(0x989),
            'MsqCu': 'entity.iron_golem.name',
            'yEzEY': _0x28cf2c(0x427),
            'vWRIG': _0x28cf2c(0x5c3),
            'xxpqP': _0x28cf2c(0x949),
            'BoqeJ': _0x28cf2c(0x589),
            'nIHsD': _0x28cf2c(0x37f),
            'jPIzl': _0x28cf2c(0x22c),
            'CiTew': _0x28cf2c(0x536)
        }, _0x1e0ada = [
            {
                'id': _0x28cf2c(0x9f7),
                'event': 'pig',
                'lang': _0x2eda1c[_0x28cf2c(0x4f5)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x316)],
                'event': _0x2eda1c[_0x28cf2c(0x82e)],
                'lang': _0x2eda1c[_0x28cf2c(0x61e)]
            },
            {
                'id': _0x28cf2c(0x4e6),
                'event': _0x2eda1c[_0x28cf2c(0xa9e)],
                'lang': _0x2eda1c['OipqH']
            },
            {
                'id': 'minecraft:piglin',
                'event': _0x2eda1c[_0x28cf2c(0x2ec)],
                'lang': _0x2eda1c[_0x28cf2c(0x8ff)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x7b2)],
                'event': _0x2eda1c[_0x28cf2c(0xacf)],
                'lang': _0x28cf2c(0x573)
            },
            {
                'id': 'minecraft:enderman',
                'event': _0x2eda1c[_0x28cf2c(0x244)],
                'lang': _0x2eda1c[_0x28cf2c(0xc0d)]
            },
            {
                'id': _0x28cf2c(0x77b),
                'event': _0x28cf2c(0x1bd),
                'lang': _0x2eda1c[_0x28cf2c(0x677)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x795)],
                'event': _0x2eda1c[_0x28cf2c(0x49b)],
                'lang': _0x2eda1c['GBeWv']
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0xbb9)],
                'event': _0x2eda1c[_0x28cf2c(0x599)],
                'lang': _0x2eda1c[_0x28cf2c(0x953)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x871)],
                'event': _0x2eda1c[_0x28cf2c(0x307)],
                'lang': _0x2eda1c[_0x28cf2c(0x319)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0xb45)],
                'event': _0x28cf2c(0xa19),
                'lang': _0x2eda1c[_0x28cf2c(0x64f)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0xabf)],
                'event': _0x2eda1c[_0x28cf2c(0x9ad)],
                'lang': _0x2eda1c[_0x28cf2c(0x8a9)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x73b)],
                'event': _0x2eda1c[_0x28cf2c(0x9ad)],
                'lang': _0x2eda1c['aBelo']
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x4df)],
                'event': _0x2eda1c['aXzBc'],
                'lang': _0x2eda1c[_0x28cf2c(0x86d)]
            },
            {
                'id': 'minecraft:horse',
                'event': _0x2eda1c['yEzEY'],
                'lang': _0x2eda1c[_0x28cf2c(0x2c7)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x815)],
                'event': _0x28cf2c(0xa44),
                'lang': 'entity.ender_dragon.name'
            },
            {
                'id': 'minecraft:wither',
                'event': _0x2eda1c[_0x28cf2c(0x982)],
                'lang': _0x2eda1c[_0x28cf2c(0xa2d)]
            },
            {
                'id': _0x2eda1c[_0x28cf2c(0x8b1)],
                'event': _0x2eda1c[_0x28cf2c(0x8b1)],
                'lang': _0x2eda1c['CiTew']
            }
        ];
    _0x4f5052['register']({
        'id': _0x28cf2c(0x8b7),
        'events': {
            'onUse': _0x1b1522 => {
                const _0xe7916f = _0x28cf2c, _0x3af254 = {
                        'XutYr': function (_0x3e7afb, _0xb2ad98) {
                            const _0x266e7e = _0x3124;
                            return _0x2eda1c[_0x266e7e(0x4e7)](_0x3e7afb, _0xb2ad98);
                        },
                        'TYnrg': function (_0x1825c5, _0x368cd5) {
                            return _0x1825c5 - _0x368cd5;
                        },
                        'ZFJCL': function (_0x2323e9, _0xb6cdc3) {
                            const _0x4e1b27 = _0x3124;
                            return _0x2eda1c[_0x4e1b27(0xbc8)](_0x2323e9, _0xb6cdc3);
                        },
                        'dygep': function (_0x4adc04, _0x1dd1f2) {
                            return _0x2eda1c['iOzJo'](_0x4adc04, _0x1dd1f2);
                        },
                        'rqNyh': function (_0xbff96b, _0x4d7958) {
                            const _0xeaba79 = _0x3124;
                            return _0x2eda1c[_0xeaba79(0x41a)](_0xbff96b, _0x4d7958);
                        },
                        'pGmVr': function (_0x2ba7dd, _0x2cc1c6) {
                            return _0x2eda1c['eJZgs'](_0x2ba7dd, _0x2cc1c6);
                        },
                        'xWtFC': function (_0x5d3107, _0x3503c7) {
                            return _0x5d3107 / _0x3503c7;
                        },
                        'UKDYf': function (_0x47ed36, _0x1ddff3) {
                            return _0x47ed36 < _0x1ddff3;
                        },
                        'lLxzF': function (_0x57a8c4, _0x27d9b1) {
                            return _0x57a8c4 + _0x27d9b1;
                        },
                        'wgIEm': function (_0x5ed8c1, _0x105059) {
                            const _0x4f7d67 = _0x3124;
                            return _0x2eda1c[_0x4f7d67(0x553)](_0x5ed8c1, _0x105059);
                        },
                        'LtiHw': function (_0x348970, _0x37270e) {
                            const _0x25c740 = _0x3124;
                            return _0x2eda1c[_0x25c740(0xbc8)](_0x348970, _0x37270e);
                        },
                        'SvhpN': function (_0x2682fa, _0x4a1b93) {
                            const _0x574cd3 = _0x3124;
                            return _0x2eda1c[_0x574cd3(0x895)](_0x2682fa, _0x4a1b93);
                        },
                        'ctIQx': _0x2eda1c[_0xe7916f(0x9ca)],
                        'TedDd': _0x2eda1c[_0xe7916f(0x7b8)],
                        'CLbWZ': _0x2eda1c[_0xe7916f(0x6ad)],
                        'LNadL': function (_0x15edb2, _0x3279aa, _0x5736bd) {
                            return _0x15edb2(_0x3279aa, _0x5736bd);
                        },
                        'qsoSI': _0xe7916f(0x9d3),
                        'fOhXE': _0x2eda1c[_0xe7916f(0x975)],
                        'FStzX': _0xe7916f(0xb92)
                    }, _0x5e9e90 = _0x1b1522, _0x19e211 = _0x5e9e90[_0xe7916f(0x5f1)](), _0x564c95 = _0x5e9e90[_0xe7916f(0xb6a)](), _0x3ef837 = 0x14, _0x1c3562 = 0x2d, _0x96c689 = ![], _0x29698d = _0x2eda1c[_0xe7916f(0x4d8)](_0x467cb6(_0x5e9e90, _0x2eda1c[_0xe7916f(0x728)]), 0x0);
                if (!_0x29698d && _0x2eda1c[_0xe7916f(0x88e)](_0x5e9e90[_0xe7916f(0x271)](), _0x2eda1c['QSxrU'])) {
                    _0x5e9e90[_0xe7916f(0x7b1)]({ 'translate': _0x2eda1c[_0xe7916f(0x2cb)] });
                    return;
                }
                const _0x14f669 = _0x3ef837, _0x20b5d2 = 0xf, _0x123f0e = 0.3;
                for (let _0x2bdc7c = 0x1; _0x2eda1c['iJxut'](_0x2bdc7c, _0x20b5d2); _0x2bdc7c++) {
                    const _0x4c7c60 = _0x2eda1c['SLNvG'](_0x2eda1c[_0xe7916f(0x957)](_0x2bdc7c, _0x20b5d2), _0x14f669), _0x3569f6 = {
                            'x': _0x2eda1c['dOcky'](_0x564c95['x'], _0x2eda1c[_0xe7916f(0x8de)](_0x19e211['x'], _0x4c7c60)),
                            'y': _0x2eda1c[_0xe7916f(0x58c)](_0x564c95['y'], _0x2eda1c[_0xe7916f(0x26b)](_0x19e211['y'], _0x4c7c60)),
                            'z': _0x564c95['z'] + _0x19e211['z'] * _0x4c7c60
                        };
                    _0x96c689 && _0x5e9e90[_0xe7916f(0xb28)]['spawnParticle'](_0x2eda1c[_0xe7916f(0x252)], _0x3569f6);
                    if (_0x2eda1c[_0xe7916f(0x35b)](_0x2eda1c['mlfUa'](_0x2bdc7c, 0x3), 0x0)) {
                        const _0x10f8c6 = _0x123f0e * _0x2eda1c[_0xe7916f(0xb64)](_0x2bdc7c, _0x20b5d2), _0x257d4a = {
                                'x': 0x0,
                                'y': 0x1,
                                'z': 0x0
                            }, _0x427527 = {
                                'x': _0x2eda1c[_0xe7916f(0x4e7)](_0x19e211['z'] * _0x257d4a['y'], _0x2eda1c['dQJqW'](_0x19e211['y'], _0x257d4a['z'])),
                                'y': _0x2eda1c[_0xe7916f(0xb8e)](_0x19e211['x'], _0x257d4a['z']) - _0x19e211['z'] * _0x257d4a['x'],
                                'z': _0x2eda1c[_0xe7916f(0xb8e)](_0x19e211['y'], _0x257d4a['x']) - _0x2eda1c['GiWZE'](_0x19e211['x'], _0x257d4a['y'])
                            }, _0x9303c2 = Math[_0xe7916f(0x2f8)](_0x2eda1c[_0xe7916f(0x761)](_0x2eda1c['FHwTm'](_0x2eda1c['dWIsU'](_0x427527['x'], _0x427527['x']), _0x2eda1c['QHFHK'](_0x427527['y'], _0x427527['y'])), _0x427527['z'] * _0x427527['z']));
                        if (_0x2eda1c[_0xe7916f(0x8d6)](_0x9303c2, 0x0)) {
                            _0x427527['x'] /= _0x9303c2, _0x427527['y'] /= _0x9303c2, _0x427527['z'] /= _0x9303c2;
                            for (let _0x11ab07 = 0x0; _0x2eda1c[_0xe7916f(0x403)](_0x11ab07, 0x168); _0x11ab07 += 0x5a) {
                                const _0x40123c = _0x2eda1c[_0xe7916f(0x553)](_0x11ab07, _0x2eda1c[_0xe7916f(0x1b7)](Math['PI'], 0xb4)), _0x22d8f8 = Math[_0xe7916f(0xa96)](_0x40123c), _0x2dbef3 = Math[_0xe7916f(0x884)](_0x40123c), _0xea2ae3 = {
                                        'x': _0x2eda1c[_0xe7916f(0x9ab)](_0x2eda1c[_0xe7916f(0xbc2)](_0x22d8f8, _0x427527['x']), _0x2eda1c[_0xe7916f(0x63b)](_0x2dbef3, _0x19e211['x'])),
                                        'y': _0x2eda1c[_0xe7916f(0xb8e)](_0x22d8f8, _0x427527['y']) + _0x2dbef3 * _0x19e211['y'],
                                        'z': _0x2eda1c[_0xe7916f(0x823)](_0x2eda1c[_0xe7916f(0xb8e)](_0x22d8f8, _0x427527['z']), _0x2eda1c['YlbCe'](_0x2dbef3, _0x19e211['z']))
                                    }, _0x8c0481 = {
                                        'x': _0x2eda1c['leZxi'](_0x3569f6['x'], _0x2eda1c[_0xe7916f(0x243)](_0xea2ae3['x'], _0x10f8c6)),
                                        'y': _0x2eda1c[_0xe7916f(0x531)](_0x3569f6['y'], _0x2eda1c['dQJqW'](_0xea2ae3['y'], _0x10f8c6)),
                                        'z': _0x2eda1c[_0xe7916f(0x531)](_0x3569f6['z'], _0x2eda1c['NDXld'](_0xea2ae3['z'], _0x10f8c6))
                                    };
                                _0x96c689 && _0x5e9e90[_0xe7916f(0xb28)]['spawnParticle']('minecraft:blue_flame_particle', _0x8c0481);
                            }
                        }
                    }
                }
                const _0xcee5b9 = _0x5e9e90[_0xe7916f(0xb28)]['getEntities']({
                    'location': _0x5e9e90[_0xe7916f(0x2c0)],
                    'maxDistance': _0x3ef837
                });
                function _0x4f918b(_0x4a7082, _0xcdd064, _0xb4332b) {
                    const _0x4259c4 = _0xe7916f, _0x3798df = 0.5, _0x49ad7d = {
                            'x': _0x3af254[_0x4259c4(0xac7)](_0xcdd064['x'], _0x4a7082['x']),
                            'y': _0xcdd064['y'] - _0x4a7082['y'],
                            'z': _0x3af254[_0x4259c4(0x96c)](_0xcdd064['z'], _0x4a7082['z'])
                        }, _0x517128 = Math[_0x4259c4(0x2f8)](_0x3af254['ZFJCL'](_0x3af254['dygep'](_0x49ad7d['x'], _0x49ad7d['x']) + _0x3af254['rqNyh'](_0x49ad7d['y'], _0x49ad7d['y']), _0x3af254[_0x4259c4(0x945)](_0x49ad7d['z'], _0x49ad7d['z']))), _0x301df2 = {
                            'x': _0x3af254[_0x4259c4(0x6b1)](_0x49ad7d['x'], _0x517128),
                            'y': _0x3af254[_0x4259c4(0x6b1)](_0x49ad7d['y'], _0x517128),
                            'z': _0x3af254[_0x4259c4(0x6b1)](_0x49ad7d['z'], _0x517128)
                        }, _0x7ff322 = Math[_0x4259c4(0x657)](_0x3af254[_0x4259c4(0x714)](_0x517128, _0x3798df));
                    for (let _0x6e8024 = 0x1; _0x3af254[_0x4259c4(0x56d)](_0x6e8024, _0x7ff322); _0x6e8024++) {
                        const _0x5ce01b = _0x3af254['rqNyh'](_0x6e8024, _0x3798df) / _0x517128, _0x2f21de = {
                                'x': _0x3af254[_0x4259c4(0x713)](_0x4a7082['x'], _0x3af254[_0x4259c4(0xa3d)](_0x3af254[_0x4259c4(0xa3d)](_0x301df2['x'], _0x5ce01b), _0x517128)),
                                'y': _0x3af254['lLxzF'](_0x4a7082['y'], _0x3af254[_0x4259c4(0x409)](_0x3af254[_0x4259c4(0x945)](_0x301df2['y'], _0x5ce01b), _0x517128)),
                                'z': _0x3af254['LtiHw'](_0x4a7082['z'], _0x3af254['rqNyh'](_0x301df2['z'] * _0x5ce01b, _0x517128))
                            }, _0x54a294 = {
                                'x': Math[_0x4259c4(0x904)](_0x2f21de['x']),
                                'y': Math['floor'](_0x2f21de['y']),
                                'z': Math[_0x4259c4(0x904)](_0x2f21de['z'])
                            };
                        try {
                            const _0x11dba1 = _0xb4332b[_0x4259c4(0x3c0)](_0x54a294);
                            if (_0x11dba1 && !_0x443f8d[_0x4259c4(0x620)](_0x11dba1['typeId']) && !_0xc0f2fe['includes'](_0x11dba1[_0x4259c4(0x1b9)]))
                                return _0x96c689 && (_0xb4332b[_0x4259c4(0xb85)](_0x4259c4(0x797), _0x2f21de), _0x5e9e90['sendMessage'](_0x4259c4(0x284) + _0x11dba1[_0x4259c4(0x1b9)])), ![];
                            _0x96c689 && _0x3af254[_0x4259c4(0x98a)](_0x6e8024 % 0x2, 0x0) && _0xb4332b[_0x4259c4(0xb85)](_0x3af254[_0x4259c4(0x2dd)], _0x2f21de);
                        } catch (_0x17cff0) {
                            console[_0x4259c4(0x73d)](_0x3af254['TedDd'] + _0x17cff0);
                        }
                    }
                    return !![];
                }
                for (const _0x33922d of _0xcee5b9) {
                    if (_0x2eda1c[_0xe7916f(0xc17)](_0x33922d['id'], _0x5e9e90['id']))
                        continue;
                    let _0x56fc0c = ![], _0x2d3d39 = null;
                    if (_0x2eda1c[_0xe7916f(0xbaa)](_0x33922d[_0xe7916f(0x1b9)], _0x2eda1c[_0xe7916f(0xbca)])) {
                        const _0xc6badd = _0x33922d['getComponent'](_0x2eda1c['IMrtS']);
                        if (_0xc6badd && _0xc6badd[_0xe7916f(0x6f6)]()[_0xe7916f(0x51f)] > 0x0) {
                            _0x56fc0c = !![];
                            const _0x4e5075 = _0x1e0ada[_0xe7916f(0x65e)](_0x80378a => _0x80378a['id'] === _0xe7916f(0x22c));
                            _0x4e5075 && (_0x2d3d39 = _0x4e5075), _0x96c689 && _0x5e9e90[_0xe7916f(0x7b1)](_0x2eda1c[_0xe7916f(0xa42)]);
                        }
                    }
                    const _0x5a7ef1 = _0x56fc0c ? _0x2d3d39 : _0x1e0ada[_0xe7916f(0x65e)](_0x2d0945 => _0x2d0945['id'] === _0x33922d['typeId']);
                    if (!_0x5a7ef1)
                        continue;
                    const _0x4b71c4 = {
                            'x': _0x33922d[_0xe7916f(0x2c0)]['x'],
                            'y': _0x2eda1c[_0xe7916f(0x58c)](_0x33922d[_0xe7916f(0x2c0)]['y'], 0x1),
                            'z': _0x33922d[_0xe7916f(0x2c0)]['z']
                        }, _0x379107 = _0x33922d['getHeadLocation'] ? _0x33922d[_0xe7916f(0xb6a)]() : _0x4b71c4, _0xdcbc78 = {
                            'x': _0x379107['x'] - _0x564c95['x'],
                            'y': _0x2eda1c['vLWmo'](_0x379107['y'], _0x564c95['y']),
                            'z': _0x2eda1c[_0xe7916f(0x919)](_0x379107['z'], _0x564c95['z'])
                        }, _0x2d8c78 = Math[_0xe7916f(0x2f8)](_0x2eda1c['FHwTm'](_0x2eda1c[_0xe7916f(0x5a9)](_0x2eda1c[_0xe7916f(0xb6e)](_0xdcbc78['x'], _0xdcbc78['x']), _0x2eda1c['HiGRQ'](_0xdcbc78['y'], _0xdcbc78['y'])), _0x2eda1c['SLNvG'](_0xdcbc78['z'], _0xdcbc78['z'])));
                    if (_0x2eda1c[_0xe7916f(0x8d6)](_0x2d8c78, _0x3ef837))
                        continue;
                    const _0x88cf17 = _0x416893 => {
                            const _0x36f244 = _0xe7916f, _0x1ba5a9 = Math[_0x36f244(0x2f8)](_0x2eda1c[_0x36f244(0xb8f)](_0x2eda1c[_0x36f244(0xb8f)](_0x416893['x'] * _0x416893['x'], _0x2eda1c[_0x36f244(0x74f)](_0x416893['y'], _0x416893['y'])), _0x2eda1c[_0x36f244(0x74f)](_0x416893['z'], _0x416893['z'])));
                            if (_0x2eda1c[_0x36f244(0x403)](_0x1ba5a9, 0.0001))
                                return {
                                    'x': 0x0,
                                    'y': 0x0,
                                    'z': 0x0
                                };
                            return {
                                'x': _0x2eda1c[_0x36f244(0x2ff)](_0x416893['x'], _0x1ba5a9),
                                'y': _0x2eda1c[_0x36f244(0x61f)](_0x416893['y'], _0x1ba5a9),
                                'z': _0x416893['z'] / _0x1ba5a9
                            };
                        }, _0x50154e = _0x88cf17(_0xdcbc78), _0x231fb1 = _0x2eda1c['NZPvZ'](_0x88cf17, _0x19e211), _0x4f5819 = _0x2eda1c[_0xe7916f(0xa34)](_0x2eda1c[_0xe7916f(0xb8f)](_0x2eda1c[_0xe7916f(0x553)](_0x231fb1['x'], _0x50154e['x']), _0x2eda1c[_0xe7916f(0xb8e)](_0x231fb1['y'], _0x50154e['y'])), _0x2eda1c[_0xe7916f(0x8a8)](_0x231fb1['z'], _0x50154e['z'])), _0x523d11 = Math[_0xe7916f(0x6da)](-0x1, Math['min'](0x1, _0x4f5819)), _0x286879 = Math[_0xe7916f(0x30b)](_0x523d11), _0x2b80d5 = _0x2eda1c['NDXld'](_0x286879, _0x2eda1c[_0xe7916f(0xc1e)](0xb4, Math['PI'])), _0x2005a9 = _0x2eda1c[_0xe7916f(0x3fe)](_0x1c3562, 1.2), _0x4e18df = 0x2, _0x501e1b = Math[_0xe7916f(0x2f8)](_0x2eda1c[_0xe7916f(0xbf9)](_0xdcbc78['x'] * _0xdcbc78['x'], _0x2eda1c['bJhmf'](_0xdcbc78['z'], _0xdcbc78['z']))), _0x4e6ecf = Math['abs'](_0xdcbc78['y']), _0x2c40f2 = _0x2eda1c['DZfZO'](_0x4e6ecf, _0x501e1b);
                    let _0x38297a = _0x2c40f2 ? _0x2eda1c[_0xe7916f(0x1a9)](_0x2005a9, _0x4e18df) : _0x2005a9;
                    const _0x56811c = Math[_0xe7916f(0x6da)](0.2, _0x2eda1c[_0xe7916f(0x519)](0x1, _0x2eda1c[_0xe7916f(0x957)](_0x2d8c78, _0x3ef837) * 0.5));
                    _0x38297a += _0x2005a9 * _0x56811c;
                    _0x96c689 && _0x5e9e90[_0xe7916f(0x7b1)](_0xe7916f(0x386) + _0x33922d[_0xe7916f(0x1b9)] + _0xe7916f(0x807) + _0x2d8c78[_0xe7916f(0x643)](0x1) + _0xe7916f(0x5a1) + _0x2b80d5[_0xe7916f(0x643)](0x1) + _0xe7916f(0xab0) + _0x38297a[_0xe7916f(0x643)](0x1) + '°\x0aDot:\x20' + _0x4f5819['toFixed'](0x3) + _0xe7916f(0x2b3) + _0x2c40f2);
                    const _0x59dddf = _0x2eda1c[_0xe7916f(0x99b)](_0x2b80d5, _0x2eda1c[_0xe7916f(0x6a7)](_0x38297a, 0x2));
                    let _0x425ba2 = ![];
                    _0x59dddf && (_0x425ba2 = _0x2eda1c[_0xe7916f(0xb81)](_0x4f918b, _0x564c95, _0x379107, _0x5e9e90[_0xe7916f(0xb28)]));
                    if (_0x96c689) {
                        let _0x2a44f9;
                        if (_0x59dddf && _0x425ba2)
                            _0x2a44f9 = _0x2eda1c[_0xe7916f(0x302)];
                        else
                            _0x59dddf ? _0x2a44f9 = _0x2eda1c[_0xe7916f(0x39f)] : _0x2a44f9 = _0x2eda1c[_0xe7916f(0x7eb)];
                        _0x5e9e90[_0xe7916f(0xb28)][_0xe7916f(0xb85)](_0x2a44f9, _0x379107), _0x5e9e90['sendMessage'](_0xe7916f(0x386) + _0x33922d[_0xe7916f(0x1b9)] + _0xe7916f(0xb79) + _0x2d8c78[_0xe7916f(0x643)](0x1) + _0xe7916f(0x218) + _0x59dddf + _0xe7916f(0xb1a) + _0x425ba2);
                    }
                    if (_0x2eda1c[_0xe7916f(0xb97)](_0x59dddf, _0x425ba2)) {
                        if (_0x5a7ef1) {
                            if (_0x29698d || _0x5e9e90[_0xe7916f(0x271)]() === _0x2eda1c[_0xe7916f(0x692)]) {
                                _0x2eda1c[_0xe7916f(0x88e)](_0x5e9e90[_0xe7916f(0x271)](), _0x2eda1c[_0xe7916f(0x692)]) && _0x2c8ecf(_0x5e9e90, _0x2eda1c[_0xe7916f(0x728)], 0x1, !![]);
                                _0x5e9e90[_0xe7916f(0x245)](_0x2eda1c[_0xe7916f(0x630)], { 'players': [_0x5e9e90[_0xe7916f(0x497)]] });
                                const _0x4b7879 = 0xf;
                                _0x1ea475['runTimeout'](() => {
                                    const _0x19d364 = _0xe7916f, _0x41b5e7 = _0x3af254[_0x19d364(0x408)][_0x19d364(0x1f5)]('|');
                                    let _0x55016d = 0x0;
                                    while (!![]) {
                                        switch (_0x41b5e7[_0x55016d++]) {
                                        case '0':
                                            _0x3af254[_0x19d364(0x8f3)](_0x467466, _0x5e9e90, new _0x5e5400(_0x19d364(0x300) + _0x5a7ef1[_0x19d364(0x5c9)] + '_picture'));
                                            continue;
                                        case '1':
                                            _0x5e9e90['playSound'](_0x3af254[_0x19d364(0x3c1)]);
                                            continue;
                                        case '2':
                                            _0x5e9e90[_0x19d364(0xa70)](_0x3af254['fOhXE']);
                                            continue;
                                        case '3':
                                            _0x5e9e90[_0x19d364(0x7b1)]({
                                                'rawtext': [
                                                    { 'translate': _0x19d364(0x3ee) },
                                                    { 'translate': '' + _0x5a7ef1[_0x19d364(0x676)] },
                                                    { 'text': _0x3af254[_0x19d364(0x987)] }
                                                ]
                                            });
                                            continue;
                                        case '4':
                                            _0x5e9e90[_0x19d364(0x89b)]['fade']({
                                                'fadeColor': {
                                                    'red': 0x1,
                                                    'green': 0x1,
                                                    'blue': 0x1
                                                },
                                                'fadeTime': {
                                                    'fadeInTime': 0.1,
                                                    'fadeOutTime': 0.5,
                                                    'holdTime': 0.1
                                                }
                                            });
                                            continue;
                                        }
                                        break;
                                    }
                                }, _0x4b7879);
                                return;
                            }
                        }
                    }
                }
                _0x5e9e90[_0xe7916f(0x7b1)]({ 'translate': _0x2eda1c[_0xe7916f(0xbf6)] });
            }
        }
    });
}
function _0x1c85ab() {
    const _0x46a9f1 = _0x21f734, _0x40caf7 = {
            'dliVE': 'sb_bf:scarecrow',
            'PXzMw': function (_0x113f98, _0x3ff981) {
                return _0x113f98 === _0x3ff981;
            },
            'wDtRJ': _0x46a9f1(0x1a5),
            'VhCKC': function (_0x438a50, _0x44ed89) {
                return _0x438a50(_0x44ed89);
            },
            'Czdfj': _0x46a9f1(0x5fb),
            'RjYTa': _0x46a9f1(0xa2a),
            'UlqFz': _0x46a9f1(0x9dc),
            'osMiy': _0x46a9f1(0x443),
            'TfzZM': _0x46a9f1(0xb7c),
            'JfHNF': _0x46a9f1(0xbb6),
            'eVPmB': 'minecraft:acacia_fence',
            'dtxEU': _0x46a9f1(0x613),
            'CANYt': _0x46a9f1(0x4c1),
            'gaCDp': 'minecraft:bamboo_fence',
            'WulEw': 'minecraft:nether_brick_fence',
            'zrElP': _0x46a9f1(0x34c),
            'UcjcO': _0x46a9f1(0x384),
            'INDXo': _0x46a9f1(0xb3e),
            'ZOTFQ': _0x46a9f1(0x786),
            'HFDdm': _0x46a9f1(0x297),
            'oHvEp': _0x46a9f1(0x85f),
            'LLMwy': _0x46a9f1(0x42a),
            'QfaIG': _0x46a9f1(0x9d0),
            'LDDTR': _0x46a9f1(0x3d9)
        };
    _0x4f5052[_0x46a9f1(0x341)](_0x40caf7['RjYTa'], _0x4b6274), _0x347ee5();
    const _0x4ba878 = [
        _0x40caf7[_0x46a9f1(0x91d)],
        _0x40caf7['osMiy'],
        _0x40caf7[_0x46a9f1(0x96d)],
        _0x40caf7[_0x46a9f1(0x57f)],
        _0x40caf7['eVPmB'],
        _0x40caf7[_0x46a9f1(0x61d)],
        _0x40caf7[_0x46a9f1(0x53d)],
        _0x46a9f1(0x3d7),
        'minecraft:mangrove_fence',
        _0x40caf7[_0x46a9f1(0x9e4)],
        _0x40caf7[_0x46a9f1(0x421)],
        'minecraft:crimson_fence',
        _0x40caf7[_0x46a9f1(0x366)],
        _0x40caf7[_0x46a9f1(0x1fa)],
        _0x46a9f1(0x4bf),
        _0x40caf7['INDXo'],
        _0x40caf7[_0x46a9f1(0x238)],
        _0x40caf7[_0x46a9f1(0x61c)],
        _0x46a9f1(0x4ed),
        _0x40caf7[_0x46a9f1(0xae0)],
        'sb_bf:pale_oak_special_fence',
        _0x40caf7[_0x46a9f1(0x601)],
        _0x40caf7['QfaIG'],
        _0x40caf7[_0x46a9f1(0x82f)],
        _0x46a9f1(0x294)
    ];
    _0x4f5052[_0x46a9f1(0x4c3)]({
        'id': _0x40caf7['dliVE'],
        'events': {
            'onUseOnBefore': _0xd83d6e => {
                const _0x3c176e = _0x46a9f1, _0x5e3e1d = {
                        'vnxrx': _0x40caf7['dliVE'],
                        'ahXuT': function (_0x1119c6, _0x2b0f2e, _0x364a52, _0x57f3e5) {
                            return _0x1119c6(_0x2b0f2e, _0x364a52, _0x57f3e5);
                        },
                        'WcgDu': 'dig.grass',
                        'GGOjk': _0x3c176e(0x2fb)
                    }, _0x5bbb37 = _0xd83d6e[_0x3c176e(0x87b)], _0xe7f9dd = _0xd83d6e[_0x3c176e(0x8eb)];
                if (_0x4ba878[_0x3c176e(0x620)](_0x5bbb37[_0x3c176e(0x1b9)]) && _0x40caf7[_0x3c176e(0xaf5)](_0x5bbb37[_0x3c176e(0x291)]()?.[_0x3c176e(0x1b9)], _0x40caf7['wDtRJ'])) {
                    if (_0xd83d6e[_0x3c176e(0x9e3)] !== 'Up') {
                        const _0x2c8a04 = _0x40caf7[_0x3c176e(0x791)](_0x17e1c1, _0xe7f9dd[_0x3c176e(0x5f1)]());
                        _0x9976e1[_0x3c176e(0xb7e)](() => {
                            const _0x25910f = _0x3c176e;
                            _0x5bbb37[_0x25910f(0x291)]()?.[_0x25910f(0x772)](_0x1b7838['resolve'](_0x5e3e1d[_0x25910f(0x1af)], { 'minecraft:cardinal_direction': _0x2c8a04 })), _0x5e3e1d[_0x25910f(0x9c4)](_0xed22af, _0xe7f9dd, 0x1, !![]), _0xe7f9dd[_0x25910f(0xb28)]['playSound'](_0x5e3e1d[_0x25910f(0x368)], _0x5bbb37[_0x25910f(0x2c0)]);
                        });
                    }
                    _0x9976e1[_0x3c176e(0xb7e)](() => {
                        const _0xe3111b = _0x3c176e;
                        _0xe7f9dd[_0xe3111b(0xb28)][_0xe3111b(0xa70)](_0x5e3e1d[_0xe3111b(0x774)], _0x5bbb37[_0xe3111b(0x2c0)]);
                    });
                    return;
                }
                _0xe7f9dd[_0x3c176e(0x7b1)]({ 'translate': _0x40caf7[_0x3c176e(0x3a5)] });
            }
        }
    }), _0x4f5052[_0x46a9f1(0x48b)]();
}
var _0x4f5052 = class {
    static [_0x21f734(0x4c3)](_0x264a60) {
        const _0x35f0e3 = _0x21f734, _0x3238f9 = {
                'CFjNS': function (_0x2bf1d8, _0x5d6f1d) {
                    return _0x2bf1d8 === _0x5d6f1d;
                },
                'IQfqf': _0x35f0e3(0x228)
            }, {id: _0x4f430d} = _0x264a60;
        Object[_0x35f0e3(0x69b)](_0x264a60)['forEach'](_0x5f5c71 => {
            const _0x177a27 = _0x35f0e3, _0x2b9cde = this[_0x177a27(0x9f1)][_0x5f5c71];
            if (_0x2b9cde && _0x3238f9[_0x177a27(0xb2a)](typeof _0x2b9cde[_0x177a27(0x760)], _0x3238f9[_0x177a27(0xaeb)])) {
                const _0x43d9f1 = _0x264a60[_0x5f5c71];
                _0x43d9f1 && _0x2b9cde[_0x177a27(0x760)]({
                    'id': _0x4f430d,
                    ..._0x43d9f1
                });
            }
        });
    }
    static [_0x21f734(0x341)](_0x20913f, _0x217dea) {
        const _0x1a9fc4 = _0x21f734, _0x24d654 = {
                'hvLsv': function (_0xcb0b34, _0x477de7) {
                    return _0xcb0b34 === _0x477de7;
                },
                'rmPtM': _0x1a9fc4(0xc10)
            };
        if (_0x24d654[_0x1a9fc4(0x7e7)](typeof _0x20913f, _0x24d654[_0x1a9fc4(0x9f0)]))
            this[_0x1a9fc4(0x9f1)][_0x20913f] = _0x217dea;
        else {
            const _0x26db85 = _0x20913f[_0x1a9fc4(0x497)][_0x1a9fc4(0x57d)]();
            this[_0x1a9fc4(0x9f1)][_0x26db85] = _0x20913f;
        }
    }
    static [_0x21f734(0x48b)]() {
        const _0x3deb20 = _0x21f734, _0x21f6d2 = {
                'tAXBh': function (_0x2f041a, _0x21d133) {
                    return _0x2f041a === _0x21d133;
                },
                'CYTXg': _0x3deb20(0x228)
            };
        Object[_0x3deb20(0x5a8)](this[_0x3deb20(0x9f1)])['forEach'](([_0xd94044, _0x5a206b]) => {
            const _0x15b607 = _0x3deb20;
            _0x21f6d2['tAXBh'](typeof _0x5a206b[_0x15b607(0x48b)], _0x21f6d2['CYTXg']) && _0x5a206b[_0x15b607(0x48b)]();
        });
    }
};
_0x25e7d0(_0x4f5052, _0x21f734(0x9f1), {});
var _0x49f8f7 = class extends _0x2e442a {
    constructor() {
        const _0x4419bb = _0x21f734, _0x135b8e = { 'azrJt': _0x4419bb(0x1ce) };
        super(_0x135b8e[_0x4419bb(0xb8a)]);
    }
    [_0x21f734(0x9a6)]() {
        const _0x3c6b20 = {
            'vsQxE': function (_0x4e3873) {
                return _0x4e3873();
            }
        };
        _0x3c6b20['vsQxE'](_0x1c85ab);
    }
};
import {
    ItemStack as _0x24e4b5,
    system as _0x1a8611,
    world as _0x10eede
} from '@minecraft/server';
var _0x21d8b3 = class extends _0x2e442a {
        constructor() {
            const _0x2926f6 = _0x21f734;
            super(_0x2926f6(0x41c));
        }
        [_0x21f734(0x9a6)]() {
            const _0x5ae8f2 = _0x21f734, _0x3dfcf5 = {
                    'Dkbhp': function (_0x84997e, _0x2abc23, _0x676fd8) {
                        return _0x84997e(_0x2abc23, _0x676fd8);
                    }
                };
            _0x10eede[_0x5ae8f2(0x327)]['playerSpawn'][_0x5ae8f2(0x725)](_0x21cf7f => {
                const _0x758bf = _0x5ae8f2, _0x192e4e = _0x21cf7f['player'];
                if (_0x192e4e[_0x758bf(0x206)](_0x207994 + ':has_joined'))
                    return;
                _0x1a8611[_0x758bf(0x873)](() => {
                    const _0x54a359 = _0x758bf;
                    _0x192e4e['sendMessage']({ 'translate': _0x207994 + _0x54a359(0x8e2) }), _0x192e4e[_0x54a359(0xa70)]('' + _0x4f7515);
                }, 0x64), _0x21d453[_0x758bf(0x3e1)](_0x598a43 => {
                    const _0x4d5ca = _0x758bf;
                    if (_0x598a43 === null)
                        return;
                    const _0x1f5492 = new _0x24e4b5(_0x598a43);
                    _0x3dfcf5[_0x4d5ca(0x751)](_0x467466, _0x192e4e, _0x1f5492);
                }), _0x192e4e['addTag'](_0x207994 + _0x758bf(0x2a1));
            });
        }
    }, _0xa42eb0 = [
        new _0x100bea(),
        new _0x5d0530(),
        new _0x49f8f7(),
        new _0x21d8b3(),
        new _0x16ec4f(),
        new _0x147c24()
    ];
_0xa42eb0[_0x21f734(0x3e1)](_0x1a41ff => {
    const _0x27b06d = _0x21f734;
    _0x1a41ff[_0x27b06d(0x48b)]();
});