#Whatever is given here to @s will be given to the player wearing the complete set armor
#Fish Armor
effect @s water_breathing 2 1 true
execute if block ~ ~ ~ minecraft:water run effect @s speed 2 2 true