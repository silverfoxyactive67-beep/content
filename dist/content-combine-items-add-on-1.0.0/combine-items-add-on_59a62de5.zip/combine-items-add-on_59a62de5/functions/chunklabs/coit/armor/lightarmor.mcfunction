#Whatever is given here to @s will be given to the player wearing the complete set armor
#Light Armor (Gives light to the player)
fill ~ ~ ~ ~ ~ ~ minecraft:light_block ["block_light_level"=10] replace minecraft:air
#Replace light block with air around the player (6 fill commands, left, right, front, back, up, down)
fill ~2 ~2 ~2 ~-2 ~-2 ~-2 minecraft:air replace minecraft:light_block
fill ~ ~ ~ ~ ~ ~ minecraft:light_block ["block_light_level"=10] replace minecraft:air
tag @s add cl_coit.wearslightarmor
#say test