#Whatever is given here to @s will be given to the player wearing the complete set armor
effect @a[r=4] regeneration 2 1 true
effect @s strength 2 2 true
effect @s slowness 2 1 true