execute as @a[hasitem=[{item=cl_coit:fish.helmet,location=slot.armor.head}]] as @s[hasitem=[{item=cl_coit:fish.chest,location=slot.armor.chest}]] as @s[hasitem=[{item=cl_coit:fish.leggings,location=slot.armor.legs}]] as @s[hasitem=[{item=cl_coit:fish.boots,location=slot.armor.feet}]] run function chunklabs/coit/armor/fisharmor
execute as @a[hasitem=[{item=cl_coit:lava.helmet,location=slot.armor.head}]] as @s[hasitem=[{item=cl_coit:lava.chest,location=slot.armor.chest}]] as @s[hasitem=[{item=cl_coit:lava.leggings,location=slot.armor.legs}]] as @s[hasitem=[{item=cl_coit:lava.boots,location=slot.armor.feet}]] run function chunklabs/coit/armor/lavaarmor
execute as @a[hasitem=[{item=cl_coit:light.helmet,location=slot.armor.head}]] as @s[hasitem=[{item=cl_coit:light.chest,location=slot.armor.chest}]] as @s[hasitem=[{item=cl_coit:light.leggings,location=slot.armor.legs}]] as @s[hasitem=[{item=cl_coit:light.boots,location=slot.armor.feet}]] at @s run function chunklabs/coit/armor/lightarmor
execute as @a[hasitem=[{item=cl_coit:warden.helmet,location=slot.armor.head}]] as @s[hasitem=[{item=cl_coit:warden.chest,location=slot.armor.chest}]] as @s[hasitem=[{item=cl_coit:warden.leggings,location=slot.armor.legs}]] as @s[hasitem=[{item=cl_coit:warden.boots,location=slot.armor.feet}]] run function chunklabs/coit/armor/wardenarmor
#execute as @a[hasitem=[{item=cl_coit:ender.helmet,location=slot.armor.head}]] at @s run function chunklabs/coit/armor/enderhelmet
execute as @a[hasitem=[{item=cl_coit:jetpack.chest,location=slot.armor.chest}]] at @s run function chunklabs/coit/armor/jetpack
execute as @a[hasitem=[{item=cl_coit:slime.boots,location=slot.armor.feet}]] at @s run function chunklabs/coit/armor/slimeboots


