#Whatever is given here to @s will be given to the player wearing the complete set armor
effect @s fire_resistance 2 1 true
fill ~3 ~-1 ~3 ~-3 ~-1 ~-3 minecraft:magma replace minecraft:lava