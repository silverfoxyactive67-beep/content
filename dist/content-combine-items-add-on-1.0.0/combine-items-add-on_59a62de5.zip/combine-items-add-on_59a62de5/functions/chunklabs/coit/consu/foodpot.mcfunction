#Food Potions
#Combine Foods with potions to get a potion that gives you the effects of the food
#Moved to scripting API