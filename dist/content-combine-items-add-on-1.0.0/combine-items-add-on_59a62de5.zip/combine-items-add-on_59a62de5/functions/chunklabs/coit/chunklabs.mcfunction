#######################
# Combine Items DX AD #
#    by: Chunklabs    #
#######################
#  Version: 1.0.0     #
#######################

#The world is not in your books and maps, it's out there.
#Minute by minute, hour by hour, day by day, year by year.

#######################
#    Security         #
#######################
#Security Cameras, Lasers?, Turrets?, Detectors, Secret Doors
#function chunklabs/coit/secu/cams => Moved to scripting API for now
execute as @e[type=cl_coit:detector] at @s run function chunklabs/coit/secu/detector
#######################
#    Weapons         #
#######################
#Blaze Sword,
#Ice Wand, => Shoots Ice beam
#Double Axe, => AoE Attack
#Potion Sword, => Puddle of Potion
#Thunder Sword, => Lightning Strike on interact and hit
#Amethyst Sword, => Protective shield on interact
#Slime Sword => Bounce Away Enemies on interact
#Frost Blade => Slows Enemies on hit
#Spear => Larger Range
#Poisoned Trident => Poison on hit
#Phantom Scythe => AoE Attack + Launch 
#Echo Blade => Echoes on hit

#######################
#    Bows             #
#######################
#Fire Bow, 
#Ice Bow, 
#Slime Bow, 
#Totem Bow, 
#Rod Bow

#######################
#    Tools            #
#######################
#Supercharged Axe, Supercharged Pickaxe, Torch Launcher, Aquatic Pickaxe, Magnet Compass, Replanting Hoe


#######################
#    Armor            #
#######################
#Fish Armor, => Swim Faster, Water Breathing
#Lava Armor, => Fire Resistance, Lava Walking, Damage When hit
#Light Armor, => Speed, Night Vision, Light where you go
#Warden Armor => Super Strong, Slower, Knockback Resistance, Players around you get Regeneration
function chunklabs/coit/armor/abilities

#######################
#    Blocks           #
#######################
#TNT, Hollow, Chests, Colored


#######################
#    Consumables      #
#######################
#Special Effects for Combining Foods with Potions (combine to improve saturation while saving inventory space)

#######################
#    Combi            #
#######################
#Combine Items to get structures you can use to build with

#######################
#    Guide            #
#######################
#Guide Book

#######################
#    Tutorial         #
#######################
#Tutorial Prompt opens when first opening combiner




#Add all items/blocks to the game (JSON)
        #Blocks

        #Items

        #Entities

        #Loot tables

#Add all recipes to the game (JSON)

#Add all textures to the game (PNG)

#Add all sounds to the game (WAV)

#Add all programming to the game (functions/Scripting)

#Add Guide Book to the game (JSON)

#say test
#################################
#    Standard Add-On Code       #
#################################
        #Set-Up (TMRW TMRW TMRW) (runonce)
                execute as @a[c=1,tag=cl_coit.initialised] at @s run tag @a[tag=!cl_coit.initialised] add cl_coit.initialised
                execute as @a[c=1,tag=!cl_coit.initialised] at @s run function chunklabs/coit/ro
                tag @a[tag=!cl_coit.initialised] add cl_coit.initialised
        #For Every New Player (Give Book)
                execute as @a[c=1,tag=!cl_coit.initialisedplayer] at @s run function chunklabs/coit/roeplayer
                tag @a[tag=!cl_coit.initialisedplayer] add cl_coit.initialisedplayer