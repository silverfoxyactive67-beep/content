scoreboard objectives add cl_coit.luck dummy ""
structure load "cl_coit/gb" ~ ~ ~