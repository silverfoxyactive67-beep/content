#Player spawns new door entity
        #Set door entity to closed (tags/scoreboard)

        #Setblock door entity

#Player right clicks on door entity (door is open)


#Player right clicks on door entity (door is closed)
