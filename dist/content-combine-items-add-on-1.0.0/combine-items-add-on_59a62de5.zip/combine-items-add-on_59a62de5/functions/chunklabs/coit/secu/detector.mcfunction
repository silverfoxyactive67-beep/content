#Player is detected near the detector
    #execute as @a[r=5,tag=!cl_coit.withindetectorrange] run say Something is within the detector's range
    #execute as @a[r=5,tag=!cl_coit.withindetectorrange] run tag @s add cl_coit.withindetectorrange
    #execute as @a[rm=5,r=6,tag=cl_coit.withindetectorrange] run tag @s remove cl_coit.withindetectorrange
#Mob is detected near the detector
    execute as @e[r=5,tag=!cl_coit.withindetectorrange,type=!minecraft:item] run tellraw @a { "rawtext": [ { "translate": "§f[§b§l!§r§f]§r§f Something is close to your detector" } ] }
    execute as @e[r=5,tag=!cl_coit.withindetectorrange,type=!minecraft:item] run playsound note.bell @a
    execute as @e[r=5,tag=!cl_coit.withindetectorrange,type=!minecraft:item] run tag @s add cl_coit.withindetectorrange
    execute as @e[rm=5,r=6,tag=cl_coit.withindetectorrange,type=!minecraft:item] run tag @s remove cl_coit.withindetectorrange