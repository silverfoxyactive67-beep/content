#You can place down camera's
    #Camera gets identifier
        #We check the earliest available identifier
            #Cam 1
                scoreboard players set @e[type=cl_coit:sec_camera,tag=!setup] cl_coit.camera_id 0
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=1}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 1
            #Cam 2
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=2}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 2
            #Cam 3
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=3}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 3


            #Cam 4
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=4}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 4


            #Cam 5
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=5}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 5


            #Cam 6
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=6}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 6


            #Cam 7
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=7}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 7


            #Cam 8
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=8}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 8


            #Cam 9
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=9}] run scoreboard players set @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] cl_coit.camera_id 9


            #Cam 10
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=1..10}] run say You already have 10 cameras placed down
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}]  unless entity @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=1..10}] run kill @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=!1..10}] 
            #Max 10 cameras per world (The Above code works in assigning the camera id's)
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=0},tag=!setup] run scoreboard players add @a[scores={cl_coit.camera_count=1..9}] cl_coit.camera_count 1
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=0},tag=!setup] if entity @a[scores={cl_coit.camera_count=10}] run say max camera amount reached
                execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=0},tag=!setup] if entity @a[scores={cl_coit.camera_count=10}] run kill @e[type=cl_coit:sec_camera,tag=!setup]
            
            execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=1..10},tag=!setup] run say new camera setup!

            execute as @e[type=cl_coit:sec_camera,scores={cl_coit.camera_id=1..10},tag=!setup] run tag @s add setup

        #Sync camera amount between users

    


    #Setting down a camera gives you a Camera Viewer
        

    #You can switch between them by crouching

    #Eventually you will crouch and get back to your original position

#Player Uses Camera Control
    #Check for nearest camera
        execute as @e[type=cl_coit:cam_control] at @s run execute as @p at @p run tp @s @e[type=cl_coit:sec_camera,c=1]
        execute as @e[type=cl_coit:cam_control] at @s run execute as @p at @p run tp @s @e[type=cl_coit:sec_camera,c=1]
        #If present, switch to that camera (tp), set player mode to camera mode
            execute as @e[type=cl_coit:cam_control] if entity @e[type=cl_coit:sec_camera,r=2] run tag @a[tag=!cl_coit.camera_mode] add cl_coit.camera_mode
            #execute as @e[type=cl_coit:cam_control] at @e[type=cl_coit:sec_camera,c=1] run tag @a[tag=cl_coit.camera_mode] add cl_coit.camera_mode
        #If not present, notify player and delete camera control unit (And give back the control unit)
            execute as @e[type=cl_coit:cam_control] unless entity @e[type=cl_coit:sec_camera,r=2] run title @s actionbar "No camera found, returning control unit"
            execute as @e[type=cl_coit:cam_control] unless entity @e[type=cl_coit:sec_camera,r=2] run kill @e[type=cl_coit:cam_control]

    #In camera mode 
        #Player can not move, tp player back to original position if they try to move
        #Invis player/Notified player that they are in camera mode
            execute as @a[tag=cl_coit.camera_mode] run effect @s invisibility 1 2 true
            execute as @a[tag=cl_coit.camera_mode] run title @s actionbar "Camera mode active, move down toe exit, left/right to switch cameras"
        #Detect down movement
            execute as @a[tag=cl_coit.camera_mode] at @e[type=cl_coit:sec_camera] if entity @s positioned ~ ~ ~ run tp @a[tag=cl_coit.camera_mode] ~ ~ ~ ~ ~
        #Detect up movement
            execute as @a[tag=cl_coit.camera_mode] at @e[type=cl_coit:sec_camera] if entity @s positioned ~ ~ ~ run tp @a[tag=cl_coit.camera_mode] ~ ~ ~ ~ ~
        #Detect left/right movement


        kill @e[type=cl_coit:cam_control]