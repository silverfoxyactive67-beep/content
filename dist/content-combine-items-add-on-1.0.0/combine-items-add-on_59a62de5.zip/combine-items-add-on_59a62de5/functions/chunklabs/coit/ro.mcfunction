scoreboard objectives add cl_coit.camera_id dummy ""
scoreboard objectives add cl_coit.camera_count dummy ""
tellraw @a { "rawtext": [ { "translate": "§f[§b§l!§r§f]§r§f Combine Items§a active" } ] }