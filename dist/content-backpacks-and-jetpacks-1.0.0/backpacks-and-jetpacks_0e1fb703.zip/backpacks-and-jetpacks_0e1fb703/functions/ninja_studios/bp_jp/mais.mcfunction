give @a[tag=!main_ninjabpjp] ns_bp:guidebook_spawn_egg

tag @a[tag=!main_ninjabpjp] add main_ninjabpjp
