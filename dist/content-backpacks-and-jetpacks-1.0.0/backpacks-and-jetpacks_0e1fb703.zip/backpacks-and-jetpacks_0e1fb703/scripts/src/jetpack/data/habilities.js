const Habilities = new Map([
    [
        "ns_bp:wither_skull",
        {
            category: "Wither Skull",
            cooldown: 5.0,
        },
    ],
]);

export default Habilities