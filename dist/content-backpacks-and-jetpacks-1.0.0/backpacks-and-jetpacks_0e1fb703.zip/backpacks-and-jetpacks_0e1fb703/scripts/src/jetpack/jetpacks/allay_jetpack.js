import { defaultFlyHandler, removeBlocksAround } from "../utils/utils";

export function allayJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    removeBlocksAround(player, "minecraft:light_gray_stained_glass", 3, 1);

    player.addEffect("haste", 1 * 20, {
        amplifier: 1,
        showParticles: false,
    });

    const location = player.location;
    const blockBelow = player.dimension.getBlock({
        x: location.x,
        y: location.y - 2,
        z: location.z,
    });

    if (!player.isOnGround && player.isSneaking) {
        if (blockBelow.isAir || blockBelow.isLiquid) {
            player.dimension.runCommand(
                `setblock ${location.x} ${location.y - 2} ${location.z} light_gray_stained_glass`
            );
        }
    }
}
