import { defaultFlyHandler, increaseJetpackFuel } from "../utils/utils";
import { world } from "@minecraft/server";

export function phantomJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    if (world.getTimeOfDay() > 13000 && world.getTimeOfDay() < 23000) {
        player.addEffect("night_vision", 11 * 20, {
            amplifier: 0,
            showParticles: false,
        });

        increaseJetpackFuel(player, equipment, chest, 100);
    }
}
