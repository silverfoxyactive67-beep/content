import { defaultFlyHandler } from "../utils/utils";

export function silverfishJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    const location = player.location;

    if (location.y < 256 && location.y > -64) {
        const block = player.dimension.getBlock({
            x: location.x,
            y: location.y,
            z: location.z,
        });

        if (block) {
            if (block.isAir) {
                player.dimension.runCommand(
                    `setblock ${location.x} ${location.y} ${location.z} light_block ["block_light_level"=15]`
                );
            }
        }
    }
}
