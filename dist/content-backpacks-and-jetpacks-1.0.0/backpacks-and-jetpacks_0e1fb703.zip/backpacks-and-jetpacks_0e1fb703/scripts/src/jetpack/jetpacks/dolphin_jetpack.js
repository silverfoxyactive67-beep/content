import { defaultFlyHandler, increaseJetpackFuel } from "../utils/utils";

export function dolphinJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    if (player.isInWater) {
        player.addEffect("water_breathing", 1 * 20, {
            amplifier: 1,
            showParticles: false,
        });
        player.addEffect("conduit_power", 1 * 20, {
            amplifier: 1,
            showParticles: false,
        });

        increaseJetpackFuel(player, equipment, chest, 100);
    }
}
