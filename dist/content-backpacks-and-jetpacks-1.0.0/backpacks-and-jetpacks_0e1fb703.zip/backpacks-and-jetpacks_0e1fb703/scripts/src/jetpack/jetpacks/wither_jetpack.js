import { startSkillCooldown } from "../main";
import { defaultFlyHandler, shootProjectile } from "../utils/utils";

export function witherJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    const skill = player.getDynamicProperty("wither_skull_cd");

    if (player.isSneaking && skill <= 0) {
        shootProjectile(player, "ns_bp:wither_skull", {
            power: 1.2,
            sound: "mob.wither.shoot",
            uncertainty: 0.0,
        });

        startSkillCooldown(player, "wither_skull_cd", 5);
    }
}
