import { defaultFlyHandler, increaseJetpackFuel } from "../utils/utils";

export function dragonJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);
    const dimension = player.dimension;

    if (dimension.id == "minecraft:the_end") {
        increaseJetpackFuel(player, equipment, chest, 100);
    }
}
