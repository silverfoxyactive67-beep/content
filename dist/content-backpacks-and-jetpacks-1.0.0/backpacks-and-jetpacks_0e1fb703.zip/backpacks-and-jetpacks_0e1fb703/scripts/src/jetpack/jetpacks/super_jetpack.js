import { system } from "@minecraft/server";
import { startSkillCooldown } from "../main";
import {
    defaultFlyHandler,
    isInNether,
    isInTheEnd,
    isNight,
    shootProjectile,
    increaseJetpackFuel,
    removeBlocksAround,
} from "../utils/utils";

export function superJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    const location = player.location;

    if (isNight()) {
        player.addEffect("night_vision", 11 * 20, {
            amplifier: 0,
            showParticles: false,
        });
        player.addEffect("strength", 1 * 20, {
            amplifier: 2,
            showParticles: false,
        });

        increaseJetpackFuel(player, equipment, chest, 100);
    }
    if (isInNether(player)) {
        increaseJetpackFuel(player, equipment, chest, 100);
    }
    if (isInTheEnd(player)) {
        increaseJetpackFuel(player, equipment, chest, 100);
    }

    player.addEffect("fire_resistance", 1 * 20, {
        amplifier: 0,
        showParticles: false,
    });

    player.addEffect("haste", 1 * 20, {
        amplifier: 1,
        showParticles: false,
    });

    if (player.isInWater) {
        player.addEffect("water_breathing", 1 * 20, {
            amplifier: 1,
            showParticles: false,
        });
        player.addEffect("conduit_power", 1 * 20, {
            amplifier: 1,
            showParticles: false,
        });

        increaseJetpackFuel(player, equipment, chest, 100);
    }

    if (location.y < 256 && location.y > -64) {
        const block = player.dimension.getBlock({
            x: location.x,
            y: location.y,
            z: location.z,
        });

        if (block) {
            if (block.isAir) {
                player.dimension.runCommand(
                    `setblock ${location.x} ${location.y} ${location.z} light_block ["block_light_level"=15]`
                );
            }
        }
    }

    removeBlocksAround(player, "minecraft:light_gray_stained_glass", 3, 1);

    const blockBelow = player.dimension.getBlock({
        x: location.x,
        y: location.y - 2,
        z: location.z,
    });

    if (!player.isOnGround && player.isSneaking) {
        if (blockBelow.isAir || blockBelow.isLiquid) {
            player.dimension.runCommand(
                `setblock ${location.x} ${location.y - 2} ${location.z} light_gray_stained_glass`
            );
        }
    }

    const skill1 = player.getDynamicProperty("wither_skull_cd");
    const skill2 = player.getDynamicProperty("sonic_boom_cd");

    if ((player.isSneaking && skill1 <= 0) || (player.isSneaking && skill2 <= 0)) {
        system.runTimeout(() => {
            shootProjectile(player, "ns_bp:sonic_boom", {
                power: 1.2,
                sound: "mob.warden.sonic_boom",
                uncertainty: 0.0,
            });
        }, 0 * 20);
        system.runTimeout(() => {
            shootProjectile(player, "ns_bp:wither_skull", {
                power: 1.2,
                sound: "mob.wither.shoot",
                uncertainty: 0.0,
            });
        }, 0.5 * 20);

        startSkillCooldown(player, "wither_skull_cd", 5);
        startSkillCooldown(player, "sonic_boom_cd", 5);
    }

    const effects = player.getEffects();

    for (let effect of effects) {
        if (effect.typeId.includes("darkness")) {
            player.removeEffect(effect.typeId);
        }
    }
}
