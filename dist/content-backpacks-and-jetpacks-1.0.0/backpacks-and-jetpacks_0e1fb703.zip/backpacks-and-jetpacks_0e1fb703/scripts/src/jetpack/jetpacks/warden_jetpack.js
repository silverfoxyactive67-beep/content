import { startSkillCooldown } from "../main";
import { defaultFlyHandler, increaseJetpackFuel, shootProjectile } from "../utils/utils";
import { world } from "@minecraft/server";

export function wardenJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);

    if (world.getTimeOfDay() > 13000 && world.getTimeOfDay() < 23000) {
        player.addEffect("strength", 1 * 20, {
            amplifier: 2,
            showParticles: false,
        });

        increaseJetpackFuel(player, equipment, chest, 100);
    }

    const skill = player.getDynamicProperty("sonic_boom_cd");

    if (player.isSneaking && skill <= 0) {
        shootProjectile(player, "ns_bp:sonic_boom", {
            power: 1.2,
            sound: "mob.warden.sonic_boom",
            uncertainty: 0.0,
        });

        startSkillCooldown(player, "sonic_boom_cd", 5);
    }

    const effects = player.getEffects();

    for (let effect of effects) {
        if (effect.typeId.includes("darkness")) {
            player.removeEffect(effect.typeId);
        }
    }
}
