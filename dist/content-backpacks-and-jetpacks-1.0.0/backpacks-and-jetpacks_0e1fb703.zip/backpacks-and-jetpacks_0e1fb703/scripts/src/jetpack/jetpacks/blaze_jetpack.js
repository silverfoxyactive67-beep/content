import { defaultFlyHandler, increaseJetpackFuel } from "../utils/utils";

export function blazeJetpack(player, equipment, chest) {
    defaultFlyHandler(player, equipment, chest);
    const dimension = player.dimension;

    if (dimension.id == "minecraft:nether") {
        increaseJetpackFuel(player, equipment, chest, 100);
    }
    player.addEffect("fire_resistance", 1 * 20, {
        amplifier: 1,
        showParticles: false,
    });
}
