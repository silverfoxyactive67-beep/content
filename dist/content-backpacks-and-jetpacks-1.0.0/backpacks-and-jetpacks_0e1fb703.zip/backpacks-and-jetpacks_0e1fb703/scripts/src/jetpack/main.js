import { EntityDamageCause, Player, system, world } from "@minecraft/server";
import {
    ToolTypes,
    defaultFlyHandler,
    getJetpackFuel,
    getJetpacks,
    increaseJetpackFuel,
    isInNether,
    isInTheEnd,
    isNight,
    isToolType,
    mineVein,
    randomTeleport,
    removeBlocksAround,
    setEquippedJetpackFuel,
    setJetpackFuel,
} from "./utils/utils";

import { allayJetpack } from "./jetpacks/allay_jetpack";
import { blazeJetpack } from "./jetpacks/blaze_jetpack";
import { dolphinJetpack } from "./jetpacks/dolphin_jetpack";
import { dragonJetpack } from "./jetpacks/dragon_jetpack";
import { phantomJetpack } from "./jetpacks/phantom_jetpack";
import { silverfishJetpack } from "./jetpacks/silverfish_jetpack";
import { superJetpack } from "./jetpacks/super_jetpack";
import { wardenJetpack } from "./jetpacks/warden_jetpack";
import { witherJetpack } from "./jetpacks/wither_jetpack";
import Jetpacks from "./data/jetpacks";

const skillCooldowns = ["sonic_boom_cd", "wither_skull_cd"];

world.afterEvents.playerSpawn.subscribe((event) => {
    const { player, initialSpawn } = event;

    for (let skill of skillCooldowns) {
        if (player.getDynamicProperty(skill) == undefined) {
            player.setDynamicProperty(skill, 0);
        }
    }
});

world.afterEvents.entityHitEntity.subscribe((event) => {
    const { hitEntity, damagingEntity } = event;
    const attackerCurrentHealth = damagingEntity.getComponent("minecraft:health")?.currentValue;
    const victimCurrentHealth = hitEntity.getComponent("minecraft:health")?.currentValue;

    const thornsDamage = 2.0;

    if (hitEntity instanceof Player) {
        const chest = hitEntity.getEquipment()?.chest;
        const equipment = hitEntity.equipment();

        if (hitEntity.hasJetpack()) {
            switch (chest.typeId) {
                case Jetpacks.golem.find((e) => e == chest.typeId): {
                    damagingEntity.applyDamage(Math.min(thornsDamage, attackerCurrentHealth), {
                        cause: EntityDamageCause.thorns,
                        damagingEntity: hitEntity,
                    });

                    increaseJetpackFuel(hitEntity, equipment, chest, 100);
                    break;
                }
                case Jetpacks.wither.find((e) => e == chest.typeId): {
                    damagingEntity.applyDamage(Math.min(thornsDamage, attackerCurrentHealth), {
                        cause: EntityDamageCause.thorns,
                        damagingEntity: hitEntity,
                    });

                    break;
                }
                case Jetpacks.dragon.find((e) => e == chest.typeId): {
                    if (victimCurrentHealth <= 6) {
                        randomTeleport(hitEntity);
                    }
                    break;
                }
                case Jetpacks.super.find((e) => e == chest.typeId): {
                    damagingEntity.applyDamage(Math.min(thornsDamage, attackerCurrentHealth), {
                        cause: EntityDamageCause.thorns,
                        damagingEntity: hitEntity,
                    });

                    increaseJetpackFuel(hitEntity, equipment, chest, 100);
                    if (victimCurrentHealth <= 6) {
                        randomTeleport(hitEntity);
                    }
                    break;
                }
            }
        }
    }
});

world.afterEvents.projectileHitEntity.subscribe((event) => {
    const { projectile, source: damagingEntity } = event;
    const hitEntity = event.getEntityHit().entity;

    const attackerCurrentHealth = damagingEntity.getComponent("minecraft:health")?.currentValue;
    const victimCurrentHealth = hitEntity.getComponent("minecraft:health")?.currentValue;

    const thornsDamage = 2.0;

    if (hitEntity instanceof Player) {
        const chest = hitEntity.getEquipment()?.chest;
        const equipment = hitEntity.equipment();

        if (hitEntity.hasJetpack()) {
            switch (chest.typeId) {
                case Jetpacks.golem.find((e) => e == chest.typeId): {
                    damagingEntity.applyDamage(Math.min(thornsDamage, attackerCurrentHealth), {
                        cause: EntityDamageCause.thorns,
                        damagingEntity: hitEntity,
                    });

                    increaseJetpackFuel(hitEntity, equipment, chest, 100);
                    break;
                }
                case Jetpacks.wither.find((e) => e == chest.typeId): {
                    damagingEntity.applyDamage(Math.min(thornsDamage, attackerCurrentHealth), {
                        cause: EntityDamageCause.thorns,
                        damagingEntity: hitEntity,
                    });

                    break;
                }
                case Jetpacks.dragon.find((e) => e == chest.typeId): {
                    if (victimCurrentHealth <= 6) {
                        randomTeleport(hitEntity);
                    }
                    break;
                }
                case Jetpacks.super.find((e) => e == chest.typeId): {
                    damagingEntity.applyDamage(Math.min(thornsDamage, attackerCurrentHealth), {
                        cause: EntityDamageCause.thorns,
                        damagingEntity: hitEntity,
                    });

                    increaseJetpackFuel(hitEntity, equipment, chest, 100);
                    if (victimCurrentHealth <= 6) {
                        randomTeleport(hitEntity);
                    }
                    break;
                }
            }
        }
    }
});

world.afterEvents.entityHurt.subscribe((event) => {
    const { hurtEntity: hitEntity, damageSource } = event;
    const damagingEntity = damageSource.damagingEntity;
    const cause = event.cause;
    const victimCurrentHealth = hitEntity.getComponent("minecraft:health")?.currentValue;

    if (hitEntity instanceof Player) {
        const chest = hitEntity.getEquipment()?.chest;
        const equipment = hitEntity.equipment();

        if (
            cause != EntityDamageCause.fire &&
            cause != EntityDamageCause.fireTick &&
            cause != EntityDamageCause.wither
        ) {
            if (hitEntity.hasJetpack()) {
                switch (chest.typeId) {
                    case Jetpacks.dragon.find((e) => e == chest.typeId): {
                        if (victimCurrentHealth <= 6) {
                            randomTeleport(hitEntity);
                        }
                        break;
                    }
                    case Jetpacks.super.find((e) => e == chest.typeId): {
                        if (victimCurrentHealth <= 6) {
                            randomTeleport(hitEntity);
                        }
                        break;
                    }
                }
            }
        }
    }
});

world.afterEvents.entityDie.subscribe((event) => {
    const { deadEntity, damageSource } = event;

    const damagingEntity = damageSource.damagingEntity;
    if (damagingEntity instanceof Player) {
        const chest = damagingEntity.getEquipment()?.chest;
        const equipment = damagingEntity.equipment();

        if (damagingEntity.hasJetpack()) {
            switch (chest.typeId) {
                case Jetpacks.wither.find((e) => e == chest.typeId): {
                    increaseJetpackFuel(damagingEntity, equipment, chest, 100);
                    break;
                }
                case Jetpacks.super.find((e) => e == chest.typeId): {
                    increaseJetpackFuel(damagingEntity, equipment, chest, 100);
                    break;
                }
            }
        }
    }
});

world.afterEvents.playerPlaceBlock.subscribe((event) => {
    const { player, block, dimension } = event;

    const inventory = player.inventory();
    const chest = player.getEquipment()?.chest;
    const equipment = player.equipment();

    if (player.hasJetpack()) {
        switch (chest.typeId) {
            case Jetpacks.allay.find((e) => e == chest.typeId): {
                increaseJetpackFuel(player, equipment, chest, 100);
                break;
            }
            case Jetpacks.super.find((e) => e == chest.typeId): {
                increaseJetpackFuel(player, equipment, chest, 100);
                break;
            }
        }
    }
});

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const { player, block, itemStack } = event;
    const equipment = player.equipment();
    const chest = player.getEquipment()?.chest;

    if (player.hasJetpack()) {
        switch (chest.typeId) {
            case Jetpacks.silverfish.find((e) => e == chest.typeId): {
                if (itemStack) {
                    if (itemStack && isToolType(itemStack, ToolTypes.Pickaxe)) {
                        mineVein(player, block);
                    }
                    system.run(() => {
                        increaseJetpackFuel(player, equipment, chest, 100);
                    });
                }

                break;
            }
            case Jetpacks.super.find((e) => e == chest.typeId): {
                if (itemStack) {
                    if (itemStack && isToolType(itemStack, ToolTypes.Pickaxe)) {
                        mineVein(player, block);
                    }
                    system.run(() => {
                        increaseJetpackFuel(player, equipment, chest, 100);
                    });
                }

                break;
            }
        }
    }
});

world.beforeEvents.effectAdd.subscribe((event) => {
    const { entity, effectType } = event;

    if (entity instanceof Player) {
        const player = entity;
        const jetpack = player.getEquipment()?.chest;

        if (player.hasJetpack()) {
            switch (jetpack.typeId) {
                case Jetpacks.warden.find((e) => e == jetpack.typeId): {
                    if (effectType.includes("Darkness")) {
                        event.cancel = true;
                    }
                    break;
                }
                case Jetpacks.super.find((e) => e == jetpack.typeId): {
                    if (effectType.includes("Darkness")) {
                        event.cancel = true;
                    }
                    break;
                }
            }
        }
    }
});

/* world.afterEvents.itemUse.subscribe((event) => {
    const { itemStack: item, source: player } = event;
 
    
}); */

//JETPACK FLY SYSTEM
system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        const chest = player.getEquipment()?.chest;
        const equipment = player.equipment();
        const direction = player.getViewDirection();

        if (player) {
            removeBlocksAround(player, "minecraft:light_block", 4, 0);
        }
        if (chest) {
            if (player.hasJetpack()) {
                switch (chest.typeId) {
                    case Jetpacks.golem.find((e) => e == chest.typeId): {
                        defaultFlyHandler(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.allay.find((e) => e == chest.typeId): {
                        allayJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.wither.find((e) => e == chest.typeId): {
                        witherJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.blaze.find((e) => e == chest.typeId): {
                        blazeJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.silverfish.find((e) => e == chest.typeId): {
                        silverfishJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.dragon.find((e) => e == chest.typeId): {
                        dragonJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.dolphin.find((e) => e == chest.typeId): {
                        dolphinJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.warden.find((e) => e == chest.typeId): {
                        wardenJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.phantom.find((e) => e == chest.typeId): {
                        phantomJetpack(player, equipment, chest);
                        break;
                    }
                    case Jetpacks.super.find((e) => e == chest.typeId): {
                        superJetpack(player, equipment, chest);
                        break;
                    }
                }

                if (player.isFalling) {
                    system.runTimeout(() => {
                        if (player.isOnGround) {
                            player.playSound("jetpack.stop_fly", {
                                location: player.location,
                                pitch: 1.0,
                                volume: 1.0,
                            });
                        }
                    }, 0.8 * 20);
                }
            }
        }
    }
});

//JETPACK SPEED HANDLER
system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        const jetpack = player.getEquipment()?.chest;

        if (jetpack) {
            if (player.hasJetpack()) {
                switch (jetpack.typeId) {
                    case Jetpacks.dolphin.find((e) => e == jetpack.typeId): {
                        applyInWaterSpeed(player, player.isInWater ? 0.8 : 0.5);
                    }
                    case Jetpacks.phantom.find((e) => e == jetpack.typeId): {
                        applyFlySpeed(player, isNight() ? 0.8 : 0.6);
                    }
                    case Jetpacks.blaze.find((e) => e == jetpack.typeId): {
                        applyFlySpeed(player, isInNether(player) ? 0.8 : 0.6);
                    }
                    case Jetpacks.dragon.find((e) => e == jetpack.typeId): {
                        applyFlySpeed(player, isInTheEnd(player) ? 0.8 : 0.6);
                    }
                    case Jetpacks.super.find((e) => e == jetpack.typeId): {
                        applyInWaterSpeed(player, player.isInWater ? 0.8 : 0.5);
                        applyFlySpeed(
                            player,
                            isNight() || isInTheEnd(player) || isInNether(player) ? 0.8 : 0.6
                        );
                    }
                    default: {
                        applyFlySpeed(player, 0.5);
                    }
                }
            }
        }
    }
}, 0.15 * 20);

//JETPACK SETUP
system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        const inventory = player.inventory();
        const chest = player.getEquipment()?.chest;
        const equipment = player.equipment();
        const jetpacks = getJetpacks(inventory);

        jetpacks.forEach((jetpack) => {
            setJetpackFuel(inventory, jetpack);
        });

        if (chest) {
            if (chest.hasTag("ns_bp:jetpack") && chest.typeId.includes("jetpack")) {
                setEquippedJetpackFuel(equipment, {
                    item: chest,
                });
            }

            if (getJetpackFuel(chest) <= 30 && player.warning == false) {
                player.warning = true;
                player.playSound("jetpack.low_fuel", {
                    location: player.location,
                    pitch: 1.0,
                    volume: 0.25,
                });

                system.runTimeout(() => {
                    if (player.warning) {
                        player.warning = false;
                    }
                }, 3 * 20);
            }
        }
    }
}, 1 * 20);

//JETPACK RECHARGE
system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        const chest = player.getEquipment()?.chest;
        const equipment = player.equipment();
        const rechargeAmount = 5.0;

        if (chest) {
            if (player.hasJetpack()) {
                if (!player.isJumping) {
                    increaseJetpackFuel(player, equipment, chest, rechargeAmount);
                }
            }
        }
    }
}, 1 * 20);

//COOLDOWNS HANDLER
system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        for (let skill of skillCooldowns) {
            if (player.getDynamicProperty(skill) == undefined) {
                player.setDynamicProperty(skill, 0);
            }
        }
        if (player.getDynamicProperty("sonic_boom_cd") > 0) {
            const skillCD = player.getDynamicProperty("sonic_boom_cd");

            player.setDynamicProperty("sonic_boom_cd", skillCD - 1);
        }

        if (player.getDynamicProperty("wither_skull_cd") > 0) {
            const skillCD = player.getDynamicProperty("wither_skull_cd");

            player.setDynamicProperty("wither_skull_cd", skillCD - 1);
        }
    }
}, 1 * 20);

/**
 *
 * @param {Player} player
 * @param {Number} speed
 */
function applyFlySpeed(player, speed) {
    const direction = player.getViewDirection();

    if (player.isUsingJetpack()) {
        if (player.isMoving()) {
            player.applyKnockback(direction.x, direction.z, speed, direction.y / 3);
        }
    }
}
/**
 *
 * @param {Player} player
 * @param {Number} speed
 */
function applyInWaterSpeed(player, speed) {
    const direction = player.getViewDirection();

    if (player.isInWater) {
        if (player.isMoving()) {
            player.applyKnockback(direction.x, direction.z, speed, direction.y / 2);
        }
    }
}

export function startSkillCooldown(player, skillid, time) {
    const skill = player.getDynamicProperty(skillid);

    if (skill != undefined) {
        player.setDynamicProperty(skillid, time);
    }
}

function placeBlocks(player, block, inventory) {
    const location = block.location;
    const itemStack = block.getItemStack();

    for (let y = location.y; y < location.y + 3; y++) {
        for (let x = location.x - 1; x < location.x + 2; x++) {
            for (let z = location.z - 1; z < location.z + 2; z++) {
                const blockAtLocation = player.dimension.getBlock({ x, y, z });

                if (blockAtLocation.isAir) {
                    if (hasBlockSupply(inventory, itemStack)) {
                        consumeSupply(inventory, itemStack);
                        const blockName = block.typeId.replace("minecraft:", "");
                        player.dimension.runCommand(`setblock ${x} ${y} ${z} ${blockName}`);
                    }
                }
            }
        }
    }
}

function hasBlockSupply(inventory, itemStack) {
    const size = inventory.size;

    const items = [];

    for (let i = 0; i < size; i++) {
        const item = inventory.getItem(i);

        if (item) {
            items.push(item);
        }
    }

    const hasItem = items.some((item) => item.typeId == itemStack.typeId);
    return hasItem;
}

function consumeSupply(inventory, itemStack) {
    const size = inventory.size;

    const items = [];

    for (let i = 0; i < size; i++) {
        const item = inventory.getItem(i);

        if (item) {
            items.push({
                item,
                index: i,
            });
        }
    }

    const itemToConsume = items.find((item) => item.item.typeId == itemStack.typeId);

    if (itemToConsume) {
        const amount = itemToConsume.item.amount;

        if (amount > 1) {
            const newItem = itemToConsume.item.clone();

            newItem.amount = amount - 1;

            inventory.setItem(itemToConsume.index, newItem);
        } else if (amount <= 1) {
            inventory.setItem(itemToConsume.index);
        }
    }
}
