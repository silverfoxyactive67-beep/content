import { Player, EquipmentSlot, system, world, MolangVariableMap } from "@minecraft/server";
import Jetpacks from "../data/jetpacks";

export function shootProjectile(player, projectileId, options) {
    const location = player.location;
    const direction = player.getViewDirection();
    const rotation = player.getRotation();
    const { power, sound, uncertainty } = options;

    const projectile = player.dimension.spawnEntity(projectileId, {
        x: location.x,
        y: location.y + 1.4,
        z: location.z,
    });
    projectile.setRotation({ x: rotation.x, y: rotation.y });

    const shootable = projectile.getComponent("minecraft:projectile");
    const velocity = {
        x: direction.x * power,
        y: direction.y * power,
        z: direction.z * power,
    };

    if (shootable) {
        shootable.owner = player;
        shootable.gravity = 0.0;

        player.playSound(sound, location);
        //shootable.shoot(velocity, { uncertainty });
        // projectile.clearVelocity();
        projectile.setDynamicProperty("speed", {
            x: direction.x * power,
            y: direction.y * power,
            z: direction.z * power,
        });

        projectile.applyImpulse({
            x: direction.x * power,
            y: direction.y * power,
            z: direction.z * power,
        });
    }
}

system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        const projectiles = player.dimension.getEntities({
            families: ["projectile"],
        });

        for (let projectile of projectiles) {
            projectile.clearVelocity();
            const speed = projectile.getDynamicProperty("speed");
            if (speed) {
                projectile.applyImpulse(speed);
            }
        }
    }
});

export function mineVein(player, brokenBlock) {
    const brokenBlockLocation = brokenBlock.location;
    const dimension = brokenBlock.dimension;
    const direction = player.getViewDirection();

    if (isOre(brokenBlock.typeId)) {
        for (let x = brokenBlockLocation.x - 4; x < brokenBlockLocation.x + 5; x++) {
            for (let y = brokenBlockLocation.y - 4; y < brokenBlockLocation.y + 5; y++) {
                for (let z = brokenBlockLocation.z - 4; z < brokenBlockLocation.z + 5; z++) {
                    const location = { x, y, z };

                    const block = dimension.getBlock(location);

                    if (
                        block &&
                        block.typeId != "minecraft:bedrock" &&
                        block.typeId != "minecraft:light_block"
                    ) {
                        if (isOre(block.typeId)) {
                            breakBlock(block);
                        }
                    }
                }
            }
        }
    } else {
        for (let x = brokenBlockLocation.x - 1; x < brokenBlockLocation.x + 2; x++) {
            for (let y = brokenBlockLocation.y - 1; y < brokenBlockLocation.y + 2; y++) {
                for (let z = brokenBlockLocation.z - 1; z < brokenBlockLocation.z + 2; z++) {
                    const location = { x, y, z };

                    const block = dimension.getBlock(location);

                    if (
                        block &&
                        block.typeId != "minecraft:bedrock" &&
                        block.typeId != "minecraft:light_block"
                    ) {
                        breakBlock(block);
                    }
                }
            }
        }
    }
}

function breakBlock(block) {
    const { x, y, z } = block.location;

    system.run(() => {
        block.dimension.runCommand(`setblock ${x} ${y} ${z} air destroy`);
    });
}

const Ores = new Set([
    "minecraft:iron_ore",
    "minecraft:gold_ore",
    "minecraft:diamond_ore",
    "minecraft:copper_ore",
    "minecraft:redstone_ore",
    "minecraft:lapis_ore",
    "minecraft:coal_ore",
    "minecraft:deepslate_iron_ore",
    "minecraft:deepslate_gold_ore",
    "minecraft:deepslate_diamond_ore",
    "minecraft:deepslate_copper_ore",
    "minecraft:deepslate_redstone_ore",
    "minecraft:deepslate_lapis_ore",
    "minecraft:deepslate_coal_ore",
    "minecraft:quartz_ore",
    "minecraft:nether_gold_ore",
]);

function isOre(blockId) {
    if (Ores.has(blockId)) {
        return true;
    } else return false;
}

export const ToolTypes = {
    Pickaxe: "minecraft:is_pickaxe",
};

export function isToolType(itemStack, ToolType) {
    if (itemStack.getTags().includes(ToolType)) {
        return true;
    } else return false;
}

export function getJetpacks(inventory) {
    const size = inventory.size;

    const jetpacks = [];

    for (let i = 0; i < size; i++) {
        const item = inventory.getItem(i);

        if (item) {
            if (item.hasTag("ns_bp:jetpack") && item.typeId.includes("jetpack")) {
                jetpacks.push({
                    item,
                    slot: i,
                });
            }
        }
    }

    return jetpacks;
}

export function setJetpackFuel(inventory, jetpack) {
    const MAX_FUEL = 100;

    if (jetpack.item.getLore()[0] == undefined) {
        const item = jetpack.item.clone();

        item.setLore([`FUEL: ${MAX_FUEL}`]);

        inventory.setItem(jetpack.slot, item);
    }
}

export function setEquippedJetpackFuel(equipment, jetpack) {
    const MAX_FUEL = 100;

    if (jetpack.item.getLore()[0] == undefined) {
        const item = jetpack.item.clone();

        item.setLore([`FUEL: ${MAX_FUEL}`]);

        equipment.setEquipment(EquipmentSlot.Chest, item);
    }
}

export function decreaseJetpackFuel(player, equipment, jetpack) {
    if (jetpack.getLore()[0] != undefined) {
        const MIN_FUEL = 0;
        const CURRENT_FUEL = parseFloat(jetpack.getLore()[0].substring(5));
        const CONSUME_AMOUNT = 0.5;

        const item = jetpack.clone();

        item.setLore([`FUEL: ${Math.max(MIN_FUEL, CURRENT_FUEL - CONSUME_AMOUNT).toFixed(1)}`]);

        equipment.setEquipment(EquipmentSlot.Chest, item);
        player.runCommand(`stopsound @a armor.equip_generic`);
    }
}

export function increaseJetpackFuel(player, equipment, jetpack, amount) {
    if (jetpack.getLore()[0] != undefined) {
        const MAX_FUEL = 100;
        const CURRENT_FUEL = parseFloat(jetpack.getLore()[0].substring(5));
        const CHARGE_AMOUNT = amount;

        const item = jetpack.clone();

        item.setLore([`FUEL: ${Math.min(CURRENT_FUEL + CHARGE_AMOUNT, MAX_FUEL).toFixed(1)}`]);

        equipment.setEquipment(EquipmentSlot.Chest, item);
        player.runCommand(`stopsound @a armor.equip_generic`);
    }
}

export function getJetpackFuel(jetpack) {
    if (jetpack.getLore()[0] != undefined) {
        return parseFloat(jetpack.getLore()[0].substring(5));
    }
}

export function randomTeleport(player) {
    const location = player.location;
    const name = player.name;
    try {
        player.runCommand(`spreadplayers ${location.x} ${location.z} 32 64 "${name.toString()}"`);
    } catch (e) {
        console.warn(e);
    }

    system.runTimeout(() => {
        const location = player.location;
        player.playSound("mob.shulker.teleport", location);
        player.teleport({
            x: location.x,
            y: location.y + 1,
            z: location.z,
        });
    }, 0.1 * 20);
}

export function removeBlocksAround(player, id, radius, yOffset) {
    const location = player.location;

    for (let x = location.x - radius; x < location.x + radius; x++) {
        for (let y = location.y - radius; y < location.y + radius; y++) {
            for (let z = location.z - radius; z < location.z + radius; z++) {
                if (y < 256 && y > -64) {
                    const block = player?.dimension?.getBlock({ x, y, z });

                    if (block) {
                        const playerOnBlock = player.dimension.getEntitiesAtBlockLocation({
                            x: block?.location.x,
                            y: block?.location.y + yOffset,
                            z: block?.location.z,
                        })[0];

                        if (playerOnBlock && block.typeId == id) {
                        } else if (!playerOnBlock && block.typeId == id) {
                            player.dimension.runCommand(
                                `setblock ${block.location.x} ${block.location.y} ${block.location.z} air`
                            );
                        }
                    }
                }
            }
        }
    }
}

function displayJetpackFuel(player) {
    const chest = player.getEquipment()?.chest;

    if (chest) {
        const fuel = getJetpackFuel(chest);

        const fuelBarEmpty = Array(10).fill("§8■", 0, 10);

        const value = Math.ceil(((fuel / 100) * 100) / 10);

        let fuelBar = fuelBarEmpty.fill("§a■", 0, value).toString().replaceAll(",", "");
        let cooldown = "";

        const sonic_boom_cd = player.getDynamicProperty("sonic_boom_cd");
        const wither_skull_cd = player.getDynamicProperty("wither_skull_cd");

        if (sonic_boom_cd > 0) {
            cooldown = `§4Cooldown: ${sonic_boom_cd}`;
        } else if (wither_skull_cd > 0) {
            cooldown = `§4Cooldown: ${wither_skull_cd}`;
        }

        player.onScreenDisplay.setActionBar(`${fuelBar}\n${cooldown}`);
    }
}

export function defaultFlyHandler(player, equipment, chest) {
    if (player.isUsingJetpack() && getJetpackFuel(chest) > 0) {
        const jetpack = equipment.getEquipment(EquipmentSlot.Chest);

        player.addEffect("levitation", 0.8 * 20, {
            amplifier: player.getViewDirection().y > 0.65 ? 6 : 3,
            showParticles: false,
        });
        player.playSound("jetpack.fly", {
            pitch: 1.0,
            volume: 0.6,
        });
        displayJetpackFuel(player);
        decreaseJetpackFuel(player, equipment, chest);
    }
    if (player.isFalling) {
        player.addEffect("slow_falling", 1 * 20, {
            amplifier: 1,
            showParticles: false,
        });
    }
}

export function isNight() {
    if (world.getTimeOfDay() > 13000 && world.getTimeOfDay() < 23000) {
        return true;
    } else false;
}

export function isInNether(player) {
    const dimension = player.dimension;

    if (dimension.id == "minecraft:nether") {
        return true;
    } else return false;
}

export function isInTheEnd(player) {
    const dimension = player.dimension;

    if (dimension.id == "minecraft:the_end") {
        return true;
    } else return false;
}

/**
 *
 * @param {Object} Jetpacks
 */
export function getJetpackItems() {
    const jetpacks = [];

    for (let jetpack in Jetpacks) {
        jetpacks.push(Jetpacks[jetpack]);
    }

    return jetpacks.flat();
}

Player.prototype.inventory = function () {
    return this.getComponent("minecraft:inventory").container;
};

Player.prototype.getEquipment = function () {
    const equipment = this.getComponent("minecraft:equippable");

    const chest = equipment.getEquipment(EquipmentSlot.Chest);

    return {
        chest,
    };
};

Player.prototype.equipment = function () {
    return this.getComponent("minecraft:equippable");
};

Player.prototype.hasJetpack = function () {
    const item = this.getEquipment()?.chest;
    const jetpacks = getJetpackItems();

    if (item) {
        // return Jetpacks.has(item.typeId);
        return jetpacks.includes(item.typeId);
    }
};

Player.prototype.isUsingJetpack = function () {
    if (this.hasJetpack()) {
        if (this.isJumping && !this.isInWater) {
            return true;
        } else return false;
    }
};
Player.prototype.hasBlockBelow = function () {
    if (this.hasJetpack()) {
        const block = this.dimension.getBlock({
            x: this.location.x,
            y: this.location.y - 1,
            z: this.location.z,
        });

        if (!block.isAir && !block.isLiquid) {
            return true;
        } else return false;
    }
};

Player.prototype.warning = false;

Player.prototype.isMoving = function () {
    const { x, y, z } = this.getVelocity();
    const speed = 0.1;

    return x > speed || x < -speed || z > speed || z < -speed;
};
