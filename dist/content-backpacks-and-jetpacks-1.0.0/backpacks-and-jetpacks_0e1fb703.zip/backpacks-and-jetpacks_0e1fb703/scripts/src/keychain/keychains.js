import {
    world,
    system,
    Player,
    Entity,
    EntityComponentTypes,
    ItemStack,
    Dimension,
    EquipmentSlot
} from "@minecraft/server";

import { isToolType, ToolTypes, mineVein } from "../jetpack/utils/utils";

const Keychains = new Map([
    [
        "ns_bp:creeper_keychain",
        {
            id: "ns_bp:creeper_keychain",
            effects: [],
        },
    ],
    [
        "ns_bp:emerald_keychain",
        {
            id: "ns_bp:emerald_keychain",
            effects: [
                {
                    id: "village_hero",
                    amplifier: 9,
                    duration: 15,
                },
            ],
        },
    ],
    [
        "ns_bp:frog_keychain",
        {
            id: "ns_bp:frog_keychain",
            effects: [
                {
                    id: "jump_boost",
                    amplifier: 1,
                    duration: 15,
                },
                {
                    id: "water_breathing",
                    amplifier: 0,
                    duration: 15,
                },
            ],
        },
    ],
    [
        "ns_bp:pickaxe_keychain",
        {
            id: "ns_bp:pickaxe_keychain",
            effects: [
                {
                    id: "haste",
                    amplifier: 1,
                    duration: 15,
                },
            ],
        },
    ],
    [
        "ns_bp:sword_keychain",
        {
            id: "ns_bp:sword_keychain",
            effects: [
                {
                    id: "strength",
                    amplifier: 1,
                    duration: 15,
                },
            ],
        },
    ],
    [
        "ns_bp:torch_keychain",
        {
            id: "ns_bp:torch_keychain",
            effects: [
                {
                    id: "night_vision",
                    amplifier: 1,
                    duration: 15,
                },
            ],
        },
    ],
    [
        "ns_bp:turtle_keychain",
        {
            id: "ns_bp:turtle_keychain",
            effects: [
                {
                    id: "resistance",
                    amplifier: 1,
                    duration: 15,
                },
                {
                    id: "health_boost",
                    amplifier: 1,
                    duration: 15,
                },
                {
                    id: "fire_resistance",
                    amplifier: 1,
                    duration: 15,
                },
                {
                    id: "regeneration",
                    amplifier: 0,
                    duration: 15,
                },
            ],
        },
    ],
    [
        "ns_bp:xp_keychain",

        {
            id: "ns_bp:xp_keychain",
            effects: [],
        },
    ],
]);

const Keychain = {
    creeper: "ns_bp:creeper_keychain",
    emerald: "ns_bp:emerald_keychain",
    frog: "ns_bp:frog_keychain",
    pickaxe: "ns_bp:pickaxe_keychain",
    sword: "ns_bp:sword_keychain",
    turtle: "ns_bp:turtle_keychain",
    torch: "ns_bp:torch_keychain",
    xp: "ns_bp:xp_keychain",
};

world.afterEvents.itemUse.subscribe((event) => {
    const { source: player, itemStack } = event;

    if (Keychains.has(itemStack.typeId)) {
        const keychain = itemStack;
        equipKeychain(player, keychain);
    }
});

world.beforeEvents.playerBreakBlock.subscribe((event) => {
    const { player, block, itemStack } = event;

    const equippedKeychain = player.getEquippedKeychain();

    if (equippedKeychain) {
        if (player.hasBackpackOrJetpackEquipped()) {
            switch (equippedKeychain.id) {
                case Keychain.pickaxe: {
                    if (itemStack) {
                        if (
                            itemStack &&
                            player.isSneaking &&
                            isToolType(itemStack, ToolTypes.Pickaxe)
                        ) {
                            mineVein(player, block);
                        }
                    }
                    break;
                }
            }
        }
    }
});

world.beforeEvents.explosion.subscribe((event) => {
    const { source, dimension } = event;
    const location = source.location;

    if (source.typeId == "minecraft:creeper") {
    }
});

world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
    const { eventId, entity } = event;

    if (entity.typeId == "minecraft:creeper") {
        if (
            eventId == "minecraft:start_exploding" ||
            eventId == "minecraft:start_exploding_forced"
        ) {
            const nearbyPlayers = entity.dimension.getPlayers({
                location: entity.location,
                maxDistance: 8,
            });

            for (let player of nearbyPlayers) {
                if (player.getEquippedKeychain()?.id == Keychain.creeper) {
                    if (player.hasBackpackOrJetpackEquipped()) {
                        player.addEffect("resistance", 3 * 20, {
                            amplifier: 255,
                            showParticles: false,
                        });
                    }
                }
            }
        }
    }
});

world.afterEvents.entityHitEntity.subscribe((event) => {
    const { hitEntity, damagingEntity } = event;

    if (damagingEntity instanceof Player) {
        const equippedKeychain = damagingEntity.getEquippedKeychain();
        if (equippedKeychain) {
            if (damagingEntity.hasBackpackOrJetpackEquipped()) {
                if (equippedKeychain.id == Keychain.sword) {
                    swordKeychain(damagingEntity, hitEntity);
                }
            }
        }
    }
});

const KEYCHAIN_HANDLER = system.runInterval(() => {
    const players = world.getAllPlayers();

    for (let player of players) {
        const equippedKeychain = player.getEquippedKeychain();
        if (equippedKeychain) {
            if (player.hasBackpackOrJetpackEquipped()) {
                const { effects } = equippedKeychain;

                for (let effect of effects) {
                    player.addEffect(effect.id, effect.duration * 20, {
                        amplifier: effect.amplifier,
                        showParticles: false,
                    });
                }

                switch (equippedKeychain.id) {
                    case Keychain.frog: {
                        if (
                            player.isFalling &&
                            player.dimension.getBlockFromRay(
                                player.location,
                                { x: 0, y: -1, z: 0 },
                                {
                                    maxDistance: 6,
                                    includeLiquidBlocks: false,
                                    includePassableBlocks: false,
                                }
                            )?.block == undefined
                        ) {
                            player.addEffect("slow_falling", 1 * 20);
                        }
                        break;
                    }
                    case Keychain.creeper: {
                        if (player.isSneaking) {
                            creeperKeychain(player, 4);
                        }
                        break;
                    }
                    case Keychain.xp: {
                        xpKeychain(player);

                        break;
                    }
                    case Keychain.torch: {
                        torchKeychain(player);

                        break;
                    }
                }
            }
        }
    }
}, 0.1 * 20);

Player.prototype.getEquippedKeychain = function () {
    /**
     * @type {EntityComponentTypes.Inventory}
     */
    const inventory = this.getComponent(EntityComponentTypes.Inventory);

    const keychainSlot = 9;

    const keychain = inventory.container.getItem(keychainSlot);

    if (keychain) {
        if (Keychains.has(keychain.typeId)) {
            return Keychains.get(keychain.typeId);
        } else {
            return undefined;
        }
    } else {
        return undefined;
    }
};

Player.prototype.hasBackpackOrJetpackEquipped = function () {
    const inventory = this.getComponent(EntityComponentTypes.Inventory);
    const equippable = this.getComponent(EntityComponentTypes.Equippable);
    const chestplate = equippable.getEquipment(EquipmentSlot.Chest);

    if (chestplate) {
        if (chestplate.typeId.includes("jetpack") || chestplate.typeId.includes("backpack")) {
            return true;
        } else return false;
    } else return false;
};

/**
 *
 * @param {Player} player
 * @param {ItemStack} keychain
 */
function equipKeychain(player, keychain) {
    /**
     * @type {EntityComponentTypes.Inventory}
     */
    const inventory = player.getComponent(EntityComponentTypes.Inventory);
    const container = inventory.container;
    const keychainSlot = 9;

    if (container.getItem(keychainSlot)) {
        const item = container.getItem(keychainSlot);
        container.swapItems(player.selectedSlotIndex, keychainSlot, container);
    } else {
        container.swapItems(player.selectedSlotIndex, keychainSlot, container);
    }
}

/**
 *
 * @param {Player} player
 * @param {Number} radius
 */
function creeperKeychain(player, radius) {
    const inventory = player.getComponent(EntityComponentTypes.Inventory);
    const container = inventory.container;

    const keychainSlot = 9;
    const keychain = container.getItem(keychainSlot);

    const cooldown = keychain.getComponent("minecraft:cooldown");

    if (cooldown) {
        const cooldownTicks = cooldown?.cooldownTicks;
        const remainingCooldown = cooldown?.getCooldownTicksRemaining(player);

        if (remainingCooldown == 0) {
            cooldown.startCooldown(player);

            const fuseTime = 3;

            player.playSound("random.fuse");

            system.runTimeout(() => {
                const players = world.getAllPlayers();
                if (players.includes(player)) {
                    if (player.isSneaking) {
                        /**
                         * @type {Dimension}
                         */
                        const dimension = player.dimension;

                        dimension.createExplosion(player.location, radius, {
                            breaksBlocks: false,
                            source: player,
                        });
                    }
                }
            }, fuseTime * 20);
        } else {
            const time = Math.round(remainingCooldown / 20);
            player.onScreenDisplay.setActionBar(
                "§fHold Crouch for 3 seconds to explode\n§eSkill Cooldown:§r " + time
            );
        }
    }
}

/**
 *
 * @param {Player} player
 */
function xpKeychain(player) {
    const inventory = player.getComponent(EntityComponentTypes.Inventory);
    const container = inventory.container;

    const keychainSlot = 9;
    const keychain = container.getItem(keychainSlot);

    const cooldown = keychain.getComponent("minecraft:cooldown");

    if (cooldown) {
        const cooldownTicks = cooldown?.cooldownTicks;
        const remainingCooldown = cooldown?.getCooldownTicksRemaining(player);

        if (remainingCooldown == 0) {
            cooldown.startCooldown(player);

            const time = 10;

            system.runTimeout(() => {
                const players = world.getAllPlayers();
                if (players.includes(player)) {
                    const equippedKeychain = player.getEquippedKeychain();
                    if (equippedKeychain.id == Keychain.xp) {
                        player.dimension.spawnEntity("minecraft:xp_orb", player.location);
                    }
                }
            }, time * 20);
        }
    }
}
function torchKeychain(player) {
    const inventory = player.getComponent(EntityComponentTypes.Inventory);
    const container = inventory.container;
    const emptySlots = container.emptySlotsCount;

    const torchs = getItem(player, "minecraft:torch");

    if (torchs == 0) {
        if (emptySlots > 0) {
            container.addItem(new ItemStack("minecraft:torch", 64));
        }
    } else if (torchs > 0 && torchs < 64) {
        const torch = getItems(player).find((element) => element.item.typeId == "minecraft:torch");

        if (torch) {
            const itemCount = torch.amount;

            container.setItem(
                torch.slot,
                new ItemStack("minecraft:torch", Math.min(64, torchs + 64))
            );
        }
    }
}

/**
 *
 * @param {Player} player
 * @param {Entity} entity
 */
function swordKeychain(player, entity) {
    const direction = player.getViewDirection();

    entity.applyImpulse({
        x: direction.x * 0.4,
        y: 0.2,
        z: direction.z * 0.4,
    });
}

/**
 *
 * @param {Player} player
 * @param {String} itemId
 */
function getItem(player, itemId) {
    /**
     * @type {EntityInventoryComponent}
     */
    const component = player.getComponent(EntityComponentTypes.Inventory);

    let itemAmount = 0;

    for (let index = 0; index < component.inventorySize; index++) {
        if (component.container.getItem(index)?.typeId == itemId) {
            const item = component.container.getItem(index);
            itemAmount += item.amount;
        }
    }

    return itemAmount;
}

/**
 *
 * @param {Player} player
 * @param {String} item
 */
function getItems(player) {
    /**
     * @type {EntityInventoryComponent}
     */
    const component = player.getComponent(EntityComponentTypes.Inventory);

    let items = [];

    for (let index = 0; index < component.inventorySize; index++) {
        const item = component.container.getItem(index);

        if (item) {
            items.push({
                typeId: item.typeId,
                item: item,
                amount: item.amount,
                slot: index,
            });
        }
    }

    return items;
}
