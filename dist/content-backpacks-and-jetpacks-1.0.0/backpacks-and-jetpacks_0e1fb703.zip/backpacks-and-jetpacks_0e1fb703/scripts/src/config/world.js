import { system, world } from "@minecraft/server";

world.gameRules.showTags = false

system.runInterval(()=>{
    if (world.gameRules.showTags) world.gameRules.showTags = false
})