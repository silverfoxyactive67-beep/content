import {
    Entity,
    world,
    StructureSaveMode,
    EntityEquippableComponent,
    EntityInventoryComponent,
    EntityComponentTypes,
    EquipmentSlot,
    ItemStack,
    Player,
} from "@minecraft/server";
import { backpacks_items, backpacks } from "./backpacks";
/**
 * Salva a barra de atalho (hotbar) do jogador em uma entidade temporária e cria uma estrutura para armazenamento.
 *
 * @param {Entity} source - A entidade (jogador) cuja barra de atalho será salva.
 * @param {Entity} backpack - A entidade (jogador) cuja barra de atalho será salva.
 */
export function saveBackpack(source, backpack) {
    backpack.tryTeleport({
        x: backpack.location.x,
        y: backpack.location.y - 1,
        z: backpack.location.z,
    });
    world.structureManager.createFromWorld(
        `mystructure:bp_${backpack.id}_of_${source.id}`,
        source.dimension,
        backpack.location,
        backpack.location,
        { saveMode: StructureSaveMode.World, includeEntities: true, includeBlocks: false }
    );
    backpack.remove();
}

/**
 * Carrega a barra de atalho (hotbar) do jogador de uma estrutura previamente salva e restaura os itens ao jogador.
 *
 * @param {Entity} source - A entidade (jogador) cuja barra de atalho será carregada.
 */
export function loadBackpack(source, idBackpack, location) {
    let structure = world.structureManager.get(`mystructure:bp_${idBackpack}_of_${source.id}`);
    world.structureManager.place(structure, source.dimension, location, {
        includeEntities: true,
    });
    world.structureManager.delete(`mystructure:bp_${idBackpack}_of_${source.id}`);
}

export function getItem(source) {
    /**
     * @type {EntityEquippableComponent}
     */
    const componet = source.getComponent("minecraft:equippable");
    try {
        if (componet.getEquipment(EquipmentSlot.Chest) != undefined)
            return componet.getEquipment(EquipmentSlot.Chest);
        else return new ItemStack("minecraft:stick", 1);
    } catch (error) {
        return new ItemStack("minecraft:stick", 1);
    }
}

export function getItemHand(source) {
    /**
     * @type {EntityEquippableComponent}
     */
    const componet = source.getComponent("minecraft:equippable");
    try {
        if (componet.getEquipment(EquipmentSlot.Mainhand) != undefined)
            return componet.getEquipment(EquipmentSlot.Mainhand);
        else return new ItemStack("minecraft:stick", 1);
    } catch (error) {
        return new ItemStack("minecraft:stick", 1);
    }
}

export function removeItemSuffix(str) {
    return str.replace("_item", "");
}

/**
 *
 * @param {Player} player
 * @param {Entity} backpack
 */
export function handleCauldronBackpack(player, backpack) {
    let lava = backpack.getProperty("ns_bp:lava");
    let water = backpack.getProperty("ns_bp:water");
    let milk = backpack.getProperty("ns_bp:milk");
    let liquids = lava + water + milk;
    let maxLiquid = 10;
    if (liquids >= maxLiquid) {
        player.onScreenDisplay.setActionBar("The backpack is already full of liquids");
        return false;
    } else {
        return true;
    }
}

/**
 *
 * @param {Entity} source
 */
export function setPropertyInEntity(source, property) {
    let current_property = source.getProperty(property);
    source.setProperty(property, current_property + 1);
}

/**
 *
 * @param {Entity} source
 */
export function check_inventory(source) {
    /** @type {EntityInventoryComponent} */
    const inventory = source.getComponent("minecraft:inventory");
    if (inventory.container.emptySlotsCount > 0 && source.location.y > -59) return true;
    else if (inventory.container.emptySlotsCount <= 0 && source.location.y <= -59) return false;
}

/**
 *
 * @param {Entity} backpack
 */
export function handleFurnaceBackpack(backpack) {
    /** @type {EntityInventoryComponent} */
    const inventory = backpack.getComponent("minecraft:inventory");
    for (let index = 0; index < inventory.container.size; index++) {
        const itemInventory = inventory.container.getSlot(index).getItem();
        if (itemInventory != undefined) {
            if (food[itemInventory.typeId]) {
                const itemStack = new ItemStack(food[itemInventory.typeId], itemInventory.amount);
                inventory.container.setItem(index, itemStack);
            }
            if (ore[itemInventory.typeId]) {
                const itemStack = new ItemStack(ore[itemInventory.typeId], itemInventory.amount);
                inventory.container.setItem(index, itemStack);
            }
        }
    }
}

/**
 *
 * @param {Entity} source
 */
export function magnet_item(source) {
    source.dimension
        .getEntities({
            maxDistance: 3,
            location: source.location,
        })
        .forEach((victim) => {
            if (victim.typeId == "minecraft:item") victim.teleport(source.location);
        });
}

/**
 *
 * @param {Entity} source
 */
export function saveCheckPoint(source) {
    let idCoord = `ns_bp:coor_${source.nameTag}`;
    let newCoord = idCoord;
    let cont = 1;

    while (world.getDynamicProperty(newCoord) !== undefined) {
        newCoord = idCoord + cont;
        cont++;
    }
    world.setDynamicProperty(newCoord, source.location);
}

/**
 *
 * @param {Entity} source
 * @returns {string[]}
 */
export function loadCheckPoints(source) {
    let coor = [];
    world.getDynamicPropertyIds().forEach((idProperty) => {
        if (idProperty.includes(source.nameTag)) {
            coor.push(idProperty);
        }
    });
    return coor;
}

export function handleBeaconBackpack(player) {
    player.getTags().forEach((tag) => {
        if (effects_tag.includes(tag)) {
            player.dimension
                .getEntities({
                    location: player.location,
                    maxDistance: 5,
                    families: ["player"],
                })
                .forEach((other_player) => {
                    other_player.addEffect(`${tag.replace("effect_", "")}`, 200);
                });
        }
    });
}

/**
 *
 * @param {Player} player
 * @param {Entity} entity
 * @param {ItemStack} itemStack
 */
export function dyeBackpack(player, entity, itemStack) {
    if (backpacks[entity.typeId] != undefined) {
        const isDye = dyeMap.has(itemStack.typeId);
        if (isDye) {
            switch (itemStack.typeId) {
                case itemStack.typeId: {
                    player.runCommand(`clear @s ${itemStack.typeId} 0 1`);
                    entity.dimension.spawnParticle("ns_bp:change_color", {
                        x: entity.location.x,
                        y: entity.location.y,
                        z: entity.location.z,
                    });
                    entity.dimension.playSound("backpack.painting", entity.location);
                    entity.setProperty("backpack:color", dyeMap.get(itemStack.typeId));
                    break;
                }
            }
        }
    } else return;
}

export const dsEntity = ["overworld", "nether", "the_end"];

export const liquids_backpack = {
    "minecraft:lava_bucket": {},
    "minecraft:water_bucket": {},
    "minecraft:milk_bucket": {},
    "minecraft:bucket": {},
};

export const propertys = [
    "ns_bp:cultivator",
    "ns_bp:lock",
    "ns_bp:lava",
    "ns_bp:water",
    "ns_bp:milk",
];

const food = {
    "minecraft:potato": "minecraft:baked_potato",
    "minecraft:chicken": "minecraft:cooked_chicken",
    "minecraft:porkchop": "minecraft:cooked_porkchop",
    "minecraft:beef": "minecraft:cooked_beef",
    "minecraft:rabbit": "minecraft:cooked_rabbit",
    "minecraft:mutton": "minecraft:cooked_mutton",
    "minecraft:cod": "minecraft:cooked_cod",
    "minecraft:salmon": "minecraft:cooked_salmon",
    "minecraft:kelp": "minecraft:dried_kelp",
};

const ore = {
    // Overworld Normal Ore
    "minecraft:iron_ore": "minecraft:iron_ingot",
    "minecraft:gold_ore": "minecraft:gold_ingot",
    "minecraft:diamond_ore": "minecraft:diamond",
    "minecraft:lapis_ore": "minecraft:lapis_lazuli",
    "minecraft:redstone_ore": "minecraft:redstone",
    "minecraft:coal_ore": "minecraft:coal",
    "minecraft:copper_ore": "minecraft:copper_ingot",
    "minecraft:emerald_ore": "minecraft:emerald",
    // Overworld Deepslate Ore
    "minecraft:deepslate_iron_ore": "minecraft:iron_ingot",
    "minecraft:deepslate_gold_ore": "minecraft:gold_ingot",
    "minecraft:deepslate_diamond_ore": "minecraft:diamond",
    "minecraft:deepslate_lapis_ore": "minecraft:lapis_lazuli",
    "minecraft:deepslate_redstone_ore": "minecraft:redstone",
    "minecraft:deepslate_coal_ore": "minecraft:coal",
    "minecraft:deepslate_copper_ore": "minecraft:copper_ingot",
    "minecraft:deepslate_emerald_ore": "minecraft:emerald",
    // Nether Ore
    "minecraft:quartz_ore": "minecraft:quartz",
    "minecraft:nether_gold_ore": "minecraft:gold_ingot",
    "minecraft:ancient_debris": "minecraft:netherite_scrap",
    // Raw
    "minecraft:raw_copper": "minecraft:copper_ingot",
    "minecraft:raw_iron": "minecraft:iron_ingot",
    "minecraft:raw_gold": "minecraft:gold_ingot",
};

export const mobs = [
    { name: "Bee", id: "minecraft:bee" },
    { name: "Pig", id: "minecraft:pig" },
    { name: "Cod", id: "minecraft:cod" },
    { name: "Zombie", id: "minecraft:zombie" },
    { name: "Cat", id: "minecraft:cat" },
    { name: "Cow", id: "minecraft:cow" },
    { name: "Fox", id: "minecraft:fox" },
    { name: "Mooshroom Cow", id: "minecraft:mooshroom" },
    { name: "Ocelot", id: "minecraft:ocelot" },
    { name: "Panda", id: "minecraft:panda" },
    { name: "Parrot", id: "minecraft:parrot" },
    { name: "Polar Bear", id: "minecraft:polarbear" },
    { name: "Snow Golem", id: "minecraft:snow_golem" },
    { name: "Turtle", id: "minecraft:turtle" },
    { name: "Wolf", id: "minecraft:wolf" },
    { name: "Chicken", id: "minecraft:chicken" },
    { name: "Camel", id: "minecraft:camel" },
    { name: "Sheep", id: "minecraft:sheep" },
    { name: "Silverfish", id: "minecraft:silverfish" },
    { name: "Spider", id: "minecraft:spider" },
    { name: "Cave Spider", id: "minecraft:cave_spider" },
    { name: "Sniffer", id: "minecraft:sniffer" },
    { name: "Salmon", id: "minecraft:salmon" },
    { name: "Squid", id: "minecraft:squid" },
    { name: "Allay", id: "minecraft:allay" },
    { name: "Warden", id: "minecraft:warden" },
    { name: "Armadillo", id: "minecraft:armadillo" },
    { name: "Frog", id: "minecraft:frog" },
    { name: "Rabbit", id: "minecraft:rabbit" },
    { name: "Witch", id: "minecraft:witch" },
    { name: "Ghast", id: "minecraft:ghast" },
    { name: "Mule", id: "minecraft:mule" },
    { name: "Ravager", id: "minecraft:ravager" },
    { name: "Pufferfish", id: "minecraft:pufferfish" },
    { name: "Axolotl", id: "minecraft:axolotl" },
    { name: "Creeper", id: "minecraft:creeper" },
    { name: "Glow Squid", id: "minecraft:glow_squid" },
    { name: "Strider", id: "minecraft:strider" },
    { name: "Wither Skeleton", id: "minecraft:wither_skeleton" },
    { name: "Bat", id: "minecraft:bat" },
    { name: "Dolphin", id: "minecraft:dolphin" },
    { name: "Goat", id: "minecraft:goat" },
    { name: "Tadpole", id: "minecraft:tadpole" },
    { name: "Donkey", id: "minecraft:donkey" },
    { name: "Guardian", id: "minecraft:guardian" },
    { name: "Shulker", id: "minecraft:shulker" },
    { name: "Llama", id: "minecraft:llama" },
    { name: "Zoglin", id: "minecraft:zoglin" },
    { name: "Blaze", id: "minecraft:blaze" },
    { name: "Drowned", id: "minecraft:drowned" },
    { name: "Hoglin", id: "minecraft:hoglin" },
    { name: "Phantom", id: "minecraft:phantom" },
    { name: "Tropical Fish", id: "minecraft:tropicalfish" },
    { name: "Elder Guardidan", i: "minecraft:elder_guardian" },
    { name: "Horse", id: "minecraft:horse" },
    { name: "Skeleton Horse", id: "minecraft:skeleton_horse" },
    { name: "Zombie Horse", id: "minecraft:zombie_horse" },
    { name: "Husk", id: "minecraft:husk" },
    { name: "Piglin Brute", id: "minecraft:piglin_brute" },
    { name: "Vex", id: "minecraft:vex" },
    { name: "Zombie Villager", id: "minecraft:zombie_villager" },
    { name: "Enderman", id: "minecraft:enderman" },
    { name: "Iron Golem", id: "minecraft:iron_golem" },
    { name: "Piglin", id: "minecraft:piglin" },
    { name: "Slime", id: "minecraft:slime" },
    { name: "Villager", id: "minecraft:villager" },
    { name: "Zombified Piglin", id: "minecraft:zombie_pigman" },
    { name: "Endermite", id: "minecraft:endermite" },
    { name: "Pillager", id: "minecraft:pillager" },
    { name: "Vindicator", id: "minecraft:vindicator" },
    { name: "Evoker", id: "minecraft:evocation_illager" },
    { name: "Magma Cube", id: "minecraft:magma_cube" },
    { name: "Wandering Trader", id: "minecraft:wandering_trader" },
];

export const beacon_ores = [
    "minecraft:iron_ingot",
    "minecraft:gold_ingot",
    "minecraft:diamond",
    "minecraft:emerald",
    "minecraft:netherite",
];

export const effects_tag = [
    "effect_speed",
    "effect_haste",
    "effect_resistance",
    "effect_jump_boost",
    "effect_strength",
];

export const blocks = ["minecraft:enchanting_table", "minecraft:crafting_table", "minecraft:anvil"];

const dyeMap = new Map([
    ["minecraft:black_dye", 1],
    ["minecraft:blue_dye", 2],
    ["minecraft:brown_dye", 3],
    ["minecraft:cyan_dye", 4],
    ["minecraft:gray_dye", 5],
    ["minecraft:green_dye", 6],
    ["minecraft:light_blue_dye", 7],
    ["minecraft:light_gray_dye", 8],
    ["minecraft:lime_dye", 9],
    ["minecraft:magenta_dye", 10],
    ["minecraft:orange_dye", 11],
    ["minecraft:pink_dye", 12],
    ["minecraft:purple_dye", 13],
    ["minecraft:red_dye", 14],
    ["minecraft:white_dye", 15],
    ["minecraft:yellow_dye", 16],
]);
