import { Entity, EntityComponentTypes, EntityInventoryComponent, ItemStack, Player } from '@minecraft/server';
import { ActionFormData, ModalFormData } from '@minecraft/server-ui'
import { loadCheckPoints, mobs } from './communs';

export function sleeping_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Sleeping Backpack')
    .button('Sleeping');
    return form
}

export function cultivator_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Cultivator Backpack')
    .body('The tick acceleration time lasts 10 seconds and has a cooldown time of 20 seconds before it can be used again.')
    .button('Active');
    return form
}

export function cauldron_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Cauldron Backpack')
    .button('Lava')
    .button('Milk')
    .button('Water');
    return form
}

export function mobtrap_backpack_menu(source) {
    const form = new ModalFormData()
    .title("Mob Trap Backpack\nEntity generation has a cooling off time of 5 seconds to generate the next entity")
    .dropdown(
        "Mobs",
        mobs.map((mob) => mob.name)
    )
    if (source.hasTag('active')) {
        form.toggle("Active", true);
    } else form.toggle("Active", false);

    return form
}

export function checkpoint_backpack_menu(source) {
    const form = new ActionFormData()
    .title('CheckPoint Backpack')
    .button('Save')
    .button('Load');
    return form
}

export function load_checkpoint_menu(source) {
    const form = new ActionFormData()
    .title('CheckPoint Backpack');
    let buttons = loadCheckPoints(source);
    buttons.forEach((button, index) => {
        form.button(`Check Point ${index+1}`)
    })
    return form
}

export function beacon_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Beacon Backpack')
    .button('Turn off/on ')
    .button('Speed')
    .button('Haste')
    .button('Resistance')
    .button('Jump Boost')
    .button('Strength');
    return form
}

export function utility_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Utility Backpack')
    .button('Backpack ')
    .button('Crafting table')
    .button('Anvil')
    .button('Enchanting Table')
    return form
}

export function super_backpack () {
    const form = new ActionFormData()
    .title('Super Backpack')
    .button('Sleeping Backpack')
    .button('Cultivator Backpack')
    .button('Furnace Backpack')
    .button('Mobtrap Backpack')
    .button('CheckPoint Backpack')
    .button('Beacon Backpack')
    .button('Mining Station Backpack')
    .button('Utility Backpack');
    return form
}

// =====================================================================================================================================================

export function super_sleeping_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Sleeping Backpack')
    .button('Sleeping');
    return form
}

export function super_cultivator_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Cultivator Backpack')
    .body('The tick acceleration time lasts 10 seconds and has a cooldown time of 20 seconds before it can be used again.')
    .button('Active');
    return form
}

export function super_cauldron_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Cauldron Backpack')
    .button('Lava')
    .button('Milk')
    .button('Water');
    return form
}

/**
 * 
 * @param {Entity} source 
 * @param {Entity} victim 
 */
export function super_mobtrap_backpack_menu(source) {
    const form = new ModalFormData()
    .title("Mob Trap Backpack\nEntity generation has a cooling off time of 5 seconds to generate the next entity")
    .dropdown(
        "Mobs",
        mobs.map((mob) => mob.name)
    )
    .toggle("Active", false);
    return form
}

export function super_checkpoint_backpack_menu(source) {
    const form = new ActionFormData()
    .title('CheckPoint Backpack')
    .button('Save')
    .button('Load');
    return form
}

export function super_load_checkpoint_menu(source) {
    const form = new ActionFormData()
    .title('CheckPoint Backpack');
    let buttons = loadCheckPoints(source);
    buttons.forEach((button, index) => {
        form.button(`Check Point ${index+1}`)
    })
    return form
}

export function super_beacon_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Beacon Backpack')
    .button('Turn off/on')
    .button('Speed')
    .button('Haste')
    .button('Resistance')
    .button('Jump Boost')
    .button('Strength');
    return form
}

export function super_utility_backpack_menu(source) {
    const form = new ActionFormData()
    .title('Utility Backpack')
    .button('Backpack ')
    .button('Crafting table')
    .button('Anvil')
    .button('Enchanting Table')
    return form
}
// ==============================================================================================================================
/**
 * 
 * @param {Player} source 
 * @param {Entity} backpack 
 */
export function ui_backpack(source,backpack) {
    const form = new ActionFormData()
    .title('Backpack')
    /**@type {EntityInventoryComponent} */
    const inventory_backpack = backpack.getComponent(EntityComponentTypes.Inventory);
    for (let index = 0; index < inventory_backpack.container.size; index++ ) {
        const item = inventory_backpack.container.getSlot(index).getItem()
        if ( item != undefined) form.button(`Slot: ${index} - ${item.typeId}`)
        else form.button(`Slot: ${index} - Emply`) 
    }
    return form
}

export function backpack_options(source, backpack) {
    const form = new ActionFormData()
    .title('Backpack')
    .button('Config')
    return form
}

// ==============================================================================================================================

