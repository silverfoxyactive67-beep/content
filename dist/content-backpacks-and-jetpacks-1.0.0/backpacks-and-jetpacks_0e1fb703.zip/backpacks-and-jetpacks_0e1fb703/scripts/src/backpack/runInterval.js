import { system, world, EntityComponentTypes } from "@minecraft/server";
import {
    dsEntity,
    effects_tag,
    getItem,
    getItemHand,
    handleFurnaceBackpack,
    handleBeaconBackpack,
    blocks,
} from "./communs";
import { backpacks, BackpackVariant } from "./backpacks";

system.runInterval(() => {
    handleBackpack();
    handlePlayer();
});

function handleBackpack() {
    dsEntity.forEach((dimension) => {
        world
            .getDimension(dimension)
            .getEntities()
            .forEach((victim) => {
                if (backpacks[victim.typeId]) {
                    switch (victim.typeId) {
                        case BackpackVariant.beacon.find((e) => e == victim.typeId):
                            victim.getTags().forEach((tag) => {
                                if (effects_tag.includes(tag)) {
                                    victim.dimension
                                        .getEntities({
                                            location: victim.location,
                                            maxDistance: 5,
                                            families: ["player"],
                                        })
                                        .forEach((player) => {
                                            player.addEffect(`${tag.replace("effect_", "")}`, 200);
                                        });
                                }
                            });
                            break;
                        case "ns_bp:cauldron_backpack":
                            break;
                        case "ns_bp:checkpoint_backpack":
                            break;
                        case "ns_bp:cultivator_backpack":
                            break;
                        case "ns_bp:furnace_backpack":
                            break;
                        case "ns_bp:mobtrap_backpack":
                            break;
                        case "ns_bp:sleeping_backpack":
                            break;
                        case BackpackVariant.super.find((e) => e == victim.typeId):
                            victim.dimension
                                .getEntities({
                                    type: "item",
                                    maxDistance: 1,
                                    location: victim.location,
                                })
                                .forEach((item) => {
                                    if (item.typeId == "minecraft:item") {
                                        let drop = item.getComponent(EntityComponentTypes.Item);
                                        if (blocks.includes(drop.itemStack.typeId)) item.remove();
                                    }
                                });
                            victim.getTags().forEach((tag) => {
                                if (effects_tag.includes(tag)) {
                                    victim.dimension
                                        .getEntities({
                                            location: victim.location,
                                            maxDistance: 5,
                                            families: ["player"],
                                        })
                                        .forEach((player) => {
                                            player.addEffect(`${tag.replace("effect_", "")}`, 200);
                                        });
                                }
                            });
                            break;
                        case BackpackVariant.utility.find((e) => e == victim.typeId):
                            victim.dimension
                                .getEntities({
                                    type: "item",
                                    maxDistance: 1,
                                    location: victim.location,
                                })
                                .forEach((item) => {
                                    if (item.typeId == "minecraft:item") {
                                        let drop = item.getComponent(EntityComponentTypes.Item);
                                        if (blocks.includes(drop.itemStack.typeId)) item.remove();
                                    }
                                });
                            break;
                        default:
                            break;
                    }
                }
            });
    });
}

let itemInMainhand = false;

function handlePlayer() {
    world.getAllPlayers().forEach((player) => {
        const chestplateItem = getItem(player);

        if (
            (chestplateItem.typeId == "ns_bp:furnace_backpack_item" ||
                chestplateItem.typeId == "ns_bp:super_backpack_item") &&
            player.hasTag("on_furnace")
        ) {
            handleFurnaceBackpack(player);
        }
        /*  if ((chestplateItem.typeId == 'ns_bp:beacon_backpack_item' || chestplateItem.typeId == 'ns_bp:super_backpack_item') && player.hasTag('on_beacon')) {
            handleBeaconBackpack(player)
        } */
        if (
            (BackpackVariant.beacon.includes(chestplateItem.typeId + "_item") ||
                chestplateItem.typeId == "ns_bp:super_backpack_item") &&
            player.hasTag("on_beacon")
        ) {
            handleBeaconBackpack(player);
        }
        // const item = getItemHand(player);
        // if (!itemInMainhand && item.typeId != 'minecraft:stick') {
        //     world.sendMessage(`${item.typeId}`)
        //     itemInMainhand = true
        // }
        // if (itemInMainhand && item.typeId == 'minecraft:stick') {
        //     itemInMainhand = false
        // }
    });
}
