import { ItemStopUseAfterEvent, system, world, ItemStack, GameRule } from "@minecraft/server";
import { check_inventory, handleFurnaceBackpack, magnet_item } from "./communs";

system.afterEvents.scriptEventReceive.subscribe((event) => {
    const { id, message, sourceEntity } = event;
    switch (id) {
        case "ns_bp:off_cultivator": {
            sourceEntity.runCommand("gamerule randomtickspeed 1");
            sourceEntity.setProperty("ns_bp:cultivator", 0);
            break;
        }
        case "ns_bp:cooldown_cultivator": {
            sourceEntity.setProperty("ns_bp:lock", 0);
            world.sendMessage('Cooldown time is up.')
            break
        }
        case "ns_bp:check_inventory": {
            magnet_item(sourceEntity)
            const inventorySlot = check_inventory(sourceEntity);
            if ( inventorySlot ) sourceEntity.setProperty('ns_bp:breakblock',1);
            else sourceEntity.setProperty('ns_bp:breakblock', 0);
            break
        }
        case "ns_bp:on_furnace": {
            handleFurnaceBackpack(sourceEntity);
            break
        }
        case "ns_bp:summon_entity": {
            
            sourceEntity.getTags().forEach((tag) => {
                try {
                    if (tag.includes("minecraft:")) sourceEntity.dimension.spawnEntity(tag,sourceEntity.location)
                } catch (error) {
                    world.sendMessage('You cannot spawn the mob while in peaceful mode')
                }
                
            })
            break
        }
        case 'a:a': {
            sourceEntity.dimension.getEntities({
                families:["backpack_ns"],
                maxDistance:50,
                location:sourceEntity.location
            }).forEach((backpack)=>{
                backpack.remove()
            })
            break
        }
        case 'ns_bp:timer_cultivator': {
            const timer = sourceEntity.getProperty('ns_bp:cultivator_timer');
            if (timer == 1) {
                sourceEntity.nameTag = '§f'
                sourceEntity.setProperty('ns_bp:cultivator_timer', timer - 1)
            } else if (timer <= 20) {
                sourceEntity.nameTag = `Cooldown: ${timer}`,
                sourceEntity.setProperty('ns_bp:cultivator_timer', timer - 1)
            }
            break
        }
        case 'book:death': {
            let spawnEgg = new ItemStack(`${sourceEntity.typeId}_spawn_egg`)
            sourceEntity.dimension.spawnItem(spawnEgg,sourceEntity.location)
            sourceEntity.remove();
            break
        }
    }
});
