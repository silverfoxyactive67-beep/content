import "./itemUse";
import "./damageSensor";
import "./eventscript";
import "./runInterval";
import { system, world } from "@minecraft/server";
import { BackpackVariant } from "./backpacks";

system.runInterval(() => {
    world.getAllPlayers().forEach((player) => {
        player
            .getEntitiesFromViewDirection({
                families: ["backpack_ns"],
                maxDistance: 8,
            })
            .forEach((victim) => {
                let typeId = victim.entity.typeId;
                let timer = victim.entity.getProperty("ns_bp:cultivator_timer") ?? 0;
                let extra_sentence = `The backpack is in the process of cooling down, wait for it to finish before you remove it.`;
                if (typeId.includes("ns_bp:")) {
                    switch (typeId) {
                        /* case "ns_bp:beacon_backpack": {
                        player.onScreenDisplay.setActionBar('§5[Beacon Backpack]§r\nPress Crouch + Hit to access the skill menu.\nYou can only acess this skill with a ore in hand.');
                        break
                    } */
                        case BackpackVariant.beacon.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Beacon Backpack]§r\nPress Crouch + Hit to access the skill menu.\nYou can only acess this skill with a ore in hand."
                            );
                            break;
                        }

                        case BackpackVariant.mining.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Mining Station Backpack]§r\nPress Crouch + Hit to start mining."
                            );
                            break;
                        }
                        case BackpackVariant.furnace.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Furnace Backpack]§r\nPress Crouch + Hit to activate cooking items inside your bag."
                            );
                            break;
                        }
                        case BackpackVariant.cultivator.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                `§5[Cultivator Backpack]§r\nPress Crouch + Hit to open your skills menu.${
                                    timer != 0 ? "\n" + extra_sentence : ""
                                }`
                            );
                            break;
                        }
                        case BackpackVariant.checkpoint.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Checkpoint Backpack]§r\nPress Crouch + Hit to open your skills menu."
                            );
                            break;
                        }
                        case BackpackVariant.cauldron.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Cauldron Backpack]§r\nPress Crouch + Hit to open your skills menu.\nYou need to hold a bucket to collect the liquid."
                            );
                            break;
                        }
                        case BackpackVariant.sleeping.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Sleeping Bag Backpack]§r\nPress Crouch + Hit to open your skills menu."
                            );
                            break;
                        }
                        case BackpackVariant.super.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                `§5[Super Backpack]§r\nPress Crouch + Hit to open your skills menu.${
                                    timer != 0 ? "\n" + extra_sentence : ""
                                }`
                            );
                            break;
                        }
                        case BackpackVariant.utility.find((e) => e == typeId): {
                            player.onScreenDisplay.setActionBar(
                                "§5[Utility Backpack]§r\nPress Crouch + Hit to open your skills menu."
                            );
                            break;
                        }
                    }
                }
            });
    });
});

world.afterEvents.entitySpawn.subscribe((event) => {
    const { cause, entity } = event;
    if (entity.typeId.includes("ns_bp")) {
        entity.nameTag = "§f";
    }
});
