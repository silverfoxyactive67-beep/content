import {
    EntityComponentTypes,
    EntityInventoryComponent,
    Player,
    world,
    EquipmentSlot,
    EntityEquippableComponent,
    ItemStack,
    ItemLockMode,
    system,
    World,
    EffectType,
} from "@minecraft/server";
import { backpacks, backpacks_items } from "./backpacks";
import { saveBackpack, loadBackpack, getItem, dyeBackpack } from "./communs";
import { backpack_options, ui_backpack } from "./menu";
import { Colors } from "./damageSensor";

world.afterEvents.itemUse.subscribe((event) => {
    const { itemStack, source } = event;
    const typeId = itemStack.typeId;
    const gamemode = source.getGameMode();

    if (backpacks_items[typeId]) {
        if (source.isSneaking) {
            const lores = itemStack.getLore();
            if (lores.length > 0) {
                let blockFrowView = source.getBlockFromViewDirection({
                    maxDistance: 6,
                });

                if (blockFrowView != undefined) {
                    const block = blockFrowView.block;
                    let locationBlock = {
                        x: block.location.x + 0.5,
                        y: block.location.y + 1,
                        z: block.location.z + 0.5,
                    };
                    if (source.nameTag == lores[0]) {
                        const rotaion_player = source.getRotation();
                        loadBackpack(source, lores[1], locationBlock);
                        //  source.runCommand(`replaceitem entity @s slot.armor.chest 0 air`);
                        source.dimension
                            .getEntities({
                                maxDistance: 8,
                                location: source.location,
                                tags: [`${source.nameTag}`],
                                closest: 1,
                            })
                            .forEach((player_backpack) => {
                                player_backpack.setRotation(rotaion_player);
                                player_backpack.tryTeleport(locationBlock);
                            });
                    } else
                        source.sendMessage(
                            "You are not allowed to use this backpack, you are not the owner."
                        );
                } else {
                    if (source.nameTag == lores[0]) {
                        const rotaion_player = source.getRotation();
                        loadBackpack(source, lores[1], source.location);
                        //  source.runCommand(`replaceitem entity @s slot.armor.chest 0 air`);
                        source.dimension
                            .getEntities({
                                maxDistance: 8,
                                location: source.location,
                                tags: [`${source.nameTag}`],
                                closest: 1,
                            })
                            .forEach((player_backpack) => {
                                player_backpack.setRotation(rotaion_player);
                                player_backpack.tryTeleport(source.location);
                            });
                    } else
                        source.sendMessage(
                            "You are not allowed to use this backpack, you are not the owner."
                        );
                }
            } else {
                const colorId = typeId
                    .replace("ns_bp:", "")
                    .replace("_item", "")
                    .split("_")
                    .slice(2)
                    .join("_");

                const backpackColor = Array.from(Colors.values()).find(
                    (color) => color === colorId && color.length === colorId.length
                );

                if (backpackColor) {
                    const colorIndex = Array.from(Colors.entries()).findIndex(
                        (element) => element[1] === backpackColor
                    );

                    const backpack = source.dimension.spawnEntity(
                        typeId.replace(`_${backpackColor}_item`, ""),
                        source.location
                    );
                    backpack.setProperty("backpack:color", colorIndex);
                    backpack.addTag(`${source.nameTag}`);
                } else {
                    const backpack = source.dimension.spawnEntity(
                        typeId.replace("_item", ""),
                        source.location
                    );
                    backpack.setProperty("backpack:color", 0);
                    backpack.addTag(`${source.nameTag}`);
                }

                //source.runCommand(`replaceitem entity @s slot.armor.chest 0 air`);
            }
            source.runCommand(`clear @s ${typeId} 0 1`);
        } else {
            //  set_item_controller(source);
        }
    }
    if (typeId == "ns_bp:backpack_controller") {
        const chestplate = getItem(source);
        if (chestplate != undefined) {
            if (backpacks_items[chestplate.typeId]) {
                open_backpack(source, itemStack);
            }
        }
    }
});

world.beforeEvents.itemUse.subscribe((event) => {
    const { itemStack, source } = event;
    const typeId = itemStack.typeId;
    const gamemode = source.getGameMode();
    const equippable = source.getComponent(EntityComponentTypes.Equippable);
    const chestplate = equippable.getEquipment(EquipmentSlot.Chest);

    if (backpacks_items[typeId]) {
        if (!source.isSneaking) {
            if (gamemode == "creative" && getItem(source).typeId == "minecraft:stick") {
                source.runCommandAsync(`clear @s ${typeId} 0 1`);
            }
            if (chestplate) {
                system.runTimeout(() => {
                    equippable.setEquipment(EquipmentSlot.Chest, itemStack);
                    equippable.setEquipment(EquipmentSlot.Mainhand, chestplate);
                });
            }
        }
    }
});

world.afterEvents.playerInteractWithEntity.subscribe((event) => {
    const { player, itemStack, target: entity } = event;

    if (backpacks[entity.typeId] != undefined) {
        if (player.isSneaking) {
            dyeBackpack(player, entity, itemStack);
        }
    }
});

/**
 *
 * @param {Player} source
 * @param {ItemStack} itemStack
 */
function open_backpack(source, itemStack) {
    world.sendMessage("rpaz");
    const sourceLocation = source.location;
    const lores = itemStack.getLore();
    const location = {
        x: sourceLocation.x,
        y: sourceLocation.y - 1,
        z: sourceLocation.z,
    };
    loadBackpack(source, lores[1], location);
    source.dimension
        .getEntities({
            maxDistance: 1,
            location: location,
            tags: [`${source.nameTag}`],
            closest: 1,
        })
        .forEach((backpack) => {
            backpack.addEffect("invisibility", 9999, { showParticles: false });

            let form_options_backpack = backpack_options(source, backpack);
            form_options_backpack.show(source).then((response_options_backpack) => {
                if (
                    response_options_backpack.canceled ||
                    response_options_backpack.cancelationReason
                )
                    close_backpack(source, backpack);
                switch (response_options_backpack.selection) {
                    case 0: {
                        close_backpack(source, backpack);
                        world.sendMessage("Caso de teste 2");
                        break;
                    }
                }
            });
        });
}

/**
 *
 * @param {Player} source
 */
function set_item_controller(source) {
    const controller_backpack = new ItemStack("minecraft:air", 1);
    controller_backpack.keepOnDeath = false;
    controller_backpack.lockMode = ItemLockMode.inventory;

    const backpack = getItem(source);
    if (backpack != undefined) {
        let lores = backpack.getLore();
        if (lores.length > 0) {
            controller_backpack.setLore(lores);
        }
    }
    /**
     * @type {EntityEquippableComponent}
     */
    const componet = source.getComponent("minecraft:equippable");

    componet.setEquipment(EquipmentSlot.Mainhand, controller_backpack);
}

// system.runInterval(() => {
//     world.getAllPlayers().forEach((player) => {
//         controller_inventory_item_controller(player)
//     })
// })

/**
 *
 * @param {Player} source
 */
function controller_inventory_item_controller(source) {
    /** @type {EntityInventoryComponent} */
    const inventory = source.getComponent(EntityComponentTypes.Inventory);

    for (let index = 0; index < inventory.container.size; index++) {
        const item = inventory.container.getItem(index);

        if (item && item.typeId === "ns_bp:backpack_controller") {
            const lores = item.getLore();

            if (!lores.includes(`${source.nameTag}`)) {
                const slotType = index < 9 ? "hotbar" : "inventory";
                const slotIndex = index < 9 ? index : index - 9;
                source.runCommand(`replaceitem entity @s slot.${slotType} ${slotIndex} air`);
            }
        }
    }

    /** @type {EntityEquippableComponent} */
    const equipComponent = source.getComponent("minecraft:equippable");
    const chestplate = equipComponent.getEquipment(EquipmentSlot.Chest);

    if (!chestplate || !chestplate.typeId.includes("backpack")) {
        source.runCommand(`clear @s ns_bp:backpack_controller`);
    }
}

function close_backpack(source, backpack) {
    const item_backpack = new ItemStack(`${backpack.typeId}_item`, 1);
    item_backpack.setLore([`${source.nameTag}`, `${backpack.id}`]);
    let lores = item_backpack.getLore();

    const item_controller_backpack = new ItemStack("ns_bp:backpack_controller", 1);
    item_controller_backpack.keepOnDeath = false;
    item_controller_backpack.lockMode = ItemLockMode.inventory;

    item_controller_backpack.setLore(lores);

    backpack.removeEffect("invisibility");
    saveBackpack(source, backpack);

    /**
     * @type {EntityEquippableComponent}
     */
    const componet = source.getComponent("minecraft:equippable");
    componet.setEquipment(EquipmentSlot.Chest, item_backpack);
    componet.setEquipment(EquipmentSlot.Mainhand, item_controller_backpack);
}
