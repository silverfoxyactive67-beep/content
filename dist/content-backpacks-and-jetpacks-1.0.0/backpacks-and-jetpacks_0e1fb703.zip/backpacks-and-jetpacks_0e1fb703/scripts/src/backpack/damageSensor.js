import {
    Entity,
    ItemStack,
    World,
    world,
    EntityEquippableComponent,
    EquipmentSlot,
} from "@minecraft/server";
import { backpacks, BackpackVariant } from "./backpacks";
import {
    beacon_ores,
    blocks,
    effects_tag,
    getItemHand,
    handleCauldronBackpack,
    liquids_backpack,
    loadCheckPoints,
    mobs,
    propertys,
    saveBackpack,
    saveCheckPoint,
    setPropertyInEntity,
} from "./communs";
import {
    cultivator_backpack_menu,
    sleeping_backpack_menu,
    cauldron_backpack_menu,
    mobtrap_backpack_menu,
    checkpoint_backpack_menu,
    load_checkpoint_menu,
    beacon_backpack_menu,
    utility_backpack_menu,
    super_backpack,
    super_sleeping_backpack_menu,
} from "./menu";

export const Colors = new Map([
    [0, "none"],
    [1, "black"],
    [2, "blue"],
    [3, "brown"],
    [4, "cyan"],
    [5, "gray"],
    [6, "green"],
    [7, "light_blue"],
    [8, "light_gray"],
    [9, "lime"],
    [10, "magenta"],
    [11, "orange"],
    [12, "pink"],
    [13, "purple"],
    [14, "red"],
    [15, "white"],
    [16, "yellow"],
]);

world.afterEvents.entityHitEntity.subscribe((event) => {
    const { damagingEntity, hitEntity } = event;
    if (damagingEntity.typeId == "minecraft:player") {
        if (backpacks[hitEntity.typeId]) {
            if (hitEntity.hasTag(`${damagingEntity.nameTag}`))
                mainDamageSensor(damagingEntity, hitEntity);
            else
                damagingEntity.sendMessage(
                    "You are not allowed to interact with this backpack\nYou are not the owner."
                );
        }
    }
});

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function mainDamageSensor(damagingEntity, hitEntity) {
    if (!damagingEntity.isSneaking && backpacks[hitEntity.typeId]) {
        handleNormalHit(damagingEntity, hitEntity);
    } else if (damagingEntity.isSneaking && backpacks[hitEntity.typeId]) {
        switch (hitEntity.typeId) {
            /*  case "ns_bp:beacon_backpack": {
                let itemStack = getItemHand(damagingEntity);
                if (beacon_ores.includes(itemStack.typeId))
                    handleBeacon(damagingEntity, hitEntity, itemStack.typeId);
                break;
            } */
            case BackpackVariant.beacon.find((e) => e == hitEntity.typeId): {
                let itemStack = getItemHand(damagingEntity);
                if (beacon_ores.includes(itemStack.typeId))
                    handleBeacon(damagingEntity, hitEntity, itemStack.typeId);
                break;
            }
            case BackpackVariant.cauldron.find((e) => e == hitEntity.typeId):
                handleCauldron(damagingEntity, hitEntity);
                break;
            case BackpackVariant.mining.find((e) => e == hitEntity.typeId):
                handleMN(damagingEntity, hitEntity);
                break;
            case BackpackVariant.checkpoint.find((e) => e == hitEntity.typeId):
                handleCheckPoint(damagingEntity, hitEntity);
                break;
            case BackpackVariant.cultivator.find((e) => e == hitEntity.typeId):
                let timer = hitEntity.getProperty("ns_bp:cultivator_timer");
                if (timer == 0) {
                    handleCultivator(damagingEntity, hitEntity);
                } else {
                    return;
                }
                break;
            case BackpackVariant.furnace.find((e) => e == hitEntity.typeId):
                handleFurnace(damagingEntity, hitEntity);
                break;
            case BackpackVariant.mobtrap.find((e) => e == hitEntity.typeId):
                handleMobtrap(damagingEntity, hitEntity);
                break;
            case BackpackVariant.sleeping.find((e) => e == hitEntity.typeId):
                handleSleeping(damagingEntity, hitEntity);
                break;
            case BackpackVariant.super.find((e) => e == hitEntity.typeId):
                let itemHand = getItemHand(damagingEntity);

                if (liquids_backpack[itemHand.typeId]) handleCauldron(damagingEntity, hitEntity);
                else handleSuper(damagingEntity, hitEntity);
                break;
            case BackpackVariant.utility.find((e) => e == hitEntity.typeId):
                handleUtility(damagingEntity, hitEntity);
                break;
            default:
                break;
        }
    }
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleNormalHit(damagingEntity, hitEntity) {
    const color = hitEntity.getProperty("backpack:color") ?? 0;

    const itemStack = new ItemStack(
        hitEntity.typeId + `${color > 0 ? `_${Colors.get(color)}` : ""}` + "_item",
        1
    );
    const location = hitEntity.location;
    itemStack.setLore([`${damagingEntity.nameTag}`, `${hitEntity.id}`]);

    if (
        BackpackVariant.utility.find((e) => e == hitEntity.typeId) ||
        BackpackVariant.super.find((e) => e == hitEntity.typeId)
    ) {
        const locationBlock = {
            x: location.x,
            y: location.y - 1,
            z: location.z,
        };
        const locationAboveBlock = {
            x: location.x,
            y: location.y,
            z: location.z,
        };

        const block = hitEntity.dimension.getBlock(locationBlock);
        const blockAbove = hitEntity.dimension.getBlock(locationAboveBlock);
        if (blocks.includes(block.typeId)) {
            hitEntity.runCommand(
                `setblock ${locationBlock.x} ${locationBlock.y} ${locationBlock.z} air`
            );
        } else if (blocks.includes(blockAbove.typeId)) {
            hitEntity.runCommand(
                `setblock ${locationAboveBlock.x} ${locationAboveBlock.y} ${locationAboveBlock.z} air`
            );
        }
    }
    if (
        BackpackVariant.cultivator.find((e) => e == hitEntity.typeId) ||
        BackpackVariant.super.find((e) => e == hitEntity.typeId)
    ) {
        let timer = hitEntity.getProperty("ns_bp:cultivator_timer");
        if (timer == 0) {
            saveBackpack(damagingEntity, hitEntity);
            damagingEntity.dimension.spawnItem(itemStack, damagingEntity.location);
        } else {
            return;
        }
    } else {
        saveBackpack(damagingEntity, hitEntity);
        damagingEntity.dimension.spawnItem(itemStack, damagingEntity.location);
    }
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleCauldron(damagingEntity, hitEntity) {
    let lava = hitEntity.getProperty("ns_bp:lava");
    let water = hitEntity.getProperty("ns_bp:water");
    let milk = hitEntity.getProperty("ns_bp:milk");

    let item_bucket_lava = new ItemStack("minecraft:lava_bucket", 1);
    let item_bucket_water = new ItemStack("minecraft:water_bucket", 1);
    let item_bucket = new ItemStack("minecraft:bucket", 1);

    let location = damagingEntity.location;

    let item_mainhand = getItemHand(damagingEntity);

    if (item_mainhand.typeId == "minecraft:lava_bucket") {
        if (milk == 0 && water == 0 && lava < 10) {
            hitEntity.setProperty("ns_bp:lava", lava + 1);
            set_item(damagingEntity, item_bucket);
        }
    } else if (item_mainhand.typeId == "minecraft:water_bucket") {
        if (milk == 0 && lava == 0 && water < 10) {
            hitEntity.setProperty("ns_bp:water", water + 1);
            set_item(damagingEntity, item_bucket);
        }
    }
    if (item_mainhand.typeId == "minecraft:bucket" && (lava != 0 || water != 0 || milk != 0)) {
        if (lava > 0) {
            hitEntity.setProperty("ns_bp:lava", lava - 1);
            set_item(damagingEntity, item_bucket_lava);
        } else if (water > 0) {
            hitEntity.setProperty("ns_bp:water", water - 1);
            set_item(damagingEntity, item_bucket_water);
        }
    }
}

function set_item(source, itemStack) {
    /**
     * @type {EntityEquippableComponent}
     */
    const componet = source.getComponent("minecraft:equippable");

    componet.setEquipment(EquipmentSlot.Mainhand, itemStack);
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleCultivator(damagingEntity, hitEntity) {
    let cultivator_form = cultivator_backpack_menu(damagingEntity);

    cultivator_form.show(damagingEntity).then((response) => {
        if (response.canceled) return;

        let cultivatorof = hitEntity.getProperty(propertys[0]);
        let lock = hitEntity.getProperty(propertys[1]);

        if (response.selection === 0) {
            if (cultivatorof === 0 && lock === 0) {
                damagingEntity.runCommand("gamerule randomtickspeed 500");
                hitEntity.setProperty(propertys[0], 1);
                hitEntity.setProperty(propertys[1], 1);
            } else {
                world.sendMessage(`Cooldown is active.`);
            }
        }
    });
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleSleeping(damagingEntity, hitEntity) {
    let form = sleeping_backpack_menu(damagingEntity);

    form.show(damagingEntity).then((response) => {
        if (response.canceled) return;
        const timeDay = world.getTimeOfDay();
        if (response.selection == 0) {
            if (timeDay > 12000) {
                damagingEntity.runCommand("camera @s fade time 0 1 0.5 color 0 0 0");
                world.setTimeOfDay(5000);
            } else {
                damagingEntity.runCommand("camera @s fade time 0 1 0.5 color 0 0 0");
                world.setTimeOfDay(17000);
            }
        }
    });
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleMobtrap(damagingEntity, hitEntity) {
    const form = mobtrap_backpack_menu(hitEntity);

    form.show(damagingEntity).then((response) => {
        if (response.canceled) return;

        const [dropdownValue, active] = response.formValues;
        for (let index = 0; index < mobs.length; index++) {
            hitEntity.removeTag(`${mobs[index].id}`);
        }
        if (active) {
            hitEntity.setProperty("ns_bp:mobtrap", 1);
            hitEntity.addTag("active");
        } else {
            hitEntity.setProperty("ns_bp:mobtrap", 0);
            hitEntity.removeTag("active");
        }

        hitEntity.addTag(mobs[dropdownValue].id);
    });
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleFurnace(damagingEntity, hitEntity) {
    if (hitEntity.hasTag("on_furnace")) {
        hitEntity.removeTag("on_furnace");
        damagingEntity.removeTag("on_furnace");
    } else {
        hitEntity.addTag("on_furnace");
        damagingEntity.addTag("on_furnace");
    }
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleMN(damagingEntity, hitEntity) {
    const blockBelow = hitEntity.dimension.getBlock(hitEntity.location).below();
    const blockId = blockBelow.typeId;

    if (hitEntity.location.y > -59 && blockId != "minecraft:bedrock") {
        if (hitEntity.getProperty("ns_bp:breakblock") == 1) {
            hitEntity.setProperty("ns_bp:breakblock", 0);
        } else {
            hitEntity.setProperty("ns_bp:breakblock", 1);
        }
    }
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleCheckPoint(damagingEntity, hitEntity) {
    const form = checkpoint_backpack_menu(damagingEntity);
    form.show(damagingEntity).then((response) => {
        if (response.canceled) return;
        if (response.selection == 0) {
            saveCheckPoint(damagingEntity);
        } else if (response.selection == 1) {
            const loadForm = load_checkpoint_menu(damagingEntity);
            loadForm.show(damagingEntity).then((laodResponse) => {
                if (laodResponse.canceled) return;
                let coord = loadCheckPoints(damagingEntity);
                let coordinates = world.getDynamicProperty(coord[laodResponse.selection]);
                damagingEntity.teleport(coordinates);
                hitEntity.teleport(coordinates);
            });
        }
    });
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleBeacon(damagingEntity, hitEntity, item) {
    const form = beacon_backpack_menu(damagingEntity);
    form.show(damagingEntity).then((response) => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0: {
                if (damagingEntity.hasTag("on_beacon")) {
                    effects_tag.forEach((tag) => {
                        damagingEntity.removeTag(`${tag}`);
                        hitEntity.removeTag(`${tag}`);
                    });
                    damagingEntity.removeTag("on_beacon");
                } else {
                    damagingEntity.addTag("on_beacon");
                    hitEntity.addTag("on_beacon");
                }
                break;
            }

            case 1: {
                damagingEntity.addTag(`${effects_tag[0]}`);
                hitEntity.addTag(`${effects_tag[0]}`);
                damagingEntity.runCommand(`clear @s ${item} 0 1`);
                damagingEntity.addTag("on_beacon");
                hitEntity.addTag("on_beacon");
                break;
            }

            case 2: {
                damagingEntity.addTag(`${effects_tag[1]}`);
                hitEntity.addTag(`${effects_tag[1]}`);
                damagingEntity.runCommand(`clear @s ${item} 0 1`);
                damagingEntity.addTag("on_beacon");
                hitEntity.addTag("on_beacon");
                break;
            }

            case 3: {
                damagingEntity.addTag(`${effects_tag[2]}`);
                hitEntity.addTag(`${effects_tag[2]}`);
                damagingEntity.runCommand(`clear @s ${item} 0 1`);
                damagingEntity.addTag("on_beacon");
                hitEntity.addTag("on_beacon");
                break;
            }

            case 4: {
                damagingEntity.addTag(`${effects_tag[3]}`);
                hitEntity.addTag(`${effects_tag[3]}`);
                damagingEntity.runCommand(`clear @s ${item} 0 1`);
                damagingEntity.addTag("on_beacon");
                hitEntity.addTag("on_beacon");
                break;
            }

            case 5: {
                damagingEntity.addTag(`${effects_tag[4]}`);
                hitEntity.addTag(`${effects_tag[4]}`);
                damagingEntity.runCommand(`clear @s ${item} 0 1`);
                damagingEntity.addTag("on_beacon");
                hitEntity.addTag("on_beacon");
                break;
            }

            default:
                break;
        }
    });
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleUtility(damagingEntity, hitEntity) {
    const location = hitEntity.location;
    const locationBlock = {
        x: location.x,
        y: location.y - 1,
        z: location.z,
    };
    const locationAboveBlock = {
        x: location.x,
        y: location.y,
        z: location.z,
    };
    const form = utility_backpack_menu(damagingEntity);

    form.show(damagingEntity).then((response) => {
        if (response.cancelationReason) return;

        const block = hitEntity.dimension.getBlock(locationBlock);
        const blockAbove = hitEntity.dimension.getBlock(locationAboveBlock);
        let newY = location.y;
        let newX = Math.floor(location.x) + 0.5;
        let newZ = Math.floor(location.z) + 0.5;

        switch (response.selection) {
            case 0: {
                if (blocks.includes(block.typeId)) {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y} ${locationBlock.z} air`
                    );
                } else if (blocks.includes(blockAbove.typeId)) {
                    hitEntity.runCommand(
                        `setblock ${locationAboveBlock.x} ${locationAboveBlock.y} ${locationAboveBlock.z} air`
                    );
                }
                newY = Math.round(location.y + 0.25);
                break;
            }
            case 1: {
                if (!blocks.includes(block.typeId)) {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y + 1} ${
                            locationBlock.z
                        } crafting_table`
                    );
                    newY = location.y + 1;
                } else {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y} ${locationBlock.z} crafting_table`
                    );
                }
                break;
            }
            case 2: {
                if (!blocks.includes(block.typeId)) {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y + 1} ${
                            locationBlock.z
                        } minecraft:anvil`
                    );
                    newY = location.y + 1;
                } else {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y} ${locationBlock.z} minecraft:anvil`
                    );
                }
                break;
            }
            case 3: {
                if (!blocks.includes(block.typeId)) {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y + 1} ${
                            locationBlock.z
                        } minecraft:enchanting_table`
                    );
                    newY = location.y + 2;
                } else {
                    hitEntity.runCommand(
                        `setblock ${locationBlock.x} ${locationBlock.y} ${locationBlock.z} minecraft:enchanting_table`
                    );
                }
                break;
            }
        }
        hitEntity.setRotation({
            x: 0,
            y: 0,
        });

        // Teleport the entity to the new location, centered on the block
        hitEntity.teleport({
            x: newX,
            y: newY,
            z: newZ,
        });
    });
}

/**
 *
 * @param {Entity} damagingEntity
 * @param {Entity} hitEntity
 */
function handleSuper(damagingEntity, hitEntity) {
    let timer = hitEntity.getProperty("ns_bp:cultivator_timer");

    const form = super_backpack();
    let itemStack = getItemHand(damagingEntity);
    form.show(damagingEntity).then((response) => {
        if (response.canceled) return;
        switch (response.selection) {
            case 0: {
                handleSleeping(damagingEntity, hitEntity);
                break;
            }
            case 1: {
                if (timer == 0) {
                    handleCultivator(damagingEntity, hitEntity);
                } else {
                    return;
                }
                break;
            }
            case 2: {
                handleFurnace(damagingEntity, hitEntity);
                break;
            }
            case 3: {
                handleMobtrap(damagingEntity, hitEntity);
                break;
            }
            case 4: {
                handleCheckPoint(damagingEntity, hitEntity);
                break;
            }
            case 5: {
                if (beacon_ores.includes(itemStack.typeId))
                    handleBeacon(damagingEntity, hitEntity, itemStack.typeId);
                break;
            }
            case 6: {
                handleMN(damagingEntity, hitEntity);
                break;
            }
            case 7: {
                handleUtility(damagingEntity, hitEntity);
            }
        }
    });
}
