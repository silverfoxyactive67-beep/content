import {
    beacon_backpack_menu,
    cauldron_backpack_menu,
    checkpoint_backpack_menu,
    cultivator_backpack_menu,
    sleeping_backpack_menu,
} from "./menu";

export const backpacks = {
    //BEACON BACKPACKS
    "ns_bp:beacon_backpack": {},
    "ns_bp:beacon_backpack_black": {},
    "ns_bp:beacon_backpack_blue": {},
    "ns_bp:beacon_backpack_brown": {},
    "ns_bp:beacon_backpack_cyan": {},
    "ns_bp:beacon_backpack_gray": {},
    "ns_bp:beacon_backpack_green": {},
    "ns_bp:beacon_backpack_light_blue": {},
    "ns_bp:beacon_backpack_light_gray": {},
    "ns_bp:beacon_backpack_lime": {},
    "ns_bp:beacon_backpack_magenta": {},
    "ns_bp:beacon_backpack_orange": {},
    "ns_bp:beacon_backpack_pink": {},
    "ns_bp:beacon_backpack_purple": {},
    "ns_bp:beacon_backpack_red": {},
    "ns_bp:beacon_backpack_white": {},
    "ns_bp:beacon_backpack_yellow": {},

    //CAULDRON BACKPACKS
    "ns_bp:cauldron_backpack": {},
    "ns_bp:cauldron_backpack_black": {},
    "ns_bp:cauldron_backpack_blue": {},
    "ns_bp:cauldron_backpack_brown": {},
    "ns_bp:cauldron_backpack_cyan": {},
    "ns_bp:cauldron_backpack_gray": {},
    "ns_bp:cauldron_backpack_green": {},
    "ns_bp:cauldron_backpack_light_blue": {},
    "ns_bp:cauldron_backpack_light_gray": {},
    "ns_bp:cauldron_backpack_lime": {},
    "ns_bp:cauldron_backpack_magenta": {},
    "ns_bp:cauldron_backpack_orange": {},
    "ns_bp:cauldron_backpack_pink": {},
    "ns_bp:cauldron_backpack_purple": {},
    "ns_bp:cauldron_backpack_red": {},
    "ns_bp:cauldron_backpack_white": {},
    "ns_bp:cauldron_backpack_yellow": {},

    //CHECKPOINT BACKPACKS
    "ns_bp:checkpoint_backpack": {},
    "ns_bp:checkpoint_backpack_black": {},
    "ns_bp:checkpoint_backpack_blue": {},
    "ns_bp:checkpoint_backpack_brown": {},
    "ns_bp:checkpoint_backpack_cyan": {},
    "ns_bp:checkpoint_backpack_gray": {},
    "ns_bp:checkpoint_backpack_green": {},
    "ns_bp:checkpoint_backpack_light_blue": {},
    "ns_bp:checkpoint_backpack_light_gray": {},
    "ns_bp:checkpoint_backpack_lime": {},
    "ns_bp:checkpoint_backpack_magenta": {},
    "ns_bp:checkpoint_backpack_orange": {},
    "ns_bp:checkpoint_backpack_pink": {},
    "ns_bp:checkpoint_backpack_purple": {},
    "ns_bp:checkpoint_backpack_red": {},
    "ns_bp:checkpoint_backpack_white": {},
    "ns_bp:checkpoint_backpack_yellow": {},

    //CULTIVATOR BACKPACKS
    "ns_bp:cultivator_backpack": {},
    "ns_bp:cultivator_backpack_black": {},
    "ns_bp:cultivator_backpack_blue": {},
    "ns_bp:cultivator_backpack_brown": {},
    "ns_bp:cultivator_backpack_cyan": {},
    "ns_bp:cultivator_backpack_gray": {},
    "ns_bp:cultivator_backpack_green": {},
    "ns_bp:cultivator_backpack_light_blue": {},
    "ns_bp:cultivator_backpack_light_gray": {},
    "ns_bp:cultivator_backpack_lime": {},
    "ns_bp:cultivator_backpack_magenta": {},
    "ns_bp:cultivator_backpack_orange": {},
    "ns_bp:cultivator_backpack_pink": {},
    "ns_bp:cultivator_backpack_purple": {},
    "ns_bp:cultivator_backpack_red": {},
    "ns_bp:cultivator_backpack_white": {},
    "ns_bp:cultivator_backpack_yellow": {},

    //FURNACE BACKPACKS
    "ns_bp:furnace_backpack": {},
    "ns_bp:furnace_backpack_black": {},
    "ns_bp:furnace_backpack_blue": {},
    "ns_bp:furnace_backpack_brown": {},
    "ns_bp:furnace_backpack_cyan": {},
    "ns_bp:furnace_backpack_gray": {},
    "ns_bp:furnace_backpack_green": {},
    "ns_bp:furnace_backpack_light_blue": {},
    "ns_bp:furnace_backpack_light_gray": {},
    "ns_bp:furnace_backpack_lime": {},
    "ns_bp:furnace_backpack_magenta": {},
    "ns_bp:furnace_backpack_orange": {},
    "ns_bp:furnace_backpack_pink": {},
    "ns_bp:furnace_backpack_purple": {},
    "ns_bp:furnace_backpack_red": {},
    "ns_bp:furnace_backpack_white": {},
    "ns_bp:furnace_backpack_yellow": {},

    //MINING BACKPACKS
    "ns_bp:mn_backpack": {},
    "ns_bp:mn_backpack_black": {},
    "ns_bp:mn_backpack_blue": {},
    "ns_bp:mn_backpack_brown": {},
    "ns_bp:mn_backpack_cyan": {},
    "ns_bp:mn_backpack_gray": {},
    "ns_bp:mn_backpack_green": {},
    "ns_bp:mn_backpack_light_blue": {},
    "ns_bp:mn_backpack_light_gray": {},
    "ns_bp:mn_backpack_lime": {},
    "ns_bp:mn_backpack_magenta": {},
    "ns_bp:mn_backpack_orange": {},
    "ns_bp:mn_backpack_pink": {},
    "ns_bp:mn_backpack_purple": {},
    "ns_bp:mn_backpack_red": {},
    "ns_bp:mn_backpack_white": {},
    "ns_bp:mn_backpack_yellow": {},

    //MOBTRAP BACKPACKS
    "ns_bp:mobtrap_backpack": {},
    "ns_bp:mobtrap_backpack_black": {},
    "ns_bp:mobtrap_backpack_blue": {},
    "ns_bp:mobtrap_backpack_brown": {},
    "ns_bp:mobtrap_backpack_cyan": {},
    "ns_bp:mobtrap_backpack_gray": {},
    "ns_bp:mobtrap_backpack_green": {},
    "ns_bp:mobtrap_backpack_light_blue": {},
    "ns_bp:mobtrap_backpack_light_gray": {},
    "ns_bp:mobtrap_backpack_lime": {},
    "ns_bp:mobtrap_backpack_magenta": {},
    "ns_bp:mobtrap_backpack_orange": {},
    "ns_bp:mobtrap_backpack_pink": {},
    "ns_bp:mobtrap_backpack_purple": {},
    "ns_bp:mobtrap_backpack_red": {},
    "ns_bp:mobtrap_backpack_white": {},
    "ns_bp:mobtrap_backpack_yellow": {},

    //SLEEPING BACKPACKS
    "ns_bp:sleeping_backpack": {},
    "ns_bp:sleeping_backpack_black": {},
    "ns_bp:sleeping_backpack_blue": {},
    "ns_bp:sleeping_backpack_brown": {},
    "ns_bp:sleeping_backpack_cyan": {},
    "ns_bp:sleeping_backpack_gray": {},
    "ns_bp:sleeping_backpack_green": {},
    "ns_bp:sleeping_backpack_light_blue": {},
    "ns_bp:sleeping_backpack_light_gray": {},
    "ns_bp:sleeping_backpack_lime": {},
    "ns_bp:sleeping_backpack_magenta": {},
    "ns_bp:sleeping_backpack_orange": {},
    "ns_bp:sleeping_backpack_pink": {},
    "ns_bp:sleeping_backpack_purple": {},
    "ns_bp:sleeping_backpack_red": {},
    "ns_bp:sleeping_backpack_white": {},
    "ns_bp:sleeping_backpack_yellow": {},

    //SUPER BACKPACKS
    "ns_bp:super_backpack": {},
    "ns_bp:super_backpack_black": {},
    "ns_bp:super_backpack_blue": {},
    "ns_bp:super_backpack_brown": {},
    "ns_bp:super_backpack_cyan": {},
    "ns_bp:super_backpack_gray": {},
    "ns_bp:super_backpack_green": {},
    "ns_bp:super_backpack_light_blue": {},
    "ns_bp:super_backpack_light_gray": {},
    "ns_bp:super_backpack_lime": {},
    "ns_bp:super_backpack_magenta": {},
    "ns_bp:super_backpack_orange": {},
    "ns_bp:super_backpack_pink": {},
    "ns_bp:super_backpack_purple": {},
    "ns_bp:super_backpack_red": {},
    "ns_bp:super_backpack_white": {},
    "ns_bp:super_backpack_yellow": {},

    //UTILITY BACKPACKS
    "ns_bp:utility_backpack": {},
    "ns_bp:utility_backpack_black": {},
    "ns_bp:utility_backpack_blue": {},
    "ns_bp:utility_backpack_brown": {},
    "ns_bp:utility_backpack_cyan": {},
    "ns_bp:utility_backpack_gray": {},
    "ns_bp:utility_backpack_green": {},
    "ns_bp:utility_backpack_light_blue": {},
    "ns_bp:utility_backpack_light_gray": {},
    "ns_bp:utility_backpack_lime": {},
    "ns_bp:utility_backpack_magenta": {},
    "ns_bp:utility_backpack_orange": {},
    "ns_bp:utility_backpack_pink": {},
    "ns_bp:utility_backpack_purple": {},
    "ns_bp:utility_backpack_red": {},
    "ns_bp:utility_backpack_white": {},
    "ns_bp:utility_backpack_yellow": {},
};

export const backpacks_items = {
    //BEACON BACKPACKS
    "ns_bp:beacon_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_black_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:beacon_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },

    //CAULDRON BACKPACKS
    "ns_bp:cauldron_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_black_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cauldron_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },

    //CHECKPOINT BACKPACK

    "ns_bp:checkpoint_backpack_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_white_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_orange_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_magenta_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_light_blue_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_yellow_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_lime_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_pink_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_gray_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_light_gray_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_cyan_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_purple_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_blue_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_brown_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_green_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_red_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },
    "ns_bp:checkpoint_backpack_black_item": {
        use: function (source) {
            checkpoint_backpack_menu(source);
        },
    },

    // CULTIVATOR BACKPACKS

    "ns_bp:cultivator_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:cultivator_backpack_black_item": {
        use: function (source) {
            return;
        },
    },

    // FURNACE BACKPACKS

    "ns_bp:furnace_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:furnace_backpack_black_item": {
        use: function (source) {
            return;
        },
    },

    // MINING BACKPACKS

    "ns_bp:mn_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mn_backpack_black_item": {
        use: function (source) {
            return;
        },
    },

    // MOBTRAP BACKPACKS

    "ns_bp:mobtrap_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:mobtrap_backpack_black_item": {
        use: function (source) {
            return;
        },
    },

    // SLEEPING BACKPACKS

    "ns_bp:sleeping_backpack_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_white_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_orange_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_magenta_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_light_blue_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_yellow_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_lime_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_pink_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_gray_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_light_gray_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_cyan_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_purple_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_blue_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_brown_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_green_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_red_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },
    "ns_bp:sleeping_backpack_black_item": {
        use: function (source) {
            sleeping_backpack_menu(source);
        },
    },

    // SUPER BACKPACKS

    "ns_bp:super_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:super_backpack_black_item": {
        use: function (source) {
            return;
        },
    },

    // UTILITY BACKPACKS

    "ns_bp:utility_backpack_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_white_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_orange_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_magenta_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_light_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_yellow_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_lime_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_pink_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_light_gray_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_cyan_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_purple_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_blue_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_brown_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_green_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_red_item": {
        use: function (source) {
            return;
        },
    },
    "ns_bp:utility_backpack_black_item": {
        use: function (source) {
            return;
        },
    },
};

export const BackpackVariant = {
    beacon: [
        "ns_bp:beacon_backpack",
        "ns_bp:beacon_backpack_black",
        "ns_bp:beacon_backpack_blue",
        "ns_bp:beacon_backpack_brown",
        "ns_bp:beacon_backpack_cyan",
        "ns_bp:beacon_backpack_gray",
        "ns_bp:beacon_backpack_green",
        "ns_bp:beacon_backpack_light_blue",
        "ns_bp:beacon_backpack_light_gray",
        "ns_bp:beacon_backpack_lime",
        "ns_bp:beacon_backpack_magenta",
        "ns_bp:beacon_backpack_orange",
        "ns_bp:beacon_backpack_pink",
        "ns_bp:beacon_backpack_purple",
        "ns_bp:beacon_backpack_red",
        "ns_bp:beacon_backpack_white",
        "ns_bp:beacon_backpack_yellow",
    ],
    cauldron: [
        "ns_bp:cauldron_backpack",
        "ns_bp:cauldron_backpack_black",
        "ns_bp:cauldron_backpack_blue",
        "ns_bp:cauldron_backpack_brown",
        "ns_bp:cauldron_backpack_cyan",
        "ns_bp:cauldron_backpack_gray",
        "ns_bp:cauldron_backpack_green",
        "ns_bp:cauldron_backpack_light_blue",
        "ns_bp:cauldron_backpack_light_gray",
        "ns_bp:cauldron_backpack_lime",
        "ns_bp:cauldron_backpack_magenta",
        "ns_bp:cauldron_backpack_orange",
        "ns_bp:cauldron_backpack_pink",
        "ns_bp:cauldron_backpack_purple",
        "ns_bp:cauldron_backpack_red",
        "ns_bp:cauldron_backpack_white",
        "ns_bp:cauldron_backpack_yellow",
    ],
    checkpoint: [
        "ns_bp:checkpoint_backpack",
        "ns_bp:checkpoint_backpack_black",
        "ns_bp:checkpoint_backpack_blue",
        "ns_bp:checkpoint_backpack_brown",
        "ns_bp:checkpoint_backpack_cyan",
        "ns_bp:checkpoint_backpack_gray",
        "ns_bp:checkpoint_backpack_green",
        "ns_bp:checkpoint_backpack_light_blue",
        "ns_bp:checkpoint_backpack_light_gray",
        "ns_bp:checkpoint_backpack_lime",
        "ns_bp:checkpoint_backpack_magenta",
        "ns_bp:checkpoint_backpack_orange",
        "ns_bp:checkpoint_backpack_pink",
        "ns_bp:checkpoint_backpack_purple",
        "ns_bp:checkpoint_backpack_red",
        "ns_bp:checkpoint_backpack_white",
        "ns_bp:checkpoint_backpack_yellow",
    ],
    cultivator: [
        "ns_bp:cultivator_backpack",
        "ns_bp:cultivator_backpack_black",
        "ns_bp:cultivator_backpack_blue",
        "ns_bp:cultivator_backpack_brown",
        "ns_bp:cultivator_backpack_cyan",
        "ns_bp:cultivator_backpack_gray",
        "ns_bp:cultivator_backpack_green",
        "ns_bp:cultivator_backpack_light_blue",
        "ns_bp:cultivator_backpack_light_gray",
        "ns_bp:cultivator_backpack_lime",
        "ns_bp:cultivator_backpack_magenta",
        "ns_bp:cultivator_backpack_orange",
        "ns_bp:cultivator_backpack_pink",
        "ns_bp:cultivator_backpack_purple",
        "ns_bp:cultivator_backpack_red",
        "ns_bp:cultivator_backpack_white",
        "ns_bp:cultivator_backpack_yellow",
    ],
    furnace: [
        "ns_bp:furnace_backpack",
        "ns_bp:furnace_backpack_black",
        "ns_bp:furnace_backpack_blue",
        "ns_bp:furnace_backpack_brown",
        "ns_bp:furnace_backpack_cyan",
        "ns_bp:furnace_backpack_gray",
        "ns_bp:furnace_backpack_green",
        "ns_bp:furnace_backpack_light_blue",
        "ns_bp:furnace_backpack_light_gray",
        "ns_bp:furnace_backpack_lime",
        "ns_bp:furnace_backpack_magenta",
        "ns_bp:furnace_backpack_orange",
        "ns_bp:furnace_backpack_pink",
        "ns_bp:furnace_backpack_purple",
        "ns_bp:furnace_backpack_red",
        "ns_bp:furnace_backpack_white",
        "ns_bp:furnace_backpack_yellow",
    ],
    mining: [
        "ns_bp:mn_backpack",
        "ns_bp:mn_backpack_black",
        "ns_bp:mn_backpack_blue",
        "ns_bp:mn_backpack_brown",
        "ns_bp:mn_backpack_cyan",
        "ns_bp:mn_backpack_gray",
        "ns_bp:mn_backpack_green",
        "ns_bp:mn_backpack_light_blue",
        "ns_bp:mn_backpack_light_gray",
        "ns_bp:mn_backpack_lime",
        "ns_bp:mn_backpack_magenta",
        "ns_bp:mn_backpack_orange",
        "ns_bp:mn_backpack_pink",
        "ns_bp:mn_backpack_purple",
        "ns_bp:mn_backpack_red",
        "ns_bp:mn_backpack_white",
        "ns_bp:mn_backpack_yellow",
    ],
    mobtrap: [
        "ns_bp:mobtrap_backpack",
        "ns_bp:mobtrap_backpack_black",
        "ns_bp:mobtrap_backpack_blue",
        "ns_bp:mobtrap_backpack_brown",
        "ns_bp:mobtrap_backpack_cyan",
        "ns_bp:mobtrap_backpack_gray",
        "ns_bp:mobtrap_backpack_green",
        "ns_bp:mobtrap_backpack_light_blue",
        "ns_bp:mobtrap_backpack_light_gray",
        "ns_bp:mobtrap_backpack_lime",
        "ns_bp:mobtrap_backpack_magenta",
        "ns_bp:mobtrap_backpack_orange",
        "ns_bp:mobtrap_backpack_pink",
        "ns_bp:mobtrap_backpack_purple",
        "ns_bp:mobtrap_backpack_red",
        "ns_bp:mobtrap_backpack_white",
        "ns_bp:mobtrap_backpack_yellow",
    ],
    sleeping: [
        "ns_bp:sleeping_backpack",
        "ns_bp:sleeping_backpack_black",
        "ns_bp:sleeping_backpack_blue",
        "ns_bp:sleeping_backpack_brown",
        "ns_bp:sleeping_backpack_cyan",
        "ns_bp:sleeping_backpack_gray",
        "ns_bp:sleeping_backpack_green",
        "ns_bp:sleeping_backpack_light_blue",
        "ns_bp:sleeping_backpack_light_gray",
        "ns_bp:sleeping_backpack_lime",
        "ns_bp:sleeping_backpack_magenta",
        "ns_bp:sleeping_backpack_orange",
        "ns_bp:sleeping_backpack_pink",
        "ns_bp:sleeping_backpack_purple",
        "ns_bp:sleeping_backpack_red",
        "ns_bp:sleeping_backpack_white",
        "ns_bp:sleeping_backpack_yellow",
    ],
    super: [
        "ns_bp:super_backpack",
        "ns_bp:super_backpack_black",
        "ns_bp:super_backpack_blue",
        "ns_bp:super_backpack_brown",
        "ns_bp:super_backpack_cyan",
        "ns_bp:super_backpack_gray",
        "ns_bp:super_backpack_green",
        "ns_bp:super_backpack_light_blue",
        "ns_bp:super_backpack_light_gray",
        "ns_bp:super_backpack_lime",
        "ns_bp:super_backpack_magenta",
        "ns_bp:super_backpack_orange",
        "ns_bp:super_backpack_pink",
        "ns_bp:super_backpack_purple",
        "ns_bp:super_backpack_red",
        "ns_bp:super_backpack_white",
        "ns_bp:super_backpack_yellow",
    ],
    utility: [
        "ns_bp:utility_backpack",
        "ns_bp:utility_backpack_black",
        "ns_bp:utility_backpack_blue",
        "ns_bp:utility_backpack_brown",
        "ns_bp:utility_backpack_cyan",
        "ns_bp:utility_backpack_gray",
        "ns_bp:utility_backpack_green",
        "ns_bp:utility_backpack_light_blue",
        "ns_bp:utility_backpack_light_gray",
        "ns_bp:utility_backpack_lime",
        "ns_bp:utility_backpack_magenta",
        "ns_bp:utility_backpack_orange",
        "ns_bp:utility_backpack_pink",
        "ns_bp:utility_backpack_purple",
        "ns_bp:utility_backpack_red",
        "ns_bp:utility_backpack_white",
        "ns_bp:utility_backpack_yellow",
    ],
};
