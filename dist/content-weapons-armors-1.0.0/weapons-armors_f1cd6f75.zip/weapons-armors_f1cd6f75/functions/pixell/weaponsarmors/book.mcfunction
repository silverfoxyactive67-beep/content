give @a[tag=!pxwaa_book] px_waa:guidebook

playsound random.orb @a[tag=!pxwaa_book]

tellraw @a[tag=!pxwaa_book] {"rawtext":[{"text":"The Add-on §l§6Weapons & Armors§r by §bPixell Studio§r is installed!"},{"text":"\n"},{"text":"\n"},{"text":"You have received a §lGuidebook§r with detailed descriptions of Weapons/Armor and all craft recipes."}]}







tag @a[tag=!pxwaa_book] add pxwaa_book