import { system, world } from "@minecraft/server";
const guidebookId = "px_waa:guidebook";
const pageAmount = 36;
world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
    const { entity, eventId } = event;
    if (entity.typeId == guidebookId) {
        const pageProperyId = "book:page";
        const currentPage = entity.getProperty("book:page");
        switch (eventId) {
            case "book:nextpage": {
                entity.playAnimation("animation.px_waa.guidebook.slide_left");
                entity.dimension.playSound("entity.book.page", entity.location);
                system.runTimeout(() => {
                    currentPage < pageAmount - 1
                        ? entity?.setProperty(pageProperyId, currentPage + 1)
                        : entity?.setProperty(pageProperyId, 0);
                }, 0.3 * 20);
                break;
            }
            case "book:previouspage": {
                entity.playAnimation("animation.px_waa.guidebook.slide_right");
                entity.dimension.playSound("entity.book.page", entity.location);
                system.runTimeout(() => {
                    currentPage == 0
                        ? entity.setProperty(pageProperyId, pageAmount - 1)
                        : entity.setProperty(pageProperyId, currentPage - 1);
                }, 0.3 * 20);
                break;
            }
            case "book:despawn": {
                entity.triggerEvent("book:drop_timer");
                break;
            }
            case "minecraft:entity_spawned": {
                entity.dimension.playSound("entity.book.page", entity.location);
                break;
            }
        }
    }
});
