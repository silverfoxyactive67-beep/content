import {
  EntityComponentTypes,
  EntityDamageCause,
  EntityEquippableComponent,
  EntityHealthComponent,
  EntityInventoryComponent,
  EntityProjectileComponent,
  EntityRideableComponent,
  EquipmentSlot,
  ItemComponentTypes,
  ItemDurabilityComponent,
  ItemEnchantableComponent,
  ItemStack,
  Player,
  system,
  WeatherType,
  world,
} from "@minecraft/server";
import "./book";
import { armor } from "./communs";
import { WEAPONS } from "./data";
import "./registerComponents";

const ignoreEntity = [
  "minecraft:lightning_bolt",
  "minecraft:item",
  "minecraft:ender_crystal",
  "minecraft:tnt",
  "minecraft:command_block_minecart",
  "minecraft:minecart",
  "minecraft:hopper_minecart",
  "minecraft:tnt_minecart",
  "minecraft:chest_minecart",
  "minecraft:chest_boat",
  "minecraft:boat",

  "minecraft:arrow",
  "minecraft:snowball",
  "minecraft:fireball",
  "minecraft:small_fireball",
  "minecraft:dragon_fireball",
  "minecraft:fishing_hook",
  "minecraft:wither_skull_dangerous",
  "minecraft:wither_skull",
  "minecraft:xp_orb",
  "minecraft:xp",
  "minecraft:xp_bottle",
  "minecraft:lingering_potion",
  "minecraft:splash_potion",
  "minecraft:wind_charge_projectile_potion",
  "px_waa:vfx_water_2",

  "minecraft:villager_v2",
  "px_waa:guidebook",
];

const DATA_PLAYER_ABILITY_ARMOR = {};

system.runInterval(() => {
  handlePlayer();
  world.getAllPlayers().forEach((player) => {
    dataAbility(player, "thunder");
    dataAbility(player, "end");
    dataAbility(player, "miner");
  });
});
function dataAbility(player, ability) {
  const cooldown =
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_${ability}`]?.cooldown ?? 40;
  const currentTick =
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_${ability}`]?.currentTick ??
    system.currentTick + 100;
  if (system.currentTick > cooldown + currentTick) {
    delete DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_${ability}`];

    if (player.hasTag("end") || player.hasTag("thunder")) {
      player.onScreenDisplay.setActionBar("Finished cooldown");
      player.removeTag("end");
      player.removeTag("thunder");
    }
  }
}

const blocksReplaceTsunami = ["grass_block", "dirt"];

world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
  const { entity, eventId } = event;
  if (eventId == "suffocated") {
    /**
     * @type {EntityRideableComponent}
     */
    const rideableComponent = entity.getComponent(
      EntityComponentTypes.Rideable
    );

    if (!rideableComponent) return;

    const riders = rideableComponent?.getRiders() ?? [];

    if (riders.length == 0) {
      if (system.currentTick % (3 * 20) <= 5) {
        if (entity && riders.length == 0) {
          entity?.remove();
        }
      }

      return;
    }

    const controllerRider = riders[0];

    controllerRider.applyDamage(2, {
      cause: EntityDamageCause.entityAttack,
      damagingEntity: entity,
    });

    if (controllerRider.typeId == "minecraft:creeper")
      controllerRider.triggerEvent("minecraft:stop_exploding");
  } else if (eventId == "storm") {
    try {
      entity.dimension
        .getEntities({
          location: entity.location,
          maxDistance: 10,
          families: ["mob"],
        })
        .forEach((target) => {
          if (target == entity) return;
          const dx = target.location.x - entity.location.x;
          const dy = target.location.y - entity.location.y;
          const dz = target.location.z - entity.location.z;

          const step = 0.1;

          const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
          const directionX = (dx / distance) * step;
          const directionY = (dy / distance) * step;
          const directionZ = (dz / distance) * step;

          target.teleport({
            x: target.location.x - directionX,
            y: target.location.y - directionY,
            z: target.location.z - directionZ,
          });
        });
      entity.dimension
        .getEntities({
          location: entity.location,
          maxDistance: 1,
          families: ["mob"],
        })
        .forEach((target) => {
          if (target == entity) return;
          target.applyDamage(7, {
            cause: EntityDamageCause.entityAttack,
            damagingEntity: entity,
          });
          if (entity.typeId == "px_waa:vfx_fire_storm") target.setOnFire(5);
        });
    } catch (error) {
      return;
    }
  } else if (eventId == "px_waa:front") {
    const viewDirection = entity.getDynamicProperty("viewDirection");
    if (!viewDirection) return;
    entity.applyKnockback(0.1 * viewDirection.x, 0.1 * viewDirection.z, 1, 0);
    entity.dimension.spawnParticle("px_waa:tsunami_foam", entity.location);
    blocksReplaceTsunami.forEach((block) => {
      entity.runCommand(
        `fill ${entity.location.x - 1} ${entity.location.y - 1} ${
          entity.location.z - 1
        } ${entity.location.x + 1} ${entity.location.y - 1} ${
          entity.location.z + 1
        } mud replace ${block}`
      );
    });
    entity.dimension
      .getEntities({
        maxDistance: 3,
        location: entity.location,
        minDistance: 0,
        excludeTypes: ["px_waa:vfx_tsunami"],
      })
      .forEach((target) => {
        processTarget(entity, target, () => {
          target.teleport(entity.location, { rotation: entity.getRotation() });
          target.applyDamage(2, {
            cause: EntityDamageCause.entityAttack,
            damagingEntity: entity,
          });
        });
      });
  }
});

world.afterEvents.playerSpawn.subscribe((event) => {
  const { player } = event;

  player.camera.clear();
  player.removeTag("in_storm");
});

function processTarget(entity, target, callback) {
  if (target.typeId == "minecraft:player") {
    entity.getTags().forEach((tag) => {
      if (target.nameTag != tag.split("_")[2]) {
        callback();
      }
    });
  } else {
    callback();
  }
}

function handlePlayer() {
  world.getAllPlayers().forEach((player) => {
    const itemMainhand = checkMainhand(player);
    const view = player.getViewDirection();

    switch (itemMainhand.typeId) {
      case "px_waa:poison_dagger": {
        player.dimension
          .getEntities({
            location: player.location,
            maxDistance: 5,
          })
          .forEach((target) => {
            const tamed = target.getComponent(EntityComponentTypes.IsTamed);
            if (
              target != player &&
              !tamed &&
              !ignoreEntity.includes(target.typeId)
            )
              target.addEffect("poison", 10 * 20, { amplifier: 5 });
          });
        break;
      }
    }
    if (armor(player, "heavy")) {
      heavyArmor(player);
    }
    if (armor(player, "moonlight")) {
      moonlightArmor(player);
    }
    if (armor(player, "storm")) {
      stormArmor(player);
    }
    if (armor(player, "heaven")) {
      handleHeaven(player, view);
    }
    if (armor(player, "nether")) {
      handleNether(player);
    }
    if (armor(player, "fire")) {
      handleFire(player);
    }
    if (armor(player, "hades")) {
      handleHades(player);
    }
    if (armor(player, "adventure")) {
      handleAdventure(player);
    }
    if (armor(player, "winter")) {
      handleWinter(player);
    }
    if (armor(player, "toxic")) {
      handleToxic(player);
    }
    if (armor(player, "assassins") && !armor(player, "_invisibility")) {
      handleAssassinsNormal(player);
    }
    if (armor(player, "_invisibility")) {
      handleInvisibility(player);
    }
    if (armor(player, "god")) {
      handleGod(player);
    }
    if (armor(player, "end")) {
      handleEnd(player);
    }
    if (armor(player, "miner")) {
      handleMiner(player);
    }
    if (armor(player, "overpower") && !armor(player, "_invisibility")) {
      handleOverpowerNormal(player);
    }
    if (armor(player, "overpower") && armor(player, "_invisibility")) {
      handleHeaven(player, view);
      handleNether(player);
      handleWinter(player);
      handleToxic(player);
      handleAssassinsNormal(player);
      handleInvisibility(player);
      handleGod(player);
      handleEnd(player);
      handleMiner(player);
    }
    if (armor(player, "samurai")) {
      handleSamurai(player);
    }
    if (armor(player, "jade")) {
      handleJade(player);
    }
  });
}

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    if (player.isSneaking && armor(player, "rgb")) {
      const score = world.scoreboard.getObjective("px_waa:rgb_armor");
      const func = score.addScore(player, 1);
      if (func >= 3) {
        score.setScore(player, 0);
      }
      player.onScreenDisplay.setActionBar(
        rgbPowers[
          world.scoreboard.getObjective("px_waa:rgb_armor").getScore(player)
        ]
      );
    }
  });
}, 20);

const rgbPowers = ["§cRed: Fire", "§aGreen: Poison", "§bBlue: Absorption"];

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    try {
      if (
        world.scoreboard.getObjective("px_waa:rgb_armor").getScore(player) ==
          2 &&
        armor(player, "rgb")
      ) {
        player.addEffect("minecraft:absorption", 20 * 30, {
          amplifier: 0,
          showParticles: false,
        });
      }
    } catch (error) {}
  });
}, 60 * 20);

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    if (armor(player, "archer")) {
      handleArcher(player);
    }
  });
}, 40);

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    if (armor(player, "pet")) {
      handlePet(player);
    }
  });
}, 15 * 20);

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    if (armor(player, "witch")) {
      handleWitch(player);
    }
  });
}, 5 * 20);

world.afterEvents.weatherChange.subscribe(({ newWeather }) => {
  if (newWeather != WeatherType.Clear) {
    world.getPlayers().forEach((player) => player.addTag("in_storm"));
  } else {
    world.getPlayers().forEach((player) => player.removeTag("in_storm"));
  }
});

world.afterEvents.entityHitEntity.subscribe(
  ({ damagingEntity: player, hitEntity: entity }) => {
    if (
      player.typeId == "minecraft:player" &&
      !ignoreEntity.includes(entity.typeId) &&
      armor(player, "storm")
    ) {
      const ramdom = Math.random();
      if (ramdom < 0.1)
        player.dimension.spawnEntity(
          "minecraft:lightning_bolt",
          entity.location
        );
    }

    if (player.typeId == "minecraft:player" && armor(player, "vampire")) {
      const score = world.scoreboard.getObjective("px_waa:vampire_armor");
      const hits = score.addScore(player, 1);
      if (hits >= 5) {
        const health = player.getComponent(EntityComponentTypes.Health);
        health.setCurrentValue(health.currentValue + 2);
        score.setScore(player, 0);
      }
    }

    if (player.typeId == "minecraft:player" && armor(player, "rgb")) {
      const power = world.scoreboard
        .getObjective("px_waa:rgb_armor")
        .getScore(player);
      switch (power) {
        case 0: {
          entity.setOnFire(5, true);
          break;
        }
        case 1: {
          entity.addEffect("minecraft:poison", 20 * 10);
          break;
        }
      }
    }
  }
);

system.run(() => {
  if (!world.scoreboard.getObjective("px_waa:vampire_armor"))
    world.scoreboard.addObjective("px_waa:vampire_armor");
  if (!world.scoreboard.getObjective("px_waa:rgb_armor"))
    world.scoreboard.addObjective("px_waa:rgb_armor");
});

/**
 * @param {Player} player
 */
function handlePet(player) {
  const effects = ["strength", "speed", "regeneration"];
  player.dimension
    .getEntities({
      maxDistance: 10,
      location: player.location,
    })
    .forEach((target) => {
      const tamed = target.getComponent(EntityComponentTypes.IsTamed);
      if (target != player && tamed && !ignoreEntity.includes(target.typeId)) {
        effects.forEach((effect) => {
          target.addEffect(effect, 10 * 20, { amplifier: 1 });
        });
      }
    });
}

function handleArcher(player) {
  const arrows = ["archer_damage", "archer_veneno"];
  world.structureManager.place(
    `px_waa:${arrows[Math.round(Math.random())]}`,
    player.dimension,
    player.location
  );
}

function handleHeaven(player, view) {
  const isNight =
    world.getTimeOfDay() >= 13000 && world.getTimeOfDay() <= 23000;
  const isDay = world.getTimeOfDay() < 13000 || world.getTimeOfDay() > 23000;

  if (isDay) {
    player.addEffect("strength", 20 * 5, {
      amplifier: 1,
      showParticles: false,
    });
    player.addEffect("regeneration", 20 * 5, {
      amplifier: 1,
      showParticles: false,
    });
  }
  if (player.isJumping) {
    system.runTimeout(() => {
      if (player.isJumping) {
        player.applyKnockback(0.2 * view.x, 0.2 * view.z, 1, 0.5 * view.y);
        player.playAnimation("animation.px_waa.player_fly");
      }
    }, 5);
  }
  if (!player.isOnGround) {
    player.addEffect("slow_falling", 10, { showParticles: false });
  }
}

function heavyArmor(player) {
  player.addEffect("minecraft:resistance", 20 * 5, {
    amplifier: 1,
    showParticles: false,
  });
  player.addEffect("minecraft:slowness", 20 * 5, {
    amplifier: 0,
    showParticles: false,
  });
}
function moonlightArmor(player) {
  if (world.getTimeOfDay() < 13500) return;
  player.addEffect("minecraft:strength", 20 * 5, {
    amplifier: 0,
    showParticles: false,
  });
  player.addEffect("minecraft:speed", 20 * 5, {
    amplifier: 1,
    showParticles: false,
  });
}
function stormArmor(player) {
  if (!player.hasTag("in_storm")) return;
  player.addEffect("minecraft:strength", 20 * 5, {
    amplifier: 0,
    showParticles: false,
  });
  player.addEffect("minecraft:speed", 20 * 5, {
    amplifier: 1,
    showParticles: false,
  });
}
function handleSamurai(player) {
  player.addEffect("speed", 20 * 5, { amplifier: 1, showParticles: false });
}

function handleJade(player) {
  player.addEffect("resistance", 20 * 5, {
    amplifier: 1,
    showParticles: false,
  });
}

function handleWitch(player) {
  player.addEffect("regeneration", 20 * 10, {
    amplifier: 0,
    showParticles: false,
  });
}

function handleNether(player) {
  player.addEffect("fire_resistance", 20 * 5, {
    amplifier: 1,
    showParticles: false,
  });
  if (player.dimension.id == "minecraft:nether") {
    player.addEffect("strength", 20 * 5, {
      amplifier: 1,
      showParticles: false,
    });
  }
  player.dimension
    .getEntities({
      families: ["monster"],
      location: player.location,
      maxDistance: 5,
    })
    .forEach((target) => {
      target.setOnFire(10, true);
    });
}
/**
 *
 * @param {Player} player
 */
function handleAdventure(player) {
  player.addEffect("speed", 20 * 5, { amplifier: 1, showParticles: false });
  player.dimension
    .getEntities({
      location: player.location,
      maxDistance: 10,
      type: "minecraft:item",
    })
    .forEach((target) => {
      target.teleport(player.location);
    });
}
/**
 *
 * @param {Player} player
 */
function handleFire(player) {
  player.dimension.spawnParticle(
    "minecraft:basic_flame_particle",
    player.location
  );
  player.dimension
    .getEntities({
      location: player.location,
      maxDistance: 5,
      families: ["monster"],
    })
    .forEach((target) => {
      target.setOnFire(4, true);
    });
}
function handleHades(player) {
  const health = getHealth(player);
  const effects = ["strength", "speed", "regeneration"];
  if (health.currentValue <= health.defaultValue / 2) {
    effects.forEach((effect) => {
      player.addEffect(effect, 20 * 5, { amplifier: 0, showParticles: true });
    });
  }
}
function getHealth(source) {
  /**@type {EntityHealthComponent} */
  const health = source.getComponent("minecraft:health");
  return health;
}

function handleWinter(player) {
  player.dimension
    .getEntities({
      families: ["monster"],
      location: player.location,
      maxDistance: 5,
    })
    .forEach((target) => {
      target.addEffect("slowness", 20 * 5, {
        amplifier: 3,
        showParticles: true,
      });
    });
}

function handleToxic(player) {
  player.dimension
    .getEntities({
      families: ["monster"],
      location: player.location,
      maxDistance: 5,
    })
    .forEach((target) => {
      target.addEffect("poison", 20 * 5, { amplifier: 3, showParticles: true });
      target.addEffect("wither", 20 * 5, { amplifier: 3, showParticles: true });
    });
}

function handleAssassinsNormal(player) {
  player.addEffect("strength", 20 * 5, { amplifier: 3, showParticles: false });
  /** @type {EntityEquippableComponent} */
  const equippable = player.getComponent(EntityComponentTypes.Equippable);

  const itemHelmet = equippable.getEquipment(EquipmentSlot.Head);
  replaceitem(player, itemHelmet);
  const itemChestplate = equippable.getEquipment(EquipmentSlot.Chest);
  replaceitem(player, itemChestplate);
  const itemLeggings = equippable.getEquipment(EquipmentSlot.Legs);
  replaceitem(player, itemLeggings);
  const itemBoots = equippable.getEquipment(EquipmentSlot.Feet);
  replaceitem(player, itemBoots);
}

function handleInvisibility(player) {
  player.addEffect("strength", 20 * 1, { amplifier: 3, showParticles: false });
  player.addEffect("invisibility", 20 * 1, {
    amplifier: 3,
    showParticles: false,
  });
}

function handleGod(player) {
  player.addEffect("speed", 20 * 3, { amplifier: 2, showParticles: false });
  if (!DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_thunder`]) {
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_thunder`] = { cooldown: 0 };
  }

  let cooldown =
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_thunder`].cooldown ?? 0;

  const mobs = player.dimension.getEntities({
    location: player.location,
    maxDistance: 6,
    families: ["monster"],
  });

  if (mobs.length > 0 && cooldown == 0) {
    mobs.forEach((target) => {
      target.dimension.spawnEntity("minecraft:lightning_bolt", target.location);
      cooldown = cooldown < 30 ? cooldown + 5 : 30;
    });
    player.addTag("thunder");
    player.onScreenDisplay.setActionBar(`Cooldown: ${cooldown}`);
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_thunder`].cooldown =
      cooldown * 20;
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_thunder`].currentTick =
      system.currentTick;
  }
}

function handleEnd(player) {
  if (!DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_end`]) {
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_end`] = { cooldown: 0 };
  }

  let cooldown =
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_end`].cooldown ?? 0;
  if (cooldown == 0 && player.isSneaking) {
    const blockView = player.getBlockFromViewDirection({
      maxDistance: 60,
    });
    if (blockView) {
      const block = blockView.block;
      player.tryTeleport(
        {
          x: block.location.x,
          y: block.location.y + 1,
          z: block.location.z,
        },
        {
          checkForBlocks: true,
        }
      );
      cooldown = 3;
      player.addTag("end");
      player.onScreenDisplay.setActionBar(`Cooldown: ${cooldown}`);
      DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_end`].cooldown =
        cooldown * 20;
      DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_end`].currentTick =
        system.currentTick;
    }
  }
}

function handleMiner(player) {
  player.addEffect("haste", 30 * 20, { amplifier: 1, showParticles: false });

  if (!DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_miner`]) {
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_miner`] = { cooldown: 0 };
  }

  let cooldown =
    DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_miner`].cooldown ?? 0;

  if (cooldown == 0) {
    const mobs = player.dimension.getEntities({
      location: player.location,
      maxDistance: 1,
      type: "px_waa:light_block_entity",
    });
    if (mobs.length == 0) {
      cooldown = 0.2;
      player.dimension.spawnEntity("px_waa:light_block_entity", {
        x: player.location.x,
        y: player.location.y,
        z: player.location.z,
      });
      DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_miner`].cooldown =
        cooldown * 20;
      DATA_PLAYER_ABILITY_ARMOR[`${player.nameTag}_miner`].currentTick =
        system.currentTick;
    }
  }
}

function handleOverpowerNormal(player) {
  player.addEffect("strength", 20 * 5, { amplifier: 3, showParticles: false });
  /** @type {EntityEquippableComponent} */
  const equippable = player.getComponent(EntityComponentTypes.Equippable);

  const itemHelmet = equippable.getEquipment(EquipmentSlot.Head);
  replaceitem(player, itemHelmet);
  const itemChestplate = equippable.getEquipment(EquipmentSlot.Chest);
  replaceitem(player, itemChestplate);
  const itemLeggings = equippable.getEquipment(EquipmentSlot.Legs);
  replaceitem(player, itemLeggings);
  const itemBoots = equippable.getEquipment(EquipmentSlot.Feet);
  replaceitem(player, itemBoots);
}

/**
 *
 * @param {Player} source
 * @param {Item|null} [cloneItem=null]
 */
function replaceitem(source, cloneItem = null) {
  if (cloneItem instanceof ItemStack) {
    /** @type {EntityEquippableComponent} */
    const equippable = source.getComponent(EntityComponentTypes.Equippable);

    const itemHelmetfoda = equippable.getEquipment(EquipmentSlot.Head);

    if (!itemHelmetfoda.typeId.includes("_invisibility")) {
      equippable.setEquipment(
        EquipmentSlot.Head,
        addInvisibleItem(equippable.getEquipment(EquipmentSlot.Head))
      );

      equippable.setEquipment(
        EquipmentSlot.Chest,
        addInvisibleItem(equippable.getEquipment(EquipmentSlot.Chest))
      );

      equippable.setEquipment(
        EquipmentSlot.Legs,
        addInvisibleItem(equippable.getEquipment(EquipmentSlot.Legs))
      );

      equippable.setEquipment(
        EquipmentSlot.Feet,
        addInvisibleItem(equippable.getEquipment(EquipmentSlot.Feet))
      );
    }
  }
}

/**
 *
 * @param {Player} source
 */
function resetArmor(source) {
  /**
   * @type {EntityInventoryComponent}
   */
  const inventory = source.getComponent(EntityComponentTypes.Inventory);
  for (let index = 0; index < inventory.inventorySize; index++) {
    const slot = inventory.container.getSlot(index);
    if (slot) {
      const item = slot.getItem();
      if (item && item.typeId.includes("_invisibility")) {
        inventory.container.setItem(index, addNonInvisibleItem(item));
      }
    }
  }

  /** @type {EntityEquippableComponent} */
  const equippable = source.getComponent(EntityComponentTypes.Equippable);

  const armorSlots = checkSlotsArmor(source, "_invisibility");
  if (armorSlots.helmet) {
    equippable.setEquipment(
      EquipmentSlot.Head,
      addNonInvisibleItem(equippable.getEquipment(EquipmentSlot.Head))
    );
  }
  if (armorSlots.chestplate) {
    equippable.setEquipment(
      EquipmentSlot.Chest,
      addNonInvisibleItem(equippable.getEquipment(EquipmentSlot.Chest))
    );
  }
  if (armorSlots.leggings) {
    equippable.setEquipment(
      EquipmentSlot.Legs,
      addNonInvisibleItem(equippable.getEquipment(EquipmentSlot.Legs))
    );
  }
  if (armorSlots.boots) {
    equippable.setEquipment(
      EquipmentSlot.Feet,
      addNonInvisibleItem(equippable.getEquipment(EquipmentSlot.Feet))
    );
  }
}

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    if (!armor(player, "_invisibility")) resetArmor(player);
  });
}, 10);

/**
 *
 * @param {ItemStack} item
 * @returns {ItemStack}
 */
function addNonInvisibleItem(item) {
  const normalItem = new ItemStack(item.typeId.split("_invisibility")[0]);
  /** @type {ItemDurabilityComponent} */
  const durability = normalItem.getComponent(ItemComponentTypes.Durability);
  /** @type {ItemEnchantableComponent} */
  const enchantment = normalItem.getComponent(ItemComponentTypes.Enchantable);

  // durability.damage = durability.maxDurability+item.getComponent(ItemComponentTypes.Durability).damage;

  enchantment.addEnchantments(
    item.getComponent(ItemComponentTypes.Enchantable).getEnchantments()
  );

  return normalItem;
}

function addInvisibleItem(item) {
  try {
    const normalItem = new ItemStack(`${item.typeId}_invisibility`);
    /** @type {ItemDurabilityComponent} */
    const durability = normalItem.getComponent(ItemComponentTypes.Durability);
    /** @type {ItemEnchantableComponent} */
    const enchantment = normalItem.getComponent(ItemComponentTypes.Enchantable);

    // durability.damage = durability.maxDurability+item.getComponent(ItemComponentTypes.Durability).damage;

    enchantment.addEnchantments(
      item.getComponent(ItemComponentTypes.Enchantable).getEnchantments()
    );

    return normalItem;
  } catch (error) {
    return;
  }
}

/**
 *
 * @param {Player} source
 * @param {string} material
 * @returns {Object}
 */
export function checkSlotsArmor(source, material) {
  /** @type {ItemStack} */
  const helmet =
    source
      .getComponent(EntityComponentTypes.Equippable)
      ?.getEquipment(EquipmentSlot.Head) ?? new ItemStack("minecraft:stick", 1);
  /** @type {ItemStack} */
  const chestplate =
    source
      .getComponent(EntityComponentTypes.Equippable)
      ?.getEquipment(EquipmentSlot.Chest) ??
    new ItemStack("minecraft:stick", 1);
  /** @type {ItemStack} */
  const leggings =
    source
      .getComponent(EntityComponentTypes.Equippable)
      ?.getEquipment(EquipmentSlot.Legs) ?? new ItemStack("minecraft:stick", 1);
  /** @type {ItemStack} */
  const boots =
    source
      .getComponent(EntityComponentTypes.Equippable)
      ?.getEquipment(EquipmentSlot.Feet) ?? new ItemStack("minecraft:stick", 1);

  const slotsArmor = {};

  if (helmet.typeId.includes(material)) {
    slotsArmor["helmet"] = true;
  } else {
    slotsArmor["helmet"] = false;
  }
  if (chestplate.typeId.includes(material)) {
    slotsArmor["chestplate"] = true;
  } else {
    slotsArmor["chestplate"] = false;
  }
  if (leggings.typeId.includes(material)) {
    slotsArmor["leggings"] = true;
  } else {
    slotsArmor["leggings"] = false;
  }
  if (boots.typeId.includes(material)) {
    slotsArmor["boots"] = true;
  } else {
    slotsArmor["boots"] = false;
  }

  return slotsArmor;
}

/**
 *
 * @param {Player} source
 * @returns {ItemStack}
 */
function checkMainhand(source) {
  return (
    source
      .getComponent(EntityComponentTypes.Equippable)
      ?.getEquipment(EquipmentSlot.Mainhand) ??
    new ItemStack("minecraft:stick", 1)
  );
}

system.afterEvents.scriptEventReceive.subscribe((event) => {
  const { id, sourceEntity } = event;
  switch (id) {
    case "px_waa:attack": {
      sourceEntity.dimension
        .getEntities({
          type: "player",
          maxDistance: 1,
          location: sourceEntity.location,
        })
        .forEach((player) => {
          if (sourceEntity.hasTag(player.nameTag)) {
            const { damage } = WEAPONS[sourceEntity.typeId.split("vfx_")[1]];
            player
              .getEntitiesFromViewDirection({
                maxDistance: 7,
                excludeFamilies: ["vfx"],
              })
              .forEach((target) => {
                const victim = target.entity;
                const tamed = victim.getComponent(EntityComponentTypes.IsTamed);
                if (
                  !tamed &&
                  victim != player &&
                  victim != sourceEntity &&
                  !ignoreEntity.includes(victim.typeId)
                )
                  victim.applyDamage(damage, {
                    cause: EntityDamageCause.entityAttack,
                    damagingEntity: player,
                  });
              });
          }
        });
      break;
    }
    case "px_waa:fire_attack_area": {
      sourceEntity.dimension
        .getEntities({
          type: "player",
          maxDistance: 10,
          location: sourceEntity.location,
        })
        .forEach((player) => {
          if (sourceEntity.hasTag(player.nameTag)) {
            player.dimension
              .getEntities({
                location: player.location,
                maxDistance: 10,
                excludeFamilies: ["vfx"],
              })
              .forEach((target) => {
                const victim = target;
                const tamed = victim.getComponent(EntityComponentTypes.IsTamed);
                if (
                  !tamed &&
                  victim != player &&
                  victim != sourceEntity &&
                  !ignoreEntity.includes(victim.typeId)
                )
                  victim.setOnFire(10, true);
              });
          }
        });
      break;
    }
    case "px_waa:poison": {
      sourceEntity.dimension
        .getEntities({
          type: "player",
          maxDistance: 10,
          location: sourceEntity.location,
        })
        .forEach((player) => {
          if (sourceEntity.hasTag(player.nameTag)) {
            player.dimension
              .getEntities({
                location: player.location,
                maxDistance: 10,
                excludeFamilies: ["vfx"],
              })
              .forEach((target) => {
                const victim = target;
                const tamed = victim.getComponent(EntityComponentTypes.IsTamed);
                if (
                  !tamed &&
                  victim != player &&
                  victim != sourceEntity &&
                  !ignoreEntity.includes(victim.typeId)
                )
                  victim.addEffect("poison", 20 * 10, { amplifier: 1 });
              });
          }
        });
      break;
    }
    case "px_waa:thunder_attack_area": {
      sourceEntity.dimension
        .getEntities({
          type: "player",
          maxDistance: 10,
          location: sourceEntity.location,
        })
        .forEach((player) => {
          if (sourceEntity.hasTag(player.nameTag)) {
            player.dimension
              .getEntities({
                location: player.location,
                maxDistance: 10,
                excludeFamilies: ["vfx"],
              })
              .forEach((target) => {
                const victim = target;
                const tamed = victim.getComponent(EntityComponentTypes.IsTamed);
                if (
                  !tamed &&
                  victim != player &&
                  victim != sourceEntity &&
                  !ignoreEntity.includes(victim.typeId)
                )
                  victim.dimension.spawnEntity(
                    "minecraft:lightning_bolt",
                    victim.location
                  );
              });
          }
        });
      break;
    }
    case "px_waa:slowness": {
      sourceEntity.dimension
        .getEntities({
          type: "player",
          maxDistance: 10,
          location: sourceEntity.location,
        })
        .forEach((player) => {
          if (sourceEntity.hasTag(player.nameTag)) {
            player.dimension
              .getEntities({
                location: player.location,
                maxDistance: 10,
                excludeFamilies: ["vfx"],
              })
              .forEach((target) => {
                const victim = target;
                const tamed = victim.getComponent(EntityComponentTypes.IsTamed);
                if (
                  !tamed &&
                  victim != player &&
                  victim != sourceEntity &&
                  !ignoreEntity.includes(victim.typeId)
                )
                  victim.addEffect("slowness", 20 * 5, {
                    amplifier: 10,
                    showParticles: false,
                  });
              });
          }
        });
      break;
    }
    case "px_waa:teleport_owner": {
      if (sourceEntity) {
        sourceEntity.dimension
          .getEntities({
            families: ["player"],
            maxDistance: 20,
            location: sourceEntity.location,
          })
          .forEach((owner) => {
            if (sourceEntity.hasTag(owner.nameTag)) {
              sourceEntity.teleport(owner.location),
                sourceEntity.setRotation(owner.getRotation());
            }
          });
      }
      break;
    }
    case "px_waa:reset": {
      delete DATA_PLAYER_ABILITY_ARMOR[`${sourceEntity.nameTag}_thunder`];
      break;
    }
    case "px_waa:break_block": {
      const mobs = sourceEntity.dimension.getEntities({
        location: sourceEntity.location,
        maxDistance: 2,
        type: "minecraft:player",
      });
      if (mobs.length == 0) {
        sourceEntity.runCommand("fill ~ ~ ~ ~ ~ ~ air replace light_block_13");
        sourceEntity.remove();
      }
      break;
    }
    case "px_waa:return_camera": {
      sourceEntity.dimension
        .getEntities({
          type: "player",
          maxDistance: 10,
          location: sourceEntity.location,
        })
        .forEach((player) => {
          if (sourceEntity.hasTag(player.nameTag)) {
            player.camera.clear();
          }
        });
      break;
    }
  }
});

world.afterEvents.dataDrivenEntityTrigger.subscribe((event) => {
  const { entity, eventId } = event;
  if (event.eventId === "px_waa:is_owner") {
  /** @type {EntityProjectileComponent} */
  const proj = entity.getComponent(EntityComponentTypes.Projectile);

 
  if (!proj) return;


  const owner = proj.owner;
  if (!owner || !owner.isValid()) {
 
    entity.remove();
    return;
  }

 

  const now = system.currentTick;
  const startTick = entity.getDynamicProperty("px_waa:returnStartTick");

  if (typeof startTick !== "number") {
    entity.setDynamicProperty("px_waa:returnStartTick", now);
  } else if (now - startTick > 100) {
    // força devolver
    const spawnItem = owner.dimension.spawnItem(
      new ItemStack("px_waa:hammer_thunder", 1),
      owner.location
    );
    if (spawnItem?.isValid()) entity.remove();
    else entity.remove(); 
    return;
  }

  const entityPos = entity.location;
  const ownerPos = owner.location;

  const dx = ownerPos.x - entityPos.x;
  const dy = ownerPos.y - entityPos.y;
  const dz = ownerPos.z - entityPos.z;


  const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);


  if (distance <= 2) {
    const spawnItem = owner.dimension.spawnItem(
      new ItemStack("px_waa:hammer_thunder", 1),
      owner.location
    );
    if (spawnItem?.isValid()) entity.remove();
    return;
  }


  if (!isFinite(distance) || distance < 0.001) {
    const spawnItem = owner.dimension.spawnItem(
      new ItemStack("px_waa:hammer_thunder", 1),
      owner.location
    );
    if (spawnItem?.isValid()) entity.remove();
    return;
  }

  const step = Math.min(3.5, distance);

  const dirX = (dx / distance) * step;
  const dirY = (dy / distance) * step;
  const dirZ = (dz / distance) * step;

  entity.teleport({
    x: entityPos.x + dirX,
    y: entityPos.y + dirY + 0.5,
    z: entityPos.z + dirZ,
  });
}



  if (event.eventId == "px_waa:is_owner_chalicar") {
    const tamed = entity.getComponent(EntityComponentTypes.Projectile);
    if (tamed && tamed.owner && tamed.owner.isValid()) {
      const owner = tamed.owner;

      const now = system.currentTick;
      const startTick = entity.getDynamicProperty("px_waa:returnStartTick_chalicar");
      if (typeof startTick !== "number") {
        entity.setDynamicProperty("px_waa:returnStartTick_chalicar", now);
      } else if (now - startTick > 100) {
        let spawnItem = owner.dimension.spawnItem(
          new ItemStack("px_waa:chalicarwither", 1),
          owner.location
        );
        if (spawnItem?.isValid()) entity.remove();
      } else {
        const entityPosition = entity.location;
        const ownerPosition = owner.location;

        const dx = ownerPosition.x - entityPosition.x;
        const dy = ownerPosition.y - entityPosition.y;
        const dz = ownerPosition.z - entityPosition.z;

        const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (isFinite(distance) && distance > 0.001) {
          const step = Math.min(3.5, distance);

          const directionX = (dx / distance) * step;
          const directionY = (dy / distance) * step;
          const directionZ = (dz / distance) * step;

          entity.teleport({
            x: entityPosition.x + directionX,
            y: entityPosition.y + directionY + 0.5,
            z: entityPosition.z + directionZ,
          });

          entity.dimension
            .getEntities({
              name: tamed.owner.nameTag,
              maxDistance: 2,
              location: entity.location,
            })
            .forEach((rpaz) => {
              if (rpaz) {
                let spawnItem = owner.dimension.spawnItem(
                  new ItemStack("px_waa:chalicarwither", 1),
                  owner.location
                );
                if (spawnItem?.isValid()) entity.remove();
              }
            });
        }
      }
    } else {
      entity.remove();
    }
  }
});
