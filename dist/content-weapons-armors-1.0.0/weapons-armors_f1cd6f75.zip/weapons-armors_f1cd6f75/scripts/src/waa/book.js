import { ItemStack, system, world } from "@minecraft/server";

const pagesAmount = 2
const tempProperties = {}

system.afterEvents.scriptEventReceive.subscribe(event=>{
    const {id,message,sourceType,sourceEntity} = event


    if(message == "inkbook" && sourceEntity.isValid){
        let delay = getTempProperty( sourceEntity.id, 0)
        let page = sourceEntity.getProperty("book:page")

        if(id == "ink_book:dead" && sourceEntity.isValid) {
            sourceEntity.dimension.spawnItem(new ItemStack("px_waa:guidebook_spawn_egg",1),sourceEntity.location)
            sourceEntity.remove()
        } else
        if(delay+25 < system.currentTick && sourceEntity.isValid) {
            setTempProperty( sourceEntity.id, system.currentTick)

            switch(id) {
                case "ink_book:nextpage":
                    if(page < pagesAmount) {
                        system.runTimeout(()=>{
                            sourceEntity.setProperty( "book:page", ++page)
                        }, 19)
                        
                        sourceEntity.playAnimation( "next")
                    }
                break 
                case "ink_book:backpage":
                    if(page > 0) {
                        sourceEntity.playAnimation( "back")
                        sourceEntity.setProperty( "book:page", --page)
                    }
                break
            }
        }
    }
})

function getTempProperty( id, def) {
    tempProperties[id] = (tempProperties[id]??def)

    return tempProperties[id]
}

function setTempProperty( id, def) {
    tempProperties[id] = def
}