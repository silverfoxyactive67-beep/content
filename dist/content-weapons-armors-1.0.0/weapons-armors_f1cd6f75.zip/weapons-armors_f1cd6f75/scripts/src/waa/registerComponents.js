import {
  BlockVolume,
  EntityComponentTypes,
  EntityDamageCause,
  EntityHealthComponent,
  EntityIsTamedComponent,
  EntityProjectileComponent,
  EntityTameableComponent,
  EquipmentSlot,
  GameMode,
  ItemStack,
  MolangVariableMap,
  Player,
  system,
  world,
} from "@minecraft/server";
import { armor } from "./communs";
import { WEAPONS } from "./data";

const ignoreEntity = [
  "px_waa:ice_spike",
  "minecraft:lightning_bolt",
  "minecraft:item",
  "minecraft:ender_crystal",
  "minecraft:tnt",
  "minecraft:command_block_minecart",
  "minecraft:minecart",
  "minecraft:hopper_minecart",
  "minecraft:tnt_minecart",
  "minecraft:chest_minecart",
  "minecraft:chest_boat",
  "minecraft:boat",

  "minecraft:arrow",
  "minecraft:snowball",
  "minecraft:fireball",
  "minecraft:small_fireball",
  "minecraft:dragon_fireball",
  "minecraft:fishing_hook",
  "minecraft:wither_skull_dangerous",
  "minecraft:wither_skull",
  "minecraft:xp_orb",
  "minecraft:xp",
  "minecraft:xp_bottle",
  "minecraft:lingering_potion",
  "minecraft:splash_potion",
  "minecraft:wind_charge_projectile_potion",

  "minecraft:villager_v2",
  "px_waa:guidebook",
];

const DATA_SPEAR_NATURE_ABILITY = {};
const DATA_STEALTH_DAGGER_ABILITY = {};
const DATA_TIME_ITENS_COOLDOWN = {};

function generateParticles(player, particle) {
  const offset = player.getViewDirection();
  let pos = player.getHeadLocation();
  world.se;
  for (let i = 0; i < 10; i++) {
    const newPos = {
      x: pos.x + offset.x * 3,
      y: pos.y + offset.y * 2,
      z: pos.z + offset.z * 3,
    };
    pos = newPos;
    player?.dimension?.spawnParticle(particle, newPos);
  }
}

system.runInterval(() => {
  world.getAllPlayers().forEach((player) => {
    const cooldown = DATA_SPEAR_NATURE_ABILITY[player.nameTag]?.cooldown ?? 0;
    const currentTick =
      DATA_SPEAR_NATURE_ABILITY[player.nameTag]?.currentTick ?? 0;

    const cooldownStealth =
      DATA_STEALTH_DAGGER_ABILITY[`${player.nameTag}_stealth`]?.cooldown ?? 0;
    const currentTickStealth =
      DATA_STEALTH_DAGGER_ABILITY[`${player.nameTag}_stealth`]?.currentTick ??
      0;

    const cooldownTime =
      DATA_TIME_ITENS_COOLDOWN[player.nameTag]?.cooldown ?? 0;
    const currentTickTime =
      DATA_TIME_ITENS_COOLDOWN[player.nameTag]?.currentTick ?? 0;

    if (system.currentTick > cooldown + currentTick) {
      player.runCommand("gamerule randomtickspeed 1");
      delete DATA_SPEAR_NATURE_ABILITY[player.nameTag];
    }
    if (system.currentTick > cooldownStealth + currentTickStealth) {
      if (player.hasTag("stealth_dagger")) {
        player.addEffect("invisibility", 15 * 20, { showParticles: false });
        player.removeTag("stealth_dagger");
        delete DATA_SPEAR_NATURE_ABILITY[`${player.nameTag}_stealth`];
      }
    }
    if (system.currentTick > cooldownTime + currentTickTime) {
      // player.camera.clear();
      delete DATA_TIME_ITENS_COOLDOWN[player.nameTag];
    }
  });
});

world.beforeEvents.worldInitialize.subscribe((init) => {
  const { itemComponentRegistry } = init;
  itemComponentRegistry.registerCustomComponent("px_waa:use_ability", {
    onUse(arg) {
      const { source, itemStack } = arg;
      if (WEAPONS[itemStack.typeId.split(":")[1]]) {
        const { cooldown, animation, vfx } =
          WEAPONS[itemStack.typeId.split(":")[1]];
        if (animation != "") {
          source.playAnimation(animation);
        }
        if (vfx != "") {
          const entity = source.dimension.spawnEntity(vfx, source.location);
          entity.addTag(source.nameTag);
        }
        applyCooldown(source, itemStack, cooldown);

        source.camera.setCamera("minecraft:third_person");
      }
    },
  });
  itemComponentRegistry.registerCustomComponent(
    "px_waa:thunder_spear_ability",
    {
      onUse(arg) {
        const { source, itemStack } = arg;
        source.camera.setCamera("minecraft:third_person");
        source.playAnimation("animation.px_waa.nature_spear_attack");
        source.playSound("nature_spear");
        applyCooldown(source, itemStack, 10);
        const particle =
          itemStack.typeId == "px_waa:fire_spear"
            ? "px_waa:firehit"
            : "px_waa:thunderhit";
        source.dimension
          .getEntities({
            location: source.location,
            maxDistance: 5,
            excludeTypes: ignoreEntity,
          })
          .forEach((entity) => {
            if (entity != source) {
              entity.applyDamage(4, { cause: EntityDamageCause.entityAttack });
              source.dimension.spawnParticle(particle, {
                x: entity.location.x,
                y: entity.location.y + 0.25,
                z: entity.location.z,
              });
              if (itemStack.typeId == "px_waa:fire_spear")
                entity.setOnFire(5, true);
            }
          });
        system.runTimeout(() => {
          source.dimension
            .getEntities({
              location: source.location,
              maxDistance: 5,
              excludeTypes: ignoreEntity,
            })
            .forEach((entity) => {
              if (entity != source) {
                entity.applyDamage(4, {
                  cause: EntityDamageCause.entityAttack,
                });
                source.dimension.spawnParticle(particle, {
                  x: entity.location.x,
                  y: entity.location.y + 0.25,
                  z: entity.location.z,
                });
                if (itemStack.typeId == "px_waa:fire_spear")
                  entity.setOnFire(5, true);
              }
            });
        }, 20);
        system.runTimeout(() => {
          source.dimension
            .getEntities({
              location: source.location,
              maxDistance: 5,
              excludeTypes: ignoreEntity,
            })
            .forEach((entity) => {
              if (entity != source) {
                entity.applyDamage(4, {
                  cause: EntityDamageCause.entityAttack,
                });
                source.dimension.spawnParticle(particle, {
                  x: entity.location.x,
                  y: entity.location.y + 0.25,
                  z: entity.location.z,
                });
                if (itemStack.typeId == "px_waa:fire_spear")
                  entity.setOnFire(5, true);
              }
            });
          source.camera.clear();
        }, 40);
      },
    }
  );
  itemComponentRegistry.registerCustomComponent("px_waa:use_ability_staff", {
    onUse(arg) {
      const { source, itemStack } = arg;
      if (WEAPONS[itemStack.typeId.split(":")[1]]) {
        const { cooldown, animation, projetil } =
          WEAPONS[itemStack.typeId.split(":")[1]];
        if (animation != "") {
          source.playAnimation(animation);
        }
        if (armor(source, "wizzards"))
          source.startItemCooldown(
            `${itemStack.typeId.split(":")[1]}_attack`,
            cooldown * 10
          );
        else
          source.startItemCooldown(
            `${itemStack.typeId.split(":")[1]}_attack`,
            cooldown * 20
          );

        system.runTimeout(() => {
          shootProjectile(source, `px_waa:${projetil}`, {
            power: 2,
            sound: "mob.wither.shoot",
            uncertainty: 0.0,
          });
        }, 0.5 * 20);
      }
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:poison_staff", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.sttafs.attack");
      source.playSound("mob.wither.shoot");
      generateParticles(source, "px_waa:poison_staff_particle");
      const block = source.getBlockFromViewDirection({
        maxDistance: 32,
        includePassableBlocks: true,
      })?.block;
      if (!block) return;
      block.dimension.spawnParticle(
        "px_waa:phanteon_hammer_shockwave",
        block.above(1)?.center()
      );
      block.dimension
        .getEntities({
          location: block.center(),
          maxDistance: 5,
          excludeTypes: ignoreEntity,
        })
        .forEach((entity) => {
          if (entity != source) {
            entity.addEffect("minecraft:poison", 20 * 10);
            entity.applyDamage(10, {
              cause: EntityDamageCause.entityExplosion,
            });
          }
        });

      if (armor(source, "wizzards")) {
        source.startItemCooldown(
          `${itemStack.typeId.split(":")[1]}_attack`,
          3.25 * 10
        );
      } else {
        source.startItemCooldown(
          `${itemStack.typeId.split(":")[1]}_attack`,
          5.25 * 20
        );
      }
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:bow_attack", {
    onUse(arg) {
      const { source, itemStack } = arg;

      const gamemode = source.getGameMode();

      const isInCreative =
        gamemode == GameMode.creative || gamemode == GameMode.spectator;

      if (WEAPONS[itemStack.typeId.split(":")[1]]) {
        const { cooldown, animation, projetil } =
          WEAPONS[itemStack.typeId.split(":")[1]];

        if (!isInCreative) {
          const inventoryComponent = source.getComponent(
            EntityComponentTypes.Inventory
          );

          if (!inventoryComponent) return;

          const hasAmmo = hasItem(source, "minecraft:arrow", 1);

          if (!hasAmmo) {
            source.sendMessage("§cYou don't have arrows to shoot!");
            return;}
        }

        if (animation != "") {
          source.playAnimation(animation);
        }
        if (armor(source, "wizzards"))
          source.startItemCooldown(
            `${itemStack.typeId.split(":")[1]}_attack`,
            cooldown * 10
          );
        else
          source.startItemCooldown(
            `${itemStack.typeId.split(":")[1]}_attack`,
            cooldown * 20
          );

        system.runTimeout(() => {
          shootProjectile(source, `px_waa:${projetil}`, {
            power: 2,
            sound: "bow.hit",
            uncertainty: 0.0,
          });
        }, 0.5 * 20);
      }
      handleItemDurability(source, itemStack);
    },
  });
  itemComponentRegistry.registerCustomComponent(
    "px_waa:break_block_use_durability",
    {
      onMineBlock(arg) {
        handleItemDurability(arg.source, arg.itemStack);
      },
    }
  );
  itemComponentRegistry.registerCustomComponent("px_waa:summon_zombie", {
    onUse(arg) {
      const { source, itemStack } = arg;
      remove_tamed(source, ["px_waa:tamed_zombie"]);
      spawnRandomMinionsPlayer(["px_waa:tamed_zombie"], source, 3);
      source.playAnimation("animation.px_waa.undead_sword_attack");
      source.playSound("undead_sword");
      source.startItemCooldown(
        `${itemStack.typeId.split(":")[1]}_attack`,
        1.5 * 20
      );
      source.camera.setCamera("minecraft:third_person");
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:sun_axe_day", {
    onUse(arg) {
      world.setTimeOfDay(6000);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:night", {
    onUse(arg) {
      world.setTimeOfDay(18000);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:stealth_dagger", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.undead_sword_attack");
      DATA_STEALTH_DAGGER_ABILITY[`${source.nameTag}_stealth`] = {
        cooldown: 1.5 * 20,
        currentTick: system.currentTick,
      };
      source.addTag("stealth_dagger");
      source.camera.setCamera("minecraft:third_person");
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:nature_spear_ability", {
    onUse(arg) {
      arg.source.runCommand("gamerule randomtickspeed 500");
      DATA_SPEAR_NATURE_ABILITY[arg.source.nameTag] = {
        cooldown: 200,
        currentTick: system.currentTick,
      };
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:thunder_hammer", {
    onUse(arg) {
      const { source, itemStack } = arg;
      const equipment = source.getComponent("minecraft:equippable");
      equipment.setEquipment(EquipmentSlot.Mainhand);
      shootProjectile(source, "px_waa:thunder_hammer", {
        power: 2,
        sound: "bow.hit",
        uncertainty: 0.0,
      });
      source.startItemCooldown("hammer_thunder_attack", 5 * 20);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:pale_life", {
    onHitEntity(arg) {
      const { source, itemStack, hitEntity, attackingEntity } = arg;
      attackingEntity.playSound("pale_sickle");
      const attackingEntityHealth = getHealth(attackingEntity);
      attackingEntityHealth.setCurrentValue(
        attackingEntityHealth.currentValue + 4
      );
      generateParticlesBetweenPoints(
        attackingEntity.dimension,
        attackingEntity.location,
        hitEntity.location,
        "minecraft:heart_particle",
        0.5
      );
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:hammer_impact", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.camera.setCamera("minecraft:third_person");
      source.playAnimation("animation.px_waa.sword.heavy_spell1");
      source.dimension
        .getEntities({
          maxDistance: 7,
          location: source.location,
        })
        .forEach((target) => {
          const tamed = getTamed(target);
          if (
            target != source &&
            !ignoreEntity.includes(target.typeId) &&
            !tamed
          ) {
            target.applyDamage(10, {
              cause: EntityDamageCause.entityExplosion,
            });
            if (itemStack.typeId == "px_waa:fire_hammer")
              target.setOnFire(5, true);
            if (itemStack.typeId == "px_waa:thunder_hammer_item")
              target.dimension.spawnEntity(
                "minecraft:lightning_bolt",
                target.location
              );
          }
        });
      source.playSound("pantheon_hammer");
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1 * 20,
        currentTick: system.currentTick,
      };
      applyCooldown(source, itemStack, 5);
      if (itemStack.typeId == "px_waa:pantheonhammer") {
        source.dimension.spawnParticle(
          "px_waa:phanteon_hammer_hit",
          source.location
        );
      } else {
        source.dimension.spawnParticle(
          itemStack.typeId == "px_waa:thunder_hammer_item"
            ? "px_waa:thunder_hammer_particle"
            : "px_waa:fire_hammer_particle",
          {
            x: source.location.x,
            y: source.location.y + 0.25,
            z: source.location.z,
          }
        );
      }

      clearPlayerCamera(source);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:bow_attack_three", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.bow.attack");
      source.playSound("runner_bow");
      applyCooldown(source, itemStack, 2);

      system.runTimeout(() => {
        shootProjectile(source, `px_waa:heavens_arrow2`, {
          power: 2,
          sound: "bow.hit",
          uncertainty: 0.0,
        });
      }, 0.5 * 20);
      system.runTimeout(() => {
        shootProjectile(source, `px_waa:heavens_arrow2`, {
          power: 2,
          sound: "bow.hit",
          uncertainty: 0.0,
        });
      }, 1 * 20);

      system.runTimeout(() => {
        shootProjectile(source, `px_waa:heavens_arrow2`, {
          power: 2,
          sound: "bow.hit",
          uncertainty: 0.0,
        });
      }, 1.5 * 20);

      handleItemDurability(source, itemStack);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:bubble_pirate", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.piratesword");
      source.playSound("pirate_sword");
      source.camera.setCamera("minecraft:third_person");
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1.2 * 20,
        currentTick: system.currentTick,
      };
      applyCooldown(source, itemStack, 8);

      clearPlayerCamera(source);

      source.dimension
        .getEntities({
          maxDistance: 10,
          location: source.location,
        })
        .forEach((target) => {
          const tamed = getTamed(target);
          if (
            target != source &&
            !ignoreEntity.includes(target.typeId) &&
            !tamed &&
            target.typeId != "px_waa:vfx_bubble"
          ) {
            target.dimension.spawnEntity("px_waa:vfx_bubble", target.location);
          }
        });
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:storm_sand", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playSound("air_fan");
      applyCooldown(source, itemStack, 7);
      const direction = source.getViewDirection();
      const forwardLocation = {
        x: source.location.x + direction.x * 1,
        y: source.location.y,
        z: source.location.z + direction.z * 1,
      };
      source.dimension.spawnEntity(
        itemStack.typeId == "px_waa:airfan"
          ? "px_waa:vfx_sand_storm"
          : "px_waa:vfx_fire_storm",
        forwardLocation
      );
    },
  });

  itemComponentRegistry.registerCustomComponent("px_waa:fire_sai", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.camera.setCamera("minecraft:third_person");
      source.playAnimation("animation.px_waa.sword.heavy_spell1");
      source.playSound("fire_sai");
      applyCooldown(source, itemStack, 4);
      fire_impact(source, itemStack.typeId == "px_waa:firesai");

      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1 * 20,
        currentTick: system.currentTick,
      };

      clearPlayerCamera(source);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:chalicar_wither", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.chalicar");
      source.playSound("chalicar_wither");

      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1.6 * 20,
        currentTick: system.currentTick,
      };
      const equipment = source.getComponent("minecraft:equippable");
      equipment.setEquipment(EquipmentSlot.Mainhand);
      shootProjectile(source, "px_waa:chalicar_wither", {
        power: 2,
        sound: "bow.hit",
        uncertainty: 0.0,
      });
      applyCooldown(source, itemStack, 5);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:moonsickle", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.sttafs.attack");
      source.playSound("moon_sickle");
      if (itemStack.typeId == "px_waa:darksickle") {
        generateParticles(source, "px_waa:dark_sickle_particle");
        const block = source.getBlockFromViewDirection({
          maxDistance: 32,
          includePassableBlocks: true,
        })?.block;
        if (!block) return;
        block.dimension.createExplosion(block.center(), 4, {
          breaksBlocks: false,
          causesFire: false,
          allowUnderwater: true,
          source: source,
        });
        block.dimension
          .getEntities({
            location: block.center(),
            maxDistance: 4,
            excludeTypes: ignoreEntity,
          })
          .forEach((entity) => {
            if (entity != source) entity.addEffect("minecraft:wither", 20 * 10);
          });
      }
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1.2 * 20,
        currentTick: system.currentTick,
      };
      if (itemStack.typeId == "px_waa:moonsickle")
        shootProjectile(source, "px_waa:shooting_star", {
          power: 2,
          sound: "bow.hit",
          uncertainty: 0.0,
        });
      applyCooldown(source, itemStack, 5);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:end_tatsu", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.endtatsu");
      source.playSound("end_tatsu");
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1.6 * 20,
        currentTick: system.currentTick,
      };
      source
        .getEntitiesFromViewDirection({ maxDistance: 10 })
        .forEach((target) => {
          const is_tamed = target.entity.getComponent(
            EntityComponentTypes.IsTamed
          );
          const has_tag_equal_nameTag = target.entity.hasTag(source.nameTag);
          if (!is_tamed && target.entity != source && !has_tag_equal_nameTag) {
            target.entity.applyDamage(10, {
              cause: EntityDamageCause.entityAttack,
            });
          }
        });
      const direction = source.getViewDirection();
      source.dimension.spawnParticle("px_waa:end_tatsu_flame", {
        x: source.location.x + direction.x * 2,
        y: source.location.y + direction.y * 2,
        z: source.location.z + direction.z * 4,
      });
      source.dimension.spawnParticle("px_waa:end_tatsu_flame", {
        x: source.location.x + direction.x * 2,
        y: source.location.y + direction.y * 2,
        z: source.location.z + direction.z * 2,
      });
      applyCooldown(source, itemStack, 5);

      clearPlayerCamera(source);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:sand_spike", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.sttafs.attack");
      source.playSound("sand_paladine");
      shootProjectile(source, "px_waa:sand_spike", {
        power: 2,
        sound: "bow.hit",
        uncertainty: 0.0,
      });
      applyCooldown(source, itemStack, 5);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:inventors_glove", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.inventors_glove_ability");
      source.dimension.spawnParticle("px_waa:punch_ground", source.location);
      source.dimension.spawnParticle(
        itemStack.typeId == "px_waa:fire_glove"
          ? "px_waa:fire_hammer_particle"
          : itemStack.typeId == "px_waa:dark_glove"
          ? "px_waa:dark_glove_particle"
          : "px_waa:dust_particle",
        {
          x: source.location.x,
          y: source.location.y + 0.25,
          z: source.location.z,
        }
      );
      source.dimension.spawnParticle("px_waa:punch_smear", source.location);
      source.dimension
        .getEntities({
          maxDistance: 7,
          location: source.location,
        })
        .forEach((target) => {
          const tamed = getTamed(target);
          if (
            target != source &&
            !ignoreEntity.includes(target.typeId) &&
            !tamed
          ) {
            target.applyKnockback(0.1, 0.1, 0, 1);
            target.applyDamage(4, { cause: EntityDamageCause.entityExplosion });
            if (itemStack.typeId == "px_waa:fire_glove")
              target.setOnFire(5, true);
            if (itemStack.typeId == "px_waa:dark_glove")
              target.addEffect("minecraft:wither", 20 * 10);
          }
        });
      source.camera.setCamera("minecraft:third_person");
      source.playSound("pantheon_hammer");
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1.2 * 20,
        currentTick: system.currentTick,
      };

      applyCooldown(source, itemStack, 5);

      clearPlayerCamera(source);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:mace_jade", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.inventors_glove_ability");
      source.playAnimation("animation.water_sword.tsunami");
      source.playSound("pirate_sword");
      const entity = source.dimension.spawnEntity(
        "px_waa:vfx_tsunami",
        source.location
      );
      entity.addTag(`_tsunami_${source.nameTag}`);
      entity.setRotation(source.getRotation());
      entity.setDynamicProperty("viewDirection", source.getViewDirection());
      source.camera.setCamera("minecraft:third_person");
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1 * 20,
        currentTick: system.currentTick,
      };
      applyCooldown(source, itemStack, 5);

      clearPlayerCamera(source);
    },
  });
  itemComponentRegistry.registerCustomComponent("px_waa:katana_samurai", {
    onUse(arg) {
      const { source, itemStack } = arg;
      source.playAnimation("animation.px_waa.katana_samurai_ability");
      source.playSound("pirate_sword_simples");
      const viewDirection = source.getViewDirection();
      source.dimension.spawnParticle(
        itemStack.typeId == "px_waa:katana_samurai"
          ? "px_waa:dash_slash"
          : "px_waa:thunder_katana",
        source.location
      );
      const entities = source.getEntitiesFromViewDirection({ maxDistance: 5 });
      source.applyKnockback(2 * viewDirection.x, 2 * viewDirection.z, 5, 0.1);
      system.runTimeout(() => {
        entities.forEach((entity) => {
          entity.entity.applyDamage(8);
          if (itemStack.typeId == "px_waa:thunder_katana")
            source.dimension.spawnEntity(
              "minecraft:lightning_bolt",
              entity.entity.location
            );
        });
      }, 20 * 0.25);
      source.camera.setCamera("minecraft:third_person");
      DATA_TIME_ITENS_COOLDOWN[source.nameTag] = {
        cooldown: 1 * 20,
        currentTick: system.currentTick,
      };
      applyCooldown(source, itemStack, 5);

      clearPlayerCamera(source);
    },
  });
});

world.beforeEvents.playerBreakBlock.subscribe((event) => {
  const { block, cancel, dimension, player, itemStack } = event;
  const locationBlock = block.location;
  const mainhandItem = checkMainhand(player);
  if (mainhandItem.typeId == "px_waa:forest_axe") {
    if (
      block.getItemStack().typeId.includes("log") ||
      block.getItemStack().typeId.includes("stem")
    ) {
      const volume = new BlockVolume(
        { x: locationBlock.x - 3, y: locationBlock.y, z: locationBlock.z - 3 },
        {
          x: locationBlock.x + 3,
          y: locationBlock.y + 32,
          z: locationBlock.z + 3,
        }
      );
      const blocks = dimension
        .getBlocks(volume, {
          includeTags: ["log", "wood"],
          includeTypes: ["minecraft:crimson_stem", "minecraft:warped_stem"],
        })
        .getBlockLocationIterator();
      system.run(() => {
        for (const pos of blocks) {
          dimension.runCommand(
            `setblock ${pos.x} ${pos.y} ${pos.z} air destroy`
          );
        }
      });
    }
  }
  if (mainhandItem.typeId == "px_waa:strong_axe") {
    const blockVolume = new BlockVolume(
      {
        x: locationBlock.x - 1,
        y: locationBlock.y - 1,
        z: locationBlock.z - 1,
      },
      { x: locationBlock.x + 1, y: locationBlock.y + 1, z: locationBlock.z + 1 }
    );
    const blocks = dimension.getBlocks(blockVolume, {
      excludeTypes: ["minecraft:bedrock", "minecraft:water", "minecraft:lava"],
      excludeTags: ["bedrock_awakening:disable_vein_miner"],
    });
    system.run(() => {
      for (const pos of blocks.getBlockLocationIterator()) {
        dimension.runCommand(`setblock ${pos.x} ${pos.y} ${pos.z} air destroy`);
      }
    });
  }
});

function applyCooldown(source, itemStack, cooldown) {
  if (armor(source, "wizzards") || armor(source, "overpower"))
    source.startItemCooldown(
      `${itemStack.typeId.split(":")[1]}_attack`,
      cooldown * 10
    );
  else
    source.startItemCooldown(
      `${itemStack.typeId.split(":")[1]}_attack`,
      cooldown * 20
    );
}

function fire_impact(source, fire = true) {
  let { location } = source;
  let { x, y, z } = location;

  for (var r = 1; r < 10; r++) {
    mkCircle(r).forEach((e) => {
      const ex = e[0];
      const ez = e[1];

      system.runTimeout(() => {
        const nl = {
          x: ex + x,
          y: y + Math.abs(Math.random() * 2.0),
          z: ez + z,
        };
        source.dimension.spawnParticle(
          fire ? "minecraft:lava_particle" : "px_waa:thunder_blow",
          nl
        );
        source.dimension.getEntitiesAtBlockLocation(nl).forEach((e) => {
          const is_tamed = e.getComponent(EntityComponentTypes.IsTamed);
          const has_tag_equal_nameTag = e.hasTag(source.nameTag);
          if (!is_tamed && e != source && !has_tag_equal_nameTag) {
            if (fire) e.setOnFire(5, true);
            e.applyDamage(8, { cause: EntityDamageCause.entityAttack });
          }
        });
      }, r);
    });
  }
}

function mkCircle(r) {
  let N = 2 * r + 1;
  let x, y;
  let out = [];

  for (let i = 0; i < N; i++) {
    for (let j = 0; j < N; j++) {
      x = i - r;
      y = j - r;

      if (x * x + y * y <= r * r + 1) out.push([x, y]);
    }
  }

  return out;
}

function getTamed(source) {
  /** @type {EntityIsTamedComponent} */
  return source.getComponent(EntityComponentTypes.IsTamed);
}

/**
 * Gera partículas entre dois pontos.
 * @param {Dimension} dimension - A dimensão onde as partículas serão geradas.
 * @param {Object} start - O ponto inicial {x, y, z}.
 * @param {Object} end - O ponto final {x, y, z}.
 * @param {string} particleId - O ID da partícula a ser gerada.
 * @param {number} step - A distância entre cada partícula.
 */
function generateParticlesBetweenPoints(
  dimension,
  start,
  end,
  particleId,
  step = 1
) {
  const distance = Math.sqrt(
    Math.pow(end.x - start.x, 2) +
      Math.pow(end.y - start.y, 2) +
      Math.pow(end.z - start.z, 2)
  );

  const steps = Math.ceil(distance / step);

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = start.x + t * (end.x - start.x);
    const y = start.y + t * (end.y - start.y) + 1;
    const z = start.z + t * (end.z - start.z);

    dimension.spawnParticle(particleId, { x, y, z });
  }
}

function getHealth(source) {
  /**@type {EntityHealthComponent} */
  const health = source.getComponent("minecraft:health");
  return health;
}

/**
 *
 * @param {Player} source
 * @returns {ItemStack}
 */
function checkMainhand(source) {
  return (
    source
      .getComponent(EntityComponentTypes.Equippable)
      ?.getEquipment(EquipmentSlot.Mainhand) ??
    new ItemStack("minecraft:stick", 1)
  );
}

function remove_tamed(source, mobs) {
  mobs.forEach((mob) => {
    source.dimension
      .getEntities({
        location: source.location,
        maxDistance: 40,
      })
      .forEach((target) => {
        let is_tamed = target.getComponent(EntityComponentTypes.IsTamed);
        if (is_tamed && target.typeId == `${mob}`) {
          target.remove();
        }
      });
  });
}

function spawnRandomMinionsPlayer(typeID, source, cont) {
  const dimension = source.dimension;
  for (let index = 0; index < cont; index++) {
    let offsetX = Math.floor(Math.random() * 10) - 5;
    let offsetZ = Math.floor(Math.random() * 10) - 5;
    let newLocation = {
      x: source.location.x + offsetX,
      y: source.location.y,
      z: source.location.z + offsetZ,
    };
    spawnEntityWithCheck2(typeID[0], newLocation, dimension, source);
  }
}

function spawnEntityWithCheck2(typeId, position, dimension, source) {
  if (isPassableBlock(position, dimension)) {
    summon(dimension, typeId, position, source);
  } else {
    position.y += 1;
    if (isPassableBlock(position, dimension)) {
      summon(dimension, typeId, position, source);
    } else {
      return false;
    }
  }
  return true;
}

function summon(dimension, typeId, position, source) {
  const entity = dimension.spawnEntity(typeId, position);
  entity.nameTag = "§2Ally Zombie§r";
  /** @type {EntityTameableComponent} */
  const dome = entity.getComponent(EntityComponentTypes.Tameable);
  dome.tame(source);
}

function isPassableBlock(position, dimension) {
  const block = dimension.getBlock(position);
  return block && block.typeId === "minecraft:air";
}

function handleItemDurability(player, itemStack) {
  const equipment = player.getComponent("minecraft:equippable");

  const durability = itemStack.getComponent("minecraft:durability");

  const currentDurability = durability.damage;

  const maxDurability = durability.maxDurability;

  const newItem = itemStack.clone();

  if (currentDurability < maxDurability) {
    newItem.getComponent("minecraft:durability").damage = Math.min(
      maxDurability,
      currentDurability + 1
    );

    equipment.setEquipment(EquipmentSlot.Mainhand, newItem);
  } else {
    player.playSound("random.break");
    equipment.setEquipment(EquipmentSlot.Mainhand);
  }
}

/**
 *
 * @param {Player} player
 * @param {*} projectileId
 * @param {*} options
 */
function shootProjectile(player, projectileId, options) {
  const location = player.location;
  const direction = player.getViewDirection();
  const rotation = player.getRotation();
  const { power, sound, uncertainty } = options;

  const projectile = player.dimension.spawnEntity(projectileId, {
    x: location.x,
    y: location.y + 1.4,
    z: location.z,
  });

  projectile.setProperty("px_waa:rotation_x", rotation.x);
  projectile.setProperty("px_waa:rotation_y", rotation.y);
  projectile.setRotation({ x: rotation.x, y: rotation.y });
  /**@type {EntityProjectileComponent} */
  const shootable = projectile.getComponent("minecraft:projectile");
  const velocity = {
    x: direction.x * power,
    y: direction.y * power,
    z: direction.z * power,
  };

  if (shootable) {
    shootable.owner = player;
    shootable.gravity = 0.0;

    player.playSound(sound, location);
    //shootable.shoot(velocity, { uncertainty });
    // projectile.clearVelocity();
    projectile.setDynamicProperty("speed", {
      x: direction.x * power,
      y: direction.y * power,
      z: direction.z * power,
    });

    projectile.applyImpulse({
      x: direction.x * power,
      y: direction.y * power,
      z: direction.z * power,
    });
  }
}

/**
 *
 * @param {Player} player
 */
function clearPlayerCamera(player) {
  if (!DATA_TIME_ITENS_COOLDOWN[player.nameTag]) return;

  const clearCameraTimer = DATA_TIME_ITENS_COOLDOWN[player.nameTag].cooldown;

  system.runTimeout(() => {
    player.camera.clear();
  }, clearCameraTimer);
}

export function hasItem(player, itemID, amount = 1) {
  const inventoryComponent = player.getComponent(
    EntityComponentTypes.Inventory
  );
  if (!inventoryComponent) return false;
  const container = inventoryComponent.container;
  if (!container) return false;
  for (let i = 0; i < container.size; i++) {
    const slot = container.getSlot(i);
    if (slot.hasItem() && slot.typeId === itemID) {
      amount -= slot.amount;
    }
    if (amount <= 0) return true;
  }
  return false;
}
