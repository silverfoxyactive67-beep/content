export const WEAPONS = {
    fire_sword: {
        damage: 12,
        animation: 'animation.px_waa.fire_sword_attack',
        vfx: 'px_waa:vfx_fire_sword',
        cooldown:2.75
    },
    water_sword: {
        damage: 12,
        animation: 'animation.px_waa.water_sword_attack',
        vfx: 'px_waa:vfx_water_sword',
        cooldown:2.75
    },
    thunder_sword: {
        damage: 12,
        animation: 'animation.px_waa.thunder_sword_attack',
        vfx: 'px_waa:vfx_thunder_sword',
        cooldown:2.75
    },
    double_sword: {
        damage: 12,
        animation: 'animation.px_waa.double_sword_attack',
        vfx: 'px_waa:vfx_double_sword',
        cooldown:2.75
    },
    poison_sword: {
        damage: 12,
        animation: 'animation.px_waa.poison_sword_attack',
        vfx: 'px_waa:vfx_poison_sword',
        cooldown:2.75
    },
    giant_sword: {
        damage: 12,
        animation: 'animation.px_waa.giant_sword_attack',
        vfx: 'px_waa:vfx_giant_sword',
        cooldown:2.75
    },
    nature_spear: {
        damage: 12,
        animation: 'animation.px_waa.nature_spear_attack',
        vfx: 'px_waa:vfx_nature_spear',
        cooldown:10
    },
    night_spear: {
        damage: 12,
        animation: 'animation.px_waa.night_spear_attack',
        vfx: 'px_waa:vfx_night_spear',
        cooldown:2.5
    },
    sun_axe: {
        damage: 12,
        animation: 'animation.px_waa.sun_axe_attack',
        vfx: 'px_waa:vfx_sun_axe',
        cooldown:2
    },
    strong_axe: {
        damage: 12,
        animation: 'animation.px_waa.strong_axe_attack',
        vfx: 'px_waa:vfx_strong_axe',
        cooldown:1
    },
    stealth_dagger: {
        damage:0,
        animation: "",
        vfx: 'px_waa:vfx_stealth_dagger',
        cooldown: 1.5,
    },
    undead_sword: {
        damage:0,
        animation: "",
        vfx: 'px_waa:vfx_undead_sword',
        cooldown: 1.5,
    },
    fire_staff: {
        damage: 0,
        animation: 'animation.px_waa.sttafs.attack',
        vfx: '',
        cooldown: 4.25,
        projetil: 'fire_ball'
    },
    ice_staff: {
        damage: 0,
        animation: 'animation.px_waa.sttafs.attack',
        vfx: '',
        cooldown: 4.25,
        projetil: 'ice_ball'
    },
    thunder_staff: {
        damage: 0,
        animation: 'animation.px_waa.sttafs.attack',
        vfx: '',
        cooldown: 4.25,
        projetil: 'thunder_ball'
    },
    heavens_bow: {
        damage: 0,
        animation: 'animation.px_waa.bow.attack',
        vfx: '',
        cooldown: 1,
        projetil: 'heavens_arrow'
    },
    nether_bow: {
        damage: 0,
        animation: 'animation.px_waa.bow.attack',
        vfx: '',
        cooldown: 1,
        projetil: 'nether_arrow'
    },
    thunder_bow: {
        damage: 0,
        animation: 'animation.px_waa.bow.attack',
        vfx: '',
        cooldown: 1,
        projetil: 'thunder_arrow'
    }
}

export const EFFECT = ['slowness','poison']