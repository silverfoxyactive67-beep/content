import {Player, ItemStack, EntityComponentTypes, EquipmentSlot} from '@minecraft/server'
/**
 * 
 * @param {Player} source 
 * @returns {ItemStack}
 */
export function armor(source,material) {
    const helmet = source.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Head) ?? new ItemStack( "minecraft:stick", 1)
    const chestplate = source.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Chest) ?? new ItemStack( "minecraft:stick", 1)
    const leggings = source.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Legs) ?? new ItemStack( "minecraft:stick", 1)
    const boots = source.getComponent(EntityComponentTypes.Equippable)?.getEquipment(EquipmentSlot.Feet) ?? new ItemStack( "minecraft:stick", 1)
    if (helmet.typeId.includes(material) && chestplate.typeId.includes(material) && leggings.typeId.includes(material) && boots.typeId.includes(material)) return true
    else return false
}